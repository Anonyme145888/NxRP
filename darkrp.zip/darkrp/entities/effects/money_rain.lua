local emitter = ParticleEmitter(vector_origin)

function EFFECT:Init(data)
    self.Player = data:GetEntity()
    if not self.Player:IsValid() then return end
    for i = 1, 32 do
        local vOffset = self.Player:GetPos() + vector_up * 72 + VectorRand() * 20
        local particle = emitter:Add("thrusteraddon/money" .. math.random(1, 3), vOffset)
        particle:SetVelocity(-vector_up * math.Rand(0, 70))
        particle:SetDieTime(math.Rand(3, 5))
        particle:SetStartAlpha(255)
        particle:SetEndAlpha(0)
        particle:SetStartSize(5)
        particle:SetEndSize(5)
        particle:SetRoll(math.Rand(-90, 90))
    end
end

function EFFECT:Think()
    return false
end

function EFFECT:Render()
end