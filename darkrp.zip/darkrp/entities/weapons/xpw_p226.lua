AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "P226"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -3, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 12
SWEP.BulletDiameter = 3
SWEP.CaseLength = 19

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 3
SWEP.SlotPos = 0
SWEP.NormalHoldType = "pistol"
SWEP.ReloadHoldType = "pistol"
SWEP.PassiveHoldType = "normal"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/pistols/p226.mdl"
SWEP.WorldModel	= "models/weapons/w_pist_p228.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 12
SWEP.Primary.DefaultClip = 12
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Pistol"

SWEP.FireDelay = 0.16
SWEP.FireSound = Sound("FAS2_P226")
SWEP.Recoil = 0.3

SWEP.HipSpread = 0.018
SWEP.AimSpread = 0.0025
SWEP.VelocitySensitivity = 1.25
SWEP.MaxSpreadInc = 0.03
SWEP.SpreadPerShot = 0.015
SWEP.SpreadCooldown = 0.5
SWEP.Shots = 1
SWEP.Damage = 15
SWEP.DeployTime = 1