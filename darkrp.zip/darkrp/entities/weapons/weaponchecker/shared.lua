--[[
gamemodes/darkrp/entities/weapons/weaponchecker/shared.lua
--]]
AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = DarkRP.getPhrase("weaponchecker")
	SWEP.Slot = 1
	SWEP.SlotPos = 9
	SWEP.DrawAmmo = false
    SWEP.DrawCrosshair = false
    

end

if SERVER then
    util.AddNetworkString("weaponchecker")
end
SWEP.Author = "DarkRP Developers"
SWEP.Instructions = "Left click to weapon check\nRight click to confiscate weapons\nReload to give back the weapons"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = true
SWEP.AdminOnly = true
SWEP.Category = "Blue (Utility)"
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

local RecentlySearchedThreshold = 120
function DarkRP.RecentlySearched(tar)
	tar:SetNWFloat("RecentlySearched", CurTime())
end
function DarkRP.IsRecentlySearched(tar)
	return CurTime() - tar:GetNWFloat("RecentlySearched", -math.huge) <= RecentlySearchedThreshold
end

function SWEP:Initialize()
	self:SetHoldType("normal")
end

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 0, "IsWeaponChecking")
	self:NetworkVar("Float", 0, "StartCheckTime")
	self:NetworkVar("Float", 1, "EndCheckTime")
	self:NetworkVar("Float", 2, "NextSoundTime")
	self:NetworkVar("Int", 0, "TotalWeaponChecks")
end

function SWEP:Deploy()
	return true
end

function SWEP:DrawWorldModel() end

function SWEP:PreDrawViewModel(vm)
	return true
end

function SWEP:FindTarget()
	return self:GetOwner():getEyeSightHitEntity()
end


function SWEP:PrimaryAttack()
	if self:GetIsWeaponChecking() then return end
	self:SetNextPrimaryFire(CurTime() + 0.3)

	local tar = self:FindTarget()
	if not tar then return end

	self:EmitSound("npc/combine_soldier/gear5.wav", 50, 100)
	self:SetNextSoundTime(CurTime() + 0.3)

	if CLIENT or not IsFirstTimePredicted() then return end
    
    ray.PlayerLog("CheckWeapons", "DarkRP", false, self:GetOwner(), true, self:GetOwner(), true, Color(255, 255, 255), " → ", true, tar, false, Color(255, 255, 255), "")

	if self:GetOwner():isCP() then
		DarkRP.RecentlySearched(tar)
	end
    
    nxcity = {}

    nxcity.badweps = table.Copy(defaultnxcity.badweps)

	local inv_legal, inv_illegal, bag_legal, bag_illegal = {}, {}, {}, {}

	for _, wep in pairs(tar:GetWeapons()) do
        local class = wep:GetClass()
       
		if nxcity.badweps[class] then
			table.insert(inv_illegal, class)
		elseif nxcity.badweps[class] ~= nil or tar:getDarkRPVar("HasGunlicense") then
			table.insert(inv_legal, class)
		else
			table.insert(inv_illegal, class)
		end
	
	end

	if tar.darkRPPocket then
		for k, v in pairs(tar.darkRPPocket) do
			local class = v.DT and (v.ClassName == "spawned_shipment" and v.DT.contents and CustomShipments[v.DT.contents].entity or v.ClassName == "spawned_weapon" and v.DT.WeaponID and util.NetworkIDToString(v.DT.WeaponID))

			if not class then continue end

			if nxcity.badweps[class] then
				table.insert(bag_illegal, class)
			elseif nxcity.badweps[class] ~= nil or tar:getDarkRPVar("HasGunlicense") then
				table.insert(bag_legal, class)
			else
				table.insert(bag_illegal, class)
			end
		end
	end
    
	net.Start("weaponchecker")
	ray.WriteList(inv_legal, net.WriteString)
	ray.WriteList(inv_illegal, net.WriteString)
	ray.WriteList(bag_legal, net.WriteString)
	ray.WriteList(bag_illegal, net.WriteString)
	net.WriteColor(tar:getJobTable().color)
	net.WriteString(tar:Name())
	net.Send(self.Owner)
end

if CLIENT then
	local function proc(tbl)
		for k1, v1 in next, tbl do
			for k2, v2 in next, CustomShipments do
				if v2.entity == v1 then
					tbl[k1] = v2.name
					break
				end
			end
		end
	end
	net.Receive("weaponchecker", function()
		local inv_legal = ray.ReadList(net.ReadString)
		local inv_illegal = ray.ReadList(net.ReadString)
		local bag_legal = ray.ReadList(net.ReadString)
		local bag_illegal = ray.ReadList(net.ReadString)
		local color = net.ReadColor()
		local name = net.ReadString()
		
		if #inv_legal > 0 or #inv_illegal > 0 or #bag_legal > 0 or #bag_illegal > 0 then
			chat.AddText(ray.colors.white, "\n" .. DarkRP.getPhrase("wepcheck_report") .. " ", color, name, ray.colors.white, ":")

			if #inv_legal > 0 then
				proc(inv_legal)
				chat.AddText(ray.colors.green, DarkRP.getPhrase("wepcheck_legal"), ray.colors.white, table.concat(inv_legal, ", "))
			end
			if #inv_illegal > 0 then
				proc(inv_illegal)
				chat.AddText(ray.colors.red, DarkRP.getPhrase("wepcheck_illegal"), ray.colors.white, table.concat(inv_illegal, ", "))
			end

			if #bag_legal > 0 or #bag_illegal > 0 then
				if #inv_legal > 0 or #inv_illegal > 0 then
					chat.AddText(ray.colors.white, "\n" .. DarkRP.getPhrase("wepcheck_inbag"))
				else
					chat.AddText(ray.colors.white, DarkRP.getPhrase("wepcheck_inbag"))
				end
				if #bag_legal > 0 then
					proc(bag_legal)
					chat.AddText(ray.colors.green, DarkRP.getPhrase("wepcheck_legal"), ray.colors.white, table.concat(bag_legal, ", "))
				end
				if #bag_illegal > 0 then
					proc(bag_illegal)
					chat.AddText(ray.colors.red, DarkRP.getPhrase("wepcheck_illegal"), ray.colors.white, table.concat(bag_illegal, ", "))
				end
			end
		else
			chat.AddText(color, name, ray.colors.white, DarkRP.getPhrase("wepcheck_noweps"))
		end
	end)
end

function SWEP:SecondaryAttack()
	if self:GetIsWeaponChecking() then return end
	self:SetNextSecondaryFire(CurTime() + 0.3)

	local tar = self:FindTarget()
	if not tar then return end

	self:SetIsWeaponChecking(true)
	self:SetStartCheckTime(CurTime())
	self:SetEndCheckTime(CurTime() + util.SharedRandom("DarkRP_WeaponChecker"..self:EntIndex().."_"..self:GetTotalWeaponChecks(), 5, 10))
	self:SetTotalWeaponChecks(self:GetTotalWeaponChecks() + 1)

	self:SetNextSoundTime(CurTime() + 0.5)

	if CLIENT then
		self.Dots = ""
		self.NextDotsTime = CurTime() + 0.5
	end
end

function SWEP:Reload()
	if CLIENT or CurTime() < (self.NextReloadTime or 0) then return end
	self.NextReloadTime = CurTime() + 1

	local tar = self:FindTarget()
	if not tar then return end

	if not tar.ConfiscatedWeapons then
		DarkRP.notify(self:GetOwner(), 1, 4, DarkRP.getPhrase("no_weapons_confiscated", tar:Nick()))
		return
	else
		local result = {}
		local copy = tar.ConfiscatedWeapons
		tar.ConfiscatedWeapons = nil

		for k, v in pairs(copy) do
			local wep = tar:Give(v[1])

			if not wep:IsValid() then
				wep = tar:GetWeapon(v[1])
			end

			if not wep:IsValid() then
				continue
			end

			tar:RemoveAllAmmo()
			tar:SetAmmo(v[2], v[3], false)
			tar:SetAmmo(v[4], v[5], false)

			wep:SetClip1(v[6])
			wep:SetClip2(v[7])

			table.insert(result, v[1])
		end


		DarkRP.notify(self:GetOwner(), 2, 4, DarkRP.getPhrase("returned_persons_weapons", tar:Nick()))
        ray.PlayerLog("ReturnWeapons", "DarkRP", false, self:GetOwner(), true, self:GetOwner(), true, Color(255, 255, 255), " → ", true, tar, true, Color(255, 255, 255), (" : "..table.concat(result, ", ")))
		table.sort(result)
	end
end

function SWEP:Holster()
	self:SetIsWeaponChecking(false)
	self:SetNextSoundTime(0)
	return true
end

function SWEP:Succeed()
	if not self:GetOwner():IsValid() then return end

	self:SetIsWeaponChecking(false)

	if CLIENT then return end

	local tar = self:FindTarget()
	if not tar then return end

	local result = {}
	local stripped = {}

	for _, wep in pairs(tar:GetWeapons()) do
		if not wep.isinloadout then
			table.insert(result, wep:GetClass())
			table.insert(stripped, {wep:GetClass(), tar:GetAmmoCount(wep:GetPrimaryAmmoType()), wep:GetPrimaryAmmoType(), tar:GetAmmoCount(wep:GetSecondaryAmmoType()), wep:GetSecondaryAmmoType(), wep:Clip1(), wep:Clip2()})
			tar:StripWeapon(wep:GetClass())
		end
	end
	table.sort(result)
	result = table.concat(result, ", ")
    ray.PlayerLog("StripWeapons", "DarkRP", false, self:GetOwner(), true, self:GetOwner(), true, Color(255, 255, 255), " → ", true, tar, true, Color(255, 255, 255), (" : "..result))



	if not tar.ConfiscatedWeapons then
		if next(stripped) ~= nil then tar.ConfiscatedWeapons = stripped end
	else
		for k, v in pairs(stripped) do
			local found = false
			for a, b in pairs(tar.ConfiscatedWeapons) do
				if b[1] == v[1] then
					found = true
					break
				end
			end

			if not found then
				table.insert(tar.ConfiscatedWeapons, v)
			end
		end
	end

	if #stripped == 0 then
		self:GetOwner():ChatPrint(DarkRP.getPhrase("no_illegal_weapons", tar:Nick()))
		self:EmitSound("npc/combine_soldier/gear5.wav", 50, 100)
		self:SetNextSoundTime(CurTime() + 0.3)
	else
		self:EmitSound("ambient/energy/zap1.wav", 50, 100)
		self:GetOwner():ChatPrint(DarkRP.getPhrase("confiscated_these_weapons"))
		if string.len(result) >= 126 then
			local amount = math.ceil(string.len(result) / 126)
			for i = 1, amount, 1 do
				self:GetOwner():ChatPrint(string.sub(result, (i-1) * 126, i * 126 - 1))
			end
		else
			self:GetOwner():ChatPrint(result)
		end
		self:SetNextSoundTime(0)
	end
end

function SWEP:Fail()
	self:SetIsWeaponChecking(false)
	self:SetHoldType("normal")
	self:SetNextSoundTime(0)
end

function SWEP:Think()
	if self:GetIsWeaponChecking() and self:GetEndCheckTime() ~= 0 then
		local tar = self:FindTarget()
		if not tar then
			self:Fail()
		elseif self:GetEndCheckTime() <= CurTime() then
			self:Succeed()
		end
	end
	if self:GetNextSoundTime() ~= 0 and CurTime() >= self:GetNextSoundTime() then
		if self:GetIsWeaponChecking() then
			self:SetNextSoundTime(CurTime() + 0.5)
			self:EmitSound("npc/combine_soldier/gear5.wav", 100, 100)
		else
			self:SetNextSoundTime(0)
			self:EmitSound("npc/combine_soldier/gear5.wav", 50, 100)
		end
	end
	if CLIENT and self.NextDotsTime and CurTime() >= self.NextDotsTime then
		self.NextDotsTime = CurTime() + 0.5
		self.Dots = self.Dots or ""
		local len = string.len(self.Dots)
		local dots = {[0]=".", [1]="..", [2]="...", [3]=""}
		self.Dots = dots[len]
	end
end

function SWEP:DrawHUD()
	if self:GetIsWeaponChecking() and self:GetEndCheckTime() ~= 0 then
		self.Dots = self.Dots or ""
		local w = ScrW()
		local h = ScrH()
		local x,y,width,height = w/2-w/10, h/2, w/5, h/15
		draw.RoundedBox(8, x, y, width, height, Color(10,10,10,120))

		local time = self:GetEndCheckTime() - self:GetStartCheckTime()
		local curtime = CurTime() - self:GetStartCheckTime()
		local status = math.Clamp(curtime/time, 0, 1)
		local BarWidth = status * (width - 16)
		local cornerRadius = math.Min(8, BarWidth/3*2 - BarWidth/3*2%2)
		draw.RoundedBox(cornerRadius, x+8, y+8, BarWidth, height-16, Color(0, 0+(status*255), 255-(status*255), 255))

		draw.SimpleText(DarkRP.getPhrase("checking_weapons")..self.Dots, "Trebuchet24", w/2, y + height/2, Color(255,255,255,255), 1, 1)
	
	end
end

if CLIENT then
	surface.CreateFont("drp_cross", {
		font = "Arial",
		size = 128
	})

	function SWEP:DrawWeaponSelection(x, y, wide, tall, alpha)
		surface.SetFont("drp_hl2weps")
		--surface.SetTextColor(Color(0, 0, 255))	
		surface.SetTextPos(x + wide/2 - surface.GetTextSize("d")/2, y + tall/12)
		surface.DrawText("d")
		surface.SetFont("drp_cross")
		surface.SetTextColor(Color(255, 0, 0, alpha))
		surface.SetTextPos(x + wide/2 - surface.GetTextSize("✕")/2, y + tall/12)
		surface.DrawText("✕")
		
		-- Draw weapon info box
		self:PrintWeaponInfo(x + wide + 20, y + tall * 0.95, alpha)
	end
end

