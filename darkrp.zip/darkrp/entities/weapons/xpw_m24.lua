AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "M24"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -2, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 67
	SWEP.ZoomDebug = SWEP.ZoomAmount
	SWEP.ZoomAdditional = 82
end

SWEP.XPWWeapon = true
SWEP.XPWSniper = true
SWEP.ConeStayAim = 0.016 * 0.02

SWEP.SpeedDec = 30
SWEP.BulletDiameter = 7.6
SWEP.CaseLength = 37

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.ReloadHoldType = "ar2"
SWEP.PassiveHoldType = "passive"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/support/m24.mdl"
SWEP.WorldModel	= "models/weapons/w_snip_scout.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 4
SWEP.Primary.DefaultClip = 4
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "SMG1"

SWEP.FireDelay = 0.8
SWEP.FireSound = Sound("FAS2_M24")
SWEP.Recoil = 0.8

SWEP.HipSpread = 0.72
SWEP.AimSpread = 0.55
SWEP.VelocitySensitivity = 1
SWEP.MaxSpreadInc = 0.07
SWEP.SpreadPerShot = 0.053
SWEP.SpreadCooldown = 0.7
SWEP.Shots = 1
SWEP.Damage = 43
SWEP.DeployTime = 1