--[[
gamemodes/darkrp/entities/weapons/pocket/cl_menu.lua
--]]
local meta = FindMetaTable("Player")
local pocket = {}
local frame
local fr
local reload

--[[---------------------------------------------------------------------------
Stubs
---------------------------------------------------------------------------]]
DarkRP.stub{
    name = "openPocketMenu",
    description = "Open the DarkRP pocket menu.",
    realm = "Client",
    parameters = {
    },
    returns = {
    },
    metatable = DarkRP
}

--[[---------------------------------------------------------------------------
Interface functions
---------------------------------------------------------------------------]]
function meta:getPocketItems()
    if self ~= LocalPlayer() then return nil end

    return pocket
end

function meta:getPocketItemModel(str)
    if self ~= LocalPlayer() then return nil end

    for k, v in pairs(pocket) do
        if k == str then
            return v.model
        end
    end
end
function DarkRP.openPocketMenu(where)
    if IsValid(fr) and fr:IsVisible() then return end

    if LocalPlayer():GetNWBool("MediaPlayerListener") then return end

    if not pocket then pocket = {} return end
    if table.Count(pocket) == 0 then return end

    fr = vgui.Create("DFrame", where)

    fr:SetTitle("")
    fr:SetDraggable(false)
    fr:ShowCloseButton(false)
    fr.btnMaxim:SetVisible(false)
    fr.btnMinim:SetVisible(false)

    fr.Paint = function() return end

    reload()

    concommand.Add("invrem", function()
        if IsValid(fr) then
            fr:Remove()
        end
    end)
end


--[[---------------------------------------------------------------------------
UI
---------------------------------------------------------------------------]]
function reload()
    if not IsValid(fr) or not fr:IsVisible() then return end
    if not pocket or next(pocket) == nil then fr:Close() return end

    local itemCount = table.Count(pocket)

    local function wide()
        if itemCount == 1 then
            return math.Clamp(105, 0, ScrW())
        elseif itemCount == 2 then
            return math.Clamp(105 * 2, 0, ScrW())
        elseif itemCount == 3 then
            return math.Clamp(105 * 3, 0, ScrW())
        elseif itemCount == 4 then
            return math.Clamp(105 * 4, 0, ScrW())
        elseif itemCount == 5 then
            return math.Clamp(105 * 5, 0, ScrW())
        elseif itemCount == 6 then
            return math.Clamp(105 * 6, 0, ScrW())
        elseif itemCount == 7 then
            return math.Clamp(105 * 7, 0, ScrW())
        elseif itemCount == 8 then
            return math.Clamp(105 * 8, 0, ScrW())
        elseif itemCount == 9 then
            return math.Clamp(105 * 9, 0, ScrW())
        elseif itemCount == 10 then
            return math.Clamp(105 * 9, 0, ScrW())
        end
    end

    fr:SetSize(wide(), 130)
    --fr:MoveTo(middle(), ScrH() - fr:GetTall() - 5, 0.2, 0, -1) --i dont want it on every update
    fr:SetPos((ScrW() / 2) - (fr:GetWide() / 2), ScrH() - fr:GetTall() - 5)
    
    fr:SetAlpha(1)
    fr:AlphaTo(255, 0.4, 0)

    fr:MakePopup()
    fr:SetKeyboardInputEnabled(false)

    local i = 0

    local items = {}
    for k, v in pairs(pocket) do
        local item = vgui.Create("NxButton", fr)
        item:SetText("")    
        item:SetPos(3 + i * 103, 25)
        item:SetSize(100, 100)  
        item.Paint = function(self, w, h)
            cmenu_color(self, w, h)

            surface.SetDrawColor(0, 0, 0, 200)
            surface.DrawOutlinedRect(0, 0, w, h)

            draw.SimpleText(k, "cmenu_item", item:GetWide() - 10, 10, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
--            draw.SimpleText(v.ent, "cmenu_small", item:GetWide() / 2, item:GetTall() - 10, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        item.DoClick = function(self)
            net.Start("DarkRP_spawnPocket")
                net.WriteFloat(k)
            net.SendToServer()
            surface.PlaySound("xenpare/ui/click.mp3")
            pocket[k] = nil

            itemCount = itemCount - 1

            if itemCount == 0 then
                fr:Close()
                return
            end

            fn.Map(self.Remove, items)
            items = {}

            local wep = LocalPlayer():GetActiveWeapon()

            wep:SetHoldType("pistol")

            timer.Simple(0.2, function()
                if wep:IsValid() then
                    wep:SetHoldType("normal")
                end
            end)
        end

        local icon = vgui.Create("SpawnIcon", item)
        icon:SetPos(17, 15)
        icon:SetModel(v.model)
        icon:SetSize(64, 64)
        icon:SetTooltip()
        icon:SetDisabled(true)
        icon:SetMouseInputEnabled(false)
        icon.DoClick = function() return end       

        table.insert(items, item)
        i = i + 1
    end
end


function meta:getPocketItemModel(str)
    if self ~= LocalPlayer() then return nil end

    for k, v in pairs(pocket) do
        if k == str then
            return v.model
        end
    end
end
local function retrievePocket()
    pocket = net.ReadTable()
    reload()
end
net.Receive("DarkRP_Pocket", retrievePocket)


