SWEP.Spawnable = true
SWEP.AdminOnly = true

SWEP.ViewModel = Model("models/weapons/c_pistol.mdl")
SWEP.WorldModel = Model("models/grinchfox/rp/police-radar.mdl")
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
	self:SetHoldType("pistol")
end

function SWEP:SecondaryAttack() end

function SWEP:Holster()
	self.tar = nil
	return true
end

function SWEP:Deploy()
	return true
end

function SWEP:FindTarget()
	local curdist, plypos, plyaim, tar = 400, self.Owner:GetPos(), self.Owner:GetAimVector()
	for _, ent in ipairs(ents.FindByClass("prop_vehicle_jeep")) do
		local entpos = ent:GetPos()
		if plypos:DistToSqr(entpos) < 29160000 and entpos:DistToSqr(plypos + plyaim) < entpos:DistToSqr(plypos) and not util.TraceLine{start = plypos + Vector(0, 0, 66), endpos = entpos + Vector(0, 0, 66), mask = CONTENTS_SOLID + CONTENTS_WINDOW}.HitWorld then
			local dist = (plypos - entpos):Cross(plyaim):Length() / plyaim:Length()
			if dist < curdist then
				tar = ent
				curdist = dist
			end
		end
	end
	return tar
end
