include("shared.lua")

SWEP.PrintName		= DarkRP.getPhrase("nx_speedmeter")
SWEP.Category		= "Blue (Utility)"
SWEP.DrawCrosshair	= false
SWEP.DrawAmmo		= false
SWEP.Slot			= 1
SWEP.NoSights		= true

SWEP.CustomViewModel = ClientsideModel("models/grinchfox/rp/police-radar.mdl", RENDERGROUP_OPAQUE)
SWEP.CustomViewModel:SetNoDraw(true)

function SWEP:DrawWorldModel()
	if self.Owner and self.Owner:IsValid() then
		local PosAng
		local attach = self.Owner:LookupAttachment("anim_attachment_rh")
		if attach == 0 then
			PosAng = {Pos = Vector(), Ang = Angle()}
		else
			PosAng = self.Owner:GetAttachment(attach)
		end

		self:SetRenderOrigin(PosAng.Pos + PosAng.Ang:Up() + PosAng.Ang:Forward() * 1.2 + PosAng.Ang:Right() * .3)
		PosAng.Ang:RotateAroundAxis(PosAng.Ang:Up(), -90)
		self:SetRenderAngles(PosAng.Ang)
	end
	self:DrawModel()
end

function SWEP:DrawHUD()
	local offy, offx, space_width = getTotalCancerPosition()

	surface.DrawKeyCap(offx, offy, whereIsMyAttackKey(), 1, 1, DarkRP.getPhrase("speedmeter_instructions"))
end

function SWEP:Think()
	if self.Owner ~= LocalPlayer() then return end

	self.tar = self:FindTarget()
end

hook.Add("PreDrawHalos", "gx_speedmeter", function()
	local wep = LocalPlayer():GetActiveWeapon()
	if wep:IsValid() and wep:GetClass() == "gx_speedmeter" and wep.tar and wep.tar:IsValid() then
		halo.Add({wep.tar}, ray.colors.red, 1, 1, 6, true, true)
	end
end)

function SWEP:PreDrawViewModel(vm, _, ply)
	ply:GetHands():DrawModel()

	local pos, ang = vm:GetBonePosition(39)
	local pos1, pos2, ang1, ang2 = Vector(pos[1], pos[2], pos[3]), Vector(pos[1], pos[2], pos[3]), Angle(ang[1], ang[2], ang[3]), Angle(ang[1], ang[2], ang[3])

	pos1 = pos1 - ang:Up() * 3 --Forward
	pos1 = pos1 + ang:Right() * 2 --Up
	ang1:RotateAroundAxis(ang:Forward(), -90)
	ang1:RotateAroundAxis(ang:Right(), 180)

	self.CustomViewModel:SetPos(pos1)
	self.CustomViewModel:SetAngles(ang1)
	self.CustomViewModel:DrawModel()

	if self.tar and self.tar:IsValid() then
		pos2 = pos2 - ang:Up() * 7.13 --Forward
		pos2 = pos2 - ang:Right() * 2.84 --Up
		ang2:RotateAroundAxis(ang:Forward(), 180)
		ang2:RotateAroundAxis(ang:Up(), 180)
		ang2:RotateAroundAxis(ang:Forward(), 17)

		cam.Start3D2D(pos2, ang2, .1)
		draw.SimpleText(math.Round(self.tar:GetVelocity():Length() * .06858), "TargetID", 0, 0, ray.colors.red, TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER )
		cam.End3D2D()
	end

	return true
end

function SWEP:PrimaryAttack() end
