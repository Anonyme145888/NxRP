AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "Raging Bull"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1.5, -2, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 6
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 12
SWEP.BulletDiameter = 3
SWEP.CaseLength = 19

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 3
SWEP.SlotPos = 0
SWEP.NormalHoldType = "revolver"
SWEP.ReloadHoldType = "revolver"
SWEP.PassiveHoldType = "normal"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/pistols/ragingbull.mdl"
SWEP.WorldModel	= "models/weapons/w_357.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 5
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "357"

SWEP.FireDelay = 0.55
SWEP.FireSound = Sound("FAS2_RAGINGBULL")
SWEP.Recoil = 1.2

SWEP.HipSpread = 0.018
SWEP.AimSpread = 0.0025
SWEP.VelocitySensitivity = 1.25
SWEP.MaxSpreadInc = 0.03
SWEP.SpreadPerShot = 0.015
SWEP.SpreadCooldown = 0.5
SWEP.Shots = 1
SWEP.Damage = 39
SWEP.DeployTime = 1