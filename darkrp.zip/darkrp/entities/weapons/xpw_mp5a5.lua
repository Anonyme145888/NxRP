AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "MP5A5"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -2.3, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 12
SWEP.BulletDiameter = 3
SWEP.CaseLength = 26

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.ReloadHoldType = "ar2"
SWEP.PassiveHoldType = "passive"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 60
SWEP.ViewModel = "models/weapons/view/smgs/mp5a5.mdl"
SWEP.WorldModel	= "models/weapons/w_smg_mp5.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "SMG1"

SWEP.FireDelay = 0.09
SWEP.FireSound = Sound("FAS2_MP5A5")
SWEP.Recoil = 0.45

SWEP.HipSpread = 0.033
SWEP.AimSpread = 0.0013
SWEP.VelocitySensitivity = 1.45
SWEP.MaxSpreadInc = 0.025
SWEP.SpreadPerShot = 0.02
SWEP.SpreadCooldown = 0.32
SWEP.Shots = 1
SWEP.Damage = 14
SWEP.DeployTime = 1