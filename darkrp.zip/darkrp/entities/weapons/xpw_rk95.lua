AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "RK95"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -3, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 25
SWEP.BulletDiameter = 7.6
SWEP.CaseLength = 33

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.ReloadHoldType = "ar2"
SWEP.PassiveHoldType = "passive"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/rifles/rk95.mdl"
SWEP.WorldModel	= "models/weapons/w_rif_galil.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 30
SWEP.Primary.DefaultClip = 30
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "SMG1"

SWEP.FireDelay = 0.11
SWEP.FireSound = Sound("FAS2_RK95")
SWEP.Recoil = 0.5

SWEP.HipSpread = 0.058
SWEP.AimSpread = 0.0025
SWEP.VelocitySensitivity = 1.55
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadPerShot = 0.025
SWEP.SpreadCooldown = 0.6
SWEP.Shots = 1
SWEP.Damage = 17
SWEP.DeployTime = 1