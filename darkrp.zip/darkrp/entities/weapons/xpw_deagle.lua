AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "Deagle"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -3, 0.66)
	SWEP.AimAng = Vector(0, 0, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 12
SWEP.BulletDiameter = 9
SWEP.CaseLength = 24

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 3
SWEP.SlotPos = 0
SWEP.NormalHoldType = "revolver"
SWEP.ReloadHoldType = "revolver"
SWEP.PassiveHoldType = "normal"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/pistols/deagle.mdl"
SWEP.WorldModel	= "models/weapons/w_pist_deagle.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 7
SWEP.Primary.DefaultClip = 7
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Pistol"

SWEP.FireDelay = 0.2
SWEP.FireSound = Sound("FAS2_DEAGLE")
SWEP.Recoil = 1.2

SWEP.HipSpread = 0.038
SWEP.AimSpread = 0.025
SWEP.VelocitySensitivity = 1.25
SWEP.MaxSpreadInc = 0.03
SWEP.SpreadPerShot = 0.045
SWEP.SpreadCooldown = 0.8
SWEP.Shots = 1
SWEP.Damage = 26
SWEP.DeployTime = 1