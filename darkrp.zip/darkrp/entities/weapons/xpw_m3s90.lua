AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "M3S90"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-2, -2, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true
SWEP.XPWShotgun = true

SWEP.SpeedDec = 40
SWEP.BulletDiameter = 7.6
SWEP.CaseLength = 36

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "shotgun"
SWEP.ReloadHoldType = "shotgun"
SWEP.PassiveHoldType = "passive"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 72
SWEP.ViewModel = "models/weapons/view/shotguns/m3s90.mdl"
SWEP.WorldModel	= "models/weapons/w_shot_m3super90.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 8
SWEP.Primary.DefaultClip = 8
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Buckshot"

SWEP.FireDelay = 0.16
SWEP.FireSound = Sound("FAS2_M3S90")
SWEP.Recoil = 1.3

SWEP.HipSpread = 0.38
SWEP.AimSpread = 0.3
SWEP.VelocitySensitivity = 2
SWEP.MaxSpreadInc = 0.4
SWEP.SpreadPerShot = 1.25
SWEP.SpreadCooldown = 1.2
SWEP.Shots = 6
SWEP.Damage = 6.5
SWEP.DeployTime = 1