if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName 	= "Grapling Hook"
SWEP.HoldType	= "physgun"

if CLIENT then
	SWEP.PrintName = "Grappling Hook"
	SWEP.Slot = 0
	SWEP.SlotPos = 7
end

SWEP.Spawnable = true
SWEP.AdminOnly = true
SWEP.Category = "Blue (Utility)"

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.UseHands		= true
SWEP.ViewModel		= "models/weapons/c_physcannon.mdl"
SWEP.WorldModel		= "models/weapons/w_physics.mdl"
SWEP.ViewModelFlip	= false
SWEP.ViewModelFOV = 54

SWEP.Primary.Ammo   = "none"
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= true
SWEP.Primary.Delay = 3
SWEP.Primary.Ammo  = "none"
SWEP.Primary.Cone  = 0.005
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo  = "none"
SWEP.Secondary.Delay = 0.5

--SWEP.Cooldown = 120
SWEP.Cooldown = 45
SWEP.Duration = 4

SWEP.WeaponID = AMMO_PUSH

function SWEP:SetupDataTables()
	self:NetworkVar("Float", 0, "NextUse")
	self:NetworkVar("Bool", 0, "Hooked")
end

function SWEP:Deploy()
	if SERVER then
		self.HookPos = nil
		self.MotorSound = self.MotorSound or CreateSound(self:GetOwner(), "plats/crane/vertical_start.wav")
		self.MotorSound:ChangeVolume(0.3, 0)
		self:SetHooked(false)
	end
	return true
end

function SWEP:PrimaryAttack()
	if CurTime() < self:GetNextUse() then return false end
	if self.HookPos then return end
	if CLIENT then return end

	local trace = self:Trace()
	if not trace then return end

	self.HookPos = trace.HitPos
	self:GetOwner():EmitSound("weapons/flaregun/fire.wav")
	if trace.HitSky or IsValid(trace.Entity) and not util.IsInWorld(self.HookPos) then
		self.HookPos = nil
		self:GetOwner():EmitSound("HL1/ambience/steamburst1.wav")
	else
		self:SetHooked(true)
		self:GetOwner().GrapplingHookFallDamage = CurTime() + self.Duration
		self:GetOwner().NextHang = self:GetOwner().GrapplingHookFallDamage
	end
	self.LastUse = CurTime()
end

function SWEP:SecondaryAttack()
	if SERVER and self.HookPos then
		self:Unhook()
	end
end

function SWEP:Unhook()
	self:GetOwner():EmitSound("plats/crane/vertical_stop.wav")
	if self.MotorSound then
		self.MotorSound:Stop()
	end
	self.HookPos = nil
	self:SetHooked(false)
	self:GetOwner().GrapplingHookFallDamage = CurTime() + 5
	--self:SetNextUse(CurTime() + self.Cooldown * (self:GetOwner().DARKRP_PREMIUM and 0.5 or 1))
	self:SetNextUse(CurTime() + self.Cooldown)
	self:GetOwner().NextHang = CurTime() - 1
end

if SERVER then
	local up_component = Vector(0, 0, 9) -- sv_gravity / 100 * 1.5
	function SWEP:Think()
		if self.HookPos then
			self:GetOwner():SetGroundEntity()

			local vel = self.HookPos - self:GetOwner():GetPos()
			vel:Normalize()
			vel.x = vel.x * 3
			vel.y = vel.y * 3
			vel.z = vel.z * 4
			vel:Add(up_component)

			local zvel = self:GetOwner():GetVelocity().z
			if zvel < 0 then
				vel:Sub(Vector(0, 0, zvel / 100))
			end

			vel:Mul(64 * FrameTime())

			if self:GetOwner().Hanging then
				self:GetOwner():SetMoveType(MOVETYPE_WALK)
				self:GetOwner().Hanging = nil
				self:GetOwner():SetVelocity(-self:GetOwner():GetVelocity() * 2)
			end

			self:GetOwner():SetVelocity(vel)

			if self.MotorSound and not self.MotorSound:IsPlaying() then
				self.MotorSound:Play()
			end

			if CurTime() - self.LastUse > self.Duration then
				self:GetOwner():EmitSound("physics/plastic/plastic_box_break" .. math.random(1, 2) .. ".wav")
				self:Unhook()
			end
		else
			if self.MotorSound and self.MotorSound:IsPlaying() then
				self.MotorSound:Stop()
			end
		end
	end

	hook.Add("GetFallDamage", "GrapplingHook", function(pl)
		if pl.GrapplingHookFallDamage and CurTime() <= pl.GrapplingHookFallDamage then
			pl.GrapplingHookFallDamage = nil
			return 0
		end
	end)
end

function SWEP:Holster()
	if SERVER and self.HookPos then
		self:Unhook()
	end

	return true
end

function SWEP:OnDrop()
	if SERVER and self.HookPos then
		self:Unhook()
	end

	return true
end

local result = {}
local trace = {output = result}
local mins = Vector(1, 1, 1) * -6
local maxs = Vector(1, 1, 1) * 6
local maxdist = 3500
local minfrac = 128 / maxdist
function SWEP:Trace(force)
	trace.start = self:GetOwner():GetShootPos()
	trace.endpos = trace.start + self:GetOwner():GetAimVector() * maxdist
	trace.filter = self:GetOwner()
	trace.mins = mins
	trace.maxs = maxs
	util.TraceHull(trace)

	if not result.Hit then return end
	if result.Fraction < minfrac then return end

	if result.Entity:IsValid() then
		local phys = result.Entity:GetPhysicsObject()
		if phys:IsValid() and phys:IsMoveable() then return end
	end

	local dir = result.HitPos - trace.start
	if not force and math.abs(vector_up:Dot(dir:GetNormalized())) < math.Remap(math.min(dir:Length(), 1500), 0, 1500, 0.75, 0.9) then return end -- abs чтобы ещё можно было стрелять под себя чтобы спускаться вниз без урона

	return result
end

local color_red = Color(255, 0, 0, 255)
local color_green = Color(0, 255, 0, 255)
local color_orange = Color(255, 120, 0, 255)
local color_active = Color(50, 50, 255, 255)

function SWEP:DrawHUD()
	local clr = self:GetHooked() and color_active or CurTime() < self:GetNextUse() and color_red or self:Trace() and color_green or color_orange

	-- dev
	-- local trace = self:Trace(true)
	-- local dir = result.HitPos - self:GetOwner():GetShootPos()
	-- draw.SimpleText(("%.2f"):format(vector_up:Dot(dir:GetNormalized())), "TabLarge", ScrW() / 2, ScrH() / 2 + 35, clr, TEXT_ALIGN_CENTER)
	-- draw.SimpleText(("%d"):format(dir:Length()), "TabLarge", ScrW() / 2, ScrH() / 2 + 65, clr, TEXT_ALIGN_CENTER)
	-- draw.SimpleText(("%.2f"):format(math.Remap(math.min(dir:Length(), 1500), 0, 1500, 0.75, 0.9)), "TabLarge", ScrW() / 2, ScrH() / 2 + 95, clr, TEXT_ALIGN_CENTER)

	if self:GetHooked() then
		draw.SimpleText("SECONDARY ATTACK TO DETACH YOURSELF", "TabLarge", ScrW() / 2, ScrH() / 2 + 25, clr, TEXT_ALIGN_CENTER)
	elseif CurTime() < self:GetNextUse() then
		draw.SimpleText(("CHARGING: %ds"):format(math.ceil(self:GetNextUse() - CurTime())), "TabLarge", ScrW() / 2, ScrH() / 2 + 25, clr, TEXT_ALIGN_CENTER)		
	end

	local x = ScrW() / 2.0
	local y = ScrH() / 2.0

	local outer = 20
	local inner = 10

	surface.SetDrawColor(clr)

	surface.DrawLine(x - outer, y - outer, x - inner, y - inner)
	surface.DrawLine(x + outer, y + outer, x + inner, y + inner)

	surface.DrawLine(x - outer, y + outer, x - inner, y + inner)
	surface.DrawLine(x + outer, y - outer, x + inner, y - inner)
end

hook.Add("PlayerPickupDarkRPWeapon", "weapon_hook", function(pl, ent, weapon)
	if weapon:GetClass() ~= "weapon_hook" then return end
	local nextuse = ent.nextuse
	if not nextuse then return end
	timer.Simple(0, function()
		local weapon = pl:GetWeapon("weapon_hook")
		if not weapon:IsValid() then return end
		weapon:SetNextUse(nextuse)
	end)
end)

hook.Add("onDarkRPWeaponDropped", "weapon_hook", function(pl, ent, weapon)
	if weapon:GetClass() ~= "weapon_hook" then return end
	ent.nextuse = weapon:GetNextUse()
end)