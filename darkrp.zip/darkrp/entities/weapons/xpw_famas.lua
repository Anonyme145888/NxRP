AddCSLuaFile()

if CLIENT then
	SWEP.PrintName = "FAMAS F1"
	SWEP.Category = "XPW Base"
	
	SWEP.AimPos = Vector(-1, -2, 0.66)
	SWEP.AimAng = Vector(0, -0.216, 0)

	SWEP.ZoomAmount = 5
end

SWEP.XPWWeapon = true

SWEP.SpeedDec = 25
SWEP.BulletDiameter = 7.6
SWEP.CaseLength = 33

SWEP.PlayBackRate = 2
SWEP.PlayBackRateSV = 2

SWEP.Slot = 4
SWEP.SlotPos = 0
SWEP.NormalHoldType = "ar2"
SWEP.ReloadHoldType = "ar2"
SWEP.PassiveHoldType = "passive"
SWEP.Base = "xpw_base"

SWEP.Author	= "crester"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.ViewModelFlip = false
SWEP.ViewModelFOV = 64
SWEP.ViewModel = "models/weapons/view/rifles/famas.mdl"
SWEP.WorldModel	= "models/weapons/w_rif_famas.mdl"

SWEP.Spawnable = true
SWEP.AdminSpawnable	= true

SWEP.Primary.ClipSize = 35
SWEP.Primary.DefaultClip = 35
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "SMG1"

SWEP.FireDelay = 0.12
SWEP.FireSound = Sound("FAS2_FAMAS")
SWEP.Recoil = 0.8

SWEP.HipSpread = 0.5
SWEP.AimSpread = 0.5
SWEP.VelocitySensitivity = 1.55
SWEP.MaxSpreadInc = 0.04
SWEP.SpreadPerShot = 0.025
SWEP.SpreadCooldown = 0.8
SWEP.Shots = 1
SWEP.Damage = 16
SWEP.DeployTime = 1