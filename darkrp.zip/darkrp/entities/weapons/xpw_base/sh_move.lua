local playerMeta = FindMetaTable("Player")
local entityMeta = FindMetaTable("Entity")
local vectorMeta = FindMetaTable("Vector")

local GetActiveWeapon = playerMeta.GetActiveWeapon
local GetRunSpeed = playerMeta.GetRunSpeed
local GetWalkSpeed = playerMeta.GetWalkSpeed
local GetCrouchedWalkSpeed = playerMeta.GetCrouchedWalkSpeed
local Crouching = playerMeta.Crouching
local GetDTFloat = entityMeta.GetDTFloat
local velocity = entityMeta.GetVelocity
local length = vectorMeta.Length

local wep
hook.Add("Move", "XPWMove", function(ply, m)
    if Crouching(ply) then
        m:SetMaxSpeed(GetWalkSpeed(ply) * GetCrouchedWalkSpeed(ply))
    else
        wep = GetActiveWeapon(ply)
        
        if IsValid(wep) and wep.XPWWeapon then
            if wep:GetAim() then
                m:SetMaxSpeed(GetWalkSpeed(ply) * 0.75)
            else
                m:SetMaxSpeed(GetRunSpeed(ply) - wep.SpeedDec)
            end
        else
            m:SetMaxSpeed(GetRunSpeed(ply))
        end
    end
end)