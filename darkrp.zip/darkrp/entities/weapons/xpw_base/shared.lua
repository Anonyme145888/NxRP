AddCSLuaFile("cl_crosshair.lua")
AddCSLuaFile("cl_calcview.lua")
AddCSLuaFile("cl_render.lua")

AddCSLuaFile("sh_move.lua")
AddCSLuaFile("sh_sounds.lua")

include("sh_move.lua")
include("sh_sounds.lua")

if SERVER then
	include("sv_distance.lua")
end

if CLIENT then
	include("cl_crosshair.lua")
	include("cl_calcview.lua")
	include("cl_render.lua")

	SWEP.PrintName = "XPW Weapon"
	SWEP.Slot = 1
	SWEP.SlotPos = 9
	SWEP.DrawAmmo = true
	SWEP.DrawCrosshair = true
	SWEP.Category = "XPW Base"

	SWEP.ViewbobEnabled = true
	SWEP.ViewbobIntensity = 1
	SWEP.ReloadViewBobEnabled = true

	SWEP.RVBPitchMod = 1
	SWEP.RVBYawMod = 1
	SWEP.RVBRollMod = 1
end

SWEP.Author	= "crester"
SWEP.Contact = "https://steamcommunity.com/profiles/76561198159772522/"
SWEP.Purpose = ""
SWEP.Instructions = ""

SWEP.XPWWeapon = true
SWEP.XPWSniper = false
SWEP.XPWShotgun = false

SWEP.ViewModelFOV = 64
SWEP.ViewModelFlip = false
SWEP.ViewModel	= ""
SWEP.WorldModel	= ""

SWEP.Spawnable	= false
SWEP.AdminSpawnable	= false

SWEP.Damage = 25
SWEP.Cone = 0
SWEP.AimMobilitySpreadMod = 0.5
SWEP.PenMod = 1
SWEP.PenModMult = 0.5
SWEP.RecModMult = 0.75
SWEP.ClumpSpread = 0.005

SWEP.Primary.ClipSize = -1	
SWEP.Primary.DefaultClip = -1	
SWEP.Primary.Automatic = false	
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize	= -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = true
SWEP.Secondary.Ammo	= "none"

SWEP.AddSpread = 0
SWEP.SpreadWait = 0
SWEP.AddSpreadSpeed = 1

SWEP.DeployTime = 1
SWEP.ReloadWait = 0
SWEP.ReloadSpeed = 1
SWEP.AimWait = 0.35
SWEP.FireDelay = 0.1

SWEP.LerpPassive = 0
SWEP.LerpRun = 0
SWEP.KickBack = 0

SWEP.Shots = 1
SWEP.AmmoPerShot = 1
SWEP.SpeedDec = 25

SWEP.BurstCooldownMul = 0.75
SWEP.BurstSpreadIncMul = 0.5
SWEP.BurstRecoilMul = 0.25

SWEP.SprintingEnabled = true
SWEP.UseHands = true

SWEP.Sound = {
	["aim"] = {
		"weapons/weapon_sightlower.wav", 
		"weapons/weapon_sightlower2.wav"
	},

	["aim_exit"] = {
		"weapons/weapon_sightraise.wav", 
		"weapons/weapon_sightraise2.wav"
	},

	["deploy"] = {
		"weapons/weapon_deploy1.wav",
		"weapons/weapon_deploy2.wav",
		"weapons/weapon_deploy3.wav"
	},

	["holster"] = {
		"weapons/weapon_holster1.wav",
		"weapons/weapon_holster2.wav",
		"weapons/weapon_holster3.wav"
	}
}

SWEP.BadSoundClases = {
	"xpw_m3s90",
	"xpw_m24",
	"xpw_ragingbull",
	"xpw_sks"
}

SWEP.ReloadTypes = {
	["xpw_m3s90"] = function(self) 
		self:ShottyReload() 
	end,

	["xpw_m24"] = function(self) 
		self:M24Reload() 
	end,

	["xpw_ragingbull"] = function(self) 
		self:MagnumReload() 
	end,

	["xpw_sks"] = function(self) 
		self:SKSReload() 
	end
}

local SP = game.SinglePlayer()

-- Retrieve the meta-tables for Player, Entity, and Vector
local playerMeta = FindMetaTable("Player")
local entityMeta = FindMetaTable("Entity")
local vectorMeta = FindMetaTable("Vector")

-- Safely fetch the functions
local velocity = entityMeta.GetVelocity
local length = vectorMeta.Length
local GetAimVector = playerMeta.GetAimVector

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 0, "Passive")
	self:NetworkVar("Bool", 1, "Aim")
	self:NetworkVar("Bool", 2, "Running")
	self:NetworkVar("Bool", 3, "IsReloading")

	self:NetworkVar("Float", 0, "ReloadTimer")
	self:NetworkVar("Float", 1, "StatefulPosLock")
end

function SWEP:Initialize()
	self:SetHoldType(self.NormalHoldType)
	self:CalculateEffectiveRange()
	self:SetAim(false)
end

function SWEP:Deploy()
	self:SendWeaponAnim(ACT_VM_DRAW)
	self:SetAim(false)

	if IsFirstTimePredicted() then
		self.Owner:EmitSound(table.Random(self.Sound["deploy"]), 50, 100)
	end

	local CT = CurTime()
	self:SetNextSecondaryFire(CT + self.DeployTime)
	self:SetNextPrimaryFire(CT + self.DeployTime)
end

function SWEP:Holster()
	if IsFirstTimePredicted() then
		if not IsValid(self.Owner) then
			return
		end

		self.Owner:EmitSound(table.Random(self.Sound["holster"]), 50, 100)
	end

	return true
end

function SWEP:AdjustMouseSensitivity()
	if self.XPWSniper and self:GetAim() then
		return 0.05
	end
	
	if not self.XPWSniper and self:GetAim() then
		return 0.25
	end
end

function SWEP:OnRemove()
	self:Holster()
end

--[[
	Attack
]]

function SWEP:PrimaryAttack()
	if self:GetPassive() or self:GetRunning() then
		return
	end

	if self:GetIsReloading() then
		return
	end

	if self:Clip1() == 0 then
		self:EmitSound("weapons/empty_submachineguns.wav", 100, 100)
		self:SetNextPrimaryFire(CurTime() + 0.25)

		return
	end

	self.Owner:SetAnimation(PLAYER_ATTACK1)

	if self:GetAim() then
		self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	end

	if SP then
		if SERVER then
			self.Owner:GetViewModel():SetPlaybackRate(self.PlayBackRate or 1)
		end
	else
		if SERVER then
			self.Owner:GetViewModel():SetPlaybackRate(self.PlayBackRateSV or 1)
		else
			self.Owner:GetViewModel():SetPlaybackRate(self.PlayBackRate or 1)
		end
	end

	self:EmitSound(self.FireSound, 105, 100)
	self:ShootBullet(self.Damage, self.AmmoPerShot, self.Cone)
	self:MakeRecoil()
		
	local CT = CurTime()
	self.SpreadWait = CT + self.SpreadCooldown

	local mul = 1
	if self.Owner:Crouching() then
		mul = mul * 0.75
	end

	self.AddSpread = math.Clamp(self.AddSpread + self.SpreadPerShot * self.BurstSpreadIncMul * mul, 0, self.MaxSpreadInc)
	self.AddSpreadSpeed = math.Clamp(self.AddSpreadSpeed - 0.2, 0, 1)
		
	if CLIENT then
		if self:GetAim() then
			self.FireMove = 1
		else
			self.FireMove = 0.4
		end
	end

	self:TakePrimaryAmmo(self.AmmoPerShot)
	self:SetNextPrimaryFire(CT + self.FireDelay)
	self:SetNextSecondaryFire(CT + self.FireDelay)

	self.ReloadWait = CT + (self.WaitForReloadAfterFiring and self.WaitForReloadAfterFiring or self.FireDelay)
end

function SWEP:SecondaryAttack()
	if self:GetRunning() or self:GetPassive() then
		return
	end

	if self:GetIsReloading() then
		return
	end

	if self:GetAim() then
		self:SetAim(false)
		self:EmitSound(table.Random(self.Sound["aim_exit"]), 50, 100)
	else
		self:SetAim(true)
		self:EmitSound(table.Random(self.Sound["aim"]), 50, 100)
	end

	local CT = CurTime()
	self:SetNextSecondaryFire(CT + self.AimWait)
end

local ang
function SWEP:MakeRecoil(mod)
	mod = mod and mod or 1
	
	if self.Owner:Crouching() then
		mod = mod * 0.75
	end
	
	if self:GetAim() then
		mod = mod * 0.85
	end
	
	if (SP and SERVER) or (not SP and CLIENT) then
		ang = self.Owner:EyeAngles()
		ang.p = ang.p - self.Recoil * 0.5 * mod
		ang.y = ang.y + math.random(-1, 1) * self.Recoil * 0.5 * mod
	
		self.Owner:SetEyeAngles(ang)
	end
	
	self.Owner:ViewPunch(Angle(-self.Recoil * 1.25 * mod, 0, 0))
end

function SWEP:CalculateSpread(vel)
	local aim = GetAimVector(self.Owner)
	local CT = CurTime()
	
	if not self.Owner.LastView then
		self.Owner.LastView = aim
		self.Owner.ViewAff = 0
	else
		self.Owner.ViewAff = Lerp(0.25, self.Owner.ViewAff, (aim - self.Owner.LastView):Length() * 0.5)
		self.Owner.LastView = aim
	end
	
	if self:GetAim() then
		self.BaseCone = self.AimSpread
	else
		self.BaseCone = self.HipSpread
	end
	
	if self.Owner:Crouching() then
		self.BaseCone = self.BaseCone * (self:GetAim() and 0.9 or 0.75)
	end
	
	self.CurCone = math.Clamp(self.BaseCone + self.AddSpread + (vel / 10000 * self.VelocitySensitivity) * (self:GetAim() and self.AimMobilitySpreadMod or 1) + self.Owner.ViewAff, 0, 0.09 + self.MaxSpreadInc)
	
	if CT > self.SpreadWait then
		self.AddSpread = math.Clamp(self.AddSpread - 0.005 * self.AddSpreadSpeed, 0, self.MaxSpreadInc)
		self.AddSpreadSpeed = math.Clamp(self.AddSpreadSpeed + 0.05, 0, 1)
	end
end

function SWEP:CalculateEffectiveRange()
	self.EffectiveRange = self.CaseLength * 10 - self.BulletDiameter * 5 
	self.EffectiveRange = self.EffectiveRange * 39.37 
	self.EffectiveRange = self.EffectiveRange * 0.25
	
	self.DamageFallOff = (100 - (self.CaseLength - self.BulletDiameter)) / 200
	self.PenStr = (self.BulletDiameter * 0.5 + self.CaseLength * 0.35) * (self.PenAdd and self.PenAdd or 1)
	self.PenetrativeRange = self.EffectiveRange * 0.5
end

function SWEP:ShootBullet(damage, num_bullets, aimcone)
	local bullet = {}

	if self.XPWShotgun then
		for i = 1, self.Shots do 
			bullet.Num = self.Primary.Shots				
			bullet.Src = self.Owner:GetShootPos()			
			bullet.Dir = self.Owner:GetAimVector()			
			bullet.Spread = Vector(math.random(0, 10) / 90, math.random(0, 30) / 90, 0)
			bullet.Tracer = 5			
			bullet.Force = 1				
			bullet.Damage = self.Damage				
			bullet.AmmoType = self.Primary.Ammo	
			
			self.Owner:FireBullets(bullet)
		end
	else
		bullet.Num = self.Primary.Shots				
		bullet.Src = self.Owner:GetShootPos()			
		bullet.Dir = self.Owner:GetAimVector()			
		bullet.Spread = Vector(aimcone, aimcone, 0)
		bullet.Tracer = 5			
		bullet.Force = 1				
		bullet.Damage = self.Damage				
		bullet.AmmoType = self.Primary.Ammo	

		self.Owner:FireBullets(bullet)
	end

	self:ShootEffects()
end

--[[
	Reloading
]]

function SWEP:BaseReload()
	if self:GetIsReloading() then
		return
	end

	if self:GetReloadTimer() > CurTime() then
		return
	end

	self.Owner:SetFOV(0, 0)

	if self.Owner:KeyDown(IN_USE) and not self:GetAim() then
		self:SetPassive(not self:GetPassive())
		self:SetHoldType(self:GetPassive() and self.PassiveHoldType or self.NormalHoldType)

		if IsFirstTimePredicted() then
			if self:GetPassive() then
				self.Owner:EmitSound(table.Random(self.Sound["holster"]), 50, 100)
			else
				self.Owner:EmitSound(table.Random(self.Sound["deploy"]), 50, 100)
			end
		end

		self:SetReloadTimer(CurTime() + 0.3)
		return
	end

	return true
end

function SWEP:Reload()
	local class = self:GetClass()

	if not self:BaseReload() then 
		return 
	end

	if self:GetAim() then
		if self:Clip1() == 0 or self.Owner:GetAmmoCount(self.Primary.Ammo) == 0 then
			return
		end

		if self:Clip1() == self:GetMaxClip1() then
			return
		end

		self:SetAim(false)
	end

	if not self.Owner:KeyDown(IN_USE) then
		if self:GetPassive() then
			return
		end
	end

	if self.Owner:GetAmmoCount(self.Primary.Ammo) == 0 then 
		return
	end

	self:SetHoldType(self.ReloadHoldType)

	if not table.HasValue(self.BadSoundClases, class) then
		if self:GetIsReloading() or self:Clip1() == self:GetMaxClip1() then
			return
		end

		self:SetIsReloading(true)
		self:EmitSound(self.FireSound .. "_MagOut", 105, 100)

		timer.Simple(self:SequenceDuration() + 0.5, function()
			if not IsValid(self) then
				return
			end

			self:EmitSound(self.FireSound .. "_MagIn", 105, 100)
			self:SetIsReloading(false)
		end)
	end

	if self.ReloadTypes[class] then
		self.ReloadTypes[class](self)
	else
		self:DefaultReload(ACT_VM_RELOAD)
	end

	self:SetStatefulPosLock(CurTime() + self.Owner:GetViewModel():SequenceDuration())
	self:SetHoldType(self.NormalHoldType)
end

function SWEP:ShottyReload()
	if self:GetClass() ~= "xpw_m3s90" then
		return
	end

	if self:Clip1() < self:GetMaxClip1() then
		self:SetIsReloading(true)

		self.Owner:SetAnimation(PLAYER_RELOAD)

		local seq = self.Owner:GetViewModel():LookupSequence("reload_start")
		self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)
		
		self:SetReloadTimer(CurTime() + self:SequenceDuration() + 0.2)
		self:SetNextPrimaryFire(CurTime() + self:SequenceDuration() + 0.2)

		return true
	end
	
	return false
end

function SWEP:ShottyReloadThink()
	if self:GetClass() ~= "xpw_m3s90" then
		return
	end

	if not self:GetIsReloading() then 
		return 
	end

	if self:GetReloadTimer() < CurTime() then
		if self:Clip1() >= self:GetMaxClip1() or self.Owner:GetAmmoCount(self.Primary.Ammo) <= 0 then
			local seq = self.Owner:GetViewModel():LookupSequence("reload_abort")
			self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)

			self:SetIsReloading(false)

			self:SetReloadTimer(CurTime() + self:SequenceDuration())
			self:SetNextPrimaryFire(CurTime() + self:SequenceDuration())

			return
		end

		local ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
		local mag = self:Clip1()
		local amt = math.Clamp(math.Clamp(self.Primary.ClipSize - mag, 0, 4), 0, ammo)

		local seq = self.Owner:GetViewModel():LookupSequence("reload_load" .. amt)
		self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)

		if SERVER then
			local need = self:GetMaxClip1() - mag

			if self:Clip1() <= self:GetMaxClip1() - 3 then
				self:SetClip1(self:Clip1() + 3)
				self.Owner:SetAmmo(ammo - 3, self.Primary.Ammo)
			elseif self:Clip1() == 7 then
				self:SetClip1(self:Clip1() + 1)
				self.Owner:SetAmmo(ammo - 1, self.Primary.Ammo)	
			else
				self:SetClip1(self:Clip1() + 2)
				self.Owner:SetAmmo(ammo - 2, self.Primary.Ammo)
			end
		end

		self:EmitSound(self.FireSound .. "_Load", 105, 100)
		self:SetReloadTimer(CurTime() + self:SequenceDuration() + 1)
	end
end

function SWEP:M24Reload()
	if self:GetClass() ~= "xpw_m24" then
		return
	end

	if self:Clip1() < self:GetMaxClip1() then
		self.Owner:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_HL2MP_GESTURE_RELOAD_REVOLVER, true)

		local ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
		local mag = self:Clip1()
		local amt = math.Clamp(math.Clamp(self.Primary.ClipSize - mag, 0, 4), 0, ammo)

		local seq
		if mag == 0 then
			if ammo >= 5 then
				seq = self.Owner:GetViewModel():LookupSequence("reload_empty_nomen")
			else
				seq = self.Owner:GetViewModel():LookupSequence("reload_empty_" .. ammo .. "_nomen")
			end
		else
			if ammo >= 5 - mag then
				seq = self.Owner:GetViewModel():LookupSequence("reload_" .. math.max(1, 5 - mag) .. "")
			else
				seq = self.Owner:GetViewModel():LookupSequence("reload_" .. ammo .. "")
			end
		end
		
		self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)
		self:SetIsReloading(true)

		self:EmitSound(self.FireSound .. "_MagOut", 105, 100)

		timer.Simple(self:SequenceDuration() + 0.5, function()
			if not IsValid(self) then
				return
			end

			self:EmitSound(self.FireSound .. "_MagIn", 105, 100)
		end)

		timer.Create("M24Reload" .. self:EntIndex(), amt, 1, function()
			if not IsValid(self) then
				return
			end

			if SERVER then
				self:SetClip1(mag + amt)
				self.Owner:SetAmmo(ammo - amt, self.Primary.Ammo)
			end

			self:SetIsReloading(false)
		end)

		self:SetReloadTimer(CurTime() + self:SequenceDuration(seq))
		self:SetNextPrimaryFire(CurTime() + self:SequenceDuration(seq))
		self:SetNextSecondaryFire(CurTime() + self:SequenceDuration(seq))

		return true
	end

	return false
end

function SWEP:MagnumReload()
	if self:GetClass() ~= "xpw_ragingbull" then
		return
	end

	if self:Clip1() < self:GetMaxClip1() then
		self.Owner:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_HL2MP_GESTURE_RELOAD_REVOLVER, true)

		local ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
		local mag = self:Clip1()
		local amt = math.Clamp(math.Clamp(self.Primary.ClipSize - mag, 0, 4), 0, ammo)
		
		local seq
		if ammo >= 5 - mag then
			seq = self.Owner:GetViewModel():LookupSequence("Reload" .. 5 - mag .. "_nomen")
			self:SetClip1(5)
			self.Owner:SetAmmo(ammo - amt, self.Primary.Ammo)
		else
			seq = self.Owner:GetViewModel():LookupSequence("Reload" .. ammo .. "_nomen")
		end

		self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)
		self:SetReloadTimer(CurTime() + self:SequenceDuration(seq))
		self:SetNextPrimaryFire(CurTime() + self:SequenceDuration(seq))

		return true
	end

	return false
end

local sks_stages = {
	Reload_10 = "Reload5",
	Reload_10_Nomen = "Reload5_nmc",
	Reload_Empty_10 = "Reload_empty",
	Reload_Empty_10_Nomen = "Reload_empty_nmc",
	Reload_20 = "Reload_20_add",
	Reload_20_Nomen = "Reload_20_add_nmc",
	Reload_Empty_20 = "Reload_20_empty",
	Reload_Empty_20_Nomen = "Reload_20_empty_nmc",
	Reload_30 = "Reload_30",
	Reload_30_Nomen = "Reload_30_nmc",
	Reload_Empty_30 = "Reload_30_empty",
	Reload_Empty_30_Nomen = "Reload_30_empty_nmc"
}

function SWEP:SKSReload()
	if self:GetClass() ~= "xpw_sks" then
		return
	end

	if self:Clip1() < self:GetMaxClip1() then
		self.Owner:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_HL2MP_GESTURE_RELOAD_REVOLVER, true)

		local ammo = self.Owner:GetAmmoCount(self.Primary.Ammo)
		local mag = self:Clip1()
		local amt = math.Clamp(math.Clamp(self.Primary.ClipSize - mag, 0, 4), 0, ammo)
		
		if mag >= self.Primary.ClipSize or (self.Primary.ClipSize < 30 and ammo < 10) or ammo == 0 then
			return false
		end

		self.ReloadAmount = nil

		local seq
		if self.Primary.ClipSize > 0 and self.Primary.ClipSize < 11 then
			if mag > 10 then
				return
			elseif mag < 10 and mag > 0 then
				self.ReloadAmount = 10
				self:SetClip1(10)
				self.Owner:SetAmmo(ammo - amt, self.Primary.Ammo)
			elseif mag >= 0 and mag < 11 then
				seq = self.Owner:GetViewModel():LookupSequence("Reload_empty_nmc")
				self:SetClip1(10)
			    self.Owner:SetAmmo(ammo - mag, self.Primary.Ammo)
			end
		elseif self.Primary.ClipSize == 10 then
			self:SetClip1(0)
		end

		if not seq then
			if mag > 0 then
				seq = self.Owner:GetViewModel():LookupSequence(sks_stages["Reload_" .. self.Primary.ClipSize .. "_Nomen"])
			else
				seq = self.Owner:GetViewModel():LookupSequence(sks_stages["Reload_Empty_" .. self.Primary.ClipSize .. "_Nomen"])
			end
		end
			
		self.Owner:GetViewModel():SendViewModelMatchingSequence(seq)
		self:SetReloadTimer(CurTime() + self:SequenceDuration(seq))
		self:SetNextPrimaryFire(CurTime() + self:SequenceDuration(seq))

		return true
	end

	return false
end

--[[
	Think
]]

function SWEP:Think()
	local vel = length(velocity(self.Owner))
	local IFTP = IsFirstTimePredicted()
	
	if (not SP and IFTP) or SP then
		self:CalculateSpread(vel)
	end

	if self.Owner:OnGround() then
		if CLIENT then
			if self.XPWSniper and self:GetAim() then
				if input.IsKeyDown(KEY_LALT) then
					self.ZoomAmount = self.ZoomAdditional
				else
					self.ZoomAmount = self.ZoomDebug
				end
			end
		end

		if self:GetClass() == "xpw_m3s90" then
			self:ShottyReloadThink()
		end

		if self:GetRunning() and self:GetAim() then
			self:SetAim(false)
			self:SetHoldType(self.PassiveHoldType)
		end

		if ((vel > self.Owner:GetWalkSpeed() * 1.2 and self.Owner:KeyDown(IN_SPEED)) or vel > self.Owner:GetWalkSpeed() * 3 or (self.ForceRunStateVelocity and vel > self.ForceRunStateVelocity)) and self.SprintingEnabled then
			if self:GetRunning() then
				return
			end
			
			self:SetRunning(true)
			self:SetHoldType(self.PassiveHoldType)
		elseif self.Owner:KeyDown(IN_SPEED) then
			if self:GetAim() then
				self:SetAim(false)
			end
		else
			if not self:GetRunning() then
				return
			end

			self:SetRunning(false)
			self:SetHoldType(self.NormalHoldType)
		end
	else
		if self.Owner:WaterLevel() >= 1 or (self.Owner:GetMoveType() == MOVETYPE_LADDER) then
			self:SetRunning(true)
			self:SetHoldType(self.PassiveHoldType)

			if self:GetAim() then
				self:SetAim(false)
			end
		end
	end
end