local reg = debug.getregistry()

local GetVelocity = reg.Entity.GetVelocity
local Length = reg.Vector.Length
local Right = reg.Angle.Right
local Up = reg.Angle.Up
local Forward = reg.Angle.Forward
local RotateAroundAxis = reg.Angle.RotateAroundAxis

function SWEP:GetViewModelPosition(pos, ang)
	return self:VMPos(pos, ang)
end

local nullvec = Vector()
function SWEP:GetVMStatefulPosAng()
	local Pos
	local Ang

	if self:GetPassive() or self:GetRunning() then
		Pos = Vector(0.3, 0.1, -0.5)
		Ang = Vector(-9, 5, -7)

		return Pos, Ang
	end

	return nullvec, nullvec
end

local AccSway = Vector()
local lastEA = Angle()
local dtEA = Angle()
function SWEP:GetVMAffectedPosAng()
	local Pos, Ang = self:GetVMStatefulPosAng()

	local vel = self.Owner:GetVelocity()
	local len = self.Owner:IsOnGround() and vel:Length() or 0
	local move = math.Clamp(len / self.Owner:GetWalkSpeed(), 0, 1)

	local t = RealTime() * (len > 0.2 and 8 or 2)
	local amp = 0

	amp = (0.2 + move * 0.6)
    amp = amp * 0.5
    
	Pos = Pos + Vector(math.cos(t) * 0.5, 0, math.sin(2*t)/2) * amp

	dtEA.p = math.AngleDifference(EyeAngles().p, lastEA.p)
	dtEA.y = math.AngleDifference(EyeAngles().y, lastEA.y)

	local max = 5

	AccSway.x = math.Clamp(AccSway.x + dtEA.p * 0.25, -max, max)
	AccSway.y = math.Clamp(AccSway.y + dtEA.y * 0.25, -max, max)
	
	local velRoll = math.Clamp((vel:DotProduct(EyeAngles():Right()) * 0.04) * move, -5, 5)

	if self:GetAim() then
		Ang = Ang + Vector(self.AimAng.x, self.AimAng.y * 2, velRoll - self.AimAng.y)
		Pos = Pos + Vector(self.AimPos.y * 0.5, 0, self.AimPos.x * 0.5)
	else
		Ang = Ang + Vector(AccSway.x, AccSway.y * 2, velRoll - AccSway.y)
		Pos = Pos + Vector(AccSway.y * 0.5, 0, AccSway.x * 0.5)
	end

	AccSway = LerpVector(math.min(1, FrameTime() * 20), AccSway, nullvec)

	lastEA = EyeAngles()

	return Pos, Ang
end

local CurPos = Vector()
local CurAng = Vector()
function SWEP:VMPos(pos, ang)
	self.BobScale = 0
	self.SwayScale = 0

	ang:RotateAroundAxis(ang:Right(), CurAng.x)
	ang:RotateAroundAxis(ang:Up(), CurAng.y)
	ang:RotateAroundAxis(ang:Forward(), CurAng.z)

	pos:Add(ang:Right() * (CurPos.x))
	pos:Add(ang:Forward() * (CurPos.y))
	pos:Add(ang:Up() * (CurPos.z))

	return pos, ang
end

function SWEP:PreDrawViewModel(vm, wep, pl)
	self.LerpPassive = Lerp(FrameTime() * 10, self.LerpPassive, self:GetPassive() and 1 or 0)
	self.LerpRun = Lerp(FrameTime() * 10, self.LerpRun, self:GetRunning() and 1 or 0)
	self.KickBack = Lerp(FrameTime() * 10, self.KickBack, 0)

	local Pos, Ang = self:GetVMAffectedPosAng()
	CurPos = LerpVector(math.min(1, FrameTime() * 10), CurPos, Pos)
	CurAng = LerpVector(math.min(1, FrameTime() * 10), CurAng, Ang)

	self.fFOV = Lerp(FrameTime() * 5, self.fFOV or self.svFOV or 90, self.svFOV or 90)

	render.SetBlend(1)
end