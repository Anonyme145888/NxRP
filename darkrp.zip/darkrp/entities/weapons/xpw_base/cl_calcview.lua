local ft, ct, cos1, cos2, ws, vel
local angn, curang, curviewbob = Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0)

local reg = debug.getregistry()
local velocity = reg.Entity.GetVelocity
local Length = reg.Vector.Length
local Right = reg.Angle.Right
local Up = reg.Angle.Up
local Forward = reg.Angle.Forward
local RotateAroundAxis = reg.Angle.RotateAroundAxis

SWEP.LerpBackSpeed = 10

function SWEP:CalcView(ply, pos, ang, fov)
	ft, ct = FrameTime(), CurTime()

	if self:GetAim() then
		if self.DelayedZoom then
			if ct > self.AimTime then
				if self.SnapZoom then
					self.CurFOVMod = self.ZoomAmount
				else
					self.CurFOVMod = Lerp(ft * 20, self.CurFOVMod, self.ZoomAmount)
				end
			else
				self.CurFOVMod = Lerp(ft * 20, self.CurFOVMod, 0)
			end
		else
			if self.SnapZoom then
				self.CurFOVMod = self.ZoomAmount
			else
				self.CurFOVMod = Lerp(ft * 20, self.CurFOVMod, self.ZoomAmount)
			end
		end
	else
		self.CurFOVMod = Lerp(ft * 20, self.CurFOVMod, 0)
	end
	
	fov = math.Clamp(fov - self.CurFOVMod, 5, 90)
	
	if self.Owner then
		if self.ViewbobEnabled then
			ws = self.Owner:GetWalkSpeed()
			vel = Length(velocity(self.Owner))
			
			if self.Owner:OnGround() and vel > ws * 0.3 then
				if vel < ws * 1.2 then
					cos1 = math.cos(ct * 15)
					cos2 = math.cos(ct * 12)
					
					curviewbob.p = cos1 * 0.15
					curviewbob.y = cos2 * 0.1
				else
					cos1 = math.cos(ct * 20)
					cos2 = math.cos(ct * 15)

					curviewbob.p = cos1 * 0.25
					curviewbob.y = cos2 * 0.15
				end
			else
				curviewbob = LerpAngle(ft * 10, curviewbob, angn)
			end
		end
	end
	
	return pos, ang + curviewbob * self.ViewbobIntensity, fov
end