SWEP.CrossAmount = 0
SWEP.CrossAlpha = 255

SWEP.CurFOVMod = 0

SWEP.PassiveCone = 0.02
SWEP.AimCone = 0.005

SWEP.AimCrossAlpha = 0
SWEP.CrossAlpha = 0

function SWEP:DoDrawCrosshair(x, y)
    local FT = FrameTime()

    if self.XPWSniper then
        return true
    end

    if self:GetPassive() or self:GetRunning() or self:GetIsReloading() then
        self.CrossAlpha = Lerp(FT * 15, self.CrossAlpha, 120)
    elseif self:GetAim() then
        self.CrossAlpha = Lerp(FT * 15, self.CrossAlpha, 170)
    else
        self.CrossAlpha = Lerp(FT * 15, self.CrossAlpha, 255)
    end

    if self:GetAim() then
        self.AimCrossAlpha = Lerp(FT * 15, self.AimCrossAlpha, 255)
        self.CrossAmount = Lerp(FT * 15, self.CrossAmount, (self.AimCone * 350) * (90 / (math.Clamp(GetConVarNumber("fov_desired"), 75, 90) - self.CurFOVMod)))       
    else
        self.AimCrossAlpha = Lerp(FT * 15, self.AimCrossAlpha, 0)
        self.CrossAmount = Lerp(FT * 15, self.CrossAmount, (self.PassiveCone * 350) * (90 / (math.Clamp(GetConVarNumber("fov_desired"), 75, 90) - self.CurFOVMod)))
    end

    surface.SetDrawColor(0, 0, 0, self.CrossAlpha * 0.75)
    surface.DrawRect(x - 13 - self.CrossAmount, y - 1, 12, 3)
    surface.DrawRect(x + 3 + self.CrossAmount, y - 1, 12, 3)
    surface.DrawRect(x - 1, y - 13 - self.CrossAmount, 3, 12)
    surface.DrawRect(x - 1, y + 3 + self.CrossAmount, 3, 12)

    surface.SetDrawColor(255, 255, 255, self.CrossAlpha) 
    surface.DrawRect(x - 12 - self.CrossAmount, y, 10, 1) 
    surface.DrawRect(x + 4 + self.CrossAmount, y, 10, 1)
    surface.DrawRect(x, y - 12 - self.CrossAmount, 1, 10) 
    surface.DrawRect(x, y + 4 + self.CrossAmount, 1, 10)

    if self:GetAim() then
        surface.SetDrawColor(0, 0, 0, self.AimCrossAlpha * 0.75)
        surface.DrawRect(x - 1, y - 1, 4, 4)

        surface.SetDrawColor(255, 255, 255, self.AimCrossAlpha) 
        surface.DrawRect(x, y, 2, 2)
    end

    return true
end

local matScope = Material("gmod/scope")
local matScopeRefract = Material("gmod/scope-refract")

function SWEP:DrawHUDBackground()
	if self.XPWSniper and self:GetAim() then
		local h = ScrH()
		local w = h * 1.25

		local x, y = ScrW() / 2 - w / 2, ScrH() / 2 - h / 2
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, 0, x, ScrH())
		surface.DrawRect(x + w, 0, ScrW() - (x + w), ScrH())

		surface.SetDrawColor(color_black)
		surface.SetMaterial(matScope)
		surface.DrawTexturedRect(x, y, w, h)

		surface.SetDrawColor(color_black)
		surface.DrawLine(0, ScrH() / 2, ScrW(), ScrH() / 2)
		surface.DrawLine(ScrW() / 2, 0, ScrW() / 2, ScrH())

        local sz = ScrH() / 4
		surface.SetAlphaMultiplier(0.25 + (self.ConeStayAim / self.Cone) * 0.75)
        surface.SetDrawColor(Color(255, 0, 0))
        surface.DrawLine((ScrW() - sz) / 2, ScrH() / 2, (ScrW() + sz) / 2, ScrH() / 2)
        surface.DrawLine(ScrW() / 2, (ScrH() - sz) / 2, ScrW() / 2, (ScrH() + sz) / 2)
		surface.SetAlphaMultiplier(1)
	end
end