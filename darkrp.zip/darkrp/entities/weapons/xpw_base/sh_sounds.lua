local SoundChars = {
	["*"] = "STREAM",
	["#"] = "DRYMIX",
	["@"] = "OMNI",
	[">"] = "DOPPLER",
	["<"] = "DIRECTIONAL",
	["^"] = "DISTVARIANT",
	["("] = "SPATIALSTEREO_LOOP",
	[")"] = "SPATIALSTEREO",
	["}"] = "FASTPITCH",
	["$"] = "CRITICAL",
	["!"] = "SENTENCE",
	["?"] = "USERVOX"
}

local DefaultSoundChar = ")"

local SoundChannels = {
	["shoot"] = CHAN_WEAPON,
	["shootwrap"] = CHAN_STATIC,
	["misc"] = CHAN_AUTO
}

local function PatchSound(path, kind)
	local pathv
	local c = string.sub(path, 1, 1)

	if SoundChars[c] then
		pathv = string.sub(path, 2, string.len(path))
	else
		pathv = path
	end

	local kindstr = kind

	if not kindstr then
		kindstr = DefaultSoundChar
	end

	if string.len(kindstr) > 1 then
		local found = false

		for k, v in pairs(SoundChars) do
			if v == kind then
				kindstr = k
				found = true
				break
			end
		end

		if not found then
			kindstr = DefaultSoundChar
		end
	end

	return kindstr .. pathv
end

local function AddFireSound(id, path, wrap, kindv)
	kindv = kindv or ")"

	if isstring(path) then
		sound.Add({
			name = id,
			channel = wrap and SoundChannels.shootwrap or SoundChannels.shoot,
			volume = 1.0,
			level = 120,
			pitch = {97, 103},
			sound = PatchSound(path, kindv)
		})
	elseif istable(path) then
		local tb = table.Copy(path)

		for k, v in pairs(tb) do
			tb[k] = PatchSound(v, kindv)
		end

		sound.Add({
			name = id,
			channel = wrap and SoundChannels.shootwrap or SoundChannels.shoot,
			volume = 1.0,
			level = 120,
			pitch = {97, 103},
			sound = tb
		})
	end
end

local function AddWeaponSound(id, path, kindv)
	kindv = kindv or ")"

	if isstring(path) then
		sound.Add({
			name = id,
			channel = SoundChannels.misc,
			volume = 1.0,
			level = 80,
			pitch = {97, 103},
			sound = PatchSound(path, kindv)
		})
	elseif istable(path) then
		local tb = table.Copy(path)

		for k, v in pairs(tb) do
			tb[k] = PatchSound(v, kindv)
		end

		sound.Add({
			name = id,
			channel = SoundChannels.misc,
			volume = 1.0,
			level = 80,
			pitch = {97, 103},
			sound = tb
		})
	end
end

AddFireSound("FAS2_SKS", "weapons/sks/sks_fire1.wav", true)
AddWeaponSound("FAS2_SKS_MagOut", "weapons/sks/sks_magout.wav")
AddWeaponSound("FAS2_SKS_MagIn", "weapons/sks/sks_magin.wav")

AddFireSound("FAS2_FAMAS", "weapons/famas/famas_fire1.wav", true)
AddWeaponSound("FAS2_FAMAS_MagIn", "weapons/famas/famas_magin.wav")
AddWeaponSound("FAS2_FAMAS_MagOut", "weapons/famas/famas_magout.wav")

AddFireSound("FAS2_AK74", "weapons/ak74/ak74_fire1.wav", true)
AddWeaponSound("FAS2_AK74_MagOut", "weapons/ak74/ak74_magout.wav")
AddWeaponSound("FAS2_AK74_MagIn", "weapons/ak74/ak74_magin.wav")

AddFireSound("FAS2_AK47", "weapons/ak47/ak47_fire1.wav", true)
AddWeaponSound("FAS2_AK47_MagOut", "weapons/ak47/ak47_magout.wav")
AddWeaponSound("FAS2_AK47_MagIn", "weapons/ak47/ak47_magin.wav")

AddFireSound("FAS2_M4A1", "weapons/m4a1/m4_fire1.wav", true)
AddWeaponSound("FAS2_M4A1_Magout", "weapons/m4a1/m4_magout.wav")
AddWeaponSound("FAS2_M4A1_Magin", "weapons/m4a1/m4_magin.wav")

AddFireSound("FAS2_SG552", "weapons/sg55x/sg550_fire1.wav", true)
AddWeaponSound("FAS2_SG552_MagOut", "weapons/sg55x/sg550_magout.wav")
AddWeaponSound("FAS2_SG552_MagIn", "weapons/sg55x/sg550_magin.wav")

AddFireSound("FAS2_RK95", "weapons/ak74/ak74_fire1.wav", true)
AddWeaponSound("FAS2_RK95_MagOut", "weapons/ak74/ak74_magout.wav")
AddWeaponSound("FAS2_RK95_MagIn", "weapons/ak74/ak74_magin.wav")

AddFireSound("FAS2_M24", "weapons/m24/m24_fire1.wav", true)
AddWeaponSound("FAS2_M24_MagOut", "weapons/ak74/ak74_magout.wav")
AddWeaponSound("FAS2_M24_MagIn", "weapons/ak74/ak74_magin.wav")

AddFireSound("FAS2_P226", "weapons/p226/p226_fire1.wav", true)
AddWeaponSound("FAS2_P226_MagIn", "weapons/p226/p226_magin.wav")
AddWeaponSound("FAS2_P226_MagOut", "weapons/p226/p226_magout.wav")

AddFireSound("FAS2_M1911", "weapons/1911/1911_fire1.wav", true)
AddWeaponSound("FAS2_M1911_MagIn", "weapons/1911/1911_magin.wav")
AddWeaponSound("FAS2_M1911_MagOut", "weapons/1911/1911_magout.wav")

AddFireSound("FAS2_GLOCK20", "weapons/glock20/glock20_fire1.wav", true)
AddWeaponSound("FAS2_GLOCK20_MagOut", "weapons/glock20/glock20_magout.wav")
AddWeaponSound("FAS2_GLOCK20_MagIn", "weapons/glock20/glock20_magin.wav")

AddFireSound("FAS2_DEAGLE", "weapons/deserteagle/de_fire1.wav", true)
AddWeaponSound("FAS2_DEAGLE_MagOut", "weapons/deserteagle/de_magout.wav")
AddWeaponSound("FAS2_DEAGLE_MagIn", "weapons/deserteagle/de_magin.wav")

AddFireSound("FAS2_PP19", "weapons/bizon/bizon_fire1.wav", true)
AddWeaponSound("FAS2_PP19_MagOut", "weapons/bizon/bizon_magout.wav")
AddWeaponSound("FAS2_PP19_MagIn", "weapons/bizon/bizon_magin.wav")

AddFireSound("FAS2_MP5A5", "weapons/mp5/mp5_fire1.wav", true)
AddWeaponSound("FAS2_MP5A5_MagOut", "weapons/mp5/mp5_magout.wav")
AddWeaponSound("FAS2_MP5A5_MagIn", "weapons/mp5/mp5_magin.wav")

AddFireSound("FAS2_UZI", "weapons/uzi/uzi_fire1.wav", true)
AddWeaponSound("FAS2_UZI_MagOut", "weapons/uzi/uzi_magout.wav")
AddWeaponSound("FAS2_UZI_MagIn", "weapons/uzi/uzi_magin.wav")

AddFireSound("FAS2_M3S90", "weapons/m3s90p/m3s90_fire1.wav", true)
AddWeaponSound("FAS2_M3S90_Load", {
		"weapons/m3s90p/m3s90_load1.wav", 
		"weapons/m3s90p/m3s90_load2.wav", 
		"weapons/m3s90p/m3s90_load3.wav", 
		"weapons/m3s90p/m3s90_load4.wav", 
		"weapons/m3s90p/m3s90_load5.wav", 
		"weapons/m3s90p/m3s90_load6.wav", 
		"weapons/m3s90p/m3s90_load7.wav",
		"weapons/m3s90p/m3s90_load8.wav"
	}
)

AddFireSound("FAS2_RAGINGBULL", "weapons/ragingbull/ragingbull_fire1.wav", true)
AddWeaponSound("FAS2_RAGINGBULL_Load", {
	    "weapons/ragingbull/ragingbull_insert1.wav", 
	    "weapons/ragingbull/ragingbull_insert2.wav", 
	    "weapons/ragingbull/ragingbull_insert3.wav", 
	    "weapons/ragingbull/ragingbull_insert4.wav", 
	    "weapons/ragingbull/ragingbull_insert5.wav"
    }
)