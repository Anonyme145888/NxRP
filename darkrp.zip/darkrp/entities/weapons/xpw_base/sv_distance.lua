local att, wep, dist, mul

hook.Add("EntityTakeDamage", "XPWEntityTakeDamage", function(ent, dmg)
	att = dmg:GetInflictor()
	
	if att:IsPlayer() then
		wep = att:GetActiveWeapon()

		if IsValid(wep) then
			if not wep.XPWWeapon then
				return
			end

			dist = ent:GetPos():Distance(att:GetPos())
			
			if dist >= wep.EffectiveRange * 0.5 then
				dist = dist - wep.EffectiveRange * 0.5
				mul = math.Clamp(dist / wep.EffectiveRange, 0, 1)
			
				dmg:ScaleDamage(1 - wep.DamageFallOff * mul)
			end
		end
	end
end)