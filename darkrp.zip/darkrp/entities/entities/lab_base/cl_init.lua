include("shared.lua")

function ENT:Initialize()
    self:initVars()
end

function ENT:Draw()
    self:DrawModel()

    local Pos = self:GetPos()
    local Ang = self:GetAngles()

    local owner = self:Getowning_ent()
    owner = (IsValid(owner) and owner:Nick()) or DarkRP.getPhrase("unknown")

    surface.SetFont("HUDNumber5")
    local text = self.labPhrase
    local text2 = DarkRP.getPhrase("priceTag", DarkRP.formatMoney(self:Getprice()), "")
    local TextWidth = surface.GetTextSize(text)
    local TextWidth2 = surface.GetTextSize(text2)

    Ang:RotateAroundAxis(Ang:Forward(), 90)
    local TextAng = Ang

    TextAng:RotateAroundAxis(TextAng:Right(), CurTime() * -120)

    cam.Start3D2D(Pos + Ang:Right() * self.camMul, TextAng, 0.2)
        draw.WordBox(1, -TextWidth * 0.5 + 5, -60, text, "nx_hud",  Color(0, 0, 0, 70), Color(255, 255, 255, 255))
        draw.WordBox(1, -TextWidth2 * 0.5 + 5, -18, text2, "nx_hud",  Color(0, 0, 0, 70), Color(255, 255, 255, 255))
    cam.End3D2D()
end
