include("shared.lua")

local frame
local SignButton

local function KillLetter(msg)
    hook.Remove("HUDPaint", "ShowLetter")
    frame:Remove()
end
usermessage.Hook("KillLetter", KillLetter)

local function ShowLetter(msg)
    if frame then
        frame:Remove()
    end

    local LetterMsg = ""
    local Letter = msg:ReadEntity()
    local LetterType = msg:ReadShort()
    local LetterPos = msg:ReadVector()
    local sectionCount = msg:ReadShort()
    local LetterY = ScrH() / 2 - 300
    local LetterAlpha = 255

    Letter:CallOnRemove("Kill letter HUD on remove", KillLetter)

    for k = 1, sectionCount, 1 do
        LetterMsg = LetterMsg .. msg:ReadString()
    end

    frame = vgui.Create("NxGenericFrame")
    frame:AddTitle("Письмо")

    SignButton = vgui.Create("NxButton", frame)
    SignButton:SetText(DarkRP.getPhrase("sign_this_letter"))
    SignButton:SetPrimaryMainColors()
    SignButton:SetTall(48)
    frame:SetSize(yscale(1100), yscale(800))
    frame:Center()
    SignButton:Dock(BOTTOM)
    frame:SizeToContents()
    frame:MakePopup()
    
    local richtext = vgui.Create( "RichText", frame )
    richtext:Dock( FILL )
   
    local text = LetterMsg .. "\n\n\n" .. DarkRP.getPhrase("signed", IsValid(Letter:Getsigned()) and Letter:Getsigned():Nick() or DarkRP.getPhrase("no_one"))
    richtext:AppendText(text)

    richtext.Paint = function(self)
		self.Paint = nil
		self:SetFontInternal("DermaNotLarge")
	end
    function SignButton:DoClick()
        RunConsoleCommand("_DarkRP_SignLetter", Letter:EntIndex())
        SignButton:SetDisabled(true)
    end
    SignButton:SetDisabled(IsValid(Letter:Getsigned()))

end
usermessage.Hook("ShowLetter", ShowLetter)

function ENT:Draw()
	self:DrawModel()
    	local pos = self:GetPos() + Vector(0, 0, 1) * math.sin(CurTime() * 1) * 1
    local PlayersAngle = LocalPlayer():GetAngles()
    local ang = Angle( 0, PlayersAngle.y - 180, 0 )
    ang:RotateAroundAxis(ang:Right(), -90)
    ang:RotateAroundAxis(ang:Up(), 90)

	if LocalPlayer():GetPos():Distance(self:GetPos()) < 200 then
		cam.Start3D2D(pos + ang:Up() * 1 + ang:Right() * -15, ang, 0.1)
			draw.SimpleText( "Записка", "BailNPCFont", 0,0, Color(62, 90, 173, 255), 1,1 )
		cam.End3D2D()
		cam.Start3D2D(pos + ang:Up() * 1 + ang:Right() * -10, ang, 0.1)
			draw.SimpleText( "Что-же внутри написано?", "BailNPCDescFont", 0,0, Color(255, 255, 255, 255), 1,1 )
		cam.End3D2D()
	end
end