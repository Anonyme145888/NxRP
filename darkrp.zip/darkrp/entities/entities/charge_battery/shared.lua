ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Suit Charger battery"
ENT.Author = "pakun"
ENT.Spawnable = true
ENT.Category = "Chargers"

