ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Turret Shipment"
ENT.Category = "gx"
ENT.Instructions = "!"
ENT.Spawnable = true
ENT.AdminOnly = true

ENT.Author = "AnonChaos"
ENT.Purpose = "Pour gx."

ENT.PlaceProtection = false 
ENT.PlaceAfterGrabCooldown = 3 
ENT.MinDistanceBetweenTurrets = 500 
ENT.MaxDistanceToPlace = 300 

// autres variables
ENT.Last_Grabber = nil
ENT.Last_Time_Grabbed = 0

scripted_ents.Register(ENT, "gx_turret_shipment")