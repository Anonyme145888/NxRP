placing_turret = nil
placing_shipment = nil

function ENT:Initialize()
	
end

function ENT:Draw()
	self:DrawModel()
end

function DrawSphere(pos, radius, segments)
    mesh.Begin(MATERIAL_TRIANGLES, segments * (segments - 1) * 2)

    for i = 0, segments - 1 do
        for j = 0, segments do
            local theta1 = (i / segments) * math.pi
            local theta2 = ((i + 1) / segments) * math.pi

            local phi1 = (j / segments) * 2 * math.pi
            local phi2 = ((j + 1) / segments) * 2 * math.pi

            local x1 = math.sin(theta1) * math.cos(phi1)
            local y1 = math.sin(theta1) * math.sin(phi1)
            local z1 = math.cos(theta1)

            local x2 = math.sin(theta1) * math.cos(phi2)
            local y2 = math.sin(theta1) * math.sin(phi2)
            local z2 = math.cos(theta1)

            local x3 = math.sin(theta2) * math.cos(phi1)
            local y3 = math.sin(theta2) * math.sin(phi1)
            local z3 = math.cos(theta2)

            local x4 = math.sin(theta2) * math.cos(phi2)
            local y4 = math.sin(theta2) * math.sin(phi2)
            local z4 = math.cos(theta2)

            -- Créer les deux triangles qui composent chaque segment
            local function Vertex(x, y, z)
                mesh.Position(pos + Vector(x * radius, y * radius, z * radius))
                mesh.Normal(Vector(x, y, z)) -- Optionnel : définir les normales
                mesh.AdvanceVertex()
            end

            Vertex(x1, y1, z1)
            Vertex(x3, y3, z3)
            Vertex(x4, y4, z4)

            Vertex(x1, y1, z1)
            Vertex(x4, y4, z4)
            Vertex(x2, y2, z2)
        end
    end

    -- Finir la construction du mesh
    mesh.End()
end

function IsOnWorldGround(position)
    local startPos = position + Vector(0, 0, 0)
    local endPos = position - Vector(0, 0, 1)

    local trace = util.TraceLine({
        start = startPos,
        endpos = endPos,
        filter = entity
    })

    return trace.HitWorld
end

function checkValidPlacement(shipment, position)
	local all_turrets = ents.FindByClass("gx_turret")
	local valid = true

	for i,v in pairs(all_turrets) do
		if v:GetPos():Distance(position) < shipment.MinDistanceBetweenTurrets then
			valid = false
			continue
		end
	end

	if not IsOnWorldGround(position)  then
		valid = false
	end

	if LocalPlayer():GetPos():Distance(position) > shipment.MaxDistanceToPlace then
		valid = false
	end

	return valid
end

net.Receive("gx_used_turret_shipment", function()
	placing_shipment = net.ReadEntity()

	if not placing_shipment then return end

	hook.Add("PostDrawTranslucentRenderables", "placing_turret_sphere", function()
		local all_turrets = ents.FindByClass("gx_turret")
		
		for i,v in pairs(all_turrets) do
			if IsValid(v) then
				local position = v:GetPos()

				render.SetColorMaterial()

				-- Dessiner la sphère avec les faces extérieures
				render.CullMode(MATERIAL_CULLMODE_CCW)  -- CCW = faces extérieures visibles
				render.DrawSphere(position, placing_shipment.MinDistanceBetweenTurrets, 30, 30, Color(255, 0, 0, 50))

				-- Dessiner la sphère avec les faces intérieures
				render.CullMode(MATERIAL_CULLMODE_CW)  -- CW = faces intérieures visibles
				render.DrawSphere(position, placing_shipment.MinDistanceBetweenTurrets, 30, 30, Color(255, 0, 0, 50))

				-- Restaurer le culling normal
				render.CullMode(MATERIAL_CULLMODE_CCW)
			end
		end
	end)

	if (placing_turret) then
		placing_turret:Remove()
	end

	local trace = LocalPlayer():GetEyeTrace()
	local entity = ClientsideModel( "models/grinchfox/turret.mdl" )
	placing_turret = entity
	entity:SetMaterial("models/wireframe")
	entity:SetColor(Color(32, 255, 0))
	
	entity:SetPos( trace.HitPos )
	entity:Spawn()

	hook.Add("Tick", "gx_place_turret", function()
		local trace = LocalPlayer():GetEyeTrace()
		entity:SetPos( trace.HitPos )

		if (checkValidPlacement(placing_shipment, trace.HitPos)) then
			entity:SetColor(Color(32, 255, 0))
		else
			entity:SetColor(Color(255, 32, 0))
		end

		if LocalPlayer():KeyDown(IN_ATTACK2) then
			hook.Remove("Tick", "gx_place_turret")
			placing_turret:Remove()
			placing_turret = nil
			placing_shipment = nil
		end
	end)
end)

hook.Add("KeyPress", "click_detect", function()
    if (input.IsMouseDown(MOUSE_LEFT)) then
		local position = LocalPlayer():GetEyeTrace().HitPos
		if (IsValid(placing_shipment) and checkValidPlacement(placing_shipment, position)) then
			hook.Remove("PostDrawTranslucentRenderables", "placing_turret_sphere")
			hook.Remove("Tick", "gx_place_turret")

			if placing_turret then
				placing_turret:Remove()
			end
			placing_turret = nil

			net.Start("gx_place_turret")
			net.WriteEntity(placing_shipment)
			net.WriteVector(position)
			net.SendToServer()
		end
	end
end)



net.Receive("send_error_notification", function()
	local notif = net.ReadString()

	notification.AddLegacy(notif, NOTIFY_ERROR, 5)
    surface.PlaySound("buttons/button10.wav")
end)