AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("gx_place_turret")
util.AddNetworkString("gx_used_turret_shipment")
util.AddNetworkString("send_error_notification")

function ENT:Initialize()
    self:SetModel("models/Items/item_item_crate.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
    end
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    if self.PlaceProtection then
        if self.Last_Grabber == activator and CurTime() < (self.Last_Time_Grabbed + self.PlaceAfterGrabCooldown) then
            self:NotifyError(activator, "Veuillez attendre avant de poser une autre tourelle.")
            return
        end
    end

    net.Start("gx_used_turret_shipment")
    net.WriteEntity(self)
    net.Send(activator)

    self.Last_Grabber = activator
    self.Last_Time_Grabbed = CurTime()
end

function ENT:NotifyError(ply, message)
    net.Start("send_error_notification")
    net.WriteString(message)
    net.Send(ply)
end

net.Receive("gx_place_turret", function(len, ply)
    local shipment = net.ReadEntity()
    local position = net.ReadVector()

    if not IsValid(shipment) or not shipment:GetClass() == "gx_turret_shipment" then
        shipment:NotifyError(ply, "Entité invalide.")
        return
    end

    if ply:GetPos():Distance(position) > shipment.MaxDistanceToPlace then
        shipment:NotifyError(ply, "Vous êtes trop loin pour poser une tourelle ici.")
        return
    end

    local allTurrets = ents.FindByClass("gx_turret")
    for _, turret in ipairs(allTurrets) do
        if turret:GetPos():Distance(position) < shipment.MinDistanceBetweenTurrets then
            shipment:NotifyError(ply, "Trop proche d'une autre tourelle.")
            return
        end
    end

    if not util.IsInWorld(position) then
        shipment:NotifyError(ply, "Position invalide.")
        return
    end

    local turret = ents.Create("gx_turret")
    if not IsValid(turret) then
        shipment:NotifyError(ply, "Impossible de créer la tourelle.")
        return
    end

    turret:SetPos(position)
    turret:SetAngles(Angle(0, ply:EyeAngles().yaw, 0))
    turret:SetOwner(ply)
    turret:Spawn()

    turret:Activate()
end)