include("shared.lua")
ENT.RenderGroup = RENDERGROUP_BOTH
turrets_allturrets = turrets_allturrets or {}

local function PrecacheSounds(tbl)
    for _, v in pairs(tbl) do
        if type(v) == "string" then
            util.PrecacheSound(v)
        else
            PrecacheSounds(v)
        end
    end
end

PrecacheSounds(ENT.Sounds)

function ENT:Initialize()
    self.led_pvh = util.GetPixelVisibleHandle()
    self.att_eyes = self:LookupAttachment"eyes"
    self.att_led = self:LookupAttachment"attachment_led"
    self.att_shootpos = self:LookupAttachment"attachment_shootpos"
    table.insert(turrets_allturrets, self)
end

function ENT:OnRemove()
    table.iRemoveByValue(turrets_allturrets, self)
end

local blink_repair_period = 1
local state_color = {Color(64, 255, 0), Color(255, 255, 0), Color(255, 32, 0), Color(128, 0, 0), Color(255, 128, 0)} -- 0 = off -- 1 = fine -- 2 = seeking -- 3 = angry -- 4 = broken -- 5 = repairing

function ENT:Think()
    local state = self:GetAlarmState()
    local led_color = state_color[state]
    local brmul = 1

    -- broken
    if state == 4 then
        brmul = math.random()
    elseif state == 5 then
        -- at repair
        brmul = math.abs(blink_repair_period / 2 - RealTime() % blink_repair_period) / blink_repair_period * 2
    end

    if brmul ~= 1 then
        led_color = Color(led_color.r * brmul, led_color.g * brmul, led_color.b * brmul)
    end

    self.led_color = led_color

    if led_color then
        local att_led = self:GetAttachment(self.att_led)

        if att_led then
            local dlight = DynamicLight(self:EntIndex())

            if dlight then
                dlight.pos = att_led.Pos
                dlight.r = led_color.r
                dlight.g = led_color.g
                dlight.b = led_color.b
                dlight.brightness = 2
                dlight.Decay = 1000
                dlight.Size = 32
                dlight.DieTime = CurTime() + 0.1
                dlight.noworld = true
            end
        end
    end
end

local mat_glow = Material("sprites/light_glow02_add_noz")
local col_glow = Color(0, 0, 0)
local DrawDistance = 512 ^ 2

function ENT:DrawTranslucent()
    if EyePos():DistToSqr(self:GetPos()) > DrawDistance then return end
    local led_color = self.led_color
    if not led_color then return end
    local att_led = self:GetAttachment(self.att_led)
    if not att_led then return end
    local pixvis = util.PixelVisible(att_led.Pos, 1, self.led_pvh)

    if pixvis > 0 then
        col_glow.r = led_color.r * pixvis * 0.3
        col_glow.g = led_color.g * pixvis * 0.3
        col_glow.b = led_color.b * pixvis * 0.3
        render.SetMaterial(mat_glow)
        render.DrawSprite(att_led.Pos, 10 * pixvis, 10 * pixvis, led_color)
        render.DrawSprite(att_led.Pos, 120, 50, col_glow)
    end
end

local DrawDistance = 4096 ^ 2
local mat = Material("trails/laser")
local trtr = {}

local tr = {
    output = trtr,
    mask = MASK_SHOT
}

hook.Add("PostDrawTranslucentRenderables", "gx_turret", function(depth, sky)
    if depth or sky then return end

    for _, self in ipairs(turrets_allturrets) do
        if not self.led_color then continue end
        if EyePos():DistToSqr(self:GetPos()) > DrawDistance then continue end
        if not (self:GetAlarmState() == 2 or self:GetAlarmState() == 3) then continue end
        local att_eyes = self:GetAttachment(self.att_eyes)
        if not att_eyes then return end
        local att_shootpos = self:GetAttachment(self.att_shootpos)
        if not att_shootpos then return end
        tr.start = att_shootpos.Pos
        tr.endpos = tr.start - att_shootpos.Ang:Forward() * self.search_radius
        tr.filter = self
        util.TraceLine(tr)
        render.SetMaterial(mat)
        render.DrawBeam(att_eyes.Pos, att_eyes.Pos + (trtr.HitPos - trtr.StartPos), 3, 0, 1, ColorAlpha(self.led_color, 204))
    end
end)

--------------------
local red = Color(187, 51, 51)
local green = Color(51, 187, 51)
local yellow = Color(255, 238, 0)
local orange = Color(255, 136, 0)
local colors = {red, green, yellow}

net.Receive("gx_turret", function()
    if net.ReadBool() then
        ihaveturrets = net.ReadBool()

        return
    end

    if frame and frame:IsValid() then
        frame:Remove()
        --return
    end

    local lp = LocalPlayer()
    local ds = {}

    while net.ReadBool() do
        ds[net.ReadUInt(16)] = net.ReadUInt(2)
    end

    local list = {}

    for k, v in ipairs(player.GetAll()) do
        table.insert(list, {
            id = v:UserID(),
            ply = v
        })
    end

    table.sort(list, function(a, b) return ray.Sort(a.ply:Name(), b.ply:Name()) end)
    local d = net.ReadUInt(2)
    local f = net.ReadBool()
    frame = vgui.Create("DFrame")
    frame:SetTitle(DarkRP.getPhrase("turret_control"))
    frame:MakePopup()
    frame:SetKeyboardInputEnabled(false)
    frame:DockPadding(4, 27, 4, 3)
    frame:SetSize(379, 580)
    frame:Center()
    local scroll = frame:Add("DScrollPanel")
    scroll:Dock(FILL)
    scroll:DockMargin(1, 0, 1, 1)
    local layout = scroll:Add("DListLayout")
    layout:Dock(FILL)

    for k, v in next, list do
        local panel = layout:Add("DPanel")
        panel:Dock(TOP)
        panel:DockPadding(4, 1, 2, 1)
        panel:SetTall(22)
        local label = panel:Add("DLabel")
        label:SetText(v.ply:Name())
        label:Dock(LEFT)
        label:SetColor(v.ply:getJobTable().color)
        label:SetWide(156)

        function panel:Think()
            if v.ply:IsValid() then
                label:SetColor(v.ply:getJobTable().color)
            else
                self:Remove()
            end
        end

        local square, button1, button2, button3

        local function update()
            button1:SetColor(ds[v.id] == 1 and red or color_white)
            button2:SetColor(ds[v.id] == 3 and orange or color_white)
            button3:SetColor(ds[v.id] == 2 and green or color_white)
            square.color = colors[ds[v.id] or f and (lp:isCP() and v.ply:isCP() or getgroup and getgroup(lp) and getgroup(lp) == getgroup(v.ply)) and 2 or d]
        end

        square = panel:Add("Panel")
        square.color = color_black
        square:Dock(RIGHT)
        square:DockMargin(1, 0, 0, 0)
        square:SetSize(18, 18)

        function square:Paint(w, h)
            surface.SetDrawColor(0, 0, 0, 255)
            surface.DrawOutlinedRect((w - 18) / 2, (h - 18) / 2, 18, 18)
            surface.SetDrawColor(self.color)
            surface.DrawRect((w - 18) / 2 + 1, (h - 18) / 2 + 1, 16, 16)
        end

        button1 = panel:Add("DButton")
        button1:Dock(RIGHT)
        button1:DockMargin(1, 0, 1, 0)
        button1:SetWide(60)
        button1:SetText(DarkRP.getPhrase("enemy"))

        function button1.DoClick()
            if ds[v.id] == 1 then
                ds[v.id] = nil
            else
                ds[v.id] = 1
            end

            update()
            net.Start("gx_turret")
            net.WriteUInt(2, 2)
            net.WriteUInt(ds[v.id] or 0, 2)
            net.WriteBool(true)
            net.WriteUInt(v.id, 16)
            net.SendToServer()
        end

        button2 = panel:Add("DButton")
        button2:Dock(RIGHT)
        button2:DockMargin(1, 0, 1, 0)
        button2:SetWide(60)
        button2:SetText(DarkRP.getPhrase("neutral"))

        function button2.DoClick()
            if ds[v.id] == 3 then
                ds[v.id] = nil
            else
                ds[v.id] = 3
            end

            update()
            net.Start("gx_turret")
            net.WriteUInt(2, 2)
            net.WriteUInt(ds[v.id] or 0, 2)
            net.WriteBool(true)
            net.WriteUInt(v.id, 16)
            net.SendToServer()
        end

        button3 = panel:Add("DButton")
        button3:Dock(RIGHT)
        button3:DockMargin(1, 0, 1, 0)
        button3:SetWide(60)
        button3:SetText(DarkRP.getPhrase("friend"))

        function button3.DoClick()
            if ds[v.id] == 2 then
                ds[v.id] = nil
            else
                ds[v.id] = 2
            end

            update()
            net.Start("gx_turret")
            net.WriteUInt(2, 2)
            net.WriteUInt(ds[v.id] or 0, 2)
            net.WriteBool(true)
            net.WriteUInt(v.id, 16)
            net.SendToServer()
        end

        update()
        v.update = update
    end

    local close = frame:Add("DButton")
    close:Dock(BOTTOM)
    close:DockMargin(0, 1, 0, 1)
    close:SetText(DarkRP.getPhrase("close"))
    close:SetTall(30)

    close.DoClick = function()
        frame:Remove()
    end

    local footer = frame:Add("DPanel")
    footer:Dock(BOTTOM)
    footer:DockMargin(0, 1, 0, 0)
    footer:SetDrawBackground(false)
    local button_3, button_1
    local label = footer:Add("DLabel")
    label:Dock(LEFT)
    label:SetText(DarkRP.getPhrase("turret_default"))
    label:SizeToContents()
    label:DockMargin(4, 0, 0, 0)
    button_1 = footer:Add("DButton")
    button_1:Dock(RIGHT)
    button_1:SetText(DarkRP.getPhrase("enemy"))
    button_1:SetWide(123)

    function button_1.DoClick()
        d = 1

        for k, v in next, list do
            v.update()
        end

        button_3:SetColor(color_white)
        button_1:SetColor(red)
        net.Start("gx_turret")
        net.WriteUInt(2, 2)
        net.WriteUInt(1, 2)
        net.WriteBool(false)
        net.SendToServer()
    end

    button_1:SetColor(d == 1 and red or color_white)
    button_3 = footer:Add("DButton")
    button_3:Dock(RIGHT)
    button_3:DockMargin(1, 0, 1, 0)
    button_3:SetText(DarkRP.getPhrase("neutral"))
    button_3:SetWide(123)

    function button_3.DoClick()
        d = 3

        for k, v in next, list do
            v.update()
        end

        button_3:SetColor(orange)
        button_1:SetColor(color_white)
        net.Start("gx_turret")
        net.WriteUInt(2, 2)
        net.WriteUInt(3, 2)
        net.WriteBool(false)
        net.SendToServer()
    end

    button_3:SetColor(d == 3 and orange or color_white)
    local footer = frame:Add("DPanel")
    footer:Dock(BOTTOM)
    footer:DockMargin(0, 1, 0, 0)
    footer:SetDrawBackground(false)
    local label = footer:Add("DLabel")
    label:Dock(LEFT)
    label:SetText(DarkRP.getPhrase("turret_friends"))
    label:SizeToContents()
    label:DockMargin(4, 0, 0, 0)
    local p = footer:Add("DButton")
    p:Dock(RIGHT)
    p:DockMargin(0, 0, 0, 0)
    p:SetText(DarkRP.getPhrase("steam_friends"))
    p:SetWide(123)

    function p:DoClick()
        local plys = {}

        for k, v in ipairs(player.GetAll()) do
            if v:GetFriendStatus() == "friend" then
                ds[v:UserID()] = 2
                table.insert(plys, v:UserID())
            end
        end

        if #plys > 0 then
            net.Start("gx_turret")
            net.WriteUInt(2, 2)
            net.WriteUInt(2, 2)
            net.WriteBool(false)
            ray.WriteList(plys)
            net.SendToServer()
        end
    end

    local p = footer:Add("DCheckBoxLabel")
    p:Dock(RIGHT)
    p:DockMargin(1, 4, 0, 4)
    p:SetWide(123)
    p:SetText(DarkRP.getPhrase("gang_or_police"))
    p:SetChecked(f)

    function p:OnChange(state)
        f = state

        for k, v in next, list do
            v.update()
        end

        net.Start("gx_turret")
        net.WriteUInt(2, 2)
        net.WriteUInt(2, 2)
        net.WriteBool(false)
        net.WriteBool(false)
        net.WriteBool(state)
        net.SendToServer()
    end

    p:SetDisabled(not (lp:isCP() or getgroup and getgroup(lp)))
end)

hook.Add("TargetIDText", "gx_turret", function(ent)
    if not (ent:GetClass() == "gx_turret" and ent:GetNWEntity("deployable_owner"):IsValid()) then return end
    local text = {}
    table.insert(text, DarkRP.getPhrase("turret_owner", ent:GetNWEntity("deployable_owner"):Name()))

    if LocalPlayer():IsAlly(ent:GetNWEntity("deployable_owner")) then
        table.insert(text, DarkRP.getPhrase("turret_state", math.ceil(ent:Health() / ent.MaxHealth * 100), ent:Health()))
    end

    return table.concat(text, "  |  ") -- \n doesn't work here
end)