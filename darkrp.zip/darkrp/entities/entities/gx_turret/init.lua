AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

--[[
    Turrets System 2021 by Fy-e
]]

function ENT:Initialize()
    self:SetModel("models/grinchfox/turret.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetUseType( SIMPLE_USE )

    local obj = self:GetPhysicsObject()
    if IsValid(obj) then
        obj:EnableMotion(false)
    end

    self:SetAlarmState(1)
    self:SetHealth(self.MaxHealth)

    self.targets_list = {}
    self.black_target = nil
    self.seach_target = false
    self.ready = false
end

local function PrecacheSounds(tbl)
    for _, v in pairs(tbl) do
        if type(v) == "string" then
            util.PrecacheSound(v)
        else
            PrecacheSounds(v)
        end
    end
end
PrecacheSounds(ENT.Sounds)

local function FindEnemySphere(self, tbl)
    local seach = false
    local result = nil
    local pos = self:GetPos()
    
    local black = self.black_target
    if black and not table.HasValue(tbl, black) then
        self.black_target = nil
    end
    
    if not seach then
        for k, v in pairs(tbl) do
            if seach then continue end
            if v:GetClass():find("npc_") then
                result = v
                self.black_target = v

                seach = true
            end
        end
    end

    if not seach then
        for k, v in pairs(tbl) do
            if seach then continue end
            if v:IsPlayer() and self.targets_list[v:UserID()] and v:Alive() then
                result = v
                self.black_target = v

                seach = true
            end
        end
    end

    if not seach then
        local targets = {}
        for k, v in pairs(tbl) do
            if v:IsPlayer() and v:Alive() then
                table.insert(targets, {v, v:GetPos()})
            end
        end
        table.sort( targets, function(a, b) return a[2]:Distance(pos) < b[2]:Distance(pos) end)
        
        result = targets[1] and targets[1][1] or nil
        seach = true
    end

    return result
end

function ENT:FindEnemy()
    local turret = self
    local seach = false
    local ents = ents.FindInSphere(turret:GetPos(), turret.search_radius)
   
    local seach = FindEnemySphere(turret, ents)
    if seach then
        return seach
    end

    return nil
end

function ENT:Destroy()
    local turret = self
    local vPoint = turret:GetPos() + Vector(0, 0, 35)
    local effectdata = EffectData()
    effectdata:SetOrigin( vPoint )
    effectdata:SetMagnitude( 1.4 )
    util.Effect( "ElectricSpark", effectdata )
    
    turret.destroyed = true
    turret:EmitSound(table.Random(turret.Sounds.pain), 75, 100)
end

function ENT:OnTakeDamage( dmg )
    local turret = self
    local health = turret:Health()
    local new = health - dmg:GetDamage()
    if new > 0 then
        turret:SetHealth( new )
    else
        turret:SetHealth( 0 )
        turret:Destroy()
    end
end

function ENT:OnRemove()
    local turret = self
    turret:StopSound( turret.Sounds.turnloop )
end

function ENT:Think()
    local turret = self
    turret.target = turret:FindEnemy()
    if not turret.target then
        turret:StopSound( turret.Sounds.turnloop )
        return
    end

    local health = turret:Health()
    if turret.destroyed then
        if health <= 0 then
            turret:SetPoseParameter( "aim_pitch", 45 )
            turret:SetAlarmState(0)
        else
            turret.destroyed = false
            turret:SetAlarmState(1)
        end
        turret:StopSound( turret.Sounds.turnloop )
        return
    end

    if turret.seach_target then
        turret:StopSound( turret.Sounds.turnloop )
        return
    end
    
    local head = turret:WorldToLocal(turret.target:GetPos()):Angle()
    local head_command = head[2] - 180
    local up_command = head[1] - 360
    local up = (up_command < 0 and up_command > -340) and true or false
    local parameter_yaw = turret:GetPoseParameter( "aim_yaw" )
    local parameter_pitch = turret:GetPoseParameter( "aim_pitch" )

    if parameter_yaw == head_command then
        turret:StopSound( turret.Sounds.turnloop )
    end
    
    if parameter_yaw ~= head_command then
        turret:SetPoseParameter( "aim_yaw", head_command )
        if not turret.yaw_time or turret.yaw_time < CurTime() then
            turret:EmitSound(turret.Sounds.turnloop, 53, 215)
            turret.yaw_time = CurTime() + 4
        end
    else
        turret:StopSound( turret.Sounds.turnloop )
        turret.yaw_time = 0
    end

    if up then
        if parameter_pitch ~= up_command then
            turret:SetPoseParameter( "aim_pitch", up_command )
        end
    else
        if parameter_pitch ~= up_command then
            turret:SetPoseParameter( "aim_pitch", 0 )
        end
    end
    
    local black = turret.black_target
    if black then
        if not turret.yellow_code then
            turret.yellow_code = true
            turret:EmitSound(turret.Sounds.alarm, 75, 140)
            timer.Simple(1, function()
                if turret:IsValid() then
                    turret.ready = true
                end
            end)
        end
        
        if turret.ready then
            local source = turret:GetPos() + Vector( 0, 0, 24 )
            local random = Vector(math.random(1, 6), math.random(1, 6), 0)
            local bullet = {}
            bullet.Damage = math.random(3, 5)
            bullet.Force = 0
            bullet.Spread = random
            bullet.Distance = turret.search_radius2
            bullet.Dir = ( black:LocalToWorld( black:OBBCenter() ) - source ) + random
            bullet.Src = source  + random
            turret:FireBullets( bullet )

            turret:SetAlarmState(3)
            turret:EmitSound(turret.Sounds.gunfire, 75, 100)
        end
    else
        if turret:GetAlarmState() == 3 then
            turret:SetAlarmState(2)
            turret.seach_target = true
            timer.Simple(3, function()
                if turret:IsValid() then
                    if turret:GetAlarmState() == 2 then
                        turret:SetAlarmState(1)
                        turret.yellow_code = false
                        turret.seach_target = false
                        turret.ready = false
                        turret:EmitSound(turret.Sounds.alarmoff, 75, 200)
                    end
                end
            end)
        end
    end

    turret:NextThink( CurTime() + 0.2 )
    return true
end