ENT.Base = "base_anim"
ENT.Spawnable = true
ENT.AdminOnly = true

ENT.AutomaticFrameAdvance = true
ENT.search_radius = 1400
ENT.search_radius2 = ENT.search_radius ^ 2

ENT.Sounds = {
	--alarm = "npc/attack_helicopter/aheli_damaged_alarm1.wav",
	alarm = "npc/roller/mine/rmine_tossed1.wav",
	alarmoff = "npc/scanner/combat_scan3.wav",
	gunfire = "^npc/turret_floor/shoot1.wav",
	pain = {
		"ambient/energy/zap1.wav",
		"ambient/energy/zap2.wav",
		"ambient/energy/zap3.wav"
	},
	turnloop = "ambient/machines/engine1.wav",
}

ENT.PlacementProximityLimit = {
	gx_turret = {dist = 700},
	gx_elevator_floor = {dist = 1600},
	deployable_spawning = {dist = 700, check = function(ent)
		return ent:GetItem().deployable_class == "gx_turret"
	end}
}

ENT.MaxHealth = 150
function ENT:GetMaxHealth()
	return self.MaxHealth
end

ENT.RepairInterval = .2

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "AlarmState")
end