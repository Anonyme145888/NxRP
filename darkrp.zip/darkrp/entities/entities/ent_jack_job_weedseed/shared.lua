ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Cannabis Seed"
ENT.Category  = "DarkRP"
ENT.Author = "Jackarunda"
ENT.Spawnable = true

