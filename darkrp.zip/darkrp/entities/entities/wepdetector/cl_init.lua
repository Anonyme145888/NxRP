include("shared.lua")

function ENT:Draw()
	if self.RenderOverride then
		self:RenderOverride()
	else
		self:DrawModel()
	end
	self:AlertDraw(self:GetNWInt("wepfound"))
end

local color = Material("sprites/ledlighttall_additive")
function ENT:AlertDraw(alert)
	render.SetMaterial(color)

	local dvecoffset = 3 * -self:GetAngles():Right()

	local vec1 = self:LocalToWorld(Vector(12, -17.5, 102))
	local vec2 = self:LocalToWorld(Vector(12, -15.5, 102))
	local vec3 = self:LocalToWorld(Vector(12, -15.5, 98))
	local vec4 = self:LocalToWorld(Vector(12, -17.5, 98))

	local rvec1 = self:LocalToWorld(Vector(-12, 17.5, 102))
	local rvec2 = self:LocalToWorld(Vector(-12, 15.5, 102))
	local rvec3 = self:LocalToWorld(Vector(-12, 15.5, 98))
	local rvec4 = self:LocalToWorld(Vector(-12, 17.5, 98))

	for i = 1, math.min(12, alert) do
		local col = Color(185 + i*8, 255 - i*12, 0)

		render.DrawQuad(vec1, vec2, vec3, vec4, col)
		vec1 = vec1 + dvecoffset
		vec2 = vec2 + dvecoffset
		vec3 = vec3 + dvecoffset
		vec4 = vec4 + dvecoffset

		render.DrawQuad(rvec1, rvec2, rvec3, rvec4, col)
		rvec1 = rvec1 - dvecoffset
		rvec2 = rvec2 - dvecoffset
		rvec3 = rvec3 - dvecoffset
		rvec4 = rvec4 - dvecoffset
	end
end