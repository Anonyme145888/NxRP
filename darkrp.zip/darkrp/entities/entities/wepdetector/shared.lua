ENT.Type 			= "anim"

ENT.PrintName 		= "Weapon Detector"
ENT.Category 		= "DarkRP"
ENT.Spawnable 		= true
ENT.AdminOnly		= true

ENT.Model			= "models/grinchfox/rp/frame.mdl"

ENT.AlertSnd		= "ambient/alarms/apc_alarm_loop1.wav"

ENT.IsDestructible = true

ENT.IllicitWeps	= {
	-- Knives and shit
	{pat = "fas2_machete", cost = 2},
	{pat = "fas2_dv2", cost = 2},

	-- Pistols
	{pat = "nxw_glock", cost = 3},
	{pat = "nxw_deagle", cost = 3},
	{pat = "nxw_m1911", cost = 3},
	{pat = "nxw_mac11", cost = 3},
	{pat = "nxw_p226", cost = 3},
	{pat = "nxw_ragingbull", cost = 3},

	-- Other big guns, no need to sort.
	{pat = "nxw_.*", cost = 5},

	-- Really dangerous shit
	{pat = "nx_turret", cost = 7},
	{pat = "wep_nx_c4", cost = 7},
	{pat = "fas2_m67", cost = 7},
	{pat = "weapon_rpg", cost = 7},
}

ENT.SearchBoxLV		= Vector(-24, -24, 0)
ENT.SearchBoxHV		= Vector(24, 24, 100)
