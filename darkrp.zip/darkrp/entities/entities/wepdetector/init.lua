AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")


function ENT:Initialize()
	self:SetModel("models/grinchfox/rp/frame.mdl")
	self:SetSkin(3)
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )
	self.Entity:GetPhysicsObject():Wake();
end

-- REPLACE WITH OWN WEAPONS & METALLIC SWEPS.
local willSetOff = {"nxw_ak47", "kbw_famas", "kbw_g3a3", "kbw_glock", "kbw_deagle", "kbw_m1911", "kbw_m24", "kbw_m3s90", "kbw_m4a1", "kbw_mac11", "kbw_mp5", "kbw_p226", "kbw_bizon", "kbw_ragingbull", "kbw_rk95", "kbw_sg552", "kbw_sks"}

function ENT:Think ( )

	local min = self:OBBMins()
	local cen = self:OBBCenter()
	local real = self:LocalToWorld(Vector(cen.x, cen.y, min.z))

	for _, each in pairs(player.GetAll()) do
		if (each:GetPos():Distance(real) < 50) then
			local foundMetal = false
			for _, each in pairs(each:GetWeapons()) do
				local cl = string.lower(each:GetClass())

				for _, class in pairs(willSetOff) do
					if cl == class then
						foundMetal = true
						break
					end
				end
				if foundMetal == true then break end
			end

			if foundMetal == true then
				self.goingOff = CurTime()
                self.Entity:SetNWInt("wepfound", 5)
                timer.Simple(1, function()
                self.Entity:SetNWInt("wepfound", 12)
                end)
                timer.Simple(1.5, function()
                self.Entity:SetNWInt("wepfound", 5)
                end)
                timer.Simple(2, function()
                self.Entity:SetNWInt("wepfound", 12)
                end)   
                timer.Simple(2.5, function()
                self.Entity:SetNWInt("wepfound", 5)
                end)
                timer.Simple(3, function()
                self.Entity:SetNWInt("wepfound", 12)
                end)
                timer.Simple(3.5, function()
                self.Entity:SetNWInt("wepfound", 5)
                end)     
                timer.Simple(4, function()
                self.Entity:SetNWInt("wepfound", 12)
                end)
                timer.Simple(4.5, function()
                self.Entity:SetNWInt("wepfound", 5)
                end)     
                timer.Simple(5, function()
                self.Entity:SetNWInt("wepfound", 12)
                end)                                                                     
                timer.Simple(5.5, function()
                self.Entity:SetNWInt("wepfound", 0)
                end)                                       
                self:EmitSound( "ambient/alarms/apc_alarm_loop1.wav" )
                timer.Simple(5, function()
                    self:StopSound( "ambient/alarms/apc_alarm_loop1.wav" )
                end)
				return
			end
		end
	end
end
