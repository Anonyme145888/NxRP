include('shared.lua')

ENT.RenderGroup = RENDERGROUP_BOTH

local SCALE = 0.06

surface.CreateFont("CrimeVendInfoFont", {size = 1.5 / SCALE, weight = 350, antialias = true, extended = true, font = "Roboto"})
surface.CreateFont("CrimeVendTitleFont", {size = 1.5 / SCALE, weight = 350, antialias = true, extended = true, font = "Roboto"})
surface.CreateFont("CrimeVendItemFont", {size = 1.1 / SCALE, weight = 350, antialias = true, extended = true, font = "Roboto"})
surface.CreateFont("TradeInfoFont", {size = 0.9 / SCALE, weight = 350, antialias = true, extended = true, font = "Roboto"})
surface.CreateFont("jobfont", {size = 2 / SCALE, weight = 350, antialias = true, extended = true, shadow = false, outline = false, font = "Roboto"})
surface.CreateFont("namefont", {size = 2.7 / SCALE, weight = 350, antialias = true, extended = true, shadow = false, outline = false, font = "Roboto"})

surface.CreateFont("namefont_shadow", {size = 2.7 / SCALE, weight = 350, antialias = true, extended = true, shadow = false, outline = false, font = "Roboto"})
surface.CreateFont("job_sub", {size = 3 / SCALE, weight = 350, antialias = true, extended = true, shadow = false, outline = false, font = "Roboto"})
surface.CreateFont("job_sub_shadow", {size = 3 / SCALE, weight = 350, antialias = true, extended = true, shadow = false, outline = false, blursize = 0.4 / SCALE, font = "Roboto"})

surface.CreateFont("name_shadow", {size = 3 / SCALE, weight = 350, antialias = true, extended = true, blursize = 0.4 / SCALE, font = "Roboto"})
surface.CreateFont("job_shadow", {size = 2 / SCALE, weight = 350, antialias = true, extended = true, blursize = 0.4 / SCALE, font = "Roboto"})

function ENT:OnReloaded()
end

function ENT:Initialize()
end

function ENT:Draw()
    self:DrawModel()

    local Gender = self:GetVendorGender() or "ERREUR DE DÉFINITION DU SEXE"

    local leng = self:GetPos():Distance(EyePos())
    local clam = math.Clamp(leng, 0, 255)
    local main = (255 - clam)

    if (main <= 0) then return end

    local ahAngle = self:GetAngles()
    local AhEyes = LocalPlayer():EyeAngles()

    ahAngle:RotateAroundAxis(ahAngle:Forward(), 90)
    ahAngle:RotateAroundAxis(ahAngle:Right(), -90)

    cam.Start3D2D(self:GetPos() + self:GetUp() * 79, Angle(0, AhEyes.y - 90, 90), 0.08)

    draw.SimpleText("Services criminels", "nx_hud_nametag_sub_shadow", -10, -60, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("Services criminels", "nx_hud_nametag_sub", -10, -60, team.GetColor(TEAM_GANG), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    draw.SimpleText("Acheter une imprimante", "nx_hud_nametag_sub_shadow", -10, -10, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("Acheter une imprimante", "nx_hud_nametag_sub", -10, -10, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    draw.SimpleText("Vendre de la marijuana", "nx_hud_nametag_sub_shadow", -10, 40, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("Vendre de la marijuana", "nx_hud_nametag_sub", -10, 40, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    cam.End3D2D()

    self:SetNWString("nx_wear_glasses", "lunettes de soleil")
    self:SetNWString("nx_wear_hat", "fedora")

    nxshop.drawHat(self, self, true)
end

function DrawCrimeBuyMenu()
    local gui = vgui.Create("CriminalShop")
    gui:Center()
end

net.Receive("DrawCrimeBuyMenu", DrawCrimeBuyMenu)

local function CreateVendorMark(ply, cmd, args)
    if not args[1] then 
        notification.AddLegacy("Les arguments ne sont pas spécifiés!", NOTIFY_HINT, 3)
        return 
    end
    notification.AddLegacy("Le vendeur de produits illicites est arrivé! Marque sur la carte!", NOTIFY_HINT, 7)
    
    local VendorPos = Vector(args[1], args[2], args[3])
    
    hook.Add("HUDPaint", "PaintVendorMark", function()
        local dist = math.floor(LocalPlayer():GetPos():DistToSqr(VendorPos) / 50000)
        if dist < 5 then
            hook.Remove("HUDPaint", "PaintVendorMark")
        end
        local TextPos = VendorPos:ToScreen()
    end)

    nxmarker(IsValid(pl) and pl or LocalPlayer(), VendorPos, "accept", "Rencontre ici.")
   
    timer.Create("RemoveMarkWhileDelay", 2 * 60, 1, function()
        hook.Remove("HUDPaint", "PaintVendorMark")
        notification.AddLegacy("Le vendeur a été repéré et a fui la zone! La marque a été supprimée.", NOTIFY_HINT, 8)
    end)
end

concommand.Add("createVendorMark", CreateVendorMark)