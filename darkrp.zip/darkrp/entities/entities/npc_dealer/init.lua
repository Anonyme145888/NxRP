AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("DrawCrimeBuyMenu")
util.AddNetworkString("BuyPrinter")
util.AddNetworkString("SellMarijuana")

local GAMEMODE = GAMEMODE or GM

local MaleModels = {
	"models/Humans/Group01/Male_01.mdl",
	"models/Humans/Group01/male_02.mdl",
	"models/Humans/Group01/male_03.mdl",
	"models/Humans/Group01/male_04.mdl",
	"models/Humans/Group01/male_05.mdl",
	"models/Humans/Group01/male_06.mdl",
	"models/Humans/Group01/male_07.mdl",
	"models/Humans/Group01/male_08.mdl",
	"models/Humans/Group01/male_09.mdl"
}
local MaleNames = {
	"Willie Jimenez",
	"Philip White",
	"Joseph Mills",
	"Jacob Beck",
	"Philip Jackson",
	"Adam Greene",
	"Philip Hamilton",
	"Craig Chavez",
	"Douglas Gray",
	"Roger Gordon",
	"Gary Howard",
	"Sarah Alexander",
	"Brittany Graham",
	"Scott Weaver",
	"Gregory Murphy",
	"Peter Ramos",
	"Michael Schneider",
	"Matthew Armstrong",
	"Howard Valdez",
	"Jeremy Brown"
}

local FemaleModels = {
	"models/Humans/Group01/Female_01.mdl",
	"models/Humans/Group01/Female_02.mdl",
	"models/Humans/Group01/Female_03.mdl",
	"models/Humans/Group01/Female_04.mdl",
	"models/Humans/Group01/Female_05.mdl",
	"models/Humans/Group01/Female_06.mdl",
	"models/Humans/Group01/Female_07.mdl"
}
local FemaleNames = {	--Список имён для Женских моделей NPC (выбираються рандомно при спавне)
    "Willie Jimenez",
	"Philip White",
	"Joseph Mills",
	"Jacob Beck",
	"Philip Jackson",
	"Adam Greene",
	"Philip Hamilton",
	"Craig Chavez",
	"Douglas Gray",
	"Roger Gordon",
	"Gary Howard",
	"Sarah Alexander",
	"Brittany Graham",
	"Scott Weaver",
	"Gregory Murphy",
	"Peter Ramos",
	"Michael Schneider",
	"Matthew Armstrong",
	"Howard Valdez",
	"Jeremy Brown"
}
local MalePercent = 70



local PremiumPrinterPrice = 8000

local PrinterPrice = 8000



local PrinterEntityClass = "printer_package"
local PremiumPrinterEntityClass = "printer_package_premium"



function ENT:Initialize()
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid(  SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE, CAP_TURN_HEAD)
	self:SetHullSizeNormal();
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()

	self:SetMaxYawSpeed( 90 )

	local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion(false)
		phys:Wake()
	end

	self.Timer = CurTime()

	local MixedGender = true
	local MaleGender = false
	local FemaleGender = false
	if (MixedGender) then
		local mathrandom = math.random
		local GenderRandom = mathrandom(0,100)
		if GenderRandom <= MalePercent then
			self:SetVendorName( table.Random(MaleNames) )
		else
			self:SetVendorName( table.Random(FemaleNames) )
		end
	elseif (MaleGender) then
		self:SetVendorName( table.Random(MaleNames) )
	elseif (FemaleGender) then
		self:SetVendorName( table.Random(FemaleNames) )
	end

	local function CheckGender()
		for k, v in pairs( MaleNames ) do
			if v == self:GetVendorName() then return true end
		end
	end

	self.CurrentNpcGender = CheckGender() or false

	if self.CurrentNpcGender then
		self:SetModel( table.Random(MaleModels) )
		self:SetVendorGender("Service criminel")
	else
		self:SetModel( table.Random(FemaleModels) )
		self:SetVendorGender("Service criminel")
	end



	timer.Simple(2*60, function() -- 120 secs
		if IsValid(self) then
			self:Remove()
		end
	end)

end

function ENT:OnRemove()

end

function ENT:Think()
	--[[
	if CurTime() > self.Timer+1 then
		self:DropToFloor()
		self.Timer = CurTime()
	end
	]]--
end

local nextTalk = CurTime() + 3

function ENT:AcceptInput(inpt,activator,caller)
	if (inpt == "Use" and activator:IsPlayer()) then
		if activator.CantUse then self:EmitSound( "ui/buttonrollover.wav", 75, 100, 1, CHAN_AUTO ) return end
		activator.CantUse = true
		timer.Simple(1, function() activator.CantUse = false end)

		activator.CrimeVendorENT = self

		if gmod.GetGamemode().Name == "DarkRP" and activator:isCP() then return end

		if activator:Team() == TEAM_HOBO then return end



        if nextTalk < CurTime() then

			if self.CurrentNpcGender then
				local mathflooor = math.floor
				local mathraaandom = math.random
				local rand = mathflooor( mathraaandom(1,2) )
				self:EmitSound( "vo/npc/male01/hi0"..rand..".wav", 75, 100, 1, CHAN_AUTO )
			else
				local mathflooor = math.floor
				local mathraaandom = math.random
				local rand = mathflooor( mathraaandom(1,2) )
				self:EmitSound( "vo/npc/female01/hi0"..rand..".wav", 75, 100, 1, CHAN_AUTO )
			end

			nextTalk = CurTime() + 3
		end

		self:SetUseType(SIMPLE_USE)
	        net.Start("DrawCrimeBuyMenu")
	        net.Send(caller)
    end
end


local function BuyCrimeItem(ply, price, class)
	if ply.CrimeVendorENT:GetPos():Distance( ply:GetPos() ) > 250 then return end
    if not ply.NextDaun then ply.NextDaun = CurTime()-1 end
	local mathfloooor = math.floor
	if ply.NextDaun > CurTime() then DarkRP.notify(ply, 4, 4, -mathfloooor(CurTime()-ply.NextDaun) .." secondes avant le prochain achat.") return end

	local PocketAmount = table.Count( ply:getPocketItems() )
	if PocketAmount >= 10 then
		DarkRP.notify(ply, NOTIFY_ERROR, 2, "Ton sac est rempli, fais de la place!")
		return
	end


	if ply:canAfford(price) then
		DarkRP.notify(ply, NOTIFY_HINT, 2, "Merci pour le shopping !")
		ply:addMoney(price * -1) --Take Money
		local boughtItem = ents.Create( class ) --Spawn Entity
	    boughtItem:SetPos( Vector(0,0,0) )
	    boughtItem:SetColor(Color(0,0,0,0))
	   	boughtItem:Spawn()
		boughtItem:Activate()

		ply:addPocketItem(boughtItem) --Take it in pocket


	    ply.NextDaun = CurTime()+300
		ChatAddText(ply, team.GetColor(TEAM_GANG), "[Service criminel] ", color_white, "Voici votre article, ", color_white, ply:Nick(), color_white, "...")
	else
		DarkRP.notify(ply, NOTIFY_ERROR, 2, "Tu ne peux pas te le permettre !")
	end
end

local function BuyPrinter(len, ply)
	if ply:GetUserGroup() == "premium" then
		BuyCrimeItem(ply, PremiumPrinterPrice, PremiumPrinterEntityClass)
	else
		BuyCrimeItem(ply, PrinterPrice, PrinterEntityClass)
	end
end
net.Receive("BuyPrinter",BuyPrinter)

net.Receive("SellMarijuana", function(len, ply)

	local Tab,Num = ply.darkRPPocket or {},0

	for key,item in pairs(Tab)do
		if(item.Class=="ent_jack_job_weedbag")then
			local Bag = ply:dropPocketItem(key)
			if (Bag) then SafeRemoveEntity(Bag) end
			Num=Num+1
		end
	end

	if(Num>0)then
		local IllegallyGottenCash=Num*400
		ply:addMoney(IllegallyGottenCash)
		DarkRP.notify(ply, 4, 4, "vous avez vendu "..Num.." sac de marijuana pour "..DarkRP.formatMoney(IllegallyGottenCash))
	else
		DarkRP.notify(ply, 2, 4, "Vous n’avez pas de sacs de marijuana à vendre !")
	end

end)

local function AntiExploit(pocketTable, itemIndex, itemClass)
	for k,v in pairs(pocketTable) do
		if k == itemIndex and v.class == itemClass then return false end
	end
	return true
end

local LivePoses = {
	Pos1 = {
		Vector(-4271.968750, 1191.126465, 64.031250),
		Angle( 1.517980, 4.350117, 0.000000 )
	},

	Pos2 = {
		Vector(-11469.509766, -8107.980469, 72.031250),
		Angle( 0.924001, 89.232056, 0.000000 )
	},

	Pos3 = {
		Vector(13444.589844, 5976.442871, 1600.031250),
		Angle( -1.385993, 179.886078, 0.000000 )
	},

	Pos4 = {
		Vector(3990.894531, -11528.789062, 386.425873),
		Angle( 0.528013, -84.347816, 0.000000 )
	},

	Pos5 = {
		Vector(-11539.055664, -8788.031250, 64.031250),
		Angle( 1.254012, -89.825867, 0.000000 )
	},
}


local function call_crime_vendor(ply, cmd, args)
	if not ply.NextCrimeCall then ply.NextCrimeCall = CurTime()-1 end
	local mathfloor = math.floor
	if ply.NextCrimeCall > CurTime() then ply:ChatPrint( "Tu as appelé le dealer il y a moins d’une minute, alors attends un peu ".. -mathfloor(CurTime()-ply.NextCrimeCall) .." secondes.") return end
	ply.NextCrimeCall = CurTime()+90

	local HowMuchVendors = 0

	for k, v in pairs( ents.GetAll() ) do
		if v:GetClass() == "npc_dealer" then
			HowMuchVendors = HowMuchVendors+1
		end
	end

	if HowMuchVendors < 7 then
		local CenterPosesFinished = table.Random(LivePoses) -- +
		local VendorNPC = ents.Create( "npc_dealer" )
		VendorNPC:SetPos( CenterPosesFinished[1] )
		VendorNPC:SetAngles( CenterPosesFinished[2] )
		VendorNPC:Spawn()
		VendorNPC:Activate()
		ply:ConCommand("createVendorMark "..CenterPosesFinished[1].x.." "..CenterPosesFinished[1].y.." "..CenterPosesFinished[1].z+32)
	else
		local EntTable = {}

		for k, v in pairs( ents.GetAll() ) do
			if v:GetClass() == "npc_dealer" then
				table.insert(EntTable, v:GetPos())
			end
		end

		local Position = table.Random(EntTable)
		ply:ConCommand("createVendorMark "..Position.x.." "..Position.y.." "..Position.z+32)
	end
end

concommand.Add("calldealer",call_crime_vendor)