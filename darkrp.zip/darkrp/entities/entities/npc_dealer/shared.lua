ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.PrintName		= "Crime Vendor"
ENT.Author			= "pakun"
ENT.Category        = "NPC"
ENT.Spawnable       = true


function ENT:SetupDataTables()
	self:NetworkVar("String", 1, "VendorName")
	self:NetworkVar("String", 2, "VendorGender")
end