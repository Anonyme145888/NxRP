local PANEL = {}

function PANEL:Init()
	self:SetKeyboardInputEnabled(false)
end

function PANEL:SetEntity(ent)
	self.Entity = ent

	local title = self:AddTitle(DarkRP.getPhrase("money_printer"))
	--self:SetSize(400, 500)

	do -- warn
		local warn = vgui.Create("EditablePanel", self)
		self.warn = warn
		warn:SetTall(yscale(40))
		warn:Dock(TOP)
		warn:DockMargin(0, 0, 0, SmallMargin)

		local image = vgui.Create("DImage", warn)
		image:SetImage("icon16/error.png")
		image:SizeToContents()
		image:Dock(LEFT)
		image:DockMargin(0, MediumMargin, 0, MediumMargin)
		image:SetWide(yscale(40) - MediumMargin * 2)

		local lbl = Label(DarkRP.getPhrase("printer_warning"), warn)
		lbl:SetFont("DermaNotDefault")
		lbl:SizeToContents()
		lbl:Dock(LEFT)
		lbl:DockMargin(SmallMargin, 0, 0, 0)
	end

	local progress = vgui.Create("DProgress", self)
	progress:Dock(TOP)
	progress:DockMargin(0, LargeMargin, 0, LargeMargin)
	progress:SetTall(yscale(32))

	function progress.Think()
		local ent = self.Entity
		if ent:IsValid() then
			progress:SetFraction(not ent:GetActive() and 0 or (CurTime() - ent:GetStart()) / ent:GetDuration())
		end
	end

	function progress:Paint(w, h)

		local frac = math.Clamp(self:GetFraction(), 0, 1)

		surface.SetDrawColor(Color(0, 0, 0, 150))
		surface.DrawRect(0, 0, w, h)

		local pos = (w - 2) * frac
		surface.SetDrawColor(Color(100, 200, 50, 200))
		surface.DrawRect(1, 1, pos, h - 2)

		surface.SetFont("DermaNotDefault")
		surface.SetTextColor(color_white)

		local txt = ("%.1f%%"):format(frac * 100)
		local tw, th = surface.GetTextSize(txt)

		surface.SetTextPos(math.max(1, pos - tw), (h - th)/2)
		surface.DrawText(txt)
	end

	local labelCollect = vgui.Create("DLabel", self)
	self.labelCollect = labelCollect
	labelCollect:SetText(" ")
	labelCollect:SetFont("DermaNotLarge")
	labelCollect:SetContentAlignment(5)
	labelCollect:SizeToContents()
	labelCollect:Dock(TOP)
	labelCollect:DockMargin(0, 0, 0, LargeMargin)

	local buttonsDiv = vgui.Create("EditablePanel", self)
	buttonsDiv:Dock(TOP)
	buttonsDiv:SetTall(yscale(48))

	local button = vgui.Create("NxButton", buttonsDiv)
	self.button = button
	button:SetName("PRESS ME DAMN IT")
	button:Dock(LEFT)
	button:DockMargin(0, 0, SmallMargin, 0)
	button:SetText(DarkRP.getPhrase("printer_stop"))
	button:SizeToContents()
	local w = button:GetWide()
	button:SetText(DarkRP.getPhrase("printer_start"))
	button:SizeToContents()
	button:SetWide(math.max(w, button:GetWide()) + yscale(20))

	function button.DoClick()
		surface.PlaySound("ui/buttonclickrelease.wav")

		net.Start("PrinterCommand")
			net.WriteEntity(self.Entity)
			net.WriteUInt(self.Entity:GetActive() and 2 or 1, 4)
		net.SendToServer()
	end

	local buttonCollect = vgui.Create("NxButton", buttonsDiv)
	self.buttonCollect = buttonCollect
	buttonCollect:Dock(FILL)
	buttonCollect:SetText(DarkRP.getPhrase("printer_collect"))
	buttonCollect:SizeToContents()
	buttonCollect:SetDisabled(true)

	function buttonCollect.DoClick()
		surface.PlaySound("ui/buttonclickrelease.wav")

		net.Start("PrinterCommand")
			net.WriteEntity(self.Entity)
			net.WriteUInt(3, 4)
		net.SendToServer()
	end

	buttonCollect.color = Color(0x38, 0x8E, 0x3C)
	buttonCollect.color_hover = Color(0x4C, 0xAF, 0x50)
	buttonCollect.color_down = Color(0x1B, 0x5E, 0x20)

	self:SetTall(LargeMargin + title:GetTall() + MediumMargin + self.warn:GetTall() + SmallMargin + LargeMargin + yscale(32) + LargeMargin + labelCollect:GetTall() + LargeMargin + buttonsDiv:GetTall() + MediumMargin + yscale(32) + LargeMargin)
	self:SetWide(yscale(400))
	self:Center()
end

function PANEL:Think()
	if self.Entity:IsValid() and not self.Entity:GetPolice() then
		if self.Entity:GetActive() then
			self.button:SetText(DarkRP.getPhrase("printer_stop"))
			self.button.color = Color(0x45, 0x5A, 0x64, 255)
			self.button.color_hover = Color(0x54, 0x6E, 0x7A, 255)
			self.button.color_down = Color(0x37, 0x47, 0x4F, 255)
			self.button.color_disabled = Color(0x26, 0x32, 0x38)
		else
			self.button:SetText(DarkRP.getPhrase("printer_start"))
			self.button.color = Color(0x28, 0x35, 0x93)
			self.button.color_hover = Color(0x30, 0x3F, 0x9F)
			self.button.color_down = Color(0x1A, 0x23, 0x7E)
			self.button.color_disabled = Color(0x45, 0x5A, 0x64)
		end

		self.labelCollect:SetText(DarkRP.getPhrase("printer_printed", DarkRP.formatMoney(self.Entity:GetPrintedAmount())))
		self.labelCollect:SizeToContents()
		self.buttonCollect:SetDisabled(self.Entity:GetPrintedAmount() <= 0)
	else
		self:Remove()
	end
end

derma.DefineControl("PrinterGUI", "", PANEL, "NxGenericFrame")

local menu
function ENT:OpenPanel()
	if menu and menu:IsValid() then
		menu:Remove()
		return
	end

	menu = vgui.Create("PrinterGUI")
	menu:SetEntity(self)
end

net.Receive("PrinterCommand", function()
	local ent = net.ReadEntity()
	if ent:IsValid() then
		ent:OpenPanel()
	end
end)