AddCSLuaFile("cl_init.lua")
AddCSLuaFile("cl_ui.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")
util.AddNetworkString("PrinterCommand")

function ENT:Initialize()
	--activator check variable--
	self:SetActivator(nil)

	self:SetDestroyed(false)

	self:SetActive(false)

	self:SetUseType(SIMPLE_USE)
	self:SetModel("models/grinchfox/rp/printer2.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)

	self:SetSolid(SOLID_VPHYSICS)
	self:SetCollisionGroup(COLLISION_GROUP_NONE)
	self.PrinterHealth = 100
	self.timer = CurTime()
	self.igniteTimer = CurTime()

	local phys = self:GetPhysicsObject()
	if phys and phys:IsValid() then
		phys:Wake()
	end
	-- We need to destroy his fucking printer so he doesnt farm money!
	local mathrand = math.random -- OPTIMISATION INITIALIZED
	self.maxTemperature = mathrand(1800, 14400)
end

function ENT:OnRemove()

end

--typical entity damage function--
function ENT:OnTakeDamage(dmg)
	if dmg:GetInflictor():GetClass() != "entityflame" then return end

	self:TakePhysicsDamage(dmg)
	if(self.PrinterHealth <= 0) then return end

	self.PrinterHealth = self.PrinterHealth - dmg:GetDamage();

	if(self.PrinterHealth <= 0) then
		self:SetDestroyed(true)
		self:Destruct()
		self:Remove()
	end
end

--typical destruct funtion--
function ENT:Destruct()
    local vPoint = self:GetPos()
    local effectdata = EffectData()
    effectdata:SetStart(vPoint)
    effectdata:SetOrigin(vPoint)
    effectdata:SetScale(1)
	util.Effect("glass_fleck", effectdata)

	if IsValid(self:Getowning_ent()) then
		DarkRP.notify(self:Getowning_ent(), 1, 4, DarkRP.getPhrase("money_printer_exploded"))
	end
end

function ENT:Think()
	--sets timer to every 2 seconds
	if CurTime() > self.timer + 90 then
		self.timer = CurTime()
		if self:GetActive() == true then
				self:SetPrintedAmount(self:GetPrintedAmount() + 1000)

            self:SetStart(CurTime())
			self:SetDuration(90)

			self:EmitSound("gxrp/interruptone.ogg")
		end
	end

	if CurTime() > self.igniteTimer + 0.25 then
		self.igniteTimer = CurTime()
		if self:GetActive() == true && self:IsOnFire() != true then
			self:SetTemperature(self:GetTemperature() + 0.25)

			if self:GetTemperature() >= self.maxTemperature then
				self:Ignite(20)
				self:SetTemperature(self:GetTemperature() / 2)
			end
		end
	end

	if self:GetActive() == true then
	   self:StartSound()
	end
end

--when a player presses e on it--
function ENT:Use(activator, caller)
	if activator:IsPlayer() and not activator:isCP() then
		if self:GetPolice() == true then
			self:SetPolice(false)
			DarkRP.notify(activator, 1, 4, DarkRP.getPhrase("printer_fixed"))
		else
		    net.Start("PrinterCommand")
		    net.WriteEntity(self)
		    net.Send(activator)
		    self:SetActivator(activator)
		end
	elseif activator:IsPlayer() and activator:isCP() then
		self:SetPolice(true)
		self:SetActive(false)
		DarkRP.notify(activator, 4, 4, DarkRP.getPhrase("printer_disabled"))
		timer.Simple(240, function()
			if not IsValid(self) then return end

			if self:GetPolice() == true then
				self:SetPolice(false)
			end
		end)
	end
end

function PrinterCommand(len, ply)
	local ent = net.ReadEntity()
	local cmd = net.ReadUInt(4)

	if IsValid(ent) and (ent:GetClass() == "money_printer" or ent:GetClass() == "money_printer_premium") then
		if(ply:GetPos():Distance(ent:GetPos()) < 100) then
			if cmd == 1 and ent:GetActive() == false then
				ent:SetStart(CurTime())
				ent:SetDuration(90)
				ent:SetActive(true)
			elseif cmd == 2 and ent:GetActive() == true then
				ent:SetActive(false)
				ent.timer = 0
			elseif cmd == 3 then
				if not ent:GetPolice() == true then
				   local amount = ent:GetPrintedAmount()
				   if amount <= 0 then return end
				   ply:addMoney(amount)
				   ent:SetPrintedAmount(0)
				else
					DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("printer_disabled"))
				end
			end
		end
	end	
end
net.Receive("PrinterCommand", PrinterCommand)

function ENT:StartSound()
    self.sound = CreateSound(self, Sound("gxrp/recyclerop.ogg"))
    self.sound:SetSoundLevel(75)
    self.sound:PlayEx(1, 100)
end
