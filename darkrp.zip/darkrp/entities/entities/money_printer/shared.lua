ENT.Base = "base_gmodentity"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "DarkRP"
ENT.IsMoneyPrinter = true

function ENT:SetupDataTables()
	self:NetworkVar("Int", 1, "PrintedAmount")
	self:NetworkVar("Entity", 2, "owning_ent")
	self:NetworkVar("Bool", 3, "Active")
	self:NetworkVar("Bool", 4, "Destroyed")
	self:NetworkVar("Entity", 5, "Activator")
	self:NetworkVar("Bool", 6, "Police")

	self:NetworkVar("Float", 0, "Start")
	self:NetworkVar("Float", 1, "Duration")
	self:NetworkVar("Float", 2, "Temperature")
end
