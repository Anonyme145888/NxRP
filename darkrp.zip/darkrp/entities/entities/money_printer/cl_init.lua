include("shared.lua")
ENT.PrintName = DarkRP.getPhrase("money_printer")
include("cl_ui.lua")

function ENT:UseClientside(pl)
    if self:IsOnFire() or self:GetPolice() or pl:isCP() then return end

    -- Vérification si l'imprimante est restreinte ou non
    -- Remplace DarkRP.isPrinterRestricted(pl) par une condition appropriée
    if pl:Team() == TEAM_POLICE and pl:isCP() then
        DarkRP.notify(NOTIFY_ERROR, 4, DarkRP.getPhrase("printer_onlygang_use"))
        return
    end

    self:OpenPanel()
end

local color1 = Color(0, 64, 0)
local color_green = Color(0, 255, 0)
local color_red = Color(255, 0, 0)

local bgcol = Color(0, 0, 0, 192)
local maxdist = 512^2
function ENT:Draw()
	self.Entity:DrawModel()

	if self:GetPos():DistToSqr(EyePos()) < maxdist then
		surface.SetFont("DermaLarge")

		local feelingbad = self:GetPolice()

		if feelingbad and (not self.nextRandColor or RealTime() >= self.nextRandColor) then
			local hue = math.random(0, 359)
			self.randColor1 = HSVToColor(hue, 1, 1)
			self.randColor2 = HSVToColor((hue - 180)%360, 1, 1)
			self.randStr = string.char(math.random(65, 90), math.random(65, 90), math.random(65, 90), math.random(65, 90), math.random(65, 90), math.random(65, 90))
			self.randProgress = math.random()
			self.nextRandColor = RealTime() + 0.1 + math.random() * 0.1
		end

		local color = feelingbad and  self.randColor1 or self:GetActive() and color_green or color_red
		local color2 = feelingbad and self.randColor2 or color1

		local status = feelingbad and self.randStr or self:GetActive() and "PRINTING" or "IDLE"

		local amount = DarkRP.formatMoney(self.Entity:GetPrintedAmount())
		local progress = feelingbad and math.abs(math.sin(RealTime())) or math.min(1, not self:GetActive() and 0 or (CurTime() - self:GetStart()) / self:GetDuration())

		cam.Start3D2D(self:LocalToWorld(Vector(15.2, 14, 4)), self:LocalToWorldAngles(Angle(0, 90, 90)), 0.08)
			draw.WordBox(2, -surface.GetTextSize(status) - 4, -20, status, "DermaLarge", color_transparent, color)
			draw.WordBox(2, -320, -20, amount, "DermaLarge", color_transparent, color)

			if self:GetActive() or feelingbad then
				surface.SetDrawColor(color2)
				surface.DrawRect(-320, 35, 320, 5)
				surface.SetDrawColor(color)
				surface.DrawRect(-320, 35, 320 * progress, 5)
			end
		cam.End3D2D()
	end
end

do -- glass fleck
	local EFFECT = {}

	local function Stay(particle, pos, normal)
		--particle:SetBounce(1)
		--particle:SetVelocity(particle:GetVelocity() * 0.6)
		--particle:SetPos(pos + normal*8)
		--particle:SetGravity(Vector())

		if math.Rand(0, 1) < 0.3 then
			--EmitSound("physics/glass/glass_bottle_break" .. math.random(1, 2) .. ".wav", pos, 0, 0, 1, 90, 0, math.Rand(100, 120))
		end

		-- COLLISION SOUND HERE
	end

	function EFFECT:Init(data)
		local emitter = ParticleEmitter(data:GetOrigin())
		local vec_1_1_0 = Vector(1, 1, 0)
		for i = 1, 50 do
			local p = emitter:Add("effects/fleck_glass" .. math.random(1, 3), data:GetOrigin() + vector_up * 8 + VectorRand()*16)
			p:SetVelocity(VectorRand() * vec_1_1_0 * math.Rand(100, 150) + vector_up * math.Rand(200, 300))
			p:SetDieTime(30)
			p:SetStartSize(8)
			p:SetEndSize(8)
			p:SetGravity(vector_up * -600)
			p:SetCollide(1)
			p:SetRollDelta(math.Rand(-30, 30))
			--p:SetCollideCallback(Stay)
		end
	end

	function EFFECT:Think()
	end

	function EFFECT:Render()
	end

	effects.Register(EFFECT, "glass_fleck")
end

matproxy.Add{
	name = "PrintSpeed",
	init = function(self, mat, values)
		self.mat_resultvar = values["resultvar"]
	end,
	bind = function(self, mat, ent)
		if ent.GetActive and ent:GetActive() then
			mat:SetFloat(self.mat_resultvar, 2)
		else
			mat:SetFloat(self.mat_resultvar, 0)
		end
	end
}