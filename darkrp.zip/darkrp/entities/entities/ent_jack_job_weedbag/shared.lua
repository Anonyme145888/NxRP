ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Marijuana"
ENT.Category  = "DarkRP"
ENT.Author = "Jackarunda"
ENT.Spawnable = true
-- marijuana is bad m'kay
