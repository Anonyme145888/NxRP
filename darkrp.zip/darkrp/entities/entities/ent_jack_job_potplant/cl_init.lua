include("shared.lua")
function ENT:Initialize()
    --
end
local Leaf=surface.GetTextureID("mat_jack_job_potleaf")
function ENT:Draw()
    self:DrawModel()
	local ang = Angle(0,90,45)
	local dmin = 128
	local dmax = 180
	
	local col_bg = Color(32,32,32,220)
	local col_stat_icon = Color(255,200,128)
	local col_stat_text = Color(200,200,200)
	
	local le = self:WorldToLocal(EyePos())
	local d = le:Length()
	if d > dmax then return end
	local dfrac = math.Remap( d, dmin, dmax, 1, 0)

	le.z = 0
	le = le:GetNormalized()*10
	le.z = 12

	epos = self:LocalToWorld( le )

	local angle = self:LocalToWorldAngles( le:Angle() )
	angle:RotateAroundAxis( angle:Right(), -90 )
	angle:RotateAroundAxis( angle:Up(), 90 )
	cam.Start3D2D( epos, angle , 0.1 )
		surface.SetAlphaMultiplier( dfrac )
		surface.SetDrawColor(color_white)
		draw.RoundedBox( 8, -115, 0, 230,90, col_bg )
		--[[
		surface.SetTextColor(color_white)

		surface.SetFont("DermaLarge")
		surface.SetTextPos(-117,-7)
		surface.DrawText("S")
	    ]]
		surface.SetTextColor(color_white)
		surface.SetFont"DermaLarge"
		surface.SetTextPos(-110,0)
		surface.DrawText("Влажность: "..math.floor(self:GetHydration()).."%")
		surface.SetAlphaMultiplier( 1 )
		
		surface.SetTextColor(color_white)
		surface.SetFont"DermaLarge"
		surface.SetTextPos(-110,30)
		surface.DrawText("Свет: "..math.floor(self:GetPlantHealth()).."%")
		surface.SetAlphaMultiplier( 1 )
		surface.SetTextColor(color_white)
		surface.SetFont"DermaLarge"
		surface.SetTextPos(-110,60)
		surface.DrawText("Стадия: "..math.floor(self:GetStage()).."%")
		surface.SetAlphaMultiplier( 1 )
        --[[
		local text = "Plant"
		local w,h = surface.GetTextSize( text )
		surface.SetTextPos(115-w-8, 0)
		surface.DrawText( text )
		]]
	cam.End3D2D()
    
end
function ENT:Think()
    --
end
local JackaDrugDealer,RotateAng=ents.FindByClass("npc_*")[1],0
net.Receive("JackaJobWeedDealerID",function(length,ply)
	JackaDrugDealer=net.ReadEntity()
end)
hook.Add("PostDrawTranslucentRenderables","JackaJobWeedDealerID",function()
	if((JackaDrugDealer)and(IsValid(JackaDrugDealer)))then
		local self=JackaDrugDealer
		RotateAng=RotateAng+.5
		if(RotateAng>360)then RotateAng=0 end
		local SelfPos,Up,Right,Forward,Ang=self:GetPos(),self:GetUp(),self:GetRight(),self:GetForward(),Angle(-180,-180+RotateAng,-90)
		cam.Start3D2D(SelfPos+Up*80,Ang,.1)
		draw.SimpleTextOutlined("Drug Dealer","Trebuchet24",0,0,Color(255,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,1,Color(0,0,0,255))
		cam.End3D2D()
		Ang:RotateAroundAxis(vector_up,180)
		cam.Start3D2D(SelfPos+Up*80,Ang,.1)
		draw.SimpleTextOutlined("Drug Dealer","Trebuchet24",0,0,Color(255,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,1,Color(0,0,0,255))
		cam.End3D2D()
	end
end)