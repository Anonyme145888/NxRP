ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Sun Lamp"
ENT.Category  = "DarkRP"
ENT.Author = "Jackarunda"
ENT.Spawnable = true
function ENT:SetupDataTables()
    self:NetworkVar("Bool",0,"Active")
end