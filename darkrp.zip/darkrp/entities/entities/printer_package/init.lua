AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include("shared.lua");

function ENT:Initialize()
	self:SetModel("models/Items/item_item_crate.mdl")
	
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);
	
	self:SetDTInt(0, 0);
	self:SetDTBool(0, false);
	
	timer.Simple( 0.01, function()
		if !self:GetDTBool(0) then
			self:GetPhysicsObject():EnableMotion(true);
			self:GetPhysicsObject():SetVelocity(self:GetUp()*2);
		end;
	end)
end

util.AddNetworkString("PrinterCrack")
function ENT:AcceptInput(name, caller)
	if name == "Use" and caller:IsPlayer() then
		if self:IsValid() then
		
		self:Destruct()
		
        self:PrecacheGibs()
	    net.Start("PrinterCrack")
	    net.WriteEntity(self)
	    net.Broadcast()

	    self:Remove()

		self:EmitSound("physics/wood/wood_crate_break4.wav")
		local packagepos = self:GetPos()
    	local packagea = ents.Create("money_printer")
    	packagea:SetPos(Vector(packagepos))
    	packagea:SetOwner( caller )
    	packagea.nodupe = true
		packagea:Spawn()
		packagea:Activate()
	    else
		end
	end
end

function ENT:OnTakeDamage(dmg)
    self:TakePhysicsDamage(dmg)

    if self.burningup then return end

    self.damage = (self.damage or 100) - dmg:GetDamage()
    if self.damage <= 0 then
        self:Destruct()
        self:GibBreakClient(Vector(math.random(-40, 40), math.random(-40, 40), math.random(-40, 40)))
        self:Remove()
    end
end

function ENT:Destruct()
    local vPoint = self:GetPos()
    local effectdata = EffectData()
    effectdata:SetStart(vPoint)
    effectdata:SetOrigin(vPoint)
    effectdata:SetScale(1)
    util.Effect("package_smoke", effectdata)
end
