﻿--[[
gamemodes/darkrp/entities/entities/crate_printer/shared.lua
--]]
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Printer Crate"
ENT.Category = "DarkRP"
ENT.Author = "effe"
ENT.Spawnable = true

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "price")
    self:NetworkVar("Entity", 1, "owning_ent")
end


