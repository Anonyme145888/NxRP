--[[
gamemodes/darkrp/entities/entities/crate_printer/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
    self:DrawModel()
end

net.Receive("PrinterCrack", function()
	local printer = net.ReadEntity()
	--if printer:IsValid() then
	printer:GibBreakClient(Vector(math.random(-40, 40), math.random(-40, 40), math.random(-40, 40)))
    --end
end)

if CLIENT then
	local EFFECT = {}
	
	function EFFECT:Init(data)
		local emitter = ParticleEmitter(data:GetOrigin(), false)
		local particle = emitter:Add("particles/smokey", data:GetOrigin())
		particle:SetVelocity( vector_up * math.Rand( 10, 30 ) )
		particle:SetDieTime( 2.0 )
		particle:SetStartAlpha( 40 )
		particle:SetStartSize( math.Rand( 16, 32 ) )
		particle:SetEndSize( math.Rand( 128, 128 ) )
		particle:SetRoll( math.Rand( -0.2, 0.2 ) )
		particle:SetColor( 255, 255, 255 )
	end
	
	function EFFECT:Think()
	end
	
	function EFFECT:Render()
	end
	
	effects.Register(EFFECT, "package_smoke")
end

