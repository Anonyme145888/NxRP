AddCSLuaFile()
local BaseClass = baseclass.Get("base_gmodentity")

ENT.PrintName = "Radar Package"
ENT.Category = "DarkRP"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.CanPocket = true

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/props_lab/reciever01b.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:Activate()
	end

	util.AddNetworkString("vutil.radar")
	function ENT:Use(ply)
		if ply.vutilradar then
			DarkRP.notify(ply, 1, 4, "Vous avez déjà un radar !")
		else
			ply.vutilradar = true
			self:Remove()
			net.Start("vutil.radar")
				net.WriteBool(true)
			net.Send(ply)
		end
	end

	hook.Add("PlayerDeath", "vutil.radar", function(ply)
		ply.vutilradar = nil
		net.Start("vutil.radar")
			net.WriteBool(false)
		net.Send(ply)
	end)
end

function ENT:GetOverlayText()
	return "Radar"
end