--[[---------------------------------------------------------------------------
This is an example of a custom entity.
---------------------------------------------------------------------------]]
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

--[[
	Basic config
]]--

local Ar_fill_rate = 5
local Ar_plyfill_rate = 0.2

local Ar_printer_health = 100
local Ar_printer_storage = 100

local overheatchance = 1000



--ENT.SeizeReward = 950

local PrintMore
function ENT:Initialize()
	self:SetModel("models/props_combine/suit_charger001.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.sparking = false
	self.damage = Ar_printer_health
	self.IsMoneyPrinter = true
	
	self:SetNWInt("Armour_amount",0)

	--self.sound:SetSoundLevel(52)
	--self.sound:PlayEx(1, 100)
end

function ENT:OnTakeDamage(dmg)
	if self.burningup then return end

	self.damage = (self.damage or Ar_printer_health) - dmg:GetDamage()
	if self.damage <= 0 then
		local rnd = math.random(1, 10)
		if rnd < 3 then
			self:BurstIntoFlames()
		else
			self:Destruct()
			self:Remove()
		end
	end
end

function ENT:PhysicsCollide(data, phys)
    local Class = data.HitEntity:GetClass()


    if Class == "charge_battery" then
		self:SetNWInt("Armour_amount", 100)
		data.HitEntity:Remove()
		self:EmitSound("physics/metal/metal_computer_impact_bullet1.wav")
    end

end

function ENT:Destruct()
	local vPoint = self:GetPos()
	local effectdata = EffectData()
	effectdata:SetStart(vPoint)
	effectdata:SetOrigin(vPoint)
	effectdata:SetScale(1)
	util.Effect("Explosion", effectdata)
end

function ENT:Fireball()
	if not self:IsOnFire() then self.burningup = false return end
	local dist = math.random(20, 280) -- Explosion radius
	self:Destruct()
	for k, v in pairs(ents.FindInSphere(self:GetPos(), dist)) do
		if not v:IsPlayer() and not v:IsWeapon() and v:GetClass() ~= "predicted_viewmodel" and not v.IsMoneyPrinter then
			v:Ignite(math.random(5, 22), 0)
		elseif v:IsPlayer() then
			local distance = v:GetPos():Distance(self:GetPos())
			v:TakeDamage(distance / dist * 100, self, self)
		end
	end
	self:Remove()
end

function ENT:BurstIntoFlames()
	self.burningup = true
	local burntime = math.random(8, 18)
	self:Ignite(burntime, 0)
	timer.Simple(burntime, function() self:Fireball() end)
end


PrintMore = function(ent)
	if not IsValid(ent) then return end

end



function ENT:Think()

	if self:WaterLevel() > 0 then
		self:Destruct()
		self:Remove()
		return
	end

	if not self.sparking then return end

	local effectdata = EffectData()
	effectdata:SetOrigin(self:GetPos())
	effectdata:SetMagnitude(1)
	effectdata:SetScale(1)
	effectdata:SetRadius(2)
	util.Effect("Sparks", effectdata)
end

function ENT:OnRemove()
	if self.sound then
		self.sound:Stop()
	end
end

local hp_no_spam = 0

function ENT:Use(activator, caller)
    --self.sound = CreateSound(self, Sound("ambient/levels/labs/equipment_printer_loop1.wav"))
    if self:GetNWInt("Armour_amount") > 0 and caller:Armor() < 100 then
        self:EmitSound("hl1/fvox/boop.wav", 150, caller:Armor() + 10, 1, CHAN_AUTO) -- Stolen from darkrp gamemode :(

        if hp_no_spam == 0 then
            hp_no_spam = 1
            local to_take = self:GetNWInt("Armour_amount") - 1
            local to_add = caller:Armor() + 1
            self:SetNWInt("Armour_amount", to_take)
            caller:SetArmor(to_add)

            timer.Simple(Ar_plyfill_rate, function()
                hp_no_spam = 0
            end)
		end
	else
		if caller:Armor() >= 100 then
			if self.lastMessage and (RealTime() - self.lastMessage) < 1.7 then
				return
			end
			self:EmitSound("items/suitchargeno1.wav")
			self.lastMessage = RealTime()
			
		end

		if self:GetNWInt("Armour_amount") <= 0 then
			if self.lastMessage and (RealTime() - self.lastMessage) < 1.7 then
				return
			end
			self:EmitSound("items/suitchargeno1.wav")
			self.lastMessage = RealTime()
		end
    end
end