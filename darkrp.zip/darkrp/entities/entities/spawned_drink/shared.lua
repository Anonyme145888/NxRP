ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Spawned Drink"
ENT.Author = "Rickster"
ENT.Spawnable = false
ENT.IsSpawnedDrink = true

function ENT:SetupDataTables()
    self:NetworkVar("Entity", 1, "owning_ent")
end
