AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE_DEBRIS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()
end

function ENT:OnTakeDamage(dmg)
    self:Remove()
end

function ENT:Use(activator, caller)
    local override = self.drinkItem.onEaten and self.drinkItem.onEaten(self, activator, self.drinkItem)

    if override then
        self:Remove()
        return
    end

    activator:setSelfDarkRPVar("Energy", math.Clamp((activator:getDarkRPVar("Thirst") or 50) + (self:GetTable().DrinkThirst or 1), 0, 100))
    umsg.Start("AteFoodIcon", activator)
    umsg.End()
    self:Remove()
end