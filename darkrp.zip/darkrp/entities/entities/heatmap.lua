AddCSLuaFile()
DEFINE_BASECLASS("base_gmodentity")

ENT.PrintName = "Heatmap Package"
ENT.Category = "DarkRP"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.CanPocket = true

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/beer/wiremod/gps.mdl")
		self:SetColor(Color(255,128,0))
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:Activate()
	end

	function ENT:Use(ply)
		if ply.upgrade_heatmap then
			DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("heatmap_already"))
		else
			ply.upgrade_heatmap = true
			self:Remove()
		end
	end

	hook.Add("PlayerDeath", "upgrade_heatmap", function(ply)
		ply.upgrade_heatmap = false
	end)
end

function ENT:GetOverlayText()
	return "Heatmap"
end