include("shared.lua")

local color_translucent_gray = Color(30,30,30,200)
local color_white = Color(255,255,255)

function ENT:Draw()
    self:DrawModel()

    cam.Start3D2D(self:LocalToWorld(Vector(0,-25,85)), self:LocalToWorldAngles(Angle(0, 90, 90)), 0.1)
        draw.RoundedBox(25, 0, 0, 500, 100, color_translucent_gray)
        draw.SimpleText("Achete un hélicoptère pour "..DarkRP.formatMoney(self:GetPrice()), "DermaLarge", 250, 50, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local waitTime = self:GetWaitTime()
        if waitTime > 0 then
            local secToGo = waitTime%60
            local minToGo = (waitTime-secToGo)/60
            draw.SimpleText(string.format("%02d", minToGo)..":".. string.format("%02d", secToGo), "DermaLarge", 250, -30, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    cam.End3D2D()
end

local function RespX(x)
    return x/1920 * ScrW()
end

local function RespY(y)
    return y/1080 * ScrH()
end
