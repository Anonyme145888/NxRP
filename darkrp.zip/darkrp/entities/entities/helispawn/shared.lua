ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.PrintName = "Heli Seller"
ENT.Category = "GxServ | Hélico"
ENT.Spawnable = true
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
    self:NetworkVar("Float", 1, "WaitTime")
    self:NetworkVar("Int", 1, "Price")
end