AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

local SpawnPos = {
}

local Price = 20000
local WaitTime = 1800 --en seconde

local ok_speech = {"vo/npc/male01/ok01.wav","vo/npc/male01/ok02.wav"}
local no_speech = {"vo/npc/male01/no01.wav","vo/npc/male01/no02.wav","vo/npc/male01/notthemanithought01.wav","vo/npc/male01/notthemanithought02.wav"}

function ENT:Initialize()
    self:SetModel("models/Humans/Group02/Male_04.mdl")
    self:SetHullType(HULL_HUMAN)
    self:SetHullSizeNormal()
    self:SetNPCState(NPC_STATE_SCRIPT)
    self:SetSolid(SOLID_BBOX)
    self:CapabilitiesAdd(CAP_ANIMATEDFACE)
    self:SetUseType(SIMPLE_USE)
    self:DropToFloor()
    self:SetMaxYawSpeed(90)

    self:SetPrice(Price)
    self:SetWaitTime(10)
end

function ENT:OnTakeDamage()
    return false
end

function ENT:Use(activator)
    if self:GetWaitTime()>0 or not activator:canAfford(Price) then
        self:EmitSound(no_speech[math.random(#no_speech)])
    else
        self:SetWaitTime(WaitTime)
        self:EmitSound(ok_speech[math.random(#ok_speech)])
        activator:addMoney(-Price)
        local heli = ents.Create("sent_helicopter_nonadmin")
        heli:SetPos(self:GetPos()+self:GetForward()*400+Vector(0,0,100))
        heli:Spawn()
        heli:DropToFloor()
    end
   
end

function ENT:Think()
    self:NextThink(CurTime())
    local oldTime = self:GetWaitTime()
    if oldTime>0 then
       self:SetWaitTime(math.Clamp(oldTime-FrameTime(),0,WaitTime))
    end

    return true

end

function spawnNPCS() 
    for k,v in ipairs(SpawnPos) do
        local NPC = ents.Create("helispawn")
        NPC:SetPos(v.pos)
        NPC:SetAngles(v.ang)
        NPC:Spawn()
        NPC:DropToFloor()
    end
end

timer.Simple(1,spawnNPCS)
