
ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName		= "Helicopter (no weapons)"
ENT.Author			= "Sakarias88"
ENT.Category 		= "Air Vehicles"
ENT.Contact    		= ""
ENT.Purpose 		= ""
ENT.Instructions 	= "" 

ENT.Spawnable			= true
ENT.AdminSpawnable		= true
