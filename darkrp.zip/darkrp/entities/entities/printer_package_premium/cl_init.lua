--[[
gamemodes/darkrp/entities/entities/crate_printer/cl_init.lua
--]]
include("shared.lua")

function ENT:Draw()
    self:DrawModel()
end

