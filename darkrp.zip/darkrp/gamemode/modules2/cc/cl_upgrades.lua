--[[
gamemodes/darkrp/gamemode/modules2/government_extras/cl_upgrades.lua
--]]
local haloenabled

net.Receive("police_halo", function()
	haloenabled = true
end)

net.Receive("police_halo_disabled", function()
	haloenabled = false
end)



local damaged = {}

net.Receive("police_halo_damage", function()

	local id = net.ReadUInt(16)

	damaged[id] = true

	timer.Create("police_halo_damage" .. id, 2, 1, function()

		damaged[id] = nil

	end)

end)



hook.Add("minimap", "police", function(map)

	if haloenabled then

		local lp = LocalPlayer()

		for _, ply in ipairs(player.GetAll()) do

			if ply ~= lp and not ply:GetNoDraw() and ply:Alive() and ply:isCP() then

				map:drawMarker(nmap.mat.arrow, ply, math.max(10, map:scalePixels(20)), damaged[ply:UserID()] and ray.colors.red or ply:GetNWBool("Radio") and getRadioMates(ply)[lp] and ray.colors.DarkRP or ray.colors.green, ply)

			end

		end

	end

end)



hook.Add("PreDrawOutlines", "police_halo", function()

	if haloenabled then

		local lp = LocalPlayer()

		local pos = lp:GetPos()

		for _, ply in ipairs(player.GetAll()) do

			if ply ~= lp and not ply:GetNoDraw() and ply:Alive() and pos:DistToSqr(ply:GetPos()) < 30470400 and ply:isCP() then

				local b1, b2 = ply:GetRenderBounds()

				local poss = {

					b1,

					b2,

					Vector(b2[1], b1[2], b1[3]),

					Vector(b1[1], b2[2], b1[3]),

					Vector(b1[1], b1[2], b2[3]),

					Vector(b2[1], b2[2], b1[3]),

					Vector(b1[1], b2[2], b2[3]),

					Vector(b2[1], b1[2], b2[3]),

				}

				for _, pos in next, poss do

					local toscr = ply:LocalToWorld(pos):ToScreen()

					if toscr.visible and toscr.x > 0 and toscr.y > 0 and toscr.x < ScrW() and toscr.y < ScrH() then

						outline.Add(ply, damaged[ply:UserID()] and ray.colors.red or ply:GetNWBool("Radio") and getRadioMates(ply)[lp] and ray.colors.DarkRP or ray.colors.green)

						break

					end

				end

			end

		end

	end

end)