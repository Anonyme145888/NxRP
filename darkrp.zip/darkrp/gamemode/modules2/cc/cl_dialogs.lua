--[[
gamemodes/DarkRP/gamemode/modules/ui/cl_dialogs.lua
--]]
function DarkRP.DermaQuery(strTitle, strText, ...)
	local Window = vgui.Create("NxGenericFrame")
	local title = Window:AddTitle(strTitle or "")
	Window:SetKeyboardInputEnabled(false)
	Window.backButtonDocking:SetVisible(false)

	--local InnerPanel = vgui.Create("EditablePanel", Window)

	local Text = vgui.Create("DLabel", Window)
	Text:SetFont("DermaNotDefault")
	Text:SetText(strText or "")
	Text:SizeToContents()
	--Text:SetContentAlignment(5)
	Text:DockMargin(0, MediumMargin, 0, LargeMargin)
	Text:SetTextColor(color_white)
	Text:Dock(TOP)

	local ButtonPanel = vgui.Create("EditablePanel", Window)
	ButtonPanel:SetTall(yscale(32))
	ButtonPanel:Dock(TOP)

	local x = 5

	for k = 1, 8, 2 do
		local Text = select(k, ...)
		if Text == nil then break end

		local Func = select(k + 1, ...) or function() end

		local Button = vgui.Create("NxButton", ButtonPanel)
		Button:SetText(Text)

		if Text == DarkRP.getPhrase("yes") or Text == DarkRP.getPhrase("ok") or Text == "OK" then
			Button:SetPrimaryMainColors()
		end

		Button:AutoSize()
		Button.DoClick = function()
			Window:Remove()
			Func()
		end
		Button:Dock(LEFT)
		Button:DockMargin(0, 0, MediumMargin, 0)
	end

	--local w, h = Text:GetSize()

	--w = math.max(w, ButtonPanel:GetWide())

	--Window:SetSize(w + 50, h + 25 + 45 + 10)
	--Window:Center()

	--InnerPanel:StretchToParent(5, 25, 5, 45)

	--Text:StretchToParent(5, 5, 5, 5)

	--ButtonPanel:CenterHorizontal()
	--ButtonPanel:AlignBottom(8)

	--Window:MakePopup()
	--Window:SetKeyboardInputEnabled(false)
	--Window:DoModal()

	Window:SetWide(LargeMargin*2 + math.max(title:GetWide(), Text:GetWide()))
	Window:SetTall(LargeMargin + title:GetTall() + MediumMargin + MediumMargin + Text:GetTall() + LargeMargin + yscale(32) --[[+ MediumMargin + yscale(32)]] + LargeMargin)
	Window:Center()

	return Window
end

-- TODO: Make a proper panel class instead of this bullshit

function DarkRP.StringRequest(title, text, okfunc, value, cancelfunc, oktext, canceltext)
	local frame = vgui.Create("NxGenericFrame")
	frame.backButtonDocking:SetVisible(false)
	frame.OnBackPress = function()
		if cancelfunc then
			cancelfunc()
		end

		return false
	end

	local title = frame:AddTitle(title or "")
	--frame:SetSizable(true)

	local warndock = frame:Add("Panel")
	warndock:Dock(TOP)
	warndock:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
	warndock.Paint = function(s, w, h)
		surface.SetDrawColor(255, 128, 32, 150)
		surface.DrawRect(0, 0, w, h)
	end
	local warn = warndock:Add("DLabel")
	warn:Dock(TOP)
	warn:SetFont("DermaNotDefault")
	warn:SetText("Warning\ntest")
	warn:SizeToContents()
	--warndock:SetTall(SmallMargin + warn:GetTall() + SmallMargin)
	warndock:InvalidateLayout(true)
	warndock:SizeToChildren(false, true)
	warndock:SetVisible(false)

	local label = frame:Add("DLabel")
	label:SetFont("DermaNotDefault")
	label:Dock(TOP)
	--label:DockMargin(6, 0, 6, 4)
	label:DockMargin(0, MediumMargin, 0, LargeMargin)
	label:SetText(text or "")
	label:SizeToContents()
	--label:SetContentAlignment(5)
	label:SetTextColor(color_white)

	local antinazi = frame:Add("EditablePanel")
	antinazi:Dock(TOP)
	antinazi:SetTall(yscale(40))
	antinazi:DockMargin(0, 0, 0, LargeMargin)

	local textentry = antinazi:Add("DTextEntry")
	textentry:SetFont("DermaNotLarge")
	textentry:SetTall(yscale(40))
	textentry.Paint = nxui_DTextEntry_Paint
	textentry:Dock(FILL)
	textentry:SetText(value or "")
	textentry:SetDrawLanguageID(false)
	--textentry:SetDrawLanguageIDAtLeft(true)
	function textentry.OnEnter()
		if okfunc then
			okfunc(textentry:GetValue())
		end
		frame:Remove()
	end
	textentry:RequestFocus()
	textentry:SelectAllText(true)
	function textentry:OnTextChanged(...)
		surface.SetFont("DermaNotLarge")
		frame:SetWide(math.Clamp(surface.GetTextSize(self:GetValue()) + 6 * 2 + LargeMargin * 2, frame.minWide or 400, ScrW()))
		frame:Center()
		frame:updateMaxChars()
	end

	local maxchars = frame:Add("DLabel")
	maxchars:SetVisible(false)
	maxchars:Dock(TOP)
	maxchars:SetFont("DermaNotDefault")
	maxchars:SetText("0 / 100")
	maxchars:SetContentAlignment(6)
	maxchars:SizeToContents()

	frame.updateMaxChars = function()
		if not frame.maxCharacters then return end
		local fail, len = string.BadLen(textentry:GetValue(), 0, frame.maxCharacters)

		if fail or not len then
			maxchars:SetText(fail or "???")
			maxchars:SetTextColor(Color(0xD3, 0x2F, 0x2F))
		else
			maxchars:SetText(("%d / %d"):format(len, frame.maxCharacters))
			maxchars:SetTextColor(Color(180, 180, 180))
		end
	end

	local pricedock = frame:Add("EditablePanel")
	pricedock:SetVisible(false)
	pricedock:SetTall(yscale(32))
	pricedock:Dock(TOP)
	pricedock:DockMargin(0, 0, 0, LargeMargin)

	local symbol = pricedock:Add("DLabel")
	symbol:Dock(LEFT)
	symbol:SetFont("DermaNotLargeIcon")
	symbol:SetText("2")
	symbol:SetWide(yscale(32))
	symbol:DockMargin(0, 0, SmallMargin, 0)

	local price = pricedock:Add("DLabel")
	price:Dock(LEFT)
	price:SetFont("DermaNotLarge")
	price:SetText("35")
	price:SizeToContents()

	local footer = frame:Add("EditablePanel")
	footer:Dock(TOP)
	footer:SetTall(yscale(32))
	--footer:SetDrawBackground(false)
	--[[
	local orig = frame.PerformLayout
	function frame:PerformLayout(...)
		orig(self, ...)
		footer:DockPadding((frame:GetWide() - 8 - 60 - 12 - 60) / 2, 0, (frame:GetWide() - 8 - 60 - 12 - 60) / 2, 0)
	end
	]]


	local okbutton = footer:Add("NxButton")
	okbutton:Dock(LEFT)
	okbutton:DockMargin(0, 0, MediumMargin, 0)
	okbutton:SetText(oktext or "OK")
	okbutton:SetPrimaryMainColors()
	okbutton:SizeToContents()
	okbutton:AutoSize()
	function okbutton.DoClick()
		if okfunc then
			okfunc(textentry:GetValue())
		end
		frame:Remove()
	end

	local cancelbutton = footer:Add("NxButton")
	cancelbutton:Dock(LEFT)
	--cancelbutton:DockMargin(0, 0, 0, 0)
	cancelbutton:SetText(canceltext or DarkRP.getPhrase("cancel"))
	cancelbutton:SizeToContents()
	cancelbutton:AutoSize()
	function cancelbutton.DoClick()
		if cancelfunc then
			cancelfunc(textentry:GetValue())
		end
		frame:Remove()
	end

	frame:SetWide(math.max(400, math.max(title:GetWide(), label:GetWide()) + LargeMargin * 2))
	--frame:SetTall(LargeMargin + title:GetTall() + MediumMargin + MediumMargin + label:GetTall() + LargeMargin + yscale(40) + LargeMargin + yscale(32) + LargeMargin)
	frame:InvalidateLayout(true)
	frame:SizeToChildren(false, true)

	frame.SetPrice = function(_, tsymbol, tprice)
		pricedock:SetVisible(true)
		symbol:SetText(tsymbol)
		price:SetText("x " .. tprice)
		price:SizeToContents()

		frame:InvalidateLayout(true)
		frame:SizeToChildren(false, true)
		frame:Center()
	end

	frame.SetMaxCharacters = function(_, tmax)
		frame.maxCharacters = tmax
		maxchars:SetVisible(true)
		antinazi:DockMargin(0, 0, 0, SmallMargin)
		maxchars:DockMargin(0, 0, 0, LargeMargin)

		frame:InvalidateLayout(true)
		frame:SizeToChildren(false, true)
		frame:Center()

		frame:updateMaxChars()
	end

	frame.SetWarning = function(_, text)
		warndock:SetVisible(true)
		warn:SetText(text)
		warn:SizeToContents()
		warndock:InvalidateLayout(true)
		warndock:SizeToChildren(false, true)

		warn:SizeToContents()
		frame:InvalidateLayout(true)
		frame:SizeToChildren(false, true)
		frame.minWide = math.max(frame:GetWide(), frame.minWide, warn:GetWide() + SmallMargin * 2 + LargeMargin * 2)
		frame:SetWide(frame.minWide)
		frame:Center()
	end

	frame.minWide = frame:GetWide()
	frame:Center()

	return frame
end

function DarkRP.NumberRequest(title, text, value, okfunc, cancelfunc, oktext, canceltext, min, max, decimals)
	local frame = vgui.Create("NxGenericFrame")
	frame.backButtonDocking:SetVisible(false)
	frame.OnBackPress = function()
		if cancelfunc then
			cancelfunc()
		end

		return false
	end
	local title = frame:AddTitle(title or "")

	local warndock = frame:Add("Panel")
	warndock:Dock(TOP)
	warndock:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
	warndock.Paint = function(s, w, h)
		surface.SetDrawColor(255, 128, 32, 150)
		surface.DrawRect(0, 0, w, h)
	end
	local warn = warndock:Add("DLabel")
	warn:Dock(TOP)
	warn:SetFont("DermaNotDefault")
	warn:SetText("Warning\ntest")
	warn:SizeToContents()
	--warndock:SetTall(SmallMargin + warn:GetTall() + SmallMargin)
	warndock:InvalidateLayout(true)
	warndock:SizeToChildren(false, true)
	warndock:SetVisible(false)

	local label = frame:Add("DLabel")
	label:SetFont("DermaNotDefault")
	label:Dock(TOP)
	label:DockMargin(0, MediumMargin, 0, LargeMargin)
	label:SetText(text or "")
	label:SizeToContents()
	--label:SetContentAlignment(5)
	label:SetTextColor(color_white)

	local antinazi = frame:Add("EditablePanel")
	antinazi:Dock(TOP)
	antinazi:SetTall(yscale(40))
	antinazi:DockMargin(0, 0, 0, LargeMargin)

	local textentry = antinazi:Add("DNumberWang")
	textentry:SetFont("DermaNotLarge")
	textentry:SetTall(yscale(40))
	textentry:Dock(FILL)
	if value then
		textentry:SetValue(value)
	end
	textentry:SetMin(min or -math.huge)
	textentry:SetMax(max or math.huge)
	textentry:SetDecimals(decimals or 0)
	function textentry.OnEnter()
		if okfunc then
			okfunc(textentry:GetValue())
		end
		frame:Remove()
	end
	textentry:RequestFocus()
	textentry:SelectAllText(true)
	function textentry:OnTextChanged(...)
		surface.SetFont("DermaNotLarge")
		frame:SetWide(math.Clamp(surface.GetTextSize(self:GetValue()) + 6 * 2 + LargeMargin * 2, frame.minWide or 200, ScrW()))
		frame:Center()
	end
	textentry.Paint = nxui_DTextEntry_Paint
	textentry:SetDrawLanguageID(false)

	local footer = frame:Add("EditablePanel")
	footer:Dock(TOP)
	footer:SetTall(yscale(32))
	--[[
	local orig = frame.PerformLayout
	function frame:PerformLayout(...)
		orig(self, ...)
		footer:DockPadding((frame:GetWide() - 8 - 60 - 12 - 60) / 2, 0, (frame:GetWide() - 8 - 60 - 12 - 60) / 2, 0)
	end
	]]

	local okbutton = footer:Add("NxButton")
	okbutton:Dock(LEFT)
	okbutton:DockMargin(0, 0, MediumMargin, 0)
	okbutton:SetText(oktext or "OK")
	okbutton:SetPrimaryMainColors()
	okbutton:SizeToContents()
	okbutton:AutoSize()
	function okbutton.DoClick()
		if okfunc then
			okfunc(textentry:GetValue())
		end
		frame:Remove()
	end

	local cancelbutton = footer:Add("NxButton")
	cancelbutton:Dock(LEFT)
	cancelbutton:SetText(canceltext or DarkRP.getPhrase("cancel"))
	cancelbutton:SizeToContents()
	cancelbutton:AutoSize()
	function cancelbutton.DoClick()
		if cancelfunc then
			cancelfunc(textentry:GetValue())
		end
		frame:Remove()
	end

	frame.SetWarning = function(_, text)
		warndock:SetVisible(true)
		warn:SetText(text)
		warn:SizeToContents()
		warndock:InvalidateLayout(true)
		warndock:SizeToChildren(false, true)

		warn:SizeToContents()
		frame:InvalidateLayout(true)
		frame:SizeToChildren(false, true)
		frame.minWide = math.max(frame:GetWide(), frame.minWide, warn:GetWide() + SmallMargin * 2 + LargeMargin * 2)
		frame:SetWide(frame.minWide)
		frame:Center()
	end

	--frame:SetSize(math.Clamp(12 * 2 + label:GetWide(), 200, ScrW()), 28 + label:GetTall() + 8 + textentry:GetTall() + footer:GetTall() + 20)
	frame:SetWide(math.max(200, math.max(title:GetWide(), label:GetWide()) + LargeMargin * 2))
	frame:SetTall(LargeMargin + title:GetTall() + MediumMargin + MediumMargin + label:GetTall() + LargeMargin + yscale(40) + LargeMargin + yscale(32) + LargeMargin) -- no longer need to do this shit since SizeToChildren works now??
	frame.minWide = frame:GetWide()
	frame:Center()

	return frame
end


