surface.CreateFont("NXGroupControlIcon16", {
    font = NX_ICONFONT,
    size = yscale(16)
})

local shipments = {
    --{entity = "nx_turret", name = DarkRP.getPhrase("turret")}
}

hook.Add("loadCustomDarkRPItems", "cl_citymanagement", function()
    for k, v in next, CustomShipments do
        table.insert(shipments, v)
    end
end)

function citycontrolmenu()
    net.Start("citycontrol")
    net.WriteUInt(0, 3)
    net.SendToServer()
end

local function lawsfile()
    if (_G.GM or _G.GAMEMODE).Config.locale == "ru" then
        return "nx_DarkRP_laws.txt"
    end

    return "nx_DarkRP_laws_en.txt"
end

local function OnClickLine(self, line)
    if input.IsKeyDown(KEY_LSHIFT) then
        for id = math.min(self.lastselected, self:GetSortedID(line:GetID())), math.max(self.lastselected, self:GetSortedID(line:GetID())) do
            if id ~= self.lastselected then
                local line = self.Sorted[id]
                line:SetSelected(not line:IsSelected())
            end
        end
    else
        line:SetSelected(not line:IsSelected())
    end

    self.lastselected = self:GetSortedID(line:GetID())
end

local function playermenu(frame, n, filter)
    local plys = player.GetAll()
    if filter then
        for k = #plys, 1, -1 do
            if not filter(plys[k]) then
                table.remove(plys, k)
            end
        end
    end
    table.sort(plys, function(a, b) return ray.Sort(a:Name(), b:Name()) end)
    local menu = FixedDermaMenu(true)
    for k, v in next, plys do
        menu:AddOption(v:Name(), function()
            if not v:IsValid() then return end

            if type(n) == "number" then
                net.Start("citycontrol_invite")
                net.WriteUInt(n, 3)
                net.WriteUInt(v:UserID(), 16)
                net.SendToServer()
            elseif type(n) == "function" then
                n(v)
            end
        end):SetColor(v:getJobTable().color)
    end
    menu:SetParent(frame)
    menu:Open()
end

local points1, points2
net.Receive("citycontrolpoints", function()
    local points = net.ReadUInt(20)
    if points1 and points1:IsValid() then
        points1:SetText(DarkRP.getPhrase("cc_points") .. points)
        points1:SizeToContents()
    end
    if points2 and points2:IsValid() then
        points2:SetText(DarkRP.getPhrase("cc_points") .. points)
        points2:SizeToContents()
    end
end)

net.Receive("citycontrol", function()
    local points = net.ReadUInt(20)

    local upgrades = {}
    upgrades = net.ReadTable()

    local frame = vgui.Create("NxGenericFramePaged")
    frame:EnableTabs()
    frame:Center()
    local title = frame:AddTitle(LocalPlayer():isMayor() and DarkRP.getPhrase("cc_cityman") or DarkRP.getPhrase("cc_copman"))

    if LocalPlayer():isMayor() then
        do
            local function save()
                net.Start("laws_set_table")
                net.WriteTable(nxcity.laws)
                net.SendToServer()
                frame:Remove()
                if #nxcity.laws > 0 then
                    file.Write(lawsfile(), table.concat(nxcity.laws, "\n"))
                else
                    file.Delete(lawsfile())
                end
                citycontrolmenu()
            end

            local tab, sheet = frame:NewSheet(DarkRP.getPhrase("cc_laws"))

            local scroll = tab:Add("DScrollPanel")
            scroll:Dock(FILL)

            for k, v in next, nxcity.laws do
                local panel = scroll:Add("EditablePanel")
                panel:Dock(TOP)
                panel:SetTall(yscale(32))

                local label = panel:Add("DLabel")
                label:Dock(LEFT)
                label:SetFont("DermaNotDefault")
                label:SetText(k .. ".")
                label:SetTextColor(color_white)
                label:SizeToContents()

                local entry = panel:Add("DTextEntry")
                entry:SetFont("DermaNotDefault")
                entry:SetTall(yscale(32))
                entry:Dock(FILL)
                entry:SetText(v)
                entry.Paint = nxui_DTextEntry_Paint
                entry:SetDrawLanguageID(false)

                local hint
                function entry:OnChange()
                    if not hint then
                        hint = scroll:Add("DPanel")
                        hint:SetSize(162, 14)
                        hint.y = k == #nxcity.laws and (panel.y - 12) or (panel.y + 18)
                        local label = hint:Add("DLabel")
                        label:SetText(DarkRP.getPhrase("cc_save"))
                        label:Dock(FILL)
                        label:SetTextColor(color_black)
                    end
                end
                function entry:OnFocusChanged(focus)
                    if not focus and hint then
                        hint:Remove()
                        hint = nil
                    end
                end
                function entry:OnRemove()
                    if hint then
                        hint:Remove()
                        hint = nil
                    end
                end
                function entry:OnEnter()
                    if hint then
                        hint:Remove()
                        hint = nil
                        local text = entry:GetValue()
                        if ray.Len(text) < 3 or ray.Len(text) > 1000 then
                            DarkRP.DermaQuery(DarkRP.getPhrase("cc_lawlength"), "", "OK")
                        else
                            net.Start("NxLaws_Edit")
                            net.WriteUInt(1, 8)
                            net.WriteUInt(k, 10)
                            net.SendToServer()

                            nxcity.laws[k] = text
                            save()
                        end
                    end
                end

                local xbutton = panel:Add("NxButton")
                xbutton:Dock(RIGHT)
                xbutton:DockMargin(SmallMargin, 0, 0, 0)
                xbutton:SetText("X")
                xbutton:SetWide(panel:GetTall())
                function xbutton.DoClick()
                    net.Start("NxLaws_Edit")
                    net.WriteUInt(2, 8)
                    net.WriteUInt(k, 10)
                    net.SendToServer()

                    table.remove(nxcity.laws, k)
                    save()
                end
            end

            local restorebutton = tab:Add("NxButton")
            restorebutton:Dock(BOTTOM)
            restorebutton:SetTall(yscale(32))
            restorebutton:DockMargin(0, SmallMargin, 0, 0)
            restorebutton:SetText(DarkRP.getPhrase("cc_resetlaws"))
            function restorebutton.DoClick()
                DarkRP.DermaQuery(DarkRP.getPhrase("cc_resetlaws") .. "?", "", DarkRP.getPhrase("yes"), function()
                    net.Start("NxLaws_Edit")
                    net.WriteUInt(3, 8)
                    net.SendToServer()

                    nxcity.laws = table.Copy(GAMEMODE.Config.DefaultLaws)
                    save()
                end, DarkRP.getPhrase("no"))
            end

            local clearbutton = tab:Add("NxButton")
            clearbutton:Dock(BOTTOM)
            clearbutton:SetTall(yscale(32))
            clearbutton:DockMargin(0, SmallMargin, 0, 0)
            clearbutton:SetText(DarkRP.getPhrase("cc_clearlaws"))
            function clearbutton.DoClick()
                DarkRP.DermaQuery(DarkRP.getPhrase("cc_clearlaws") .. "?", "", DarkRP.getPhrase("yes"), function()
                    net.Start("NxLaws_Edit")
                    net.WriteUInt(4, 8)
                    net.SendToServer()

                    nxcity.laws = {}
                    save()
                end, DarkRP.getPhrase("no"))
            end

            local adNxButton = tab:Add("NxButton")
            adNxButton:Dock(BOTTOM)
            adNxButton:SetTall(yscale(32))
            adNxButton:DockMargin(0, SmallMargin, 0, 0)
            adNxButton:SetText(DarkRP.getPhrase("cc_addlaw"))
            adNxButton:SetPrimaryMainColors()
            function adNxButton.DoClick()
                if #nxcity.laws > 60 then
                    DarkRP.DermaQuery(DarkRP.getPhrase("cc_lawlimit"), "", "OK")
                else
                    DarkRP.StringRequest(DarkRP.getPhrase("cc_addlaw"), DarkRP.getPhrase("cc_lawtext"), function(text)
                        if ray.Len(text) < 3 or ray.Len(text) > 1000 then
                            DarkRP.DermaQuery(DarkRP.getPhrase("cc_lawlength"), "", "OK")
                        else
                            net.Start("NxLaws_Edit")
                            net.WriteUInt(5, 8)
                            net.WriteUInt(#nxcity.laws + 1, 10)
                            net.SendToServer()

                            table.insert(nxcity.laws, text)
                            save()
                        end
                    end)
                end
            end
        end

        do
            local tab, sheet = frame:NewSheet(DarkRP.getPhrase("cc_limits"))

            local speedwang, legal, license, illegal

            local save = tab:Add("NxButton")
            save:SetText(DarkRP.getPhrase("apply"))
            save:Dock(BOTTOM)
            save:SetPrimaryMainColors()
            save:SizeBig()
            save:DockMargin(LargeMargin * 2, LargeMargin, LargeMargin * 2, 0)
            save.DoClick = function()
                local line1 = ""
                local line2 = ""
                nxcity.badweps = {}
                for k, v in next, legal:GetLines() do
                    line1 = line1 .. " " .. v.ship.entity
                    nxcity.badweps[v.ship.entity] = false
                end
                for k, v in next, illegal:GetLines() do
                    line2 = line2 .. " " .. v.ship.entity
                    nxcity.badweps[v.ship.entity] = true
                end
                nxcity.speedlimit = speedwang:GetValue()

                net.Start("laws_set_mayor")
                net.WriteUInt(1, 8)
                net.WriteTable(nxcity.laws)
                net.WriteTable(nxcity.badweps)
                net.WriteUInt(nxcity.speedlimit, 8)
                net.SendToServer()

                file.Write("nx_darkrp_city.txt", line1:sub(2) .. "\n" .. line2:sub(2) .. "\n" .. nxcity.speedlimit)
            end

            local speedpanel = tab:Add("Panel")
            speedpanel:Dock(BOTTOM)
            speedpanel:DockMargin(0, 4, 0, 0)
            local speedlabel1 = speedpanel:Add("DLabel")
            speedlabel1:SetText(DarkRP.getPhrase("laws_speedlimit"))
            speedlabel1:SizeToContents()
            speedlabel1:Dock(LEFT)
            speedlabel1:SetTextColor(color_white)
            speedwang = speedpanel:Add("DNumberWang")
            speedwang:Dock(LEFT)
            speedwang:SetDecimals(0)
            speedwang:SetMinMax(0, 200)
            speedwang:SetWide(40)
            speedwang:SetValue(nxcity.speedlimit)
            local speedlabel2 = speedpanel:Add("DLabel")
            speedlabel2:SetText(DarkRP.getPhrase("laws_kmh"))
            speedlabel2:SizeToContents()
            speedlabel2:Dock(LEFT)
            speedlabel2:SetTextColor(color_white)

            local p1 = tab:Add("Panel")
            p1:SetWide(140)
            p1:Dock(LEFT)
            legal = p1:Add("DListView")
            legal:AddColumn(DarkRP.getPhrase("laws_legal"))
            legal:Dock(FILL)
            legal.OnClickLine = OnClickLine
            local tolegal = p1:Add("NxButton")
            tolegal:SetText("^")
            tolegal:Dock(BOTTOM)
            tolegal.DoClick = function()
                for k = #license.Lines, 1, -1 do
                    local v = license.Lines[k]
                    if v and v:IsLineSelected() then
                        legal:AddLine(v.ship.name).ship = v.ship
                        license:RemoveLine(k)
                    end
                end

                for k = #illegal.Lines, 1, -1 do
                    local v = illegal.Lines[k]
                    if v and v:IsLineSelected() then
                        legal:AddLine(v.ship.name).ship = v.ship
                        illegal:RemoveLine(k)
                    end
                end
            end

            local p2 = tab:Add("Panel")
            p2:SetWide(p1:GetWide())
            p2:Dock(LEFT)
            p2:DockMargin(1, 0, 1, 0)
            license = p2:Add("DListView")
            license:AddColumn(DarkRP.getPhrase("laws_license"))
            license:Dock(FILL)
            license.OnClickLine = OnClickLine
            local tolicense = p2:Add("NxButton")
            tolicense:SetText("^")
            tolicense:Dock(BOTTOM)
            tolicense.DoClick = function()
                for k = #legal.Lines, 1, -1 do
                    local v = legal.Lines[k]
                    if v and v:IsLineSelected() then
                        license:AddLine(v.ship.name).ship = v.ship
                        legal:RemoveLine(k)
                    end
                end

                for k = #illegal.Lines, 1, -1 do
                    local v = illegal.Lines[k]
                    if v and v:IsLineSelected() then
                        license:AddLine(v.ship.name).ship = v.ship
                        illegal:RemoveLine(k)
                    end
                end
            end

            local p3 = tab:Add("Panel")
            p3:SetWide(p1:GetWide())
            p3:Dock(LEFT)
            illegal = p3:Add("DListView")
            illegal:AddColumn(DarkRP.getPhrase("laws_illegal"))
            illegal:Dock(FILL)
            illegal.OnClickLine = OnClickLine
            local toillegal = p3:Add("NxButton")
            toillegal:SetText("^")
            toillegal:Dock(BOTTOM)
            toillegal.DoClick = function()
                for k = #legal.Lines, 1, -1 do
                    local v = legal.Lines[k]
                    if v and v:IsLineSelected() then
                        illegal:AddLine(v.ship.name).ship = v.ship
                        legal:RemoveLine(k)
                    end
                end

                for k = #license.Lines, 1, -1 do
                    local v = license.Lines[k]
                    if v and v:IsLineSelected() then
                        illegal:AddLine(v.ship.name).ship = v.ship
                        license:RemoveLine(k)
                    end
                end
            end

            for k, v in next, shipments do
                if nxcity.badweps[v.entity] then
                    illegal:AddLine(v.name).ship = v
                elseif nxcity.badweps[v.entity] == nil then
                    license:AddLine(v.name).ship = v
                else
                    legal:AddLine(v.name).ship = v
                end
            end
            legal:SortByColumn(1)
            license:SortByColumn(1)
            illegal:SortByColumn(1)
        end
    end

    do
        local tab, sheet = frame:NewSheet(DarkRP.getPhrase("cc_orders"))

        local panel = tab:Add("Panel")
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, LargeMargin)

        local image = panel:Add("DImage")
        image:Dock(LEFT)
        image:SetImage("icon16/medal_gold_1.png")
        image:DockMargin(0, 0, SmallMargin, 0)

        local label = panel:Add("DLabel")
        label:Dock(LEFT)
        label:SetFont("DermaNotDefault")
        label:SetText(DarkRP.getPhrase("cc_points") .. points)
        label:SizeToContents()
        label.x = 20
        label:SetTextColor(color_white)
        panel:SetTall(label:GetTall())
        image:SetSize(label:GetTall(), label:GetTall())
        points1 = label


        local panel = tab:Add("Panel")
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, SmallMargin)
        panel:SetTall(yscale(32))
        local button = panel:Add("NxButton")
        button:SetText(DarkRP.getPhrase("cc_invitecop"))
        button:Dock(FILL)
        button.DoClick = function()
            playermenu(frame, 2, function(v) return not v:isCP() end)
        end
        local label = panel:Add("DLabel")
        label:SetFont("DermaNotDefault")
        label:SetText(nxcityactions.invite)
        label:SizeToContents()
        label:Dock(RIGHT)
        label:SetTextColor(color_white)
        local image = panel:Add("DImage")
        image:SetWide(panel:GetTall() - SmallMargin*2)
        image:DockMargin(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
        image:SetImage("icon16/medal_gold_1.png")
        image:Dock(RIGHT)

        local panel = tab:Add("Panel")
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, SmallMargin)
        panel:SetTall(yscale(32))
        local button = panel:Add("NxButton")
        button:SetText(DarkRP.getPhrase("cc_kickcop"))
        button:Dock(FILL)
        button.DoClick = function()
            playermenu(frame, function(tar)
                DarkRP.StringRequest(DarkRP.getPhrase("cc_kickcop") .. ": " .. tar:Name(), DarkRP.getPhrase("enter_reason"), function(reason)
                    if not tar:IsValid() then return end

                    reason = reason:Left(400)

                    net.Start("citycontrol_invite")
                    net.WriteUInt(3, 3)
                    net.WriteUInt(tar:UserID(), 16)
                    net.WriteString(reason)
                    net.SendToServer()
                end)
            end, function(v) return v:isCP() and not v:isMayor() end)
        end
        if LocalPlayer():GetNWInt("city_police_kick_stock", math.huge) < 1 then
            button:SetDisabled(true)
            local label = panel:Add("DLabel")
            label:SetFont("DermaNotDefault")
            label:SetText(math.ceil(math.max(0, LocalPlayer():GetNWFloat("city_police_kick_nextRestock_t") - CurTime()) / 60) .. "m")
            label:SizeToContents()
            label:Dock(RIGHT)
            label:SetTextColor(color_white)
            local image = panel:Add("DImage")
            image:SetWide(panel:GetTall() - SmallMargin*2)
            image:DockMargin(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
            image:SetImage("icon16/time.png")
            image:Dock(RIGHT)
        end

        local panel = tab:Add("Panel")
        panel:Dock(TOP)
        panel:DockMargin(0, 0, 0, SmallMargin)
        panel:SetTall(yscale(32))
        local button = panel:Add("NxButton")
        button:SetText(DarkRP.getPhrase("cc_assignchief"))
        button:Dock(FILL)
        button.DoClick = function()
            playermenu(frame, 4, function(v) return v:isCP() and not v:isMayor() and v:Team() ~= TEAM_CHIEF end)
        end
        if LocalPlayer():GetNWInt("city_police_uber_stock", math.huge) < 1 then
            button:SetDisabled(true)
            local label = panel:Add("DLabel")
            label:SetFont("DermaNotDefault")
            label:SetText(math.ceil(math.max(0, LocalPlayer():GetNWFloat("city_police_uber_nextRestock_t") - CurTime()) / 60) .. "m")
            label:SizeToContents()
            label:Dock(RIGHT)
            label:SetTextColor(color_white)
            local image = panel:Add("DImage")
            image:SetWide(panel:GetTall() - SmallMargin*2)
            image:DockMargin(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
            image:SetImage("icon16/time.png")
            image:Dock(RIGHT)
        end

        local panel = tab:Add("Panel")
        panel:Dock(TOP)
        --panel:DockMargin(0, 0, 0, SmallMargin)
        panel:SetTall(yscale(32))
        local button = panel:Add("NxButton")
        button:SetText(DarkRP.getPhrase("cc_helicopter"))
        button:Dock(FILL)
        button.DoClick = function()
            net.Start("CCSpawnHeli")
            net.SendToServer()
        end
        local label = panel:Add("DLabel")
        label:SetFont("DermaNotDefault")
        label:SetText(nxcityactions.helicopter)
        label:SizeToContents()
        label:Dock(RIGHT)
        label:SetTextColor(color_white)
        local image = panel:Add("DImage")
        image:SetWide(panel:GetTall() - SmallMargin*2)
        image:DockMargin(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
        image:SetImage("icon16/medal_gold_1.png")
        image:Dock(RIGHT)
    end

    do
        local panel, sheet = frame:NewSheet(DarkRP.getPhrase("cc_upgrades"))

        local header = panel:Add("Panel")
        header:Dock(TOP)
        header:DockMargin(0, 0, 0, LargeMargin)

        local image = header:Add("DImage")
        image:Dock(LEFT)
        image:SetImage("icon16/medal_gold_1.png")
        image:DockMargin(0, 0, SmallMargin, 0)

        local label = header:Add("DLabel")
        label:Dock(LEFT)
        label:SetFont("DermaNotDefault")
        label:SetText(DarkRP.getPhrase("cc_points") .. points)
        label:SizeToContents()
        label.x = 20
        label:SetTextColor(color_white)
        header:SetTall(label:GetTall())
        image:SetSize(label:GetTall(), label:GetTall())
        points2 = label

        local scroll = panel:Add("Upgrades")
        scroll:Dock(FILL)
        scroll:Set("citycontrol_upgrades", nxcityupgrades, upgrades, function(k)
            if k == "charger_medkit" then
                net.Start("CCSpawnHealth")
                net.SendToServer()
            elseif k == "charger_suit" then
                net.Start("CCSpawnArmor")
                net.SendToServer()
            elseif k == "halo" then
                net.Start("police_halo")
                net.SendToServer()
            elseif k == "microwave" then
                net.Start("CCSpawnFood")
                net.SendToServer()
            end
            frame:Remove()
            --groupcontrolmenu(true)
        end, false)
    end
end)


hook.Add("OnPlayerChangedTeam", "NxLaws", function(ply, before, after)
    if ply == LocalPlayer() and RPExtraTeams[after].mayor and before ~= after then
        nxcity = {}

        if file.Exists("nx_darkrp_city.txt", "DATA") then
            nxcity.badweps = {}
            local lines = file.Read("nx_darkrp_city.txt"):Split("\n")
            for k, v in next, lines[1]:Split(" ") do
                nxcity.badweps[v] = false
            end
            for k, v in next, lines[2]:Split(" ") do
                nxcity.badweps[v] = true
            end
            nxcity.speedlimit = tonumber(lines[3])
        else
            nxcity.badweps = table.Copy(defaultnxcity.badweps)
            nxcity.speedlimit = defaultnxcity.speedlimit
        end

        if file.Exists(lawsfile(), "DATA") then
            nxcity.laws = file.Read(lawsfile(), "DATA"):Split("\n")
            net.Start("laws_set_new")
            net.SendToServer()
        else
            nxcity.laws = table.Copy(GAMEMODE.Config.DefaultLaws)
            file.Write(lawsfile(), table.concat(nxcity.laws, "\n"))
        end

        net.Start("laws_set_mayor")
        net.WriteUInt(2, 8)
        net.WriteTable(nxcity.laws)
        net.WriteTable(nxcity.badweps)
        net.WriteUInt(nxcity.speedlimit, 8)
        net.SendToServer()
    end
end)

hook.Add("InitPostEntity", "NxLaws", function()
    timer.Simple(1, function()
        if LocalPlayer():Team() == TEAM_MAYOR then
            hook.Run("OnPlayerChangedTeam", LocalPlayer(), TEAM_CITIZEN, TEAM_MAYOR)
        end
    end)
end)


--[[if file.Exists("nx_DarkRP_city.txt", "DATA") then
    nxcity = {badweps = {}}
    local lines = file.Read("nx_DarkRP_city.txt"):Split("\n")
    for k, v in next, lines[1]:Split(" ") do
        nxcity.badweps[v] = false
    end
    for k, v in next, lines[2]:Split(" ") do
        nxcity.badweps[v] = true
    end
    nxcity.speedlimit = tonumber(lines[3])
else
    nxcity = defaultnxcity
end]]

--citycontrolmenu()
concommand.Add("citycontrolmenu", citycontrolmenu)