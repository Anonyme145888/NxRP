local shipments = {
	--{entity = "nx_turret", name = DarkRP.getPhrase("turret")}
}

hook.Add("loadCustomDarkRPItems", "cl_laws", function()
	for k, v in next, CustomShipments do
		table.insert(shipments, v)
	end
end)

function lawsmenu()
	net.Start("laws_show")
	net.SendToServer()
end

net.Receive("laws_show", function()
	local laws = net.ReadTable()
	local badweps = net.ReadTable()
	local speedlimit = net.ReadUInt(8)

	
	local frame = vgui.Create("NxGenericFramePaged")
    frame:Center()
	frame:EnableTabs()

	frame:SetKeyboardInputEnabled(false)



	local title = frame:AddTitle(DarkRP.getPhrase("laws_title"))



	--------------------------------------------------------------------------------------------------



	local tab, sheet = frame:NewSheet(DarkRP.getPhrase("cc_laws"))



	local text = ""



	for k, v in next, laws do

		v = k .. ". " .. v

		text = text .. "\n\n" .. v

	end



	if speedlimit > 0 then

		local str = ("%d. %s%d%s."):format(#laws + 1, DarkRP.getPhrase("laws_speedlimit"), speedlimit, DarkRP.getPhrase("laws_kmh"))

		text = text .. "\n\n" .. str

	end



	local richtext = tab:Add("RichText")

	function richtext:Paint()

		self.frame = (self.frame or 0) + 1

		if self.frame == 1 then

			self:SetFontInternal("DermaNotDefault")

		elseif self.frame == 2 then

			self.Paint = nil

			self:GotoTextStart()

		end

	end

	richtext:Dock(FILL)

	richtext:SetWrap(true)

	richtext:InsertColorChange(255, 255, 255, 255)

	richtext:AppendText(text:sub(2))



	--------------------------------------------------------------------------------------------------



	local tab, sheet = frame:NewSheet(DarkRP.getPhrase("cc_limits"))



	local function fn(text, color)

		local column = tab:Add("EditablePanel")

		column:SetWide(math.floor((frame:GetWide() - LargeMargin*2)/3))

		column:Dock(LEFT)

		

		local lbl = column:Add("DLabel")

		lbl:Dock(TOP)

		lbl:SetFont("DermaNotLarge")

		lbl:SetText(text)

		lbl:SizeToContents()

		if color then lbl:SetTextColor(color) end



		local scroll = column:Add("DScrollPanel")

		fixscrollbar(scroll)

		scroll:Dock(FILL)



		return scroll

	end



	local function add(pnl, text, color)

		local lbl = pnl:Add("DLabel")

		lbl:Dock(TOP)

		lbl:SetFont("DermaNotDefault")

		lbl:SetText(text)

		lbl:SizeToContents()

		if color then lbl:SetTextColor(color) end

	end



	local legal = fn(DarkRP.getPhrase("laws_legal"), Color(0x4C, 0xAF, 0x50))

	local license = fn(DarkRP.getPhrase("laws_license"), Color(0xFF, 0xEB, 0x3B))

	local illegal = fn(DarkRP.getPhrase("laws_illegal"), Color(0xf4, 0x43, 0x36))



	for k, v in next, shipments do

		if badweps[v.entity] then

			add(illegal, v.name, LocalPlayer():HasWeapon(v.entity) and Color(0xf4, 0x43, 0x36))

		elseif badweps[v.entity] == nil then

			add(license, v.name, LocalPlayer():HasWeapon(v.entity) and Color(0xFF, 0xEB, 0x3B))

		else

			add(legal, v.name, LocalPlayer():HasWeapon(v.entity) and Color(0x4C, 0xAF, 0x50))

		end

	end

end)

concommand.Add("lawsmenu",lawsmenu)