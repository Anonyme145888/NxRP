util.AddNetworkString("citycontrol")
util.AddNetworkString("laws_set")
util.AddNetworkString("laws_show")
util.AddNetworkString("laws_mayor_set")
util.AddNetworkString("police_halo")
util.AddNetworkString("police_halo_disabled")
util.AddNetworkString("laws_reset")
----------------------------------------------
concommand.Add("cppoints", function(ply)
    if not ply:IsSuperAdmin() then return end
    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") + 100)
end)

timer.Create("CheckMaxPoints", 10, 0, function()
    if GetGlobalFloat("CCPoints") > 250 then
        SetGlobalFloat("CCPoints", 250)
    end
end)
timer.Create("UpdateMayorPoints", 150, 0, function()
    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") + 5)
end)
----------------------------------------------
nxcity = {}
nxcity.laws = nxcity.laws or {}
nxcity.badweps = nxcity.badweps or {}
nxcity.speedlimit = nxcity.speedlimit or 70
upgrades = upgrades or {}
util.AddNetworkString("laws_set_table")
net.Receive("laws_set_table", function(len, ply)
    local laws = net.ReadTable()
    nxcity.laws = laws
end)
util.AddNetworkString("laws_set_mayor")
net.Receive("laws_set_mayor", function(len, ply)
    local code = net.ReadUInt(8)
    if code == 1 then
        DarkRP.notifyAll(0, 4, DarkRP.getPhrase("cc_limitschanged"))
    end
    local laws = net.ReadTable()
    nxcity.laws = laws
    local weapons = net.ReadTable()
    nxcity.badweps = weapons
    local kmh = net.ReadUInt(8)
    nxcity.speedlimit = kmh
end)
net.Receive("laws_show", function(len, ply)
    net.Start("laws_show")
    net.WriteTable(nxcity.laws)
    net.WriteTable(nxcity.badweps)
    net.WriteUInt(nxcity.speedlimit, 8)
    net.Send(ply)
end)
hook.Add( "OnPlayerChangedTeam", "CityControlReset", function(ply, old, new)
    if old == TEAM_MAYOR then
       DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_default"))
       nxcity.laws = table.Copy(GAMEMODE.Config.DefaultLaws)
       nxcity.badweps = table.Copy(defaultnxcity.badweps)
       nxcity.speedlimit = defaultnxcity.speedlimit
    end
end)
hook.Add("PlayerDisconnected", "CityControlReset2", function(ply)
    if ply:Team() == TEAM_MAYOR then
       DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_default"))
       nxcity.laws = table.Copy(GAMEMODE.Config.DefaultLaws)
       nxcity.badweps = table.Copy(defaultnxcity.badweps)
       nxcity.speedlimit = defaultnxcity.speedlimit
    end
end)
---------------------------------------------
util.AddNetworkString("laws_set_new")
net.Receive("laws_set_new", function(len, ply)
    local name = ply:GetNWBool("MaskedName") != false and ply:GetNWBool("MaskedName") or ply:Name()
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_set")..name)
end)
util.AddNetworkString("NxLaws_Edit")
net.Receive("NxLaws_Edit", function(len, ply)
    local code = net.ReadUInt(8)
    if code == 1 then
    local law = net.ReadUInt(10)
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_edited")..law)
    elseif code == 2 then
    local law = net.ReadUInt(10)
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_removed")..law)
    elseif code == 3 then
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_reset"))
    elseif code == 4 then
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_clear"))
    elseif code == 5 then
    local law = net.ReadUInt(10)
    DarkRP.notifyAll(0, 4, DarkRP.getPhrase("laws_added")..law)
    end
end)
hook.Add("InitPostEntity", "NxLaws", function()
    nxcity.laws = table.Copy(GAMEMODE.Config.DefaultLaws)
    nxcity.badweps = table.Copy(defaultnxcity.badweps)
    nxcity.speedlimit = defaultnxcity.speedlimit
end)
----------------------------------------------
local InviteMenus
local function InviteMenus(answer, hitman, customer, target)
   if not tobool(answer) then
      DarkRP.notify(customer, 1, 4, hitman:Nick().." N’a pas accepté l’invitation à la police.")
      return
   end
   local allowed = hitman:changeAllowed(TEAM_POLICE)
   if not allowed then
      DarkRP.notify(customer, 4, 4, hitman:Nick().." Ça ne peut pas être un policier.")
      return
   end
   if not hitman:isCP() then
   if GetGlobalFloat("CCPoints") < 30 then
      DarkRP.notify(customer, 1, 4, "Pas assez de points de gourvenements")
      return
   end
   SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") - 30)
   DarkRP.notify(hitman, 4, 4, "Vous avez rejoint la police!")
   DarkRP.notify(customer, 4, 4, hitman:Nick().." accepté l’invitation à la police!")
   hitman:changeTeam(TEAM_POLICE, true)
   else
   end
end
util.AddNetworkString("citycontrol_invite")
net.Receive("citycontrol_invite", function(len, ply)
    local code = net.ReadUInt(3)
    local player = ray.FindPlayer(net.ReadUInt(16))
    if code == 2 then
        DarkRP.notifyAll(0, 4, "Le chef de la ville a invité "..player:Name().." à rejoindre la police. ")
        DarkRP.createQuestion(ply:Name().." vous invite à rejoindre la police", "PoliceInvite"..player:UserID(), player, 60, InviteMenus, ply, false, false)
    elseif code == 3 then
        if timer.Exists("KickCopTime") then DarkRP.notify(ply, 1, 4, "n'est pas souvent !") return end
        local reason = net.ReadString()
        DarkRP.notifyAll(4, 4, ("%s a libéré %s de vos fonctions.\raison: %s"):format(ply:Name(), player:Name(), reason))
        player:changeTeam(TEAM_CITIZEN, true)
        ply:SetNWInt("city_police_kick_stock", 0)
        ply:SetNWFloat("city_police_kick_nextRestock_t", CurTime()+900)
        timer.Create("KickCopTime", 600, 1, function()
            ply:SetNWInt("city_police_kick_stock", 1)
            ply:SetNWFloat("city_police_kick_nextRestock_t", false)
        end)
    elseif code == 4 then
        if timer.Exists("ChiefCopTime") then DarkRP.notify(ply, 1, 4, "n'est pas souvent!") return end
        ply:SetNWInt("city_police_uber_stock", 0)
        ply:SetNWFloat("city_police_uber_nextRestock_t", CurTime()+900)
        DarkRP.notifyAll(4, 4, "Le Maire a nommé "..player:Name().." chef de la police!")
        player:changeTeam(TEAM_CHIEF, true)
        timer.Create("ChiefCopTime", 600, 1, function()
           ply:SetNWInt("city_police_uber_stock", 1)
           ply:SetNWFloat("city_police_uber_nextRestock_t", false)
        end)
    end
end)
----------------------------------------------
net.Receive("citycontrol", function(len, ply)
    -- У шефа полиции - управление полицией.
    if (ply:Team() == TEAM_MAYOR) or (ply:Team() == TEAM_CHIEF) or (ply:Team() == TEAM_ZAMAYOR) then
        net.Start("citycontrol")
        net.WriteUInt(GetGlobalFloat("CCPoints"), 20)
        net.WriteTable(upgrades)
        net.Send(ply)
    end
end)

net.Receive("police_halo", function(len, ply)
end)

net.Receive("police_halo_disabled", function()
end)

util.AddNetworkString("CCSpawnArmor")
util.AddNetworkString("CCSpawnHealth")
util.AddNetworkString("CCSpawnFood")
util.AddNetworkString("CCGiveRadarToCops")
util.AddNetworkString("CCKickCop")
util.AddNetworkString("CCMakeChief")
util.AddNetworkString("CCSpawnHeli")

net.Receive("CCSpawnArmor", function(len, ply)
    if not ply:Team() == TEAM_MAYOR or ply:Team() == TEAM_CHIEF then return end
    if (timer.Exists("Armor1")) then
        DarkRP.notify(ply, 4, 4, "Le distributeur d’armure est déjà en place.")
        return
    end

    if GetGlobalFloat("CCPoints") < 50 then
        DarkRP.notify(ply, 1, 4, "Pas assez de points de gourvenements .")
        return
    end

    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") - 50)

    upgrades["charger_suit"] = CurTime() + 1800

    local armor = ents.Create("item_suitcharger")
    armor:SetPos(Vector(-4919.888672, -6046.779297, 288.847198))
    armor:SetAngles(Angle(0.000, -90, 0.000))
    armor:Spawn()


    if ply:Team() == TEAM_CHIEF then
        DarkRP.notifyAll(4, 4, "Le chef de la police a acheté un distributeur d’armure.")
    end

    if ply:Team() == TEAM_MAYOR then
        DarkRP.notifyAll(4, 4, "Le Maire a acheté un distributeur d’armure.")
    end

    timer.Create("Armor1", 1800, 1, function()
        upgrades["charger_suit"] = nil
        armor:Remove()
    end)
end)

net.Receive("CCSpawnHeli", function(len, ply)
    if not ply:Team() == TEAM_MAYOR or ply:Team() == TEAM_CHIEF then return end
    if GetGlobalFloat("CCPoints") < 100 then
        DarkRP.notify(ply, 1, 4, "Manque de pouvoir.")
        return
    end

    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") - 100)


    local armor = ents.Create("sent_helicopter_nonadmin")
    armor:SetPos(Vector(-4925.040527, -5818.004883, 733.190918))
    armor:Spawn()

    DarkRP.notifyAll(4, 4, "L’hélicoptère est sur le toit du comico.")
end)

net.Receive("CCSpawnHealth", function(len, ply)
    if not ply:Team() == TEAM_MAYOR or ply:Team() == TEAM_CHIEF then return end
    if (timer.Exists("Health1")) then
        DarkRP.notify(ply, 4, 4, "Le distributeur de santé est déjà en place.")

        return
    end


    if GetGlobalFloat("CCPoints") < 50 then
        DarkRP.notify(ply, 1, 4, "Pas assez de points de gourvenements .")
        return
    end

    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") - 50)

    upgrades["charger_medkit"] = CurTime() + 1800

    local armor = ents.Create("item_healthcharger")
    armor:SetPos(Vector(-4887.074219, -6045.424805, 288.847198))
    armor:SetAngles(Angle(0.000, -90, 0.000))
    armor:Spawn()

    if ply:Team() == TEAM_CHIEF then
        DarkRP.notifyAll(4, 4, "Le chef de la police a acheté un distributeur de produits de santé.")
    end

    if ply:Team() == TEAM_MAYOR then
        DarkRP.notifyAll(4, 4, "Le Maire a acheté un distributeur de santé.")
    end

    timer.Create("Health1", 1800, 1, function()
        upgrades["charger_medkit"] = nil
        armor:Remove()
    end)
end)

net.Receive("CCSpawnFood", function(len, ply)
    if not ply:Team() == TEAM_MAYOR or ply:Team() == TEAM_CHIEF then return end
    if (timer.Exists("Food1")) then
        DarkRP.notify(ply, 4, 4, "Le micro-ondes est déjà là.")

        return
    end


    if GetGlobalFloat("CCPoints") < 50 then
        DarkRP.notify(ply, 1, 4, "Pas assez de points d’alimentation.")
        return
    end

    SetGlobalFloat("CCPoints", GetGlobalFloat("CCPoints") - 50)

    upgrades["microwave"] = CurTime() + 1800

    local armor = ents.Create("microwave")
    armor:SetPos(Vector(-3420.350830, -5915.161621, 287.400818))
    armor:SetAngles(Angle(0.000, 90, 0.000))
    armor:Spawn()

    if ply:Team() == TEAM_CHIEF then
        DarkRP.notifyAll(4, 4, "Le chef de la police a acheté un micro-ondes.")
    end

    if ply:Team() == TEAM_MAYOR then
        DarkRP.notifyAll(4, 4, "Le maire a acheté un micro-ondes.")
    end

    timer.Create("Food1", 1800, 1, function()
        upgrades["microwave"] = nil
        armor:Remove()
    end)
end)