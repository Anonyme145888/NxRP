--[[
gamemodes/darkrp/gamemode/modules2/government_extras/sh_citymanagement.lua
--]]
defaultnxcity = {

	badweps = { -- false - legal | nil - license | true - illegal
	   fas2_ifak = true,    
	   lockpick = true,    
	   nx_fuel = false,    
	   nx_radio = false,    
	   nx_repair = false,    
	   stunstick = false,    
	   weapon_extinguisher = false,    
	   weapon_fists = false,   
	   weapon_hook = false,
	   weapon_medkit = false,
	   weapon_physgun = false,
	   weapon_physcannon = false,
	   keys = false,
	   selfie = false,
	   wep_jack_job_watercan = false,
	   gmod_tool = false,
	   nx_medcenter = false,
	   weapon_vape = false,
	   fas2_ak47 = true,
	   fas2_ak74 = true,
	   fas2_g3 = true,
	   fas2_glock20 = true,
	   fas2_deagle = true,
	   fas2_uzi = true,
	   fas2_m1911 = true,
	   fas2_m24 = true,
	   fas2_m3s90 = true,
	   fas2_m4a1 = true,
	   fas2_mac11 = true,
	   fas2_mp5a5 = true,
	   fas2_p226 = true,
	   fas2_pp19 = true,
	   fas2_ragingbull = true,
	   fas2_rk95 = true,
	   fas2_sg552 = true,
	   fas2_sks = true,
	   weapon_rpg  = true,
	   fas2_m67  = true,
	   fas2_dv2  = true,
	   fas2_machete  = false,
	   weapon_extinguisher  = false,
	   wep_nx_c4  = true,
	   molotov  = true

	},

	speedlimit = 70

}



nxcityactions = {

	invite = 30,

	helicopter = 100,

}



nxcityupgrades = {

	charger_medkit = {

		name = DarkRP.getPhrase("charger_medkit"),

		desc = DarkRP.getPhrase("charger_medkit_desc"),

		price = 50,

		time = 60

	},

	charger_suit = {

		name = DarkRP.getPhrase("charger_suit"),

		desc = DarkRP.getPhrase("charger_suit_desc"),

		price = 50,

		time = 60

	},

	microwave = {

		name = DarkRP.getPhrase("microwave"),

		desc = DarkRP.getPhrase("microwave_desc"),

		price = 50,

		time = 60

	}

}



for k, v in next, nxcityupgrades do

	v.time = v.time * 60

end