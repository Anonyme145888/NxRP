Corpse = {}

function net.SendSingleMessage(name, ply)
	if CLIENT then
		net.Start(name)
		net.SendToServer()
	else
		if ply then
			net.Start(name)
			net.Send(ply)
		else
			net.Start(name)
			net.Broadcast()
		end
	end
end
