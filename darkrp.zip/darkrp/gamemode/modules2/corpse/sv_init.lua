util.AddNetworkString("Corpse.PlayerDead")
util.AddNetworkString("Corpse.PlayerSpawn")

local playerMeta = FindMetaTable("Player")

function playerMeta:MultiversionIsCP()
	if self.isCP then
		return self:isCP()
	else
		return self:IsCP()
	end
end

function MultiversionFindEmptyPos(pos, t, d1, d2, vector)
	if DarkRP && DarkRP.findEmptyPos then
		DarkRP.findEmptyPos(pos, t, d1, d2, vector)
	else
		GAMEMODE:FindEmptyPos(pos, t, d1, d2, vector)
	end
end

function playerMeta:MultiversionCanAfford(amount)
	if self.CanAfford then
		return self:CanAfford(amount)
	else
		return self:canAfford(amount)
	end
end

function playerMeta:MultiversionAddMoney(amount)
	if self.AddMoney then
		return self:AddMoney(amount)
	else
		return self:addMoney(amount)
	end
end

function playerMeta:MultiversionNotify(type, text)
	if DarkRP && DarkRP.notify then
		DarkRP.notify(self, type, 4, text)
	else
		GAMEMODE:Notify(self, type, 4, text)
	end
end

function playerMeta:MultiversionArrest()
	if self.arrest then
		self:arrest()
	else
		self:Arrest()
	end
end

function playerMeta:MultiversionUnArrest()
	if self.unArrest then
		self:unArrest()
	else
		self:Unarrest()
	end
end

function Corpse.Create(ply)
	local corpse = ents.Create("prop_ragdoll")
	corpse:SetPos(ply:GetPos())
	corpse:SetAngles(ply:GetAngles())
	corpse:SetModel(ply:GetModel())

	local v = ply:GetVelocity()/15
	local num = corpse:GetPhysicsObjectCount() - 1

	for i=0, num do
		local bone = corpse:GetPhysicsObjectNum(i)
		if IsValid(bone) then
		local bp, ba = ply:GetBonePosition(corpse:TranslatePhysBoneToBone(i))
		if bp and ba then
			bone:SetPos(bp)
			bone:SetAngles(ba)
		end
		-- not sure if this will work:
		bone:SetVelocity(v)
		end
	end

	corpse:Spawn()
	corpse:Activate()

	corpse:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	local prop = ents.Create("prop_physics")
	prop:SetModel("models/hunter/blocks/cube05x05x05.mdl")
	prop:SetPos(corpse:GetPos())
	prop:SetCollisionGroup(COLLISION_GROUP_WORLD)
	prop:SetNoDraw(true)

	prop:Spawn()
	prop:Activate()

	corpse.block = prop
	corpse.owner = ply
	corpse.IsCorpse = true

	constraint.Weld(corpse, prop, 0, 0, 0, false)

	ply.corpse = corpse
	return corpse
end

local meta = FindMetaTable("Player")
function meta:CreateRagdoll()
	local ent = Corpse.Create(self)

	timer.Simple(0.1, function()
		net.Start("Corpse.PlayerDead")
			net.WriteFloat(ent:EntIndex())
			net.WriteFloat(self.NextSpawnTime - CurTime())
		net.Send(self)
	end)
end

hook.Add("PlayerDeath", "Corpse.PlayerDeath", function(ply, inflictor, killer)
	if ply != killer then
		ply.killedBy = killer
	end
end)

hook.Add("PlayerDisconnected", "Corpse.PlayerDisconnected", function(ply)
	if ply.corpse && IsValid(ply.corpse) then
		SafeRemoveEntity(ply.corpse.block)
		SafeRemoveEntity(ply.corpse)
	end
end)

hook.Add("PlayerSpawn", "Corpse.PlayerSpawn", function(ply)
	if IsValid(ply.corpse) then
		SafeRemoveEntity(ply.corpse)
		SafeRemoveEntity(ply.corpse.block)
	end

	ply.killedBy = nil
	
	net.Start("Corpse.PlayerSpawn")
	net.Send(ply)
end)

hook.Add("EntityTakeDamage", "Corpse.EntityTakeDamage", function(ent, dmginfo)
	if ent.IsCorpse && !(ent.dmg && ent.dmg > 30) && dmginfo:GetAttacker():IsPlayer() then
		ent.dmg = (ent.dmg or 0) + dmginfo:GetDamage()
		if ent.dmg > 30 then
			ent.owner.finished = true
			ent:EmitSound("vo/npc/male01/pain0"..math.random(5, 9)..".wav", 100, 100)
		end
	end
end)

