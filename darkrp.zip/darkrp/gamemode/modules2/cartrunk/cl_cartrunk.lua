net.Receive( "CarTrunk:Player:OpenMenu", function()
	local Ent = net.ReadEntity()
	local Ents = net.ReadTable()

   if frame and frame:IsValid() and frame:IsVisible() then return end
  -- if LocalPlayer():GetActiveWeapon():GetClass() ~= "keys" then return end
   if not Ents then Ents = {} return end

   if table.Count(Ents) == 0 then
		return notification.AddLegacy( "Votre coffre est vide.", NOTIFY_ERROR, 2 )
	end

    frame = vgui.Create("DFrame")
    frame:SetTitle(DarkRP.getPhrase("drop_item"))
    frame.btnMaxim:SetVisible(false)
    frame.btnMinim:SetVisible(false)
    frame:SetVisible(true)
    frame:MakePopup()

   if not IsValid(frame) or not frame:IsVisible() then return end
   if not Ents or next(Ents) == nil then frame:Close() return end

    local itemCount = table.Count(Ents)

    frame:SetSize(itemCount*64, 90)
    frame:Center()

    local i = 0

    local items = {}
    for k,v in pairs(Ents) do

        local icon = vgui.Create("SpawnIcon", frame)
        icon:SetPos(i * 64, 25)
        icon:SetModel(v.Model)
        icon:SetSize(64, 64)
        icon:SetTooltip()
        icon.DoClick = function(self)
			icon:SetTooltip()

 			net.Start( "CarTrunk:Player:RemoveEntity" )
			net.WriteEntity( Ent )
			net.WriteInt( k, 32 )
			net.SendToServer()
			frame:Close()

            itemCount = itemCount - 1
--
            if itemCount == 0 then
                frame:Close()
                return
            end

            fn.Map(self.Remove, items)
            items = {}

            LocalPlayer():GetActiveWeapon():SetHoldType("pistol")
            timer.Simple(0.2, function() if LocalPlayer():GetActiveWeapon():IsValid() then LocalPlayer():GetActiveWeapon():SetHoldType("normal") end end)
        end

        table.insert(items, icon)
        i = i + 1
	end
	
	frame:SetSkin(GAMEMODE.Config.DarkRPSkin)
end)