CarTrunk=istable(CarTrunk) and CarTrunk or {}

util.AddNetworkString( "CarTrunk:Player:OpenMenu" )
util.AddNetworkString( "CarTrunk:Player:RemoveEntity" )

CarTrunk.ItemClass=function( Item )

	local Table = {}
	local Model
	local Ent
	local Type
	local Amount
	local ID

    if Item:GetClass() == "spawned_weapon" then
        Model = Item:GetModel()
        Ent = Item:GetClass()
        Type = Item:GetWeaponClass()
        Amount = Item:Getamount()
    elseif Item:GetClass() == "spawned_ammo" then
        Model = Item:GetModel()
        Ent = Item:GetClass()
        Type = Item.ammoType
        Amount = Item.amountGiven
    elseif Item:GetClass() == "spawned_food" then
        Model = Item:GetModel()
        Ent = Item:GetClass()
        Type = Item:GetClass()
        Amount = Item.FoodEnergy
    elseif Item:GetClass() == "spawned_shipment" then
        Model = Item:GetModel()
        Ent = Item:GetClass()
        Type = CustomShipments[ Item:Getcontents() ].entity
        Amount = Item:Getcount()
        ID = Item:Getcontents()
    else
        Model = Item:GetModel()
        Ent = Item:GetClass()
        Type = Item:GetClass()
        Amount = 1
    end


    Table[1] = Model
    Table[2] = Ent
    Table[3] = Type
    Table[4] = Amount
    Table[5] = ID

    return Table
end

CarTrunk.AddToInventory=function( ent, tb )
	if not ent.VehInventory then
		ent.VehInventory = {}
	end

	if #ent.VehInventory >= CarTrunk.Config.MaxInvSpace then
		return DarkRP.notify(ply, 1, 5, "Le coffre est plein!")
	end

	table.insert( ent.VehInventory, tb )
end

CarTrunk_OpenMenu = function( ply, ent )
	if not IsValid( ent ) then return end
	if not ent:IsVehicle() then return end
	if ply:GetPos():Distance( ent:LocalToWorld( Vector( 0,  - ent:OBBMaxs().y, 20 ) ) ) > CarTrunk.Config.DistanceToOpenTrunk then return end

	if not ent.VehInventory then
		ent.VehInventory = {}
	end

	net.Start( "CarTrunk:Player:OpenMenu" )
	net.WriteEntity( ent )
	net.WriteTable( ent.VehInventory )
	net.Send( ply )
end

hook.Add("KeyPress", "CarTrunk:Player:Use", function(ply, key)
    local Ent = ply:GetEyeTrace().Entity
    if not IsValid(Ent) then return end

    if Ent:IsVehicle() then
        if ply:GetPos():Distance(Ent:LocalToWorld(Vector(0, -Ent:OBBMaxs().y, 20))) < CarTrunk.Config.DistanceToOpenTrunk then
            if IsValid(ply:GetActiveWeapon()) then
                if CarTrunk.Config.KeyToOpen == IN_RELOAD and ply:GetActiveWeapon():GetClass() == 'keys' then
                    return
                elseif CarTrunk.Config.KeyToOpen == IN_ATTACK2 and ply:GetActiveWeapon():GetClass() == 'keys' then
                    return
                end
            end

            if ply:InVehicle() then return end

            if key == CarTrunk.Config.KeyToOpen then
                if CarTrunk.Config.BlackList[Ent:GetModel()] then return end
                if not IsValid(Ent:getDoorOwner()) then
                    return DarkRP.notify(ply, 1, 5, "Ce n'est pas votre voiture.")
                end

                CarTrunk_OpenMenu(ply, Ent)
            end
        end
    else
        if Ent:IsPlayer() then return end
        if Ent:IsVehicle() then return end
        if Ent:isDoor() then return end
        if Ent:IsWorld() then return end

        if ply:GetPos():Distance(Ent:GetPos()) > 300 then return end

        if ply:InVehicle() then return end

        if key == IN_RELOAD then
            local Veh
            for k, v in pairs(ents.FindByClass( 'prop_vehicle_jeep' )) do
                if ply:GetPos():Distance(v:LocalToWorld(Vector(0, -v:OBBMaxs().y, 20))) < CarTrunk.Config.DistanceToPickUp then
                    if not CarTrunk.Config.BlackList[v:GetModel()] then
                        if v:CPPIGetOwner() == ply then
                            Veh = v
                            break
                        end
                    end
                end
            end

            if Veh == nil then return end

            if Veh.VehInventory and #Veh.VehInventory >= CarTrunk.Config.MaxInvSpace then
                return DarkRP.notify(ply, 1, 5, "Le coffre est plein!")
            end

            if CarTrunk.Config.EntsBlackList[Ent:GetClass()] then
                return DarkRP.notify(ply, 1, 5, "Vous ne pouvez pas mettre cela dans votre coffre!")
            end

            Ent:SetPos(Vector(-165.964386, 160.212463, -14015.968750))
            local physObj = Ent:GetPhysicsObject()
            if IsValid(physObj) then
                physObj:Sleep()
            end

            if not istable(Veh.VehInventory) then
                Veh.VehInventory = {}
            end

            Ent.MYOWNERMOSHINA = true
            Ent.MYOWNERMOSHINA1 = Veh
            table.insert(Veh.VehInventory, { Index = Ent:EntIndex(), Model = Ent:GetModel() })
        end
    end
end)

net.Receive( "CarTrunk:Player:RemoveEntity", function( length, ply )
	local Ent = net.ReadEntity()
	local ID = net.ReadInt( 32 )

	if not IsValid( Ent ) then return end
	if not Ent:IsVehicle() then return end
	if CarTrunk.Config.BlackList[ Ent:GetModel() ] then return end
	if ply:GetPos():Distance( Ent:LocalToWorld( Vector( 0,  - Ent:OBBMaxs().y, 20 ) ) ) > CarTrunk.Config.DistanceToOpenTrunk then return end
	if not Ent.VehInventory then return end
	if not Ent.VehInventory[ ID ] then return end
	if (Ent:getDoorOwner()!=ply and Ent:getDoorOwner():IsPlayer()) then
		return DarkRP.notify(ply, 1, 5, "Les portes doivent être ouvertes pour ouvrir le coffre")
	end
	local Item = Entity(Ent.VehInventory[ ID ].Index)

	Item:SetPos( Ent:GetPos() + Ent:OBBCenter() + ( Ent:GetUp() * -10 ) + ( Ent:GetRight() * 110 ) + ( Ent:GetForward() * 1 ))
	Item:SetAngles( Item:GetAngles() )
	Item.MYOWNERMOSHINA=false
	local a=Item:GetPhysicsObject()
	if IsValid(a) then
		a:Wake()
		a:SetVelocity( ply:GetUp() )
	end


	table.remove( Ent.VehInventory, ID )
end)

timer.Create("CHECKOWNERMOSHINA",20,0,function()
	for k,v in pairs(ents.GetAll()) do
		if v.MYOWNERMOSHINA then
			if !IsValid(v.MYOWNERMOSHINA1) then
				v:Remove()
			end
		end
	end
end)