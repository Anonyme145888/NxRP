CarTrunk = {}

CarTrunk.Config = {}

CarTrunk.Config.KeyToOpen = IN_USE -- ( https://wiki.garrysmod.com/page/Enums/IN )
CarTrunk.Config.KeyToPickup = IN_RELOAD -- ( https://wiki.garrysmod.com/page/Enums/IN )

CarTrunk.Config.DistanceToOpenTrunk = 150
CarTrunk.Config.DistanceToPickUp = 150

CarTrunk.Config.MaxInvSpace = 10

-- Blacklist cars
CarTrunk.Config.BlackList = {
	['models/lonewolfie/ford_f350_ambu.mdl'] = true,
}
-- Entities blacklist
CarTrunk.Config.EntsBlackList = {
	['money_printer_premium'] = false,
}
