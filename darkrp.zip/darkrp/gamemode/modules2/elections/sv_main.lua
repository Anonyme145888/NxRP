-- sv_main.lua
util.AddNetworkString("AElections_VoteSent")
util.AddNetworkString("AElections_EnterSent")
util.AddNetworkString("AElections_Update")
util.AddNetworkString("AElections_EnterMenu")
util.AddNetworkString("election_ballot")

AElections.Candidates = {}

-- Reset elections data
function AElections:ResetElections()
    AElections.Candidates = {}
    SetGlobalFloat("Elections_Restock_t", 0)
    AElections.PreElectionsActive = false
    AElections.ElectionsActive = false
end

-- Add candidate to the election
function AElections:AddCandidate(ply, promise)
    if #AElections.Candidates >= AElections.MaxParticipants then
        DarkRP.notify(ply, 1, 4, "The maximum number of participants has been reached.")
        return
    end

    if AElections.RestrictJoining and not table.HasValue(AElections.AbleToJoinTeams, team.GetName(ply:Team())) then
        DarkRP.notify(ply, 1, 4, "Your job does not allow you to participate in elections.")
        return
    end

    for _, v in pairs(AElections.Candidates) do
        if v[1] == ply:SteamID() then
            DarkRP.notify(ply, 1, 4, "You are already a candidate.")
            return
        end
    end

    table.insert(AElections.Candidates, {ply:SteamID(), ply:Nick(), promise or "No promise", ply:Team()})
    DarkRP.notify(ply, 0, 4, "You have joined the elections!")
    AElections:UpdateCandidates()
end

-- Broadcast candidates to players
function AElections:UpdateCandidates()
    net.Start("AElections_Update")
    net.WriteTable(AElections.Candidates)
    net.Broadcast()
end

-- Start elections
function AElections:StartElections()
    if #AElections.Candidates < AElections.MinParticipants then
        PrintMessage(HUD_PRINTTALK, "Not enough candidates to start the elections.")
        AElections:ResetElections()
        return
    end

    AElections.PreElectionsActive = true
    PrintMessage(HUD_PRINTTALK, "Elections are starting! Voting will begin shortly.")
    SetGlobalFloat("Elections_Restock_t", AElections.PreparationTime)

    timer.Simple(AElections.PreparationTime, function()
        AElections:BeginVoting()
    end)
end

-- Begin voting
function AElections:BeginVoting()
    AElections.PreElectionsActive = false
    AElections.ElectionsActive = true
    PrintMessage(HUD_PRINTTALK, "Voting has started! Cast your vote now.")
    SetGlobalFloat("Elections_Restock_t", AElections.VotingTime)

    net.Start("election_ballot")
    net.WriteTable(AElections.Candidates)
    net.Broadcast()

    timer.Simple(AElections.VotingTime, function()
        AElections:EndVoting()
    end)
end

-- End voting and announce the winner
function AElections:EndVoting()
    AElections.ElectionsActive = false
    local votes = {}

    for _, ply in ipairs(player.GetAll()) do
        local sid = ply:GetNWString("AElections_VotedFor", nil)
        if sid then
            votes[sid] = (votes[sid] or 0) + 1
        end
    end

    local winner, maxVotes = nil, 0
    for _, candidate in ipairs(AElections.Candidates) do
        local sid = candidate[1]
        local voteCount = votes[sid] or 0
        if voteCount > maxVotes then
            winner = candidate
            maxVotes = voteCount
        end
    end

    if winner then
        local ply = player.GetBySteamID(winner[1])
        if IsValid(ply) then
            ply:setDarkRPVar("job", AElections.MayorJobName)
            PrintMessage(HUD_PRINTTALK, winner[2] .. " has been elected as the new Mayor!")
        end
    else
        PrintMessage(HUD_PRINTTALK, "No winner could be determined.")
    end

    AElections:ResetElections()
end

-- Handle vote submission
net.Receive("AElections_VoteSent", function(len, ply)
    if not AElections.ElectionsActive then
        DarkRP.notify(ply, 1, 4, "Voting is not currently active.")
        return
    end

    local ent = net.ReadEntity()
    if IsValid(ent) and ent:IsPlayer() then
        ply:SetNWString("AElections_VotedFor", ent:SteamID())
        DarkRP.notify(ply, 0, 4, "Your vote has been submitted!")
    end
end)

-- Handle candidate entry
net.Receive("AElections_EnterSent", function(len, ply)
    local promise = net.ReadString()
    AElections:AddCandidate(ply, promise)
end)

-- Admin command to start elections
concommand.Add("start_elections", function(ply)
    if not ply:IsAdmin() then return end
    AElections:StartElections()
end)