-- sv_functions.lua

-- Prevent mayor demotion on death if configured
hook.Add("PlayerDeath", "AElections_MayorDeath", function(ply)
    if AElections.DemoteMayorOnDeath and ply:getDarkRPVar("job") == AElections.MayorJobName then
        ply:changeTeam(GAMEMODE.DefaultTeam, true)
        DarkRP.notifyAll(0, 4, "The Mayor has been demoted upon death.")
    end
end)

-- Prevent F4 menu entry into elections if configured
hook.Add("ShowSpare2", "AElections_PreventF4", function(ply)
    if AElections.AllowF4ToEnterElections then
        ply:ConCommand("say /" .. AElections.VoteCommand)
    end
end)