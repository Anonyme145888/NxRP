AElections.WorkshopDownload = true
AElections.ServerDownload = false
AElections.SecretaryModel = "models/mossman.mdl"
AElections.EnterCost = 150
AElections.VoteCommand = "elections"
AElections.HideCommand = "hideelections"
AElections.MayorJobName = "Maire"
AElections.UseLegacyMayorCheck = false
AElections.AllowNewElectionsWithMayor = false
AElections.CandidatesCanVote = true
AElections.MinParticipants = 1
AElections.MaxParticipants = 5
AElections.AllowF4ToEnterElections = false
AElections.DemoteMayorOnDeath = true
AElections.RestrictJoining = false
AElections.AbleToJoinTeams = {
  "Lawyer",
  "Politician",
  "TV Star"
}
AElections.RestrictVoting = false
AElections.AbleToVoteTeams = {
  "Citizen",
  "Police Officer",
  "Medic"
}
AElections.PreparationTime = 60
AElections.VotingTime = 120
AElections.PostElectionsTime = 10
AElections.MayorAntiDemoteCooldown = 120
