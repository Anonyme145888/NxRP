local PANEL = {}

function PANEL:Init()
    self:SetKeyboardInputEnabled(false)
    self:SetWide(math.min(ScrW(), 700 + LargeMargin * 2))
    self:Center()
    self.title = self:AddTitle("")
    local scroll = self:Add("DScrollPanel")
    fixscrollbar(scroll)
    scroll:Dock(FILL)
    scroll:GetCanvas():DockPadding(0, 0, 5, 0)
    self.layout = scroll
    --[[
	local layout = scroll:Add("DListLayout")
	layout:Dock(FILL)
	self.layout = layout
	]]
end

function PANEL:AddCandidate(entid, name, sid64, reason, team)
    local pnl = self.layout:Add("EditablePanel")
    pnl:Dock(TOP)
    pnl:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
    pnl:DockMargin(0, 0, 0, SmallMargin)
    pnl:SetTall(74)
    local color = HSVToColor(sid64:Right(3) % 360, 0.2, 1)
    color.a = 12

    pnl.Paint = function(s, w, h)
        surface.SetDrawColor(color)
        surface.DrawRect(0, 0, w, h)
    end

    local pnlAvatar = pnl:Add("EditablePanel")
    pnlAvatar:Dock(LEFT)
    pnlAvatar:DockMargin(0, 0, SmallMargin, 0)
    pnlAvatar:SetWide(64)
    local avatar = pnlAvatar:Add("AvatarImage")
    avatar:Dock(TOP)
    avatar:SetSize(64, 64)
    avatar:SetSteamID(sid64, 64)
    local pnlText = pnl:Add("EditablePanel")
    pnlText:Dock(FILL)
    local lblName = pnlText:Add("DLabel")
    lblName:SetText(name)
    lblName:SetFont("DermaNotLarge")
    lblName:SizeToContents()
    lblName:Dock(TOP)
    local lblReason = pnlText:Add("DLabel")
    lblReason:SetText(DarkRP.textWrap(reason, "DermaNotDefault", 500))
    lblReason:SetFont("DermaNotDefault")
    lblReason:SizeToContents()
    lblReason:Dock(TOP)
    local btn = pnl:Add("NxButton")
    btn:Dock(RIGHT)
    btn:DockMargin(SmallMargin, 0, 0, 0)
    btn:SetText("1")
    btn:SetFont("DermaNotLargeIcon")
    btn:SetPrimaryMainColors()

    btn.DoClick = function()
        self:SetVisible(false)
        net.Start("AElections_VoteSent")
        net.WriteEntity(entid)
        net.SendToServer()
    end

    pnl:InvalidateLayout(true)
    pnl:InvalidateChildren(true)
    pnl:SetTall(math.max(64 + SmallMargin * 2, select(2, lblReason:GetPos()) + lblReason:GetTall() + SmallMargin * 2))
end

function PANEL:Think()
    if GetGlobalFloat("Elections_Restock_t") then
        if GetGlobalFloat("Elections_Restock_t") >= 0.5 then
            self.title:SetText(string.FormattedTime(math.floor(GetGlobalFloat("Elections_Restock_t") * 100) / 100, "%02i:%02i"))
        else
            self:Remove()
        end
    end
end

function PANEL:OnBackPress()
    self:SetVisible(false)

    return true
end

derma.DefineControl("ElectionBallot", "", PANEL, "NxGenericFrame")

net.Receive("election_ballot", function(len)
    local ballot = net.ReadTable()
    local pnl = vgui.Create("ElectionBallot")
    pnl:SetVisible(false)

    for k, v in pairs(ballot) do
        local ply = player.GetBySteamID(v[1])
        if ply != false then
           pnl:AddCandidate(ply, ply:Nick(), v[4], v[3], ply:Team())
        end
    end

    if IsValid(pnl) then
        pnl:SetVisible(true)
        pnl:MakePopup()
        pnl:SetKeyboardInputEnabled(false)
    end
end)

net.Receive("AElections_EnterMenu", function()
    local frame = DarkRP.StringRequest("Élections", "Indiquez votre promesse de campagne:", function(s)
        net.Start("AElections_EnterSent")
        net.WriteString(s)
        net.SendToServer()
    end)

    --frame:SetMaxCharacters(2000)
end)

net.Receive("AElections_Update", function()
    AEL_Candidates = net.ReadTable()
end)