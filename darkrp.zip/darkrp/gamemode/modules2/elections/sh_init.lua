if SERVER then
	AElections = {}
	AEL_Lang = {}
	AEL_Candidates = {}
	AEL_PreElectionsActive = false
	AEL_ElectionsActive = false

	include("sh_config.lua")
	include("sv_main.lua")
	include("sv_functions.lua")

	AddCSLuaFile("sh_config.lua")
	AddCSLuaFile("cl_menu.lua")
end

if CLIENT then
	AElections = {}
	AEL_Lang = {}
	AEL_Candidates = {}

	include("sh_config.lua")
	include("cl_menu.lua")
end