local Anims = {}
DarkRP.PlayerAnims = Anims

-- Load animations after the languages for translation purposes
hook.Add("loadCustomDarkRPItems", "loadAnimations", function()
    Anims[ACT_GMOD_GESTURE_BOW] = DarkRP.getPhrase("bow")
    Anims[ACT_GMOD_TAUNT_MUSCLE] = DarkRP.getPhrase("dance")
    Anims[ACT_GMOD_GESTURE_BECON] = DarkRP.getPhrase("follow_me")
    Anims[ACT_GMOD_TAUNT_LAUGH] = DarkRP.getPhrase("laugh")
    Anims[ACT_GMOD_TAUNT_PERSISTENCE] = DarkRP.getPhrase("lion_pose")
    Anims[ACT_GMOD_GESTURE_DISAGREE] = DarkRP.getPhrase("nonverbal_no")
    Anims[ACT_GMOD_GESTURE_AGREE] = DarkRP.getPhrase("thumbs_up")
    Anims[ACT_GMOD_GESTURE_WAVE] = DarkRP.getPhrase("wave")
    Anims[ACT_GMOD_TAUNT_DANCE] = DarkRP.getPhrase("dance2")
    Anims[ACT_GMOD_TAUNT_CHEER] = DarkRP.getPhrase("cheer")
    Anims[ACT_GMOD_TAUNT_SALUTE] = DarkRP.getPhrase("salute")
    Anims[ACT_GMOD_TAUNT_ROBOT] = DarkRP.getPhrase("robot")
end)

function DarkRP.addPlayerGesture(anim, text)
    if not anim then error("Argument #1 of DarkRP.addPlayerGesture (animation/gesture) does not exist.") end
    if not text then error("Argument #2 of DarkRP.addPlayerGesture (text) does not exist.") end

    Anims[anim] = text
end

function DarkRP.removePlayerGesture(anim)
    if not anim then error("Argument #1 of DarkRP.removePlayerGesture (animation/gesture) does not exist.") end

    Anims[anim] = nil
end

if SERVER then
    hook.Add("KeyPress", "darkrp_animations", function(ply, key)
        if key ~= IN_ATTACK then return end

        local wep = ply:GetActiveWeapon()
        if not wep:IsValid() then return end

        -- Saying hi/hello to a player
        if not ply.SaidHi and wep:GetClass() == "weapon_physgun" then
            local ent = ply:GetEyeTrace().Entity
            if ent:IsValid() and ent:IsPlayer() then
                ply.SaidHi = true
                ply:DoAnimationEvent(ACT_SIGNAL_GROUP)
            end
        end

        -- Hobo throwing poop!
        if not ply.ThrewPoop and wep:GetClass() == "weapon_bugbait" then
            ply.ThrewPoop = true
            ply:DoAnimationEvent(ACT_GMOD_GESTURE_ITEM_THROW)
        end
    end)
    hook.Add("KeyRelease", "darkrp_animations", function(ply, key)
        if key ~= IN_ATTACK then return end

        ply.SaidHi = nil
        ply.ThrewPoop = nil
    end)

    local function CustomAnim(ply, cmd, args)
        if not ply:IsValid() then return end
        local Gesture = tonumber(args[1] or 0)
        if not Anims[Gesture] then return end
        ply:DoAnimationEvent(Gesture)
    end
    concommand.Add("_DarkRP_DoAnimation", CustomAnim)

    util.AddNetworkString("AnimRestartGestureNet")
    function ray.meta.Player:AnimRestartGestureNet(slot, act, once)
        net.Start("AnimRestartGestureNet")
        net.WriteEntity(self)
        net.WriteUInt(slot, 8)
        net.WriteUInt(act, 16)
        net.WriteBool(once)
        net.SendPVS(self:GetPos())
    end

    return
end

net.Receive("AnimRestartGestureNet", function()
    local pl = net.ReadEntity()
    if not pl:IsValid() then return end
    pl:AnimRestartGesture(net.ReadUInt(8), net.ReadUInt(16), net.ReadBool())
end)

function GM:GrabEarAnimation(pl)
end

function GM:PrePlayerDraw(pl)
    pl:SetEyeTarget(pl:EyePos() + pl:GetAimVector() * 500)
end