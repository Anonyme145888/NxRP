local AccSway = Vector()
local lastEA = Angle()
local dtEA = Angle()
local CurPos = Vector()
local CurAng = Vector()
local nullvec = Vector()

local function GetVMStatefulPosAng(self)
	return nullvec, nullvec
end

local function GetVMAffectedPosAng(self)
	local Pos, Ang = nullvec, nullvec--GetVMStatefulPosAng(self)

	local vel = self.Owner:GetVelocity()
	local len = self.Owner:IsOnGround() and vel:Length() or 0
	local move = len / self.Owner:GetWalkSpeed()

	local t = RealTime() * (len > 0.2 and 8 or 2)
	local amp = 0

	amp = (0.2 + move * 0.6)

	--[[
	if self:GetClass() == "nxw_ragingbull" then
		amp = amp * 0.5
	end
	]]

	Pos = Pos + Vector(math.cos(t) * 0.5, 0, math.sin(2*t)/2) * amp



	dtEA.p = math.AngleDifference(EyeAngles().p, lastEA.p)
	dtEA.y = math.AngleDifference(EyeAngles().y, lastEA.y)

	local max = 5

	if self:IsValid() and (self:GetClass() == "nx_fuel" or self:GetClass() == "nx_repair") then
		max = 0.25
	end

	AccSway.x = math.Clamp(AccSway.x + dtEA.p * 0.25, -max, max)
	AccSway.y = math.Clamp(AccSway.y + dtEA.y * 0.25, -max, max)
	

	local velRoll = math.Clamp((vel:DotProduct(EyeAngles():Right()) * 0.04) * move, -5, 5)

	Ang = Ang + Vector(AccSway.x, AccSway.y * 2, velRoll - AccSway.y)
	Pos = Pos + Vector(AccSway.y * 0.5, 0, AccSway.x * 0.5)

	AccSway = LerpVector(math.min(1, FrameTime() * 20), AccSway, nullvec)

	lastEA = EyeAngles()

	return Pos, Ang
end

function GetNXWeaponShake(pos, ang)
	ang:RotateAroundAxis(ang:Right(), 		CurAng.x)
	ang:RotateAroundAxis(ang:Up(), 		CurAng.y)
	ang:RotateAroundAxis(ang:Forward(), 	CurAng.z)

	pos:Add( ang:Right() * (CurPos.x) )
	pos:Add( ang:Forward() * (CurPos.y) )
	pos:Add( ang:Up() * (CurPos.z) )

	return pos, ang
end

hook.Add("CalcViewModelView", "NxWeaponShake", function(wep, vm, pos, ang, newPos, newAng)
	if wep.NXVMPOS2 or wep.WM or wep:GetClass() == "weapon_vape" or wep:GetClass() == "weapon_popcorn" or wep.IsTFAWeapon then return end

	return GetNXWeaponShake(pos, ang)
end)

hook.Add("PreDrawViewModel", "NxWeaponShake", function(vm, pl, wep)
	if wep == nil then return end
	--if wep.NXVMPOS2 or wep.WM then return end
	local Pos, Ang = GetVMAffectedPosAng(wep)
	CurPos = LerpVector(math.min(1, FrameTime() * 10), CurPos, Pos)
	CurAng = LerpVector(math.min(1, FrameTime() * 10), CurAng, Ang)
end)