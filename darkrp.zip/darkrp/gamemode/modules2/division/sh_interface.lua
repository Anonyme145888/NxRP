DarkRP.PLAYER.isCivil = DarkRP.stub{
    name = "isCivil",
    description = "Whether this player is a civil.",
    parameters = {
    },
    returns = {
        {
            name = "answer",
            description = "Whether this player is a civil.",
            type = "boolean"
        }
    },
    metatable = DarkRP.PLAYER
}

DarkRP.PLAYER.isCriminal = DarkRP.stub{
    name = "isCriminal",
    description = "Whether this player is a criminal.",
    parameters = {
    },
    returns = {
        {
            name = "answer",
            description = "Whether this player is a criminal.",
            type = "boolean"
        }
    },
    metatable = DarkRP.PLAYER
}

DarkRP.PLAYER.isTrader = DarkRP.stub{
    name = "isTrader",
    description = "Whether this player is a trader.",
    parameters = {
    },
    returns = {
        {
            name = "answer",
            description = "Whether this player is a trader.",
            type = "boolean"
        }
    },
    metatable = DarkRP.PLAYER
}