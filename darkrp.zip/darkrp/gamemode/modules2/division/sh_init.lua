local plyMeta = FindMetaTable("Player")

plyMeta.isCivil = fn.Compose{fn.Curry(fn.GetValue, 2)("civil"), plyMeta.getJobTable}
plyMeta.isCriminal = fn.Compose{fn.Curry(fn.GetValue, 2)("criminal"), plyMeta.getJobTable}
plyMeta.isTrader = fn.Compose{fn.Curry(fn.GetValue, 2)("trader"), plyMeta.getJobTable}