if ray and ray.FindPlayer then
	DarkRP.findPlayer = ray.FindPlayer
end