local meta = FindMetaTable("Entity")
local metaply = FindMetaTable("Player")

function meta:IsCar()
	return self:GetClass() == "prop_vehicle_jeep" or self:GetClass() == "prop_vehicle_jeep_old"
end

function meta:IsTransport()
	return self:IsCar() or self:GetClass() == "helicopter"
end

function metaply:HasAllies()
	return self:isCP() or (getgroup and getgroup(self))
end

function metaply:isHitman()
	return self:Team() == TEAM_MOB or self:Team() == TEAM_MERC
end

function metaply:isTradingJob()
	return self:Team() == TEAM_GUN or self:Team() == TEAM_TRADE or self:Team() == TEAM_COOK or self:Team() == TEAM_CAR --[[or self:Team() == TEAM_MEDIC]]
end

function metaply:isCook()
	return self:getJobTable().cook
end