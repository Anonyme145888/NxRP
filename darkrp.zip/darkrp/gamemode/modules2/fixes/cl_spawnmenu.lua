function DarkRP.getSpawnMenuOpened()
    return input.IsButtonDown(KEY_Q) --opened
end