local eyepos = Vector()
local eyeangles = Angle()
local eyevector = Vector()
local eyefov = 90

hook.Add( "RenderScene", "Eye", function(origin, angles, fov)
	eyepos = origin
	eyeangles = angles
	eyefov = fov
	eyevector = angles:Forward()
end)

function EyePos() return eyepos end
function EyeVector() return eyevector end
function EyeAngles() return eyeangles end
function EyeFov() return eyefov end