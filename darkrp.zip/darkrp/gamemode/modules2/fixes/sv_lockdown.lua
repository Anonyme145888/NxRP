function LockDown(ply, text, public)
    if (string.sub(text, 1, 4) == "/lkd") then
        if not ply:isMayor() then DarkRP.notify(ply, 1, 4, "Vous n'avez pas les privilèges nécessaires !") return "" end
        if GetGlobalBool("LockDown1") then DarkRP.notify(ply, 1, 4, "Le protocole est déjà en cours !") return "" end
        if ply:GetNWBool("FilterLockDown") then DarkRP.notify(ply, 1, 4, "Attendez quelques secondes !") return "" end
        if string.len(string.sub(text, 5, string.len(text))) < 99999 and string.len(string.sub(text, 5, string.len(text))) > 3 then
            ply:SetNWBool("FilterLockDown", true) -- antispam
            timer.Create("T"..ply:SteamID64(), 60, 1, function() ply:SetNWBool("FilterLockDown", false) end)
            for _,self in pairs(player.GetAll()) do
                self:ConCommand("play " .. GAMEMODE.Config.lockdownsound .. "\n")
            end
            DarkRP.notifyAll(0, 3, DarkRP.getPhrase("lockdown_started"))
            SetGlobalBool("LockDown1", true)
            SetGlobalString("ReasonLockDown", string.sub(text, 9, string.len(text)))
            for k,v in pairs(player.GetAll()) do
                v:ChatPrint(DarkRP.getPhrase("hud_lockdown")..GetGlobalString("ReasonLockDown"))
            end
            hook.Run("LockdownStart", ply)
            return ""
        else
            DarkRP.notify(ply, 1, 4, "Veuillez entrer une raison !")
            return ""
        end
    end
end
hook.Add("PlayerSay", "LockDown", LockDown);

--

function TurnLockDownOff(ply)
    if ply:Team() == TEAM_MAYOR then
        SetGlobalBool("LockDown1", false)
        hook.Run("LockdownEnd", ply)
    end
end
 
hook.Add("PlayerDeath", "On Death", TurnLockDownOff)
hook.Add("OnPlayerChangedTeam", "On Change Team", TurnLockDownOff)
hook.Add("PlayerDisconnected", "On disconnect", TurnLockDownOff)

--

function UnLockDown(ply, text, public)
    if (string.sub(text, 1, 6) == "/unlkd") then
        if not ply:isMayor() then DarkRP.notify(ply, 1, 4, "Vous n'avez pas les privilèges nécessaires !") return "" end
        if not GetGlobalBool("LockDown1") then DarkRP.notify(ply, 1, 4, "Le protocole n'est pas en cours !") return "" end
        DarkRP.notifyAll(0, 3, DarkRP.getPhrase("lockdown_ended"))
        SetGlobalBool("LockDown1", false)
        hook.Run("LockdownEnd", ply)
        return ""
    end
end
hook.Add("PlayerSay", "UnLockDown", UnLockDown);