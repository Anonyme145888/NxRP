hook.Add("SpawnMenuOpen", "spawnmenu_fix", function()
	local all = {"#spawnmenu.category.dupes", "#spawnmenu.category.saves"}
	local nonadmins = {"#spawnmenu.category.weapons", "#spawnmenu.category.entities", "#spawnmenu.category.npcs", "SCars"}

	for k = #g_SpawnMenu.CreateMenu.Items, 1, -1 do
		local v = g_SpawnMenu.CreateMenu.Items[k]
		if table.HasValue(all, v.Name) or not LocalPlayer():IsSuperAdmin() and table.HasValue(nonadmins, v.Name) then
			g_SpawnMenu.CreateMenu:CloseTab(v.Tab, true)
		end
	end

	hook.Remove("SpawnMenuOpen", "spawnmenu_fix")
end)

local PopulateVehicles = function(pnlContent, tree, node)
	local Categorised = {}

	local Vehicles = list.Get("Vehicles")

	if (Vehicles) then
		for k, v in pairs(Vehicles) do

			if v.Class ~= "prop_vehicle_prisoner_pod" and not LocalPlayer():IsSuperAdmin() then
				continue
			end
			
			
			v.Category = v.Category or "Other"
			Categorised[v.Category] = Categorised[v.Category] or {}
			v.ClassName = k
			v.PrintName = v.Name
			v.ScriptedEntityType = "vehicle"
			table.insert(Categorised[ v.Category ], v)
		end
	end

	for CategoryName, v in SortedPairs(Categorised) do

		local node = tree:AddNode(CategoryName, "icon16/bricks.png")

		node.DoPopulate = function(self)
			if (self.PropPanel) then return end

			self.PropPanel = vgui.Create("ContentContainer", pnlContent)
			self.PropPanel:SetVisible(false)
			self.PropPanel:SetTriggerSpawnlistChange(false)

			for k, ent in SortedPairsByMemberValue(v, "PrintName") do
				spawnmenu.CreateContentIcon(ent.ScriptedEntityType or "entity", self.PropPanel, {
					nicename = ent.PrintName or ent.ClassName,
					spawnname = ent.ClassName,
					material = "entities/" .. ent.ClassName .. ".png",
					admin = ent.AdminOnly
				})
			end
		end

		node.DoClick = function(self)
			self:DoPopulate()
			pnlContent:SwitchPanel(self.PropPanel)
		end
	end

	local FirstNode = tree:Root():GetChildNode(0)
	if (IsValid(FirstNode)) then
		FirstNode:InternalDoClick()
	end
end

hook.Add("PopulateVehicles", "AddEntityContent", function(pnlContent, tree, node)
	hook.Add("SpawnMenuOpen", "PopulateVehicles", function()
		PopulateVehicles(pnlContent, tree, node)

		hook.Remove("SpawnMenuOpen", "PopulateVehicles")
	end)
end)