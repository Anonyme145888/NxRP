

if SERVER then
	util.AddNetworkString( 'HitInfo' )
 
	hook.Add( 'EntityTakeDamage', 'DMInfo', function( ent, dmginfo )
		if not dmginfo:GetAttacker():IsPlayer() or dmginfo:GetDamage() <= 0 or not dmginfo:GetDamage() or ent:Health() <= 0 or ent == dmginfo:GetAttacker() then return end 
        if not ent:IsPlayer() then return end 
		net.Start( 'HitInfo' )
          
           net.WriteUInt( dmginfo:GetDamage(), 8 )
           
		net.Send( dmginfo:GetAttacker() )
	end )

	hook.Add( "PlayerDeath", "HitDeathNigger", function(victim, weapon, killer)
		
		if not killer:IsPlayer() and not victim:IsPlayer() then return end 
		if not victim:IsValid() then return end
		if not killer:IsValid() then return end
		
		net.Start( 'HitInfo' )
          
           net.WriteBool(true)
           
		net.Send( killer )
	end )
else
	local Alpha = 0
	local Alpha2 = 0
	local Dmg = 0
	local hide = 0
    surface.CreateFont("RayDamage", {font = "Calibri", size = 24, weight = 900}) -- win vista+

	net.Receive( 'HitInfo', function( len, ply ) 
		
		if Alpha2 > 40 then
			Dmg = Dmg + net.ReadUInt( 8 )	
		else
			Dmg = net.ReadUInt( 8 )	
		end
        if net.ReadUInt(8) then
			Alpha = 255
			Alpha2 = 255
			hide = 0
		end
        
        if net.ReadBool() then
            surface.PlaySound("hit/hitmarker_heavy.wav")
            LocalPlayer():ScreenFade(SCREENFADE.IN, Color(10, 100, 200, 40), 0.5, 0)
        else    
            surface.PlaySound("hit/hitmarker.wav")
        end

		timer.Simple( 1.5, function() Alpha = math.max(0, Alpha - FrameTime() / 2.5) end )
	end )
 
	local texturew = Material( 'data/cherep.png' )
 
	hook.Add( 'HUDPaint', 'DMInfo', function()
		if not Dmg then return end

        local color_damage = Color(255, 85, 85)

		
        if Alpha > 0 then
            surface.SetAlphaMultiplier(Alpha)
                draw.SimpleTextOutlined(Dmg, "RayDamage", ScrW() * .5, ScrH() * .6, color_damage, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
            surface.SetAlphaMultiplier(1)
    
            Alpha = math.max(0, Alpha - FrameTime() / 2.5)
        else
            Dmg = 0
        end

		if hide then
			Alpha = Alpha - 5
			Alpha2 = Alpha2 - 2
		end
	end )
end