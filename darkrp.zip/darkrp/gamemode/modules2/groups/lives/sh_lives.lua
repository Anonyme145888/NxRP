AddCSLuaFile()
if CLIENT then
local mt = FindMetaTable("Player")

local banned = {
	["wep_nx_c4"] = true,
	["molotov"] = true,
	["weapon_rpg"] = true,
	["door_ram"] = true,
	["handcuffs"] = true,
	["stunstick"] = true,
	["taser"] = true,
  ["weapon_hook"] = true,
  ["lockpick"] = true,
  ["med_kit"] = true,
  ["arrest_stick"] = true,
  ["unarrest_stick"] = true,
  ["nx_speedmeter"] = true,
  ["moneychecker"] = true,
  ["weapon_extinguisher"] = true,
  ["greatrp_handcuffs"] = true,
  ["fun_vac"] = true,
  ["weapon_fists"] = true,
  ["manhack_welder"] = true,
  ["weapon_ultrarpg"] = true,
  ["weapon_bugbait"] = true,
}

function mt:CanPullWeapon(wep)
	return not (self:GetNWInt("life_stock") == 0 and (wep:GetClass():Left(5) == "fas2_" or wep:GetClass():Left(4) == "nxw_" or banned[wep:GetClass()]))
end
end

