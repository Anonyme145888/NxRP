include("sh_lives.lua")

-- Таймер НЕ обнуляется. Идет постояннно.
concommand.Add("LivesReset", function(ply)
  if not ply:IsSuperAdmin() then return end
  ply:SetNWInt("life_stock", 2)
end)

-- Нет жизней = нет оружия
local function Lives(ply)
      if ply:GetNWInt("life_stock") == 2 then return end
      if ply:GetNWInt("life_stock") == 1 then return end

      --[[ Что бы админы в клоке или ноклипе без жизней могли использовать оружие (Физган и т.п)
      if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
      if ply:GetNWBool("Cloak") == true then return end
      ]]

      -- Новая идея - оружие которое можно носить
      if not ply:IsValid() then return end
      if not ply:GetActiveWeapon():IsValid() then return end

      if ply:GetActiveWeapon():GetClass() == "weapon_physgun" then return end
      if ply:GetActiveWeapon():GetClass() == "weaponchecker" then return end
      if ply:GetActiveWeapon():GetClass() == "keys" then return end
      if ply:GetActiveWeapon():GetClass() == "wep_jack_job_watercan" then return end
      if ply:GetActiveWeapon():GetClass() == "selfie" then return end
      if ply:GetActiveWeapon():GetClass() == "gmod_camera" then return end
      if ply:GetActiveWeapon():GetClass() == "gmod_tool" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_physcannon" then return end
      if ply:GetActiveWeapon():GetClass() == "nx_repair" then return end
      if ply:GetActiveWeapon():GetClass() == "nx_fuel" then return end
      if ply:GetActiveWeapon():GetClass() == "nx_medcenter" then return end
      if ply:GetActiveWeapon():GetClass() == "gr_radio" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_fishing_rod" then return end
      if ply:GetActiveWeapon():GetClass() == "npc_mover" then return end
      if ply:GetActiveWeapon():GetClass() == "vc_wrench" then return end
      if ply:GetActiveWeapon():GetClass() == "vc_spikestrip_wep" then return end
      if ply:GetActiveWeapon():GetClass() == "vc_jerrycan" then return end

      if ply:GetActiveWeapon():GetClass() == "grserv_hands" then return end
      if ply:GetActiveWeapon():GetClass() == "dradio" then return end
      if ply:GetActiveWeapon():GetClass() == "guthscp_keycard_omni" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_keycard_level1" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_keycard_level2" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_keycard_level3" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_keycard_level4" then return end
      if ply:GetActiveWeapon():GetClass() == "weapon_keycard_level5" then return end
      if ply:GetActiveWeapon():GetClass() == "med_kit" then return end
      if ply:GetActiveWeapon():GetClass() == "flashlight" then return end
  
      if ply:GetNWInt("life_stock") <= 0 then
          ply:SelectWeapon("keys")
      end
end
    
-- 2 Жизни при спавне
function Ispawned( ply )
    ply:SetNWInt("life_stock", 2)
end
hook.Add( "PlayerInitialSpawn", "GetMeLives", Ispawned )

-- Минус 1 жизнь после смерти
function playerDies(ply)

    timer.Create("lives_kills"..ply:SteamID64(), .1, 0, function()
       if ply:GetNWInt("life_stock") <= 0 then
          Lives(ply)
       end
    end)

    if ply:GetNWInt("life_stock") == 2 then
        ply:SetNWInt("life_stock", 1)
        timer.Create("life_nextRestock"..ply:SteamID64(), 1, 900, function()
            ply:SetNWFloat("life_nextRestock_t", timer.RepsLeft("life_nextRestock"..ply:SteamID64()))
            if ply:GetNWInt("life_stock") == 1 and timer.RepsLeft("life_nextRestock"..ply:SteamID64()) <= 0 then
                ply:SetNWInt("life_stock", 2)
            end
            if ply:GetNWInt("life_stock") <= 0 and timer.RepsLeft("life_nextRestock"..ply:SteamID64()) <= 0 then
                ply:SetNWInt("life_stock", 1)
                timer.Create("life_nextRestock2"..ply:SteamID64(), 1, 900, function()
                    ply:SetNWFloat("life_nextRestock_t", timer.RepsLeft("life_nextRestock2"..ply:SteamID64()))
                    if ply:GetNWInt("life_stock") == 1 and timer.RepsLeft("life_nextRestock2"..ply:SteamID64()) <= 0 then
                        ply:SetNWInt("life_stock", 2)
                    end
                end)
            end
        end)
    local tempsRestant = ply:GetNWFloat("life_nextRestock_t")/60
    timer.Create("life_Restock"..ply:SteamID64(), 2, 1, function()
        DarkRP.notify(ply, 1, 4, "Il vous reste 1 vie, attendez "..(math.floor(tempsRestant * 1) / 1).." minutes avant de récupérer 2 vies.")
    end)
elseif ply:GetNWInt("life_stock") == 1 then
    local tempsRestant = ply:GetNWFloat("life_nextRestock_t")/60
    ply:SetNWInt("life_stock", 0)
    DarkRP.notify(ply, 1, 4, "Il vous reste 0 vie, attendez "..(math.floor(tempsRestant * 1) / 1).." minutes avant de récupérer 1 vie.")
end
end

hook.Add("PlayerDeath", "livesdeath", playerDies)
