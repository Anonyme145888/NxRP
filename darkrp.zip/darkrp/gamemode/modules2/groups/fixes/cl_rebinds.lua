hook.Add("PlayerBindPress", "Rebinds", function(_, bind, pressed)
	if
		bind == input.LookupKeyBinding(KEY_G)
		or
		bind == input.LookupKeyBinding(KEY_H)
		or
		bind == input.LookupKeyBinding(KEY_LALT)
		or
		bind == input.LookupKeyBinding(MOUSE_MIDDLE)
	then
		return true
	end
end)

local keys = {
	[KEY_I] = false,
	[KEY_G] = false,
	[KEY_H] = false,
	[KEY_LALT] = false,
	[MOUSE_MIDDLE] = false,
}

hook.Add("Think", "Rebinds", function()
	if gui.IsGameUIVisible() or IsValid(vgui.GetKeyboardFocus()) or IsValid(LocalPlayer().Instrument) then
		return
	end

	for key, val in pairs(keys) do
		local b = input.IsButtonDown(key)

		if b ~= keys[key] and b then
			--[[
			if key == KEY_I then
				DarkRP.openPocketMenu()
			else
			]]
			if key == KEY_G then
				local entUse, ent = hook.Run("FindUseEntity", LocalPlayer())
                if not entUse then return end
                if entUse:GetClass() == "money_printer" or entUse:GetClass() == "money_printer_premium" then
                    net.Start("withdrawp")
	                net.WriteEntity(entUse)
            
                    net.SendToServer()
               
                end
                if not entUse:IsValid() then goto skip end
								
				::skip::
				
				RunConsoleCommand("rp_pickup")
	
			elseif key == KEY_H then
				net.Start("flashlight_use")
				net.SendToServer()
			elseif key == KEY_LALT then
				local wep = LocalPlayer():GetActiveWeapon()

				if wep.IsFAS2Weapon then
					RunConsoleCommand("fas2_togglegunpimper") 
				else
					return
				end
			end
		end

		::skip::
		keys[key] = b
	end
end)