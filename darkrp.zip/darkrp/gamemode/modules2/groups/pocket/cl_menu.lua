local meta = FindMetaTable("Player")
local pocket = {}
local frame
local reload

--[[-------------------------------------------------------------------------
Stubs
---------------------------------------------------------------------------]]
DarkRP.stub{
	name = "openPocketMenu",
	description = "Open the DarkRP pocket menu.",
	realm = "Client",
	parameters = {
	},
	returns = {
	},
	metatable = DarkRP
}

--[[-------------------------------------------------------------------------
Interface functions
---------------------------------------------------------------------------]]
function meta:getPocketItems()
	if self ~= LocalPlayer() then return nil end

	return pocket
end

function meta:isPocketFull()
	return table.Count(LocalPlayer():getPocketItems()) >= GAMEMODE.Config.pocketitems
end

function DarkRP.openPocketMenu()
	if frame and frame:IsValid() and frame:IsVisible() then return end
	--if LocalPlayer():GetActiveWeapon():GetClass() ~= "pocket" then return end
	if not pocket then pocket = {} return end
	if not next(pocket) then return end
	frame = vgui.Create("DFrame")
	frame.layout = frame:Add("DIconLayout")
	frame.layout:Dock(FILL)
	frame:SetTitle(DarkRP.getPhrase("drop_item"))
	frame.btnMaxim:SetVisible(false)
	frame.btnMinim:SetVisible(false)
	frame:SetVisible(true)
	frame:MakePopup()

	reload()
	frame:SetSkin(GAMEMODE.Config.DarkRPSkin)
end


--[[-------------------------------------------------------------------------
UI
---------------------------------------------------------------------------]]
function reload()
	if not IsValid(frame) or not frame:IsVisible() then return end
	if not pocket or next(pocket) == nil then frame:Close() return end

	local itemCount = table.Count(pocket)

	frame:SetSize(5 * 64 + 10, 34 + math.ceil(itemCount/5) * 64)
	frame:Center()

	local i = 0

	local items = {}
	for k,v in pairs(pocket) do

		local icon = vgui.Create("SpawnIcon", frame.layout)
		icon:SetPos(i * 64, 25)
		icon:SetModel(v.model)
		icon:SetSize(64, 64)
		icon:SetTooltip()
		icon.DoClick = function(self)
			icon:SetTooltip()

			net.Start("DarkRP_PocketAct")
				net.WriteUInt(2, 8)
				net.WriteFloat(k)
			net.SendToServer()
			pocket[k] = nil

			itemCount = itemCount - 1

			if itemCount == 0 then
				frame:Close()
				return
			end

			fn.Map(self.Remove, items)
			items = {}
		end

		table.insert(items, icon)
		i = i + 1
	end
end

local function retrievePocket()
	pocket = net.ReadTable()
	reload()

	hook.Run("PocketUpdated", pocket)
end
net.Receive("DarkRP_Pocket", retrievePocket)
