--[[
hook.Add("HUDPaint", "Ghetto", function()
	local offx, offy = ScrW() / 2, ScrH() - 20

	surface.DrawKeyCap(offx, offy, "g", 0.5, 1, DarkRP.getPhrase("pickup_item"))
	surface.DrawKeyCap(offx, offy, "h", 0.5, 2, DarkRP.getPhrase("drop_last_item"))
	surface.DrawKeyCap(offx, offy, "i", 0.5, 1, DarkRP.getPhrase("inventory"))
end)
]]