nxgroups = {}
nxgroupjobs = {TEAM_GANG}
nxgroupupgrades = {
	radio = {
		name = DarkRP.getPhrase("nx_radio"),
		desc = DarkRP.getPhrase("radio_desc"),
		time = 0,
		price = 2000
	},
	halo = {
		name = DarkRP.getPhrase("gang_halo"),
		desc = DarkRP.getPhrase("police_halo_desc"),
		time = 60,
		price = 1500
	}
}

for k, v in next, nxgroupupgrades do
	v.time = v.time * 60
end