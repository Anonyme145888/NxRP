util.AddNetworkString("NXGroupChat")
util.AddNetworkString("NXGroupCreate")
util.AddNetworkString("NXGroupControl")

local function haloallenable(ent)
   local gang_name = ent:GetNWString("gang_name")
   for k, v in pairs(player.GetAll()) do
        if v:GetNWString("gang_name") == gang_name then
          net.Start("NXGroupHalo")
          net.WriteBool(true)
          net.Send(v)
        end
    end
end

local function haloalldisable(ent)
   local gang_name = ent:GetNWString("gang_name")
   for k, v in pairs(player.GetAll()) do
        if v:GetNWString("gang_name") == gang_name then
          net.Start("NXGroupHalo")
          net.WriteBool(false)
          net.Send(v)
        end
    end
end
local function halodisable(ent)
    net.Start("NXGroupHalo")
    net.WriteBool(false)
    net.Send(ent)
end

util.AddNetworkString("XPGangsCreation")
concommand.Add("gang_create", function(ply, len)
    if ply:Team() == TEAM_GANG and ply:GetNWString("gang_name") == "None" then
        net.Start("XPGangsCreation")
        net.Send(ply)
    else
    DarkRP.notify(ply,  1, 4, "Vous faites déjà partie d’un gang!")
    end
end)

util.AddNetworkString("NXGroupSetName")
net.Receive("NXGroupSetName", function(len, ply)
  local target = net.ReadEntity()
    local name = net.ReadString()
    local gang = target:GetNWString("gang_name")
    if gang == "None" then return end

    target:updateJob( name .." ".."<"..gang..">")
    DarkRP.notify(ply,  2, 4, "Vous avez changé le rang de "..target:Name().."!")
end)

util.AddNetworkString("GangWH")
util.AddNetworkString("NXGroupHalo")
net.Receive("GangWH", function(len,ply)
    local gang_name = ply:GetNWString("gang_name")
    if timer.Exists("halogang"..ply:SteamID()) then
         DarkRP.notify(ply, 1, 4, "Le radar de gang est déjà en place.")
      return
    end
    if !ply:canAfford(1500) then
          DarkRP.notify(ply, 1, 4, "Tu n’as pas assez à acheter.")
       return
    end
    ply:addMoney(-1500)
    DarkRP.notify(ply, 2, 4, "Tu as acheté le radar du groupe.")
    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gang_name then
          DarkRP.notify(v, 2, 4, "Le chef du gang a acquis une amélioration du radar de la bande !")
          net.Start("NXGroupHalo")
          net.WriteBool(true)
          net.Send(v)
       end
    end
    timer.Create("halogang"..ply:SteamID(), 3600, 1, function()
      for k, v in pairs(player.GetAll()) do
        if v:GetNWString("gang_name") == gang_name then
          net.Start("NXGroupHalo")
          net.WriteBool(false)
          net.Send(v)
          end
       end
    end)
end)

util.AddNetworkString("GangRadio")
net.Receive("GangRadio", function(len,ply)
    local gang_name = ply:GetNWString("gang_name")
    if timer.Exists("radiogang"..ply:SteamID()) then
         DarkRP.notify(ply, 1, 4, "La radio du groupe est déjà disponible .")
      return
    end
    if !ply:canAfford(2000) then
          DarkRP.notify(ply, 1, 4, "Tu n’as pas assez à acheter.")
       return
    end
    ply:addMoney(-2000)
    DarkRP.notify(ply, 2, 4, "Tu as acheté la radio de gangs.")
    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gang_name then
          DarkRP.notify(v, 2, 4, "Le chef du gang a acquis la mise à niveau de Radio Gang!")
          v:Give("dradio")
       end
    end
    timer.Create("radiogang"..ply:SteamID(), 3600, 1, function()
      for k, v in pairs(player.GetAll()) do
        if v:GetNWString("gang_name") == gang_name then
             v:StripWeapon("dradio")
          end
       end
    end)
end)

util.AddNetworkString("XPGangsCompletion")
net.Receive("XPGangsCompletion", function(len,ply)
    local ent = net.ReadEntity()
    local gang_name = net.ReadString()

    ent:SetNWString("gang_name", gang_name)
    ent:changeTeam(TEAM_MOB, true)
    ent:updateJob( ent:getJobTable().name .." ".."<"..gang_name..">")
    DarkRP.notify(ent,  1, 4, "Vous avez créé un gang " .. gang_name .. "!")
end)

groupupgrades = groupupgrades or {}
util.AddNetworkString("XPGangsMenu")
concommand.Add("gang_menu", function(ply, len)
   --if ply:Team() == TEAM_MOB then

    if timer.Exists("halogang"..ply:SteamID()) then
       groupupgrades["halo"] = timer.TimeLeft("halogang"..ply:SteamID())
    else
       groupupgrades["halo"] = nil
    end
    if timer.Exists("radiogang"..ply:SteamID()) then
       groupupgrades["radio"] = timer.TimeLeft("radiogang"..ply:SteamID())
    else
       groupupgrades["radio"] = nil
    end

    local gang_name = ply:GetNWString("gang_name")
    net.Start("XPGangsMenu")
    net.WriteString(gang_name)
    net.Send(ply)
    --else
    --DarkRP.notify(ply,  1, 4, "Tu n’es pas le chef du gang !")
    --end
end)

concommand.Add("xp_gangs_dissolve", function(ply, len)
    local gang_name = ply:GetNWString("gang_name")
    DarkRP.notifyAll(1, 4, "Bande "..gang_name.." (patron: "..ply:Name()..") Dissous!")
    ply:changeTeam(TEAM_GANG, true)

    if timer.Exists("halogang"..ply:SteamID()) then
    haloalldisable(ply)
    end

    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gang_name then
          v:SetNWString("gang_name", "None")
          if timer.Exists("radiogang"..ply:SteamID()) then
             v:StripWeapon("dradio")
          end
          v:updateJob( v:getJobTable().name )
       end
    end
    timer.Remove("halogang"..ply:SteamID())
    timer.Remove("radiogang"..ply:SteamID())
end)

local GangMenus
local function GangMenus(answer, hitman, customer, target, price)
    local gangname = customer:GetNWString("gang_name")
    if not tobool(answer) then
         DarkRP.notify(customer, 1, 4, hitman:Nick().." n’a pas accepté l’invitation au gang !")
        return
    end
   if hitman:Team() == TEAM_GANG then
   DarkRP.notify(hitman, 2, 4, "Tu as rejoint un gang "..gangname.."!")
   DarkRP.notify(customer, 2, 4, hitman:Nick().."a accepté une invitation au gang!")
   hitman:SetNWString("gang_name", gangname)
   if timer.Exists("halogang"..customer:SteamID()) then
   haloallenable(hitman)
   end
   if timer.Exists("radiogang"..customer:SteamID()) then
      hitman:Give("dradio")
   end
   hitman:updateJob( hitman:getJobTable().name .." ".."<"..gangname..">")
   else
   DarkRP.notify(hitman,  1, 4, "Vous devez être gangster !")
   end
end

util.AddNetworkString("XPGangsInvite")
net.Receive("XPGangsInvite", function(len,ply)
    local gang = net.ReadEntity()
    local gname = ply:GetNWString("gang_name")
    DarkRP.notify(ply, 1, 4, "Tu as invité "..gang:Name().."!")
    DarkRP.createQuestion("Souhaitez-vous rejoindre un gang "..gname.."?", "GangsCreate"..gang:UserID(), gang, 60, GangMenus, ply, false, false)
end)

hook.Add("PlayerInitialSpawn", "GangsInit", function(ply)
    ply:SetNWString("gang_name", "None")
end)

util.AddNetworkString("XPGangsKick")
net.Receive("XPGangsKick", function(len,ply)
    local gang = net.ReadEntity()
    local gname = ply:GetNWString("gang_name")
    DarkRP.notify(ply, 1, 4, "Tu n’es plus dans le gang "..gang:Name().."!")
    DarkRP.notify(gang, 1, 4, "Vous avez été expulsé du gang "..gname.."!")
    gang:SetNWString("gang_name", "None")
    gang:updateJob( gang:getJobTable().name )

    if timer.Exists("halogang"..ply:SteamID()) then
    halodisable(gang)
    end
    if timer.Exists("radiogang"..ply:SteamID()) then
    gang:StripWeapon("dradio")
    end
end)


local GangMoney
local function GangMoney(answer, hitman, customer, target, price)
    local gangname = customer:GetNWString("gang_name")
    if not tobool(answer) then
        DarkRP.notify(customer, 1, 4, hitman:Nick().." ai pas donné "..price.."kr!")
        return
    end
    if !hitman:canAfford(price) then
          DarkRP.notify(hitman, 1, 4, "Vous n’avez pas les ressources.")
       return
    end
    -- Бандит
    hitman:addMoney(-price)
    DarkRP.notify(hitman, 2, 4, "vous avez donnée "..price.."kr!")
    -- Глава
    customer:addMoney(price)
    DarkRP.notify(customer, 2, 4, hitman:Nick().." a donné "..price.."kr!")
end

util.AddNetworkString("MoneyGang")
net.Receive("MoneyGang", function(len,ply)
    local money = net.ReadUInt(32)
    local gname = ply:GetNWString("gang_name")
    if money < 100 then DarkRP.notify(ply, 1, 4, "C’est trop peu !") return end
    DarkRP.notify(ply, 2, 4, "Vous avez demandé "..money.."kr a votre gang!")
    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gname and v ~= ply then
          DarkRP.createQuestion("Le chef de gang demande "..money.."kr!", "MoneyGang"..v:UserID(), v, 60, GangMoney, ply, false, money)
       end
    end
end)


util.AddNetworkString("GiveMoneyGang")
net.Receive("GiveMoneyGang", function(len,ply)
    local target = net.ReadEntity()
    local money = net.ReadUInt(32)
    if !ply:canAfford(money) then
          DarkRP.notify(hitman, 1, 4, "Vous n’avez pas les ressources.")
       return
    end
    if money < 50 then DarkRP.notify(ply, 1, 4, "Trop peu de montant!") return end
    ply:addMoney(-money)
    DarkRP.notify(ply, 2, 4, "vous avez donnée "..target:Nick().." "..money.."kr!")
    -------------------------
    target:addMoney(money)
    DarkRP.notify(target, 2, 4, ply:Nick().." vous a remis "..money.."kr!")
end)

hook.Add( "OnPlayerChangedTeam", "GangRemove", function(ply, old, new)
   -- halodisable(ply)
    if old == TEAM_MOB then
    local gang_name = ply:GetNWString("gang_name")

    if timer.Exists("halogang"..ply:SteamID()) then
    haloalldisable(ply)
    end

    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gang_name then
          v:SetNWString("gang_name", "None")
          v:updateJob( v:getJobTable().name )
          if timer.Exists("radiogang"..ply:SteamID()) then
             v:StripWeapon("dradio")
          end
       end
     end
     timer.Remove("halogang"..ply:SteamID())
     timer.Remove("radiogang"..ply:SteamID())
    end
end)

hook.Add( "PlayerDisconnected", "GangRemove2", function(ply)
    if ply:Team() == TEAM_MOB then
    local gang_name = ply:GetNWString("gang_name")

    if timer.Exists("halogang"..ply:SteamID()) then
    haloalldisable(ply)
    end

    DarkRP.notifyAll(1, 4, " Le gang "..gang_name.." a été dissous!")
    for k, v in pairs(player.GetAll()) do
       if v:GetNWString("gang_name") == gang_name then
          v:SetNWString("gang_name", "None")
          v:updateJob( v:getJobTable().name )
          if timer.Exists("radiogang"..ply:SteamID()) then
             v:StripWeapon("dradio")
          end
       end
     end
     timer.Remove("halogang"..ply:SteamID())
     timer.Remove("radiogang"..ply:SteamID())
    end
end)


hook.Add( "PlayerSpawn", "GangGiveWeapon", function(ply)
    local gang_name = ply:GetNWString("gang_name")
    if gang_name ~= "None" then
        print(gang_name)
       --ply:updateJob( ply:getJobTable().name .." ".."<"..gang_name..">")
    end
    if ply:Team() == TEAM_GANG or ply:Team() == TEAM_MOB and not gang_name == "None" then
      for k, v in pairs(player.GetAll()) do
      if v:GetNWString("gang_name") == gang_name then
      if timer.Exists("radiogang"..v:SteamID()) then
        ply:Give("dradio")
      end
      end
      end
   end
end)

util.AddNetworkString("NXGroupLeave")
net.Receive("NXGroupLeave", function(len,ply)
    DarkRP.notify(ply, 2, 4, "Tu n’es plus dans le gang!")
    ply:SetNWString("gang_name", "None")
    ply:updateJob( ply:getJobTable().name )
    ply:StripWeapon("dradio")
    halodisable(ply)
end)

hook.Add( "OnPlayerChangedTeam", "GangRemove3", function(ply, old, new)
    local gang_name = ply:GetNWString("gang_name")
    if new == TEAM_MOB then return end
    if old == TEAM_GANG and gang_name ~= "None" then
       ply:SetNWString("gang_name", "None")
       ply:updateJob( ply:getJobTable().name )
       halodisable(ply)
    end
end)