xpgangs = {}
currency = "%s\194\160kr"

xpgangs.commands = {
    ["Inviter à rejoindre le gang"] = {
        func = function()
            local menu = DermaMenu()
            menu:MakePopup()
            menu:SetPos(input.GetCursorPos())

            for k, v in pairs(player.GetAll()) do
                if not v:IsCP() then
                    menu:AddOption(v:Name(), function()
                        net.Start("XPGangsInvite")
                        net.WriteEntity(v)
                        net.SendToServer()
                    end)  
                end
            end         
        end,
    },

    ["Bannir du gang"] = {
        func = function()
            local menu = DermaMenu()
            menu:MakePopup()
            menu:SetPos(input.GetCursorPos())

            for k, v in pairs(player.GetAll()) do
                if v:GetNWString("gang_name") == LocalPlayer():GetNWString("gang_name") and LocalPlayer() != v then
                    menu:AddOption(v:Name(), function()
                        net.Start("XPGangsKick")
                        net.WriteEntity(v)
                        net.SendToServer()
                    end)  
                end
            end  
        end,
    }, 

    [DarkRP.getPhrase("gang_disband")] = {
        func = function()
            DarkRP.DermaQuery(DarkRP.getPhrase("gang_disband_title"), DarkRP.getPhrase("gang_disband_confirm"), "ОК", function()
                RunConsoleCommand("xp_gangs_dissolve") 
            end, DarkRP.getPhrase("cancel"))
        end,
    }, 

    [DarkRP.getPhrase("gang_give")] = {
        func = function()
            local menu = DermaMenu()
            menu:MakePopup()
            menu:SetPos(input.GetCursorPos())

            for k, v in pairs(player.GetAll()) do
                if v:GetNWString("gang_name") == LocalPlayer():GetNWString("gang_name") and LocalPlayer() != v then
                    menu:AddOption(v:Name(), function()
                        DarkRP.StringRequest(DarkRP.getPhrase("gang_give_title"), "Quantité:", function(n)
                        if tonumber(n) then
                        net.Start("GiveMoneyGang")
                        net.WriteEntity(v)
                        net.WriteUInt(tonumber(n), 32)
                        net.SendToServer()
                        end
                        end, "0")
                    end)  
                end
            end  
        end,
    }, 

    [DarkRP.getPhrase("gang_request_title")] = {
        func = function()
            DarkRP.StringRequest(DarkRP.getPhrase("gang_request_title"), DarkRP.getPhrase("gang_request_am", currency), function(n)
                if tonumber(n) then
                    net.Start("MoneyGang")
                        net.WriteUInt(tonumber(n), 32)
                    net.SendToServer()
                end
            end, "0")
        end,
    },    
}