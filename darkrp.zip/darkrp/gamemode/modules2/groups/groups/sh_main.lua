function getgroup(ply)
	local name = ply:GetNWString("NXGroup")
	return name ~= "" and name or nil, SERVER and nxgroups[name] or nil
end

hook.Add("loadCustomDarkRPItems", "nxgroupjobs", function()
	nxgroupjobs = {TEAM_GANG}
end)