local death_replicas = {}
local death_replicas_female = {}

local weapons = {}
local female = {}

local delay_kill = 12
local nextOccurance_kill = 0

death_replicas = { 
    "vo/npc/male01/gordead_ques01.wav",
    "vo/npc/male01/gordead_ques02.wav",
    "vo/npc/male01/gordead_ques07.wav",
    "vo/npc/male01/gordead_ques14.wav",
    "vo/npc/male01/gordead_ques12.wav",
    "vo/npc/male01/gordead_ques11.wav",
    "vo/npc/male01/gordead_ques10.wav",    
    "vo/npc/male01/gordead_ans18.wav",
    "vo/npc/male01/gordead_ans10.wav",
    "vo/npc/male01/gordead_ans11.wav",
    "vo/npc/male01/gordead_ans12.wav",
    "vo/npc/male01/gordead_ans13.wav",
    "vo/npc/male01/gordead_ans15.wav",
    "vo/npc/male01/gordead_ans19.wav",
    "vo/npc/male01/yeah02.wav",
    "vo/npc/male01/whoops01.wav",
    "vo/npc/male01/sorry03.wav"
}

death_replicas_female = { 
    "vo/npc/female01/gordead_ques01.wav",
    "vo/npc/female01/gordead_ques02.wav",
    "vo/npc/female01/gordead_ques07.wav",
    "vo/npc/female01/gordead_ques14.wav",
    "vo/npc/female01/gordead_ques12.wav",
    "vo/npc/female01/gordead_ques11.wav",
    "vo/npc/female01/gordead_ques10.wav",
    "vo/npc/female01/gordead_ans18.wav",
    "vo/npc/female01/gordead_ans10.wav",
    "vo/npc/female01/gordead_ans11.wav",
    "vo/npc/female01/gordead_ans12.wav",
    "vo/npc/female01/gordead_ans13.wav",
    "vo/npc/female01/gordead_ans15.wav",
    "vo/npc/female01/gordead_ans19.wav",
    "vo/npc/female01/yeah02.wav",
    "vo/npc/female01/whoops01.wav",
    "vo/npc/female01/sorry03.wav"
}

weapons = {
    "skynet_ak47",
    "skynet_cz75",
    "skynet_famas",
    "skynet_g3sg1",
    "skynet_galil",
    "skynet_glock18",
    "skynet_m4a1",
    "skynet_m4a4",
    "skynet_mac10",
    "skynet_mp5",
    "skynet_mp7",
    "skynet_mp9",
    "skynet_p250",
    "skynet_tec9",
    "skynet_ump45",
    "skynet_ump45_police",
    "skynet_ak47_police",
    "skynet_glock18_police",
    "skynet_m4a1_police",
    "skynet_m4a4_police",
    "skynet_mp5_police",
    "skynet_xm1014",
    "skynet_xm1014_police",
    "skynet_bizon",
    "skynet_m249", 
    "skynet_awp",
    "skynet_deagle",
    "skynet_usp",
    "skynet_r8",
    "skynet_frag",
    "gmod_tool",
    "weapon_physgun",
    "weapon_physcannon",
    "keys",
    "selfie",
    "pocket"
}

female = {
    "models/player/group01/female_01.mdl",
    "models/player/group01/female_02.mdl",
    "models/player/group01/female_03.mdl",
    "models/player/group01/female_04.mdl",
    "models/player/group01/female_06.mdl",
    "models/player/group03/female_01.mdl",
    "models/player/group03/female_02.mdl",
    "models/player/group03/female_03.mdl",
    "models/player/group03/female_04.mdl",
    "models/player/group03/female_06.mdl",
    "models/player/group03m/female_01.mdl",
    "models/player/group03m/female_02.mdl",
    "models/player/group03m/female_03.mdl",
    "models/player/group03m/female_04.mdl",
    "models/player/group03m/female_05.mdl",
    "models/player/mossman.mdl",
    "models/player/p2_chell.mdl",
    "models/player/mossman_arctic.mdl",
    "models/fearless/chef2.mdl"
}

hook.Add("PlayerDeath", "SkynetReplicas_Death", function(victim, killer)
    replicas_kill_enabled = true
    
    if not replicas_kill_enabled then return end

    if (IsValid(killer) and IsValid(victim)) then
        if (killer:IsPlayer() and victim:IsPlayer()) then
            if killer:Name() == victim:Name() then return end
            if not table.HasValue(weapons, killer:GetActiveWeapon():GetClass()) then return end

            local timeLeft_kill = nextOccurance_kill - CurTime()
            
            if timeLeft_kill < 0 then
                nextOccurance_kill = CurTime() + delay_kill         
                
                timer.Simple(2, function()
                    if table.HasValue(female, string.lower(killer:GetModel())) then
                        killer:EmitSound(table.Random(death_replicas_female), 80, 100)
                    else
                        killer:EmitSound(table.Random(death_replicas), 80, 100)
                    end
                end)
            end
        end
    end
end)