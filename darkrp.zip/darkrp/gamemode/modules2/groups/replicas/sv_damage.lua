local attacker_replicas = {}
local attacker_replicas_female = {}

local victim_replicas = {}
local victim_replicas_female = {}

local female = {}
local weapons = {}

local delay = 8
local nextOccurance = 0

attacker_replicas = { 
    "vo/npc/male01/question14.wav",
    "vo/npc/male01/vquestion03.wav",
    "vo/npc/male01/whoops01.wav",
    "vo/npc/male01/vquestion04.wav",
    "vo/trainyard/male01/cit_window_use01.wav",
    "vo/npc/male01/squad_away03.wav",
    "vo/npc/male01/gotone01.wav",
    "vo/npc/male01/vanswer03.wav",
    "vo/Streetwar/tunnel/male01/c17_06_plank01.wav",
    "vo/trainyard/male01/cit_pedestrian05.wav",
    "vo/npc/male01/vanswer07.wav",
    "vo/coast/barn/male01/getoffroad01.wav",
    "vo/npc/male01/gordead_ques17.wav",
    "vo/npc/male01/vquestion06.wav",
    "vo/npc/male01/answer31.wav",
    "vo/npc/male01/answer30.wav",
    "vo/npc/male01/answer29.wav",
    "vo/npc/male01/answer28.wav",
    "vo/npc/male01/answer27.wav",
    "vo/npc/male01/answer26.wav",
    "vo/npc/male01/answer09.wav",
    "vo/npc/male01/answer10.wav",
    "vo/npc/male01/answer11.wav",
    "vo/npc/male01/answer12.wav",
    "vo/npc/male01/answer17.wav",
    "vo/npc/male01/answer18.wav",
    "vo/npc/male01/answer19.wav",
    "vo/npc/male01/answer24.wav",
    "vo/npc/male01/answer09.wav",
    "vo/npc/male01/gordead_ans07.wav",
    "vo/npc/male01/gordead_ans17.wav",
    "vo/npc/male01/gordead_ans16.wav",
    "vo/npc/male01/gordead_ans15.wav",
    "vo/npc/male01/gordead_ans14.wav",
    "vo/npc/male01/gordead_ans13.wav",
    "vo/npc/male01/gordead_ans12.wav",
    "vo/npc/male01/gordead_ans11.wav",
    "vo/npc/male01/gordead_ans10.wav",
    "vo/npc/male01/gordead_ans09.wav",
    "vo/npc/male01/gordead_ans08.wav",
    "vo/npc/male01/gordead_ans04.wav",
    "vo/npc/male01/gordead_ans02.wav",
    "vo/npc/male01/gordead_ans01.wav"
}

attacker_replicas_female = { 
    "vo/trainyard/female01/cit_bench01.wav",
    "vo/trainyard/female01/cit_bench02.wav",
    "vo/trainyard/female01/cit_bench03.wav",
    "vo/trainyard/female01/cit_bench04.wav",
    "vo/trainyard/female01/cit_foodline01.wav",
    "vo/trainyard/female01/cit_foodline02.wav",
    "vo/trainyard/female01/cit_foodline03.wav",
    "vo/trainyard/female01/cit_foodline04.wav",
    "vo/trainyard/female01/cit_pedestrian01.wav",
    "vo/trainyard/female01/cit_pedestrian02.wav",
    "vo/trainyard/female01/cit_pedestrian03.wav",
    "vo/trainyard/female01/cit_pedestrian04.wav",
    "vo/trainyard/female01/cit_pedestrian05.wav",
    "vo/trainyard/female01/cit_tvbust05.wav",
    "vo/trainyard/female01/cit_window_use01.wav",
    "vo/trainyard/female01/cit_window_use02.wav",
    "vo/trainyard/female01/cit_window_use03.wav",
    "vo/trainyard/female01/cit_window_use04.wav",
    "vo/npc/female01/getdown02.wav",
    "vo/npc/female01/gethellout.wav",
    "vo/npc/female01/answer31.wav",
    "vo/npc/female01/answer30.wav",
    "vo/npc/female01/answer29.wav",
    "vo/npc/female01/answer28.wav",
    "vo/npc/female01/answer27.wav",
    "vo/npc/female01/answer26.wav",
    "vo/npc/female01/answer09.wav",
    "vo/npc/female01/answer10.wav",
    "vo/npc/female01/answer11.wav",
    "vo/npc/female01/answer12.wav",
    "vo/npc/female01/answer17.wav",
    "vo/npc/female01/answer18.wav",
    "vo/npc/female01/vquestion04.wav",
    "vo/npc/female01/gotone01.wav",
    "vo/npc/female01/vanswer07.wav",
    "vo/npc/female01/vquestion06.wav",
    "vo/npc/female01/squad_away03.wav",
    "vo/npc/female01/gordead_ans07.wav",
    "vo/npc/female01/gordead_ans17.wav",
    "vo/npc/female01/gordead_ans16.wav",
    "vo/npc/female01/gordead_ans15.wav",
    "vo/npc/female01/gordead_ans14.wav",
    "vo/npc/female01/gordead_ans13.wav",
    "vo/npc/female01/gordead_ans12.wav",
    "vo/npc/female01/gordead_ans11.wav",
    "vo/npc/female01/gordead_ans10.wav",
    "vo/npc/female01/gordead_ans09.wav",
    "vo/npc/female01/gordead_ans08.wav",
    "vo/npc/female01/gordead_ans04.wav",
    "vo/npc/female01/gordead_ans02.wav",
    "vo/npc/female01/gordead_ans01.wav"     
}

victim_replicas = {
    "vo/coast/bugbait/sandy_youidiot.wav", 
    "vo/npc/male01/question12.wav", 
    "vo/npc/male01/vanswer08.wav", 
    "vo/npc/male01/squad_affirm04.wav", 
    "vo/npc/male01/vanswer10.wav",
    "vo/npc/male01/question19.wav",
    "vo/npc/male01/gordead_ans04.wav",
    "vo/npc/male01/answer18.wav",
    "vo/npc/male01/answer39.wav",
    "vo/npc/male01/okimready01.wav", 
    "vo/npc/male01/okimready02.wav", 
    "vo/npc/male01/okimready03.wav", 
    "vo/npc/male01/cps01.wav", 
    "vo/npc/male01/cps02.wav",
    "vo/canals/shanty_go_nag03.wav", 
    "vo/trainyard/cit_blocker_go01.wav", 
    "vo/trainyard/cit_blocker_go03.wav",
    "vo/npc/male01/thehacks02.wav",
    "vo/canals/matt_tearinguprr.wav",
    "vo/npc/male01/answer37.wav",
    "vo/npc/male01/imstickinghere01.wav",
    "vo/npc/male01/evenodds.wav",
    "vo/npc/male01/gordead_ans02.wav",
    "vo/npc/male01/stopitfm.wav",
    "vo/npc/male01/answer01.wav",
    "vo/npc/male01/answer02.wav",
    "vo/npc/male01/answer03.wav",
    "vo/npc/male01/answer31.wav",
    "vo/npc/male01/answer30.wav",
    "vo/npc/male01/answer29.wav",
    "vo/npc/male01/answer28.wav",
    "vo/npc/male01/answer27.wav",
    "vo/npc/male01/answer26.wav",
    "vo/npc/male01/answer09.wav",
    "vo/npc/male01/answer10.wav",
    "vo/npc/male01/answer11.wav",
    "vo/npc/male01/answer12.wav",
    "vo/npc/male01/answer17.wav"
}

victim_replicas_female = {
    "vo/trainyard/female01/cit_bench01.wav",
    "vo/trainyard/female01/cit_bench02.wav",
    "vo/trainyard/female01/cit_bench03.wav",
    "vo/trainyard/female01/cit_bench04.wav",
    "vo/trainyard/female01/cit_foodline01.wav",
    "vo/trainyard/female01/cit_foodline02.wav",
    "vo/trainyard/female01/cit_foodline03.wav",
    "vo/trainyard/female01/cit_foodline04.wav",
    "vo/trainyard/female01/cit_pedestrian01.wav",
    "vo/trainyard/female01/cit_pedestrian02.wav",
    "vo/trainyard/female01/cit_pedestrian03.wav",
    "vo/trainyard/female01/cit_pedestrian04.wav",
    "vo/trainyard/female01/cit_pedestrian05.wav",
    "vo/trainyard/female01/cit_tvbust05.wav",
    "vo/trainyard/female01/cit_window_use01.wav",
    "vo/trainyard/female01/cit_window_use02.wav",
    "vo/trainyard/female01/cit_window_use03.wav",
    "vo/trainyard/female01/cit_window_use04.wav",
    "vo/trainyard/female01/cit_hit01.wav",
    "vo/trainyard/female01/cit_hit02.wav",
    "vo/trainyard/female01/cit_hit03.wav",
    "vo/trainyard/female01/cit_hit04.wav",
    "vo/trainyard/female01/cit_hit05.wav",
    "vo/npc/female01/answer01.wav",
    "vo/npc/female01/answer02.wav",
    "vo/npc/female01/answer03.wav",
    "vo/npc/female01/answer31.wav",
    "vo/npc/female01/answer30.wav",
    "vo/npc/female01/answer29.wav",
    "vo/npc/female01/answer28.wav",
    "vo/npc/female01/answer27.wav",
    "vo/npc/female01/answer26.wav",
    "vo/npc/female01/answer09.wav",
    "vo/npc/female01/answer10.wav",
    "vo/npc/female01/answer11.wav",
    "vo/npc/female01/answer12.wav",
    "vo/npc/female01/answer17.wav",
    "vo/npc/female01/answer18.wav"       
}

female = {
    "models/player/group01/female_01.mdl",
    "models/player/group01/female_02.mdl",
    "models/player/group01/female_03.mdl",
    "models/player/group01/female_04.mdl",
    "models/player/group01/female_06.mdl",
    "models/player/group03/female_01.mdl",
    "models/player/group03/female_02.mdl",
    "models/player/group03/female_03.mdl",
    "models/player/group03/female_04.mdl",
    "models/player/group03/female_06.mdl",
    "models/player/group03m/female_01.mdl",
    "models/player/group03m/female_02.mdl",
    "models/player/group03m/female_03.mdl",
    "models/player/group03m/female_04.mdl",
    "models/player/group03m/female_05.mdl",
    "models/player/mossman.mdl",
    "models/player/p2_chell.mdl",
    "models/player/mossman_arctic.mdl",
    "models/fearless/chef2.mdl"
}

weapons = {
    "skynet_ak47",
    "skynet_cz75",
    "skynet_famas",
    "skynet_g3sg1",
    "skynet_galil",
    "skynet_glock18",
    "skynet_m4a1",
    "skynet_m4a4",
    "skynet_mac10",
    "skynet_mp5",
    "skynet_mp7",
    "skynet_mp9",
    "skynet_p250",
    "skynet_tec9",
    "skynet_ump45",
    "skynet_ump45_police",
    "skynet_ak47_police",
    "skynet_glock18_police",
    "skynet_m4a1_police",
    "skynet_m4a4_police",
    "skynet_mp5_police",
    "skynet_xm1014",
    "skynet_xm1014_police",
    "skynet_bizon",
    "skynet_m249",      
    "skynet_awp",
    "skynet_deagle",
    "skynet_usp",
    "skynet_r8",
    "skynet_frag",
    "gmod_tool",
    "weapon_physgun",
    "weapon_physcannon",
    "keys",
    "selfie",
    "pocket"
}

hook.Add("EntityTakeDamage", "SkynetReplicas_Damage", function(victim, gayperson)
    replicas_damage_enabled = false
    
    local attacker = gayperson:GetAttacker()

    if not replicas_damage_enabled then return end
    if not victim:IsPlayer() or not attacker:IsPlayer() then return end
    if not IsValid(victim) or not IsValid(attacker) then return end

    if victim:Health() < 25 or attacker:Health() < 25 then return end --doesnt protect from awp's shot but something

    if not table.HasValue(weapons, attacker:GetActiveWeapon():GetClass()) then return end --too annoying without it

    local timeLeft = nextOccurance - CurTime()
    
    if timeLeft < 0 then
        nextOccurance = CurTime() + delay
        
        if table.HasValue(female, string.lower(victim:GetModel())) then
            victim:EmitSound(table.Random(victim_replicas_female), 80, 100)
        else
            victim:EmitSound(table.Random(victim_replicas), 80, 100)
        end
        
        timer.Simple(1.7, function()
            if table.HasValue(female, string.lower(attacker:GetModel())) then
                attacker:EmitSound(table.Random(attacker_replicas_female), 80, 100)
            else
                attacker:EmitSound(table.Random(attacker_replicas), 80, 100)
            end
        end)
    end
end)