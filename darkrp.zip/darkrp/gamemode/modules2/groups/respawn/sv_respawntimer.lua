
util.AddNetworkString("RespawnTimer")
util.AddNetworkString("RespawnTimerHUD")

hook.Add("PlayerDeath", "RespawnTimer", function(ply)
    ply.deadtime = RealTime()
		
    net.Start("RespawnTimer")
    net.Send(ply)

    if ply:IsSuperAdmin() then
        timer.Simple(0, function()
            if ply:IsValid() then
                ply.NextSpawnTime = CurTime()
            end
        end)
    end
end)

hook.Add("PlayerDeathThink", "RespawnTimer", function(ply)
    if ply:IsPremium() then
        if ply.deadtime && RealTime() - ply.deadtime < 15 then
            return false
        end
    else
        if ply.deadtime && RealTime() - ply.deadtime < 40 then
            return false
        end
    end
end)

hook.Add("PlayerSpawn", "RespawnTimer", function(ply)
	timer.Simple(0.1, function()
		if !IsValid(ply) then return end

		net.Start("RespawnTimerHUD")
		net.Send(ply)
	end)

	timer.Simple(1.5, function()
		if !IsValid(ply) then return end

		net.Start("RespawnTimerHUD")
		net.Send(ply)
	end)		
end)
