surface.CreateFont("RespawnTimer", {
	font = "Roboto",
	size = 32,
	weight = 500,
	extended = true,
	antialias = true,
})

surface.CreateFont("RespawnTimerShadow", {
	font = "Roboto",
	size = 32,
	weight = 500,
	extended = true,
	antialias = true,
	blursize = 3,
})


local pp_params = {}
pp_params["$pp_colour_addr"] = 0
pp_params["$pp_colour_addg"] = 0
pp_params["$pp_colour_addb"] = 0

pp_params["$pp_colour_brightness"] = 1
pp_params["$pp_colour_contrast"] = 1
pp_params["$pp_colour_colour"] = 1

pp_params["$pp_colour_mulr"] = 0
pp_params["$pp_colour_mulg"] = 0
pp_params["$pp_colour_mulb"] = 0

local sadsongs = {
	"gxrp/music/hm_deathcam.mp3",
	"gxrp/music/ki_deathcam.mp3",
	"gxrp/music/ki_lostround.mp3",
	"gxrp/music/mi_deathcam.mp3",
	"gxrp/music/mi_lostround.mp3",
	"gxrp/music/sa_deathcam.mp3",
}

local dspOn

local matBlurScreen = Material("pp/blurscreen")
hook.Add("RenderScreenspaceEffects", "RespawnTimer", function()
	if LocalPlayer():Alive() then
		--[[
		if dspOn == true then
			LocalPlayer():SetDSP(0, true)
		end
		]]

		pp_params["$pp_colour_colour"] = 1
		pp_params["$pp_colour_brightness"] = 1
	else
		--[[
		if dspOn == nil then
			LocalPlayer():SetDSP(16)
			dspOn = true
		end
		]]

		DrawColorModify(pp_params)
		pp_params["$pp_colour_colour"] = Lerp(FrameTime(), pp_params["$pp_colour_colour"], 0.3)
		pp_params["$pp_colour_brightness"] = Lerp(FrameTime(), pp_params["$pp_colour_brightness"], 0)

		for i=0.33, 1, 0.33 do
			matBlurScreen:SetFloat( "$blur", 20 * i * (1-pp_params["$pp_colour_brightness"]) )
			matBlurScreen:Recompute()
			render.UpdateScreenEffectTexture()
			render.SetMaterial( matBlurScreen )
			render.DrawScreenQuad()
		end
	end
end)

local music
net.Receive("RespawnTimer", function()
	if net.ReadBool() then
		local dead = RealTime()
		hook.Add("HUDPaint", "RespawnTimer", function()
			local time = math.Round(15 - RealTime() + dead)
			local time1 = math.Round(40 - RealTime() + dead)
			if time > 0 and LocalPlayer():IsPremium() then
				draw.BeautyText(DarkRP.getPhrase("respawn_timer", time), "RespawnTimer", "RespawnTimerShadow", ScrW() / 2, ScrH() * 0.7, color_white, 0.5, 0.5)
			elseif time1 > 0 and not LocalPlayer():IsPremium() then
			    draw.BeautyText(DarkRP.getPhrase("respawn_timer", time1), "RespawnTimer", "RespawnTimerShadow", ScrW() / 2, ScrH() * 0.7, color_white, 0.5, 0.5)
			end
		end)
		
		hook.Add("Think", "RespawnTimerMusic", function()
			if (RealTime() - dead) < 0.5 then return end
			
			hook.Remove("Think", "RespawnTimerMusic")

			if LocalPlayer():Alive() then return end
			if not system.HasFocus() then return end

			if music then
				hook.Remove("Think", "respawntimerm")
				music:Stop()
				music = nil
			end

			sound.PlayFile("sound/"..table.Random(sadsongs), "", function(chan, err, msg)
				if err then return print(err,msg) end

				music = chan

				hook.Add("Think", "respawntimerm", function()
					if not IsValid(chan) or chan:GetState() == GMOD_CHANNEL_STOPPED then
						hook.Remove("Think", "respawntimerm")
						if IsValid(chan) then
							sound.PlayFile("sound/gxrp/music/aw_chooseteam.mp3", "noplay", function(chan, err, str)
								if err then return print(err,msg) end
								chan:Play()
								chan:SetVolume(0.4)

								music = chan
							end)
						end
					end
				end)
			end)
		end)
		system.FlashWindow()
	else
		if music then
			music:Stop()
			music = nil
		end
		hook.Remove("HUDPaint", "RespawnTimer")
		hook.Remove("Think", "RespawnTimerMusic")
		RunConsoleCommand("stopsound")
	end
end)