net.Receive("XPGangsCreation", function()
    local frame = DarkRP.StringRequest("Création du Gang", "Préciser le nom du gang:", function(s)
		net.Start("XPGangsCompletion")
	     	net.WriteEntity(LocalPlayer())
			net.WriteString(s)
		net.SendToServer()
	end)
end)


net.Receive("NXGroupChat", function()
	if net.ReadBool() then
		for i = 1, net.ReadUInt(16) do
			local name = net.ReadString()
			GAMEMODE.DarkRPGroupChats[name] = function(ply) return ply:GetNWString("NXGroup") == name end
		end
	else
		local name = net.ReadString()
		GAMEMODE.DarkRPGroupChats[name] = net.ReadBool() and function(ply) return ply:GetNWString("NXGroup") == name end or nil
	end
end)
net.Start("NXGroupChat")
net.SendToServer()

function groupcreatemenu()
	local plys = {}
	local me = LocalPlayer()
	for k, v in ipairs(player.GetAll()) do
		if table.iHasValue(nxgroupjobs, v:Team()) and v ~= me and not getgroup(v) then
			table.insert(plys, v)
		end
	end

	local longname, longteam = 0, 0
	surface.SetFont("DermaDefault")
	for k, v in pairs(plys) do
		longname = math.max(surface.GetTextSize(v:Name()), longname)
		longteam = math.max(surface.GetTextSize(team.GetName(v:Team())), longteam)
	end

	table.sort(plys, function(a, b)
		if a:Team() ~= b:Team() then
			return a:Team() < b:Team()
		else
			return a:Name():ucasefold() < b:Name():ucasefold()
		end
	end)

	local frame = vgui.Create("NxGenericFrame")
	frame:MakePopup()


	local title = frame:AddTitle(DarkRP.getPhrase("gang_creation"))

	local ndock = frame:Add("EditablePanel")
	ndock:Dock(TOP)
	ndock:DockMargin(0, 0, 0, LargeMargin)

	local namel = ndock:Add("DLabel")
	namel:SetText(DarkRP.getPhrase("gang_name"))
	namel:SetFont("DermaNotDefault")
	namel:Dock(LEFT)
	namel:DockMargin(0, 0, MediumMargin, 0)
	namel:SizeToContents()
	namel:SetContentAlignment(4)

	local namet = ndock:Add("DTextEntry")
	namet:Dock(FILL)
	namet:SetFont("DermaNotDefault")
	namet.Paint = nxui_DTextEntry_Paint
	namet.y = 0
	ndock:SetTall(yscale(32))

	local ginfol = frame:Add("DLabel")
	ginfol:SetText(DarkRP.getPhrase("gang_info"))
	ginfol:SetFont("DermaNotDefault")
	--ginfol:SetContentAlignment(5)
	ginfol:Dock(TOP)
	ginfol:DockMargin(0, 0, 0, LargeMargin)
	ginfol:SizeToContents()

	local scroll = frame:Add("DScrollPanel")
	fixscrollbar(scroll)
	scroll.x = 0
	scroll:Dock(FILL)

	local list = scroll:Add("DListLayout")
	list:Dock(FILL)

	for k, v in pairs(plys) do
		local check = list:Add("DCheckBoxLabel")
		check:SetFont("DermaNotDefault")
		check:SetText(v:Name() .. " (" .. team.GetName(v:Team()) .. ")")
		--check:SetTextColor(team.GetColor(v:Team()))
		check.ply = v
		check:Dock(TOP)
	end

	local crb = frame:Add("NxButton")
	crb:SetPrimaryMainColors()
	crb:SetText(DarkRP.getPhrase("gang_create"))
	crb:Dock(BOTTOM)
	crb:SetTall(yscale(40))
	crb:SizeBig()
	crb:DockMargin(LargeMargin*2, LargeMargin, LargeMargin*2, 0)
	function crb:DoClick()
		-- nie french support
		if #namet:GetValue() < 3 or #namet:GetValue() > 199 or #namet:GetValue():gsub("[^%aйцукенгшщзхъфывапролджэячсмитьбю]", "") == 0 then
			self:SetText(DarkRP.getPhrase("gang_poor_name"))
			return
		end
		local gang = {}
		for k, v in pairs(list:GetChildren()) do
			if v:GetChecked() then
				table.insert(gang, v.ply)
			end
		end
		if #gang < GAMEMODE.Config.gangMinMembers then
			self:SetText(DarkRP.getPhrase("gang_few_mates"))
			return
		end
		net.Start("NXGroupCreate")
			net.WriteString(namet:GetValue())
			ray.WriteList(gang, net.WriteEntity)
		net.SendToServer()
		frame:Remove()
	end
end

surface.CreateFont( "NXGroupControlIcon16", {
	font = NX_ICONFONT,
	size = yscale(16),
})

function groupcontrolmenu(ye)
	net.Start("NXGroupControl")
		net.WriteUInt(0, 4)
		net.WriteBool(ye or false)
	net.SendToServer()
end

net.Receive("NXGroupControl", function()
	local me = LocalPlayer()
	local name = getgroup(me)

	local frame = vgui.Create("NxGenericFramePaged")
	frame:MakePopup()

	local title = frame:AddTitle(DarkRP.getPhrase("manage_group"))

	frame:EnableTabs()

	do
		local panel, sheet = frame:NewSheet(DarkRP.getPhrase("gang_tab_bandits") or "MainScreen")

		local scroll = panel:Add("DScrollPanel")
		fixscrollbar(scroll)
		scroll:Dock(FILL)

		local list = scroll:Add("DListLayout")
		list:Dock(FILL)

		for k, ply in ipairs(player.GetAll()) do
			if ply ~= me and getgroup(ply) == name then
				local panel = list:Add("EditablePanel")
				panel:DockMargin(0, 0, 0, SmallMargin)
				panel:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
				function panel:Paint(w, h)
					surface.SetDrawColor(Color(255, 255, 255, 12))
					surface.DrawRect(0, 0, w, h)
				end
				panel:SetTall(yscale(42))

				local namel = panel:Add("DLabel")
				namel.x, namel.y = 3, 1
				namel:SetWide(191)
				namel:SetText(ply:Name())
				namel:SetFont("DermaNotDefault")
				namel:SetContentAlignment(4)
				namel:Dock(LEFT)
				--namel:SetColor(ply:getJobTable().color)

				local job = ply:getDarkRPVar("job")
				local rank = panel:Add("DTextEntry")
				rank:Dock(LEFT)
				rank.y = 1
				rank:SetFont("DermaNotDefault")
				rank:SetSize(180, 22)
				rank:SetValue(job:Left(job:find("<", nil, true) - 2))
				rank.Paint = nxui_DTextEntry_Paint
				rank:SetDrawLanguageID(false)
				function rank:OnEnter()
					if ply:IsValid() then
						net.Start("NXGroupControl")
							net.WriteUInt(5, 4)
							net.WriteEntity(ply)
							net.WriteString(self:GetValue())
						net.SendToServer()
					end
				end

				local kick = panel:Add("NxButton")
				kick:Dock(RIGHT)
				kick.y = 1
				kick:SizeToContents()
				kick:SetWide(kick:GetWide() + yscale(32))
				kick.color = Color(0xD3, 0x2F, 0x2F)
				kick.color_hover = Color(0xF4, 0x43, 0x36)
				kick.color_down = Color(0xB7, 0x1C, 0x1C)
				kick:SetText(DarkRP.getPhrase("gang_kick"))
				function kick.DoClick()
					if ply:IsValid() then
						net.Start("NXGroupControl")
							net.WriteUInt(4, 4)
							net.WriteEntity(ply)
						net.SendToServer()
						panel:Remove()
					end
				end
			end
		end

		local invite = panel:Add("NxButton")
		invite.x = 2
		invite:Dock(BOTTOM)
		invite:DockMargin(0, 0, 0, SmallMargin)
		invite:SetTall(yscale(32))
		invite:SetText(DarkRP.getPhrase("gang_invite"))
		function invite.DoClick()
			local plys = {}
			for k, v in ipairs(player.GetAll()) do
				if table.iHasValue(nxgroupjobs, v:Team()) and v ~= me and not getgroup(v) then
					table.insert(plys, v)
				end
			end

			local longname, longteam = 0, 0
			surface.SetFont("DermaNotDefault")
			for k, v in pairs(plys) do
				longname = math.max(surface.GetTextSize(v:Name()), longname)
				longteam = math.max(surface.GetTextSize(team.GetName(v:Team())), longteam)
			end

			table.sort(plys, function(a, b)
				if a:Team() ~= b:Team() then
					return a:Team() < b:Team()
				else
					return a:Name():ucasefold() < b:Name():ucasefold()
				end
			end)

			local frame = vgui.Create("NxGenericFrame")
			--frame:SetSize(math.max(longname + longteam + 70, 230), math.min(#plys * 16 + 68, ScrH() - 20))
			frame:SetSize(frame:GetWide() / 3, frame:GetTall() / 2)
			frame:Center()
			local title = frame:AddTitle(DarkRP.getPhrase("gang_invite_title"))
			frame:SetKeyboardInputEnabled(false)

			local scroll = vgui.Create("DScrollPanel", frame)
			fixscrollbar(scroll)
			scroll:Dock(FILL)
			scroll:DockMargin(0, 0, 0, LargeMargin)

			--for i = 1, 20 do
			for k, v in pairs(plys) do
				local check = scroll:Add("DCheckBoxLabel")
				check:Dock(TOP)
				check:SetText(v:Name() .. " (" .. team.GetName(v:Team()) .. ")")
				check:SetFont("DermaNotDefault")
				check:SizeToContents()
				--check:SetTextColor(team.GetColor(v:Team()))
				check.ply = v
			end
			--end

			local crb = vgui.Create("NxButton", frame)
			crb:SetText(DarkRP.getPhrase("gang_send_invites"))
			crb:Dock(BOTTOM)
			crb:SizeBig()
			crb:SetPrimaryMainColors()
			--crb:MoveBelow(scroll, 10)
			--crb:SetWide(frame:GetWide() - 12)
			function crb:DoClick()
				local gang = {}
				for k, v in pairs(scroll:GetCanvas():GetChildren()) do
					if v:GetChecked() then
						table.insert(gang, v.ply)
					end
				end
				net.Start("NXGroupControl")
					net.WriteUInt(3, 4)
					ray.WriteList(gang, net.WriteEntity)
				net.SendToServer()
				frame:Remove()
			end
		end

		local givemoney = panel:Add("NxButton")
		givemoney.x = 2
		givemoney:Dock(BOTTOM)
		givemoney:DockMargin(0, 0, 0, SmallMargin)
		givemoney:SetTall(yscale(32))
		givemoney:SetText(DarkRP.getPhrase("gang_give"))
		function givemoney.DoClick()
			DarkRP.DermaQuery(DarkRP.getPhrase("gang_give_title"), "", DarkRP.getPhrase("gang_split"), function()
				DarkRP.StringRequest(DarkRP.getPhrase("gang_give_title"), DarkRP.getPhrase("gang_split_am", DarkRP.config.currencySymbol), function(n)
					if tonumber(n) then
						net.Start("NXGroupControl")
							net.WriteUInt(6, 4)
							net.WriteBool(false)
							net.WriteUInt(tonumber(n), 32)
						net.SendToServer()
					end
				end, "0")
			end, DarkRP.getPhrase("gang_each"), function()
				DarkRP.StringRequest(DarkRP.getPhrase("gang_give_title"), DarkRP.getPhrase("gang_each_am", DarkRP.config.currencySymbol), function(n)
					if tonumber(n) then
						net.Start("NXGroupControl")
							net.WriteUInt(6, 4)
							net.WriteBool(true)
							net.WriteUInt(tonumber(n), 32)
						net.SendToServer()
					end
				end, "0")
			end, DarkRP.getPhrase("cancel"))
		end

		local requestmoney = panel:Add("NxButton")
		requestmoney.x = givemoney.x
		requestmoney:Dock(BOTTOM)
		requestmoney:DockMargin(0, 0, 0, SmallMargin)
		requestmoney:SetTall(yscale(32))
		requestmoney:SetText(DarkRP.getPhrase("gang_request"))
		function requestmoney.DoClick()
			DarkRP.StringRequest(DarkRP.getPhrase("gang_request_title"), DarkRP.getPhrase("gang_request_am", DarkRP.config.currencySymbol), function(n)
				if tonumber(n) then
					net.Start("NXGroupControl")
						net.WriteUInt(7, 4)
						net.WriteUInt(tonumber(n), 32)
					net.SendToServer()
				end
			end, "0")
		end

		--[[local declarewar = panel:Add("DButton")
		declarewar.x = requestmoney.x
		declarewar:MoveBelow(requestmoney, 2)
		declarewar:SetWide(panel:GetWide() - declarewar.x * 2)
		declarewar:SetText("Объявить войну")
		function declarewar.DoClick()

		end]]

		local disband = panel:Add("NxButton")
		disband.x = requestmoney.x
		disband:Dock(BOTTOM)
		disband:SetTall(yscale(32))
		disband:SetText(DarkRP.getPhrase("gang_disband"))
		function disband.DoClick()
			DarkRP.DermaQuery(DarkRP.getPhrase("gang_disband_title"), DarkRP.getPhrase("gang_disband_confirm"), "ОК", function()
				net.Start("NXGroupControl")
					net.WriteUInt(2, 4)
				net.SendToServer()
			end, DarkRP.getPhrase("cancel"))
		end

		invite:SetZPos(4)
		givemoney:SetZPos(3)
		requestmoney:SetZPos(2)
		disband:SetZPos(1)
	end

	do
		local upgrades = {}
		while net.ReadBool() do
			upgrades[net.ReadString()] = net.ReadUInt(24)
		end

		local panel, sheet = frame:NewSheet(DarkRP.getPhrase("cc_upgrades") or "Upgrades")

		local scroll = panel:Add("Upgrades")
		scroll:Dock(FILL)
		scroll:Set("NXGroupControl", nxgroupupgrades, upgrades, function(k)
			net.Start("NXGroupControl")
				net.WriteUInt(1, 4)
				net.WriteString(k)
			net.SendToServer()
			frame:Remove()
			groupcontrolmenu(true)
		end, true)

		if net.ReadBool() then
			frame.sheet:SwitchToName(DarkRP.getPhrase("cc_upgrades") or "Upgrades")
		end
	end
end)