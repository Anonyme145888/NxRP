hook.Add("HUDPaint", "TargetIDIcon", function()
	local lp = LocalPlayer()
	local tr = lp:GetEyeTraceNoCursor()

	if tr.Entity:IsValid() and tr.HitPos:DistToSqr(lp:EyePos()) < 22500 then
		local y = 28
		local mat = hook.Run("TargetIDIcon", tr.Entity)

		if mat then
			surface.SetMaterial(mat)
			surface.SetDrawColor(color_white)
			surface.DrawTexturedRect(ScrW() / 2 - 8, ScrH() / 1.85 + y - 8, 16, 16)
			y = y + 26
		end
	end
end)

local mat = Material("icon16/lock.png")
hook.Add("TargetIDIcon", "IsFadingDoor", function(ent)
	return ent:GetNWBool("IsFadingDoor") and mat or nil
end)