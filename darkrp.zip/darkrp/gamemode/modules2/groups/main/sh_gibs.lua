module("gibs", package.seeall)

mdls = {
	"models/Gibs/HGIBS.mdl",
	"models/props_junk/watermelon01_chunk01c.mdl",
	"models/props_junk/watermelon01_chunk01b.mdl",
	"models/props_junk/watermelon01_chunk01a.mdl",
	"models/props_junk/rock001a.mdl",
}

do

	_G.ENT = {}
	local BaseClass = baseclass.Get("base_anim")

	if SERVER then
		function ENT:Initialize()
			self:SetModel(table.Random(mdls))
			self:SetMaterial("models/flesh")
			self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
			self:SetMoveType(MOVETYPE_VPHYSICS)
			self:PhysicsInit(SOLID_BSP)

			self:EmitSound("physics/flesh/flesh_bloody_break.wav")
			--self:EmitSound("physics/flesh/flesh_squishy_impact_hard".. math.random(1, 4) ..".wav")
			util.Decal("Blood", self:GetPos(), self:GetPos() + VectorRand() * 5000)

			local phys = self:GetPhysicsObject()

			if phys:IsValid() then
				phys:Wake()
				phys:SetMass(1)
				phys:SetVelocity((vector_up + VectorRand() * Vector(0.5, 0.5, 0)) * 500)
				phys:AddAngleVelocity(VectorRand() * 9000)
			end

			SafeRemoveEntityDelayed(self, 30)
		end

		function ENT:Think()
			if self:GetPhysicsObject():IsAsleep() then
				self:Remove()
			end

			local effectdata = EffectData()
				effectdata:SetOrigin(self:GetPos())
				effectdata:SetNormal(self:GetAngles():Forward() * 1)
				effectdata:SetMagnitude(1)
				effectdata:SetScale(10)
				effectdata:SetRadius(1)
				effectdata:SetColor(0)
				effectdata:SetFlags(1)
			util.Effect("BloodImpact", effectdata, true, true)
		end
	end

	function ENT:PhysicsCollide(data, col)
		if data.Speed > 100 then
			self:EmitSound("physics/flesh/flesh_bloody_impact_hard1.wav")
		else
			self:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav")
		end

		util.Decal("Blood", data.HitPos, data.HitPos + data.HitNormal * 32)
	end

	scripted_ents.Register(ENT, "gibs")
	_G.ENT = nil

end

function Spawn(ent, am)
	if SERVER then
		for i = 1, (am or 1) do
			local e = ents.Create("gibs")
			e:SetPos(ent:GetPos() + Vector(math.Rand(-0.01, 0.01), math.Rand(-0.01, 0.01), math.Rand(0.1, 0.9)) * 72)
			e:Spawn()
			e:Activate()
		end
	end
end

function Explode(pl)
	pl:KillSilent()
	Spawn(pl, 10)
end

hook.Add("DoPlayerDeath", "gibs", function(pl, ent, dmg)
	if dmg:IsExplosionDamage() then
		timer.Simple(0, function()
			if not pl:Alive() then
				Explode(pl)
				if IsValid(pl:GetRagdollEntity()) then pl:GetRagdollEntity():Remove() end
			end
		end)
	end
end)

