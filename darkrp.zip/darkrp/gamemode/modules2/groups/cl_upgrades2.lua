local PANEL = {}

function PANEL:Init()
	fixscrollbar(self)
	self.panels = {}
end

function PANEL:Set(ident, allupgrades, upgrades, click, inmoney, notime)
	local list = self
	list:Clear()

	self.ident = ident
	self.allupgrades = allupgrades
	self.upgrades = upgrades

	for k, v in next, allupgrades do
		local panel = list:Add("EditablePanel")
		panel:Dock(TOP)
		panel:DockMargin(0, 0, 0, SmallMargin)
		panel:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
		panel.Paint = function(s, w, h)
			surface.SetDrawColor(Color(255, 255, 255, 12))
			surface.DrawRect(0, 0, w, h)
		end
		panel:SetTall(0)
		panel:Dock(TOP)

		local left = panel:Add("EditablePanel")
		left:Dock(FILL)
		left:DockMargin(0, 0, SmallMargin, 0)

		local right = panel:Add("EditablePanel")
		right:Dock(RIGHT)
		right:SetWide(yscale(100))

		local title = left:Add("DLabel")
		title:SetColor(upgrades[k] and ray.colors.green or ray.colors.white)
		title:SetFont("DermaNotDefault")
		title:SetText(allupgrades[k].levels and (upgrades[k] or 0) < (allupgrades[k].levels or 1) and v.name .. DarkRP.getPhrase("up_level") .. (upgrades[k] or 0) + 1 .. ")" or v.name)
		title.x = 5
		title:SizeToContents()
		title:Dock(TOP)

		local desc = left:Add("DLabel")
		--desc:SetColor(ray.colors.black)
		desc:SetFont("DermaNotDefault")
		desc:SetText(v.desc)
		desc.x = title.x
		--desc:MoveBelow(title, 0)
		--desc:SetWide(title:GetWide())
		desc:SizeToContents()
		desc:Dock(TOP)
		--desc:SetTall(panel:GetTall() - 2 - desc.y)
		desc:SetWrap(true)
		desc:SetAutoStretchVertical(true)

		local buyb = right:Add("NxButton")
		buyb:SetText(
			(upgrades[k] or 0) >= (allupgrades[k].levels or 1) and DarkRP.getPhrase("up_bought") or
			(inmoney and DarkRP.formatMoney(v.price * ((upgrades[k] or 0) + 1)) or v.price)
		)
		buyb:SetDisabled((upgrades[k] or 0) >= (allupgrades[k].levels or 1))
		buyb:SetWide(56)
		buyb:SetTall(yscale(32))
		buyb:SetPrimaryMainColors()
		buyb.x, buyb.y = panel:GetWide() - buyb:GetWide() - 10, 9
		buyb:Dock(TOP)
		function buyb.DoClick()
			click(k, buyb)
		end

		local icassdasdas = right:Add("EditablePanel")
		icassdasdas:SetTall(16)
		icassdasdas:Dock(TOP)
		icassdasdas:DockMargin(0, SmallMargin, 0, 0)

		local icon = icassdasdas:Add("DLabel")
		icon:SetSize(16 + SmallMargin, 16)
		icon.x = panel:GetWide() - icon:GetWide() - 48
		--icon:MoveBelow(buyb, 6)
		icon:Dock(LEFT)
		icon:SetFont("NXGroupControlIcon16")
		icon:SetText("0")

		local time = icassdasdas:Add("DLabel")
		time:SetFont("DermaNotDefault")
		time:SetColor(upgrades[k] and ray.colors.green or ray.colors.white)
		--time:MoveRightOf(icon, 4)
		time:Dock(FILL)
		time.y = icon.y + 2
		if not notime then
			time:SetText(v.time == 0 and "∞" or (v.time/60).."m")
		else
			time:SetVisible(false)
			icon:SetVisible(false)
		end
		time:SizeToContents()

		panel:SetTall(yscale(70))

		table.insert(self.panels, {panel = panel, title = title, time = time, k = k, v = v})
	end

	if not notime then
		timer.Create(ident, 1, 0, function()
			local upgrades = self.upgrades

			for k, v in next, upgrades do
				if v > 0 and v - CurTime() <= 0 then
					upgrades[k] = nil
				end
			end

			for k, v in ipairs(self.panels) do
				v.title:SetColor(upgrades[v.k] and (upgrades[v.k] == 0 or upgrades[v.k] - CurTime() > 0) and ray.colors.green or ray.colors.white)
				v.time:SetColor(upgrades[v.k] and (upgrades[v.k] == 0 or upgrades[v.k] - CurTime() > 0) and ray.colors.green or ray.colors.white)
				v.time:SetText(v.v.time == 0 and "∞" or (v.v.time/60).."m" or "0")
			end
		end)
	end
end

function PANEL:OnRemove()
	timer.Remove(self.ident)
end

derma.DefineControl("Upgrades", "" , PANEL, "DScrollPanel")