local function timeToStr(time)
    local tmp = time / 60 / 60

    if tmp < 1 then
        tmp = math.Round(tmp * 60)
        return tmp .. " m"
    elseif tmp < 10 then
        local minutes = tmp - math.floor(tmp)
        minutes = (math.Round(minutes * 60))
        return math.floor(tmp) .. ":" .. Format("%.2d", minutes) .. " h"
    else
        tmp = math.Round(tmp)
        return tmp ..  " h"
    end
end

local PANEL = {}

function PANEL:Init()
	self:SetTitle("Player Table")
	self:Center()
	self:SetSize(ScrW() / 1.8, ScrH() / 1.1)
    self:MakePopup()
	local scroll = self:Add("DScrollPanel")
	fixscrollbar(scroll)
	self.scroll = scroll
	scroll:Dock(FILL)
	
	local but = vgui.Create("DButton", self)
	but:Dock(BOTTOM)
	but:SetTall(32)
	but:SetText("Close")

	but.DoClick = function()
		self:Remove()
	end

	local plist = vgui.Create("DListView", self)
	plist:Dock(FILL)
	plist:SetMultiSelect(false)
	plist:AddColumn("Name")
	plist:AddColumn("Job")
	if LocalPlayer():IsAdmin() then
	plist:AddColumn("Rank")
	end
	plist:AddColumn("GM Play Time")
	plist:AddColumn("Server Play Time")
	plist:AddColumn("UserID")
	plist:AddColumn("SteamID")

    local players = player.GetAll()

    table.sort(players, function(a, b)
       	return(a:GetUTimeTotalTime() > b:GetUTimeTotalTime())
    end)

	for k, v in pairs(players) do
	
		plist:AddLine(v:Name(), v:getJobTable().name, LocalPlayer():IsAdmin() and v:GetNWString("rank"), timeToStr(v:GetUTimeTotalTime()) or "Нету", v:GetNWInt("PlayTime") .. " h", v:UserID(), v:SteamID() )
		
	end
end

derma.DefineControl("PlayerTable", "", PANEL, "DFrame")

function util.PlayerTable()

	local gui = vgui.Create("PlayerTable")
	gui:Center()
end