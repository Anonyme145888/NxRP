hook.Add("HitMarker", "HitMarkerSound", function(dmg, critical)
	if not critical then
		surface.PlaySound("gxrp/hitmarker.wav")
	else
		surface.PlaySound("gxrp/hitmarker_heavy.wav")
		LocalPlayer():ScreenFade(SCREENFADE.IN, Color(10, 100, 200, 40), 0.5, 0)
	end
end)

net.Receive("RayDamage", function()
    local addDmg = net.ReadUInt(16)
    alpha = 1
    dmg = dmg + addDmg
    hook.Run("HitMarker", addDmg, net.ReadBool())
end)
