local scale = 1

local shadow_x = 1*scale
local shadow_y = 1*scale

local col_face = Color(255,255,255,255)
local col_shadow = Color(0,0,0,255)
local col_half_shadow = Color(0,0,0,200)
local col_money = Color(64,192,32)

local function BeautyText( str, font, font_shadow, x, y, color, xalign, yalign )
    font = font or "nx_hud"
    surface.SetFont( font )
    local tw, th = surface.GetTextSize( str )
    x = (x or 0) - tw * (xalign or 0)
    y = (y or 0) - th * (yalign or 0)
    surface.SetTextPos( x, y )
    -- Ombre douce :
    if font_shadow then
        surface.SetTextPos( x, y+3 )
        surface.SetTextColor( col_shadow )
        surface.SetFont( font_shadow )
        surface.DrawText( str )
        surface.SetTextPos( x, y )
    end
    -- Ombre nette :
    surface.SetTextPos( x + shadow_x , y + shadow_y )
    surface.SetTextColor( col_half_shadow )
    surface.SetFont( font )
    surface.DrawText( str )
    -- Texte lui-même :
    surface.SetTextColor( color or col_face )
    surface.SetTextPos( x, y )
    surface.DrawText( str )

    return tw,th
end


hook.Add("HUDPaint", "DistrictHUD", function(pl)
	if not LocalPlayer():Alive() then return end
	
    local minimap = {x = 1740, w = 60, top = 810}

    if LocalPlayer():GetPos():WithinAABox(Vector(16346.267578, -15291.790039, 2827.928223), Vector(3662.570557, -1745.564575, -1142.723267)) then 
        BeautyText("Quartier côtier", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.60, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(12338.583984, 97.888580, 2038.708374), Vector(6662.463379, 9107.644531, 1321.964355)) then 
        BeautyText("Quartier d'élite", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.42, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-2934.427734, 10745.969727, 2643.589844), Vector(3450.864014, 630.001221, -346.148254)) then 
        BeautyText("Quartier résidentiel", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.35, minimap.top - 40, Color(150, 200, 255), .5, 0)
    -- Ville
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-12076.928711, 3882.766113, 2159.868652), Vector(-2988.520752, 98.944038, -1986.769775)) then -- 1
        BeautyText("Quartier des affaires", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.40, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-12089.475586, 103.855377, 1852.386475), Vector(1145.010132, -8080.775391, -2971.071777)) then -- 2
        BeautyText("Quartier des affaires", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.40, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-2607.105713, -10706.981445, 1993.617676), Vector(-12083.028320, -5202.692383, -2728.911133)) then -- 3
        BeautyText("Quartier des affaires", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.40, minimap.top - 40, Color(150, 200, 255), .5, 0)
    -- Industriel
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-3119.800537, 3893.979736, 2697.231689), Vector(-11747.617188, 10282.102539, -1492.376221)) then 
        BeautyText("Quartier industriel", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.80, minimap.top - 40, Color(150, 200, 255), .5, 0)
    -- Ceinture périphérique
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-12457.288086, 15286.690430, 1840.548096), Vector(-15397.414063, -15667.449219, -1342.196289)) then -- 1
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-15633.400391, 15608.570313, -1150.638184), Vector(17032.498047, 10987.661133, 3341.512939)) then  -- 2
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(15100.500000, 15383.661133, 925.440613), Vector(13188.563477, -1721.022217, 2424.011963)) then -- 3
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    -- Sortie de la ville
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-15348.304688, -15427.387695, -90.557846), Vector(-929.208679, -11494.476563, 436.857910)) then 
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-12294.375977, -11102.109375, -125.383148), Vector(-920.388916, -15665.250977, 336.678528)) then 
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-12813.849609, -10805.530273, -97.486496), Vector(-5155.437988, -12653.939453, 199.266937)) then 
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    -- Tunnel
    elseif LocalPlayer():GetPos():WithinAABox(Vector(-1263.526123, -11462.232422, -194.363678), Vector(3030.318848, -12851.165039, 759.621094)) then 
        BeautyText("Ceinture périphérique", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.10, minimap.top - 40, Color(150, 200, 255), .5, 0)
    else
        BeautyText("Inconnu", "nx_hud", "nx_hud_shadow", minimap.x + minimap.w / 1.25, minimap.top - 40, Color(150, 200, 255), .5, 0)
    end
end)