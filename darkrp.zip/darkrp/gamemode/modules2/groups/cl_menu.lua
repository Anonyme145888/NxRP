local function comrade_color(a, b, w, h)
    local color = team.GetColor(b:Team())

    if a.Deressed then
        surface.SetDrawColor(color.r - 40, color.g - 40 , color.b - 40)
    elseif a.Hovered then
        surface.SetDrawColor(color.r - 20, color.g - 20, color.b - 20)
    else
        surface.SetDrawColor(color)
    end	

    surface.DrawRect(0, 0, w, h)
end

net.Receive("XPGangsMenu", function()
    local gang_name = net.ReadString()

    if LocalPlayer():GetNWString("gang_name") == "None" then
        return
    end

    if not LocalPlayer():Team() == TEAM_MOB and LocalPlayer():GetNWString("gang_name") == gang_name then
        return
    end

    if IsValid(fr) then 
        return 
    end

	frame = vgui.Create("NxGenericFramePaged")
    frame:MakePopup()
	frame:SetSize(ScrW() / 2.5, math.Clamp(768, 0, ScrW()))
    frame:Center()
    frame:AddTitle(DarkRP.getPhrase("gangs_menu") .. ' <' .. gang_name .. '>')
	frame:EnableTabs()

    local fr, sheet = frame:NewSheet(DarkRP.getPhrase("gang_tab_bandits") or "MainScreen")

    local scroll = fr:Add("DScrollPanel")
    fixscrollbar(scroll)
    scroll:Dock(FILL)

    local list = scroll:Add("DListLayout")
    list:Dock(FILL)

    for k, v in pairs(player.GetAll()) do
        if v:GetNWString("gang_name") == gang_name then

            local panel = list:Add("EditablePanel")
            panel:DockMargin(0, 0, 0, SmallMargin)
            panel:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
            function panel:Paint(w, h)
            surface.SetDrawColor(Color(255, 255, 255, 12))
                surface.DrawRect(0, 0, w, h)
            end
            panel:SetTall(yscale(42))

            panel.DoClick = function()
                if LocalPlayer() == v then 
                    return 
                end

                local menu = DermaMenu()
                menu:MakePopup()
                menu:SetPos(input.GetCursorPos())
    
                menu:AddOption(DarkRP.getPhrase("gangs_kick"), function()
                    net.Start("XPGangsKick")
                    net.WriteEntity(v)
                    net.SendToServer()
                end)                
            end

            local name = panel:Add("DLabel")
            name.x, name.y = 3, 1
            name:SetWide(191)
            name:SetText(v:Name())
            name:SetFont("DermaNotDefault")
            name:SetContentAlignment(4)
            name:Dock(LEFT)

            local job = v:getDarkRPVar("job")
            local gang_name = v:GetNWString("gang_name")
            local rank = panel:Add("DTextEntry")
            rank:Dock(LEFT)
            rank.y = 1
            rank:SetFont("DermaNotDefault")
            rank:SetSize(180, 22)
            rank:SetValue(job:Left(job:find("<", nil, true) - 2) or "")
            rank.Paint = nxui_DTextEntry_Paint
            rank:SetDrawLanguageID(false)
            function rank:OnEnter()
                if v:IsValid() then
                    net.Start("NXGroupSetName")
                        net.WriteEntity(v)
                        net.WriteString(self:GetValue())
                    net.SendToServer()
                end
            end
        end
    end
     
    for k, v in pairs(xpgangs.commands) do
        local cmd = vgui.Create("NxButton", fr)
        cmd:SetText(k)	
        cmd:Dock(BOTTOM)
        cmd:SetHeight(35)

        cmd.DoClick = function()
            v["func"]() 
            if k == DarkRP.getPhrase("gang_disband") then
            frame:Remove()
            end
        end
    end    

    do
        local upgrades = {}
        local panel, sheet = frame:NewSheet(DarkRP.getPhrase("cc_upgrades") or "Upgrades")

        local scroll = panel:Add("Upgrades")
        scroll:Dock(FILL)
        scroll:Set("NXGroupControl", nxgroupupgrades, upgrades, function(k)
            if k == "halo" then
                net.Start("GangWH")
                net.SendToServer()
            end 
            if k == "radio" then
                net.Start("GangRadio")
                net.SendToServer()
            end 
            frame:Remove()
        end, true)
       -- frame.sheet:SwitchToName(DarkRP.getPhrase("cc_upgrades") or "Upgrades")
    end 
end)