--[[
gamemodes/darkrp/gamemode/modules_new/stuff/sh_roll.lua
--]]
DarkRP.declareChatCommand{
	command = "roll",
	description = "Drop the cube",
	delay = 1.5
}

if SERVER then
	DarkRP.defineChatCommand("roll", function(ply, n)
		n = tonumber(n) or 2
		DarkRP.talkToRange(ply, "[Roll]", ("%s Lance un dé avec un nombre (%d). Le nombre %d est tiré au sort."):format(ply:Name(), n, math.random(1, n)), 250)
		return ""
	end)
end

