if SERVER then
	resource.AddFile("materials/gxrp/vradar.png")
	return
end

--settings
local dist = 4000
local dist2 = dist ^ 2
local orx, ory = ScrW() - 120, 120
local linespeed = 3
local color = Color(255, 0, 0, 255)

local dg = 0
local dot
local tar

local function Timer()
	if tar and tar:IsValid() then
		local lpos = LocalPlayer():GetPos()
		if not tar:GetNoDraw() then
			local ppos = tar:GetPos()
			local pos = WorldToLocal(ppos, Angle(0, 0, tar:GetAngles().r), lpos, Angle(0, 0, LocalPlayer():GetAngles().r)) / (dist / 100)
			local ang = pos:Angle().y
			if not dot and math.abs(ppos.x - lpos.x) ^ 2 + math.abs(ppos.y - lpos.y) ^ 2 < dist2 and math.abs(ang - dg) <= linespeed --[[and math.abs(ppos.z - lpos.z) < 200]] then
				dot = {l = 40, x = orx + pos.x, y = ory - pos.y, p = tar}
			end
		end
		if dot then
			dot.l = dot.l - 1
			if dot.l <= 0 then
				dot = nil
			end
		end
		dg = (dg + linespeed) % 360
	else
		timer.Remove("hitradar")
		hook.Remove("HUDPaint", "hitradar")
	end
end

local bg = Material("gxrp/vradar.png", "nocull")
local function Hook()
	draw.SimpleText("E", "TargetID", orx + math.cos(math.rad(0)) * 110, ory - math.sin(math.rad(0)) * 110, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("N", "TargetID", orx + math.cos(math.rad(90)) * 110, ory - math.sin(math.rad(90)) * 110, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("W", "TargetID", orx + math.cos(math.rad(180)) * 110, ory - math.sin(math.rad(180)) * 110, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("S", "TargetID", orx + math.cos(math.rad(270)) * 110, ory - math.sin(math.rad(270)) * 110, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	surface.SetMaterial(bg)
	surface.SetDrawColor(color_white)
	surface.DrawTexturedRect(orx - 128, ory - 128, 256, 256)

	surface.SetDrawColor(136, 136, 136, 255)
	surface.DrawLine(orx - 100, ory, orx + 100, ory)
	surface.DrawLine(orx, ory - 100, orx, ory + 100)

	surface.SetDrawColor(68, 170, 68, 255)
	surface.DrawLine(orx, ory, orx + math.cos(math.rad(dg)) * 100, ory - math.sin(math.rad(dg)) * 100)

	surface.SetDrawColor(color_white)
	local ang = LocalPlayer():GetAngles()
	surface.DrawLine(orx + math.cos(math.rad(ang.y)) * 6, ory - math.sin(math.rad(ang.y)) * 6, orx + math.cos(math.rad(140 + ang.y)) * 6, ory - math.sin(math.rad(140 + ang.y)) * 6)
	surface.DrawLine(orx + math.cos(math.rad(ang.y)) * 6, ory - math.sin(math.rad(ang.y)) * 6, orx + math.cos(math.rad(220 + ang.y)) * 6, ory - math.sin(math.rad(220 + ang.y)) * 6)

	if dot then
		for s = 1, math.ceil(dot.l / 10) do
			surface.DrawCircle(dot.x, dot.y, s, color)
		end
	end
end

hook.Add("onHitAccepted", "hitradar", function(hitman, target)
	if hitmen == LocalPlayer() then
		tar = target
		timer.Create("hitradar", 0, 0, Timer)
		hook.Add("HUDPaint", "hitradar", Hook)
	end
end)

hook.Add("onHitCompleted", "hitradar", function(hitman)
	if hitmen == LocalPlayer() then
		tar = nil
		timer.Remove("hitradar")
		hook.Remove("HUDPaint", "hitradar")
	end
end)

hook.Add("onHitFailed", "hitradar", function(hitman)
	if hitmen == LocalPlayer() then
		tar = nil
		timer.Remove("hitradar")
		hook.Remove("HUDPaint", "hitradar")
	end
end)