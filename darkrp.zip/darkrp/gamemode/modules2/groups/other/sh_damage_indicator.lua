local DISTANT = 0
local RECEIVED = 1

if SERVER then
	util.AddNetworkString("DamageIndicator")

	local lock
	hook.Add("EntityFireBullets", "DamageIndicator", function(ent, d)
		if lock ~= CurTime() then
			local wep = ent.GetActiveWeapon and ent:GetActiveWeapon()
			if not (wep and wep.dt and wep.dt.Suppressed) and not (wep and wep.GetSuppressed and wep:GetSuppressed()) then
				net.Start("DamageIndicator")
					net.WriteUInt(DISTANT, 1)
					net.WriteEntity(ent)
					net.WriteVector(d.Src)
					lock = CurTime()
				net.SendPAS(d.Src)
			end
		end
	end)

	hook.Add("EntityTakeDamage", "DamageIndicator", function(pl, dmg)
		if not pl:IsPlayer() then
			return
		end

		if not dmg:IsBulletDamage() then
			return
		end

		local inflictor = IsValid(dmg:GetInflictor()) and dmg:GetInflictor() or dmg:GetAttacker()

		net.Start("DamageIndicator")
			net.WriteUInt(RECEIVED, 1)
			net.WriteVector(inflictor:IsWeapon() and dmg:GetAttacker():GetShootPos() or inflictor:GetPos())
		net.Send(pl)
	end)

	return
end

local indicators = {}

local function add(vec, col)
	table.insert(indicators, {
		dir = (vec - LocalPlayer():GetShootPos()):Angle().y,
		color = col or Color(255, 255, 255),
		alpha = 2,
		t = CurTime()
	})
end

net.Receive("DamageIndicator", function(len)
	local type = net.ReadUInt(1)

	if type == DISTANT then
		local pl = net.ReadEntity()
		if pl ~= LocalPlayer() then
			local vec = net.ReadVector()
			
			if vec:Distance(LocalPlayer():GetShootPos()) <= 3000 then
				add(vec, Color(255, 255, 255))
			end
		end
	elseif type == RECEIVED then
		for k, v in pairs(indicators) do
			if v.t == CurTime() then
				indicators[k] = nil
			end
		end
	
		add(net.ReadVector(), Color(255, 0, 0))
	end
end)

local tri = Material("gxrp/triangle.png", "smooth")

hook.Add("HUDPaint", "DamageIndicator", function()
	local cx = ScrW()/2
	local cy = ScrH()/2

	surface.SetMaterial(tri)
	render.SetMaterial(tri)

	for k, d in pairs(indicators) do
		local col = ColorAlpha(d.color, math.min(1, d.alpha) * 255)
		local yaw = EyeAngles().y - d.dir
		local px = cx + math.sin(math.rad(yaw)) * 128
		local py = cy - math.cos(math.rad(yaw)) * 128


		render.DrawQuadEasy(Vector(px, py), -vector_up, 32, 32, col, 90 - (yaw + 180))

		d.alpha = math.max(0, (d.alpha - FrameTime()))

		if d.alpha <= 0 then
			indicators[k] = nil
		end
	end

	--[[
	local z = 128 - 16
	surface.SetDrawColor(Color(255, 0, 0))
	surface.DrawLine(cx, cy - z, cx, cy + z)
	surface.DrawLine(cx - z, cy, cx + z, cy)
	surface.DrawLine(cx - z, cy, cx, cy - z)
	surface.DrawLine(cx - z, cy, cx, cy + z)
	]]
end)

hook.Add("HUDShouldDraw", "DamageIndicator", function(c)
	if c == "CHudDamageIndicator" then
		return false
	end
end)