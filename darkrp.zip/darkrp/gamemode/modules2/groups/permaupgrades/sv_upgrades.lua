util.AddNetworkString("permaupgrades")
permaupgradestable = permaupgradestable or {}
net.Receive("permaupgrades", function(len, ply)
    if file.Exists("flashlight/"..ply:SteamID64()..".txt", "DATA") then
       permaupgradestable["flashlight"] = 100
    else
       permaupgradestable["flashlight"] = nil
    end
    if file.Exists("parkour/"..ply:SteamID64()..".txt", "DATA") then
       permaupgradestable["parkour"] = 100
    else
       permaupgradestable["parkour"] = nil
    end
    net.Start("permaupgrades")
    net.WriteTable(permaupgradestable)
    net.Send(ply)
end)

util.AddNetworkString("flashlightbuy")
net.Receive("flashlightbuy", function(len, ply)
    if file.Exists( "flashlight/"..ply:SteamID64()..".txt", "DATA" ) then 
        DarkRP.notify(ply, 1, 4, "Это улучшение вы уже приобрели.") 
        return
    end
    if !ply:canAfford(50000) then
        DarkRP.notify(ply, 1, 4, "У вас недостаточно средств.") 
        return
    end
    ply:addMoney(-50000)
    DarkRP.notify(ply, 4, 4, "Улучшение Фонарь приобретено.") 
    file.CreateDir("flashlight")
    local date = os.time() + 1200000
    file.Write( "flashlight/"..ply:SteamID64()..".txt", date )
end)

util.AddNetworkString("parkourbuy")
net.Receive("parkourbuy", function(len, ply)
    if file.Exists( "parkour/"..ply:SteamID64()..".txt", "DATA" ) then 
        DarkRP.notify(ply, 1, 4, "Это улучшение вы уже приобрели.") 
        return
    end
    if !ply:canAfford(100000) then
        DarkRP.notify(ply, 1, 4, "У вас недостаточно средств.") 
        return
    end
    ply:addMoney(-100000)
    DarkRP.notify(ply, 4, 4, "Улучшение Паркур приобретено.") 
    file.CreateDir("parkour")
    local date = os.time() + 1200000
    file.Write( "parkour/"..ply:SteamID64()..".txt", date )
end)

local function PlayerSwitchFlashlight(ply, bool)
    if !file.Exists("flashlight/"..ply:SteamID64()..".txt", "DATA") then return end
    -- Your code logic here
end

hook.Add("PlayerSwitchFlashlight", "UniqueIdentifier", PlayerSwitchFlashlight)

util.AddNetworkString("flashlight_use")
net.Receive("flashlight_use", function(len, ply)
    if file.Exists( "flashlight/"..ply:SteamID64()..".txt", "DATA" ) then 
       if ply:FlashlightIsOn() then
       ply:Flashlight(false)
       else 
       ply:Flashlight(true)
       end
    end
end)