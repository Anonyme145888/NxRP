permaupgrades = {
	flashlight = {
		name = DarkRP.getPhrase("up_flashlight"),
		desc = DarkRP.getPhrase("up_flashlight_desc"),
		price = 50000
	},
	parkour = {
		name = DarkRP.getPhrase("up_parkour"),
		desc = DarkRP.getPhrase("up_parkour_desc"),
		price = 100000
	}
}