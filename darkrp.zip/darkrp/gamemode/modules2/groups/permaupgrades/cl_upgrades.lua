local PANEL = {}
local cachedData

function PANEL:Init()
	self:AddTitle(DarkRP.getPhrase("cc_upgrades"))
	self:SetKeyboardInputEnabled(false)

	self.upgrades = self:Add("Upgrades")
	self.upgrades:Dock(FILL)

	if cachedData then
		self:Set(cachedData)
	else
		self.spinner = self:Add("LoadingSpinner")
		self.spinner:SetSize(64, 64)
		self.spinner:Center()
	end
end

function PANEL:Set(existing)
	if IsValid(self.spinner) then
		self.spinner:Remove()
	end
	self.upgrades:Set("citycontrol_upgrades", permaupgrades, existing, function(k, button)
		button:SetDisabled(true)

		cachedData = nil

		if k == "flashlight" then
		net.Start("flashlightbuy")
		net.SendToServer()
		end
        
        if k == "parkour" then
		net.Start("parkourbuy")
		net.SendToServer()
		end
	end, true, true)
end

derma.DefineControl("PermaUpgrades", "", PANEL, "NxGenericFrame")

local spawned
function DarkRP.OpenPermaUpgrades()
	if IsValid(spawned) then
		spawned:Remove()
		spawned = nil
	end

	spawned = vgui.Create("PermaUpgrades")
    spawned:Center()
    
	net.Start("permaupgrades")
		net.WriteBool(false)
	net.SendToServer()
end

net.Receive("permaupgrades", function()
	local existing = net.ReadTable()
	cachedData = existing

	if IsValid(spawned) then
		spawned:Set(existing)
	end
end)

concommand.Add("permaupgrades", DarkRP.OpenPermaUpgrades)