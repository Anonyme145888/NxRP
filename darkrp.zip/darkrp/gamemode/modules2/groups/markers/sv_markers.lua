markers = {}

markers.tag = "NxMarker"

markers.AddMarker = function(players, marktitle, marktext, markicon, sound, position, color, time)
	net.Start(markers.tag)
		net.WriteTable {title = marktitle, text = marktext, icon = markicon, sound = sound, pos = position, time = time, color = color}
	net.Send(players)
end

util.AddNetworkString(markers.tag)
