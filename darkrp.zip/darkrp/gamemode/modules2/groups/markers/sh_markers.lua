DarkRP.declareChatCommand{
	command = "fr",
	description = "Вызвать пожарных.",
	delay = 1.5
}

DarkRP.declareChatCommand{
	command = "mr",
	description = "Вызвать скорую помощь.",
	delay = 1.5
}