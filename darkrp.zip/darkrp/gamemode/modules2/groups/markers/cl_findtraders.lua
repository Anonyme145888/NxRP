local traders = {}
hook.Add("loadCustomDarkRPItems", "findtraders", function()
	traders = {
		[TEAM_GUN or -1] = "pistol",
		[TEAM_TRADE or -1] = "cash",
		[TEAM_COOK or -1] = "burger",
		[TEAM_CAR or -1] = "wrench",
		[TEAM_MEDIC or -1] = "plus",
	}
end)
hook.Add("minimap", "findtraders", function(map)
	for _, pl in ipairs(player.GetAll()) do
		if pl ~= LocalPlayer() and traders[pl:Team()] and not pl:isArrested() and pl:Health() > 0 then
			local col = team.GetColor(pl:Team())
			col.r = 127 + col.r/2
			col.g = 127 + col.g/2
			col.b = 127 + col.b/2

			map:drawMarker(traders[pl:Team()], --[[pl:GetNWVector("shoppos", false) or]] pl:GetPos(), math.max(16, map:scalePixels(40)), col, nil, pl, false, pl:GetName())
		end
	end
end)
