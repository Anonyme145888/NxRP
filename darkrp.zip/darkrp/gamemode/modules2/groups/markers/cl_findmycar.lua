hook.Add("minimap", "findmycar", function(map)
		local car = DarkRP.mycar and Entity(DarkRP.mycar):IsValid() and Entity(DarkRP.mycar) or nil

		if not car or LocalPlayer():GetVehicle() == car then return end
		local col = car:GetColor()
		col.r = 127 + col.r/2
		col.g = 127 + col.g/2
		col.b = 127 + col.b/2

		map:drawMarker("car", car:GetPos(), math.max(16, map:scalePixels(48)), col, nil, car, false, car:getKeysTitle())
end)
