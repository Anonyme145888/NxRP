local time_to_update_ents
local entities = {}
local col_terminal = Color(200,128,64)
hook.Add("minimap", "findstatic", function(map)
	if not time_to_update_ents or time_to_update_ents < CurTime() then
		local lpos = LocalPlayer():GetPos()
		time_to_update_ents = CurTime() + 5
		entities = ents.FindByClass("car_terminal")
		table.sort(entities, function(a, b) return a:GetPos():Distance(lpos) < b:GetPos():Distance(lpos) end)
	end

	for i = 1, 3 do
		if entities[i] and entities[i]:IsValid() then
			map:drawMarker("carterminal", entities[i]:GetPos(), math.max(16, map:scalePixels(28)), col_terminal, nil, v, 64)
		end
	end
end)

hook.Add("minimap", "cinema", function(map)
	map:drawMarker("cinema", Vector(-1067.25,2364.875,1249), math.max(16, map:scalePixels(36)), Color(255,255,255), nil, v, 64)
end)
