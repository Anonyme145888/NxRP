local markers = {}

local function describeme(v)
	return (v[1]:IsValid() and v[1]:IsPlayer() and v[1]:Name() .. " " or "") .. (v[4] or "")
end

local function rm(id)
	local v = markers[id]
	timer.Remove("NxMarker" .. id)
	markers[id] = nil
	surface.PlaySound("common/wpn_denyselect.wav")
	notification.AddLegacy("✘ " .. describeme(v) , NOTIFY_HINT, 4, true)
end

concommand.Add("markers_clear", function()
	for id in pairs(markers) do
		markers[id] = nil
		timer.Remove("NxMarker" .. id)
	end
end)

net.Receive("NxMarker", function()
	local id = net.ReadUInt(16)
	local vec = net.ReadVector()
	local icon = net.ReadString()
	markers[id] = {Entity(id), vec, Material(icon == "O" and "gui/minimap/target_go.png" or "icon16/" .. icon .. ".png", "smooth noclamp"), net.ReadBool() and net.ReadString() or nil}
	notification.AddLegacy("► " .. describeme(markers[id]) , NOTIFY_HINT, 4, true)
	surface.PlaySound("common/talk.wav")
	timer.Create("NxMarker" .. id, 300, 1, function()
		rm(id)
	end)
end)

function nxmarker(pl, entOrVec, icon, text)
	local id = -SysTime()

	markers[id] = {pl, entOrVec, Material(icon == "O" and "gui/minimap/target_go.png" or "icon16/" .. icon .. ".png", "smooth noclamp"), text}
	notification.AddLegacy("► " .. describeme(markers[id]) , NOTIFY_HINT, 4, true)
	surface.PlaySound("common/talk.wav")

	timer.Create("NxMarker" .. id, 300, 1, function()
		rm(id)
	end)
end

local vec = Vector(0, 0, 36)
local color = Color(0xFF, 0xEB, 0x3B)
hook.Add("HUDPaint", "NxMarker", function()
	local lp = LocalPlayer()
	for k, v in next, markers do
		if lp:GetPos():DistToSqr(v[2]) < 90000 or (v[1]:IsPlayer() and not v[1]:IsValid()) then
			timer.Remove("NxMarker" .. k)
			markers[k] = nil
			surface.PlaySound("common/bugreporter_succeeded.wav")
			notification.AddLegacy("✔ " .. describeme(v) , NOTIFY_GENERIC, 4, true)
		else
			local pos = (v[2] + vec):ToScreen()
			local dot = math.max(0, lp:GetAimVector():Dot( ( (v[2] + vec) - lp:EyePos() ):GetNormalized() ) - 0.5) * 2
			surface.SetAlphaMultiplier(dot)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.SetMaterial(v[3])
			surface.DrawTexturedRect(pos.x - 16, pos.y - 16, 32, 32)
			surface.SetAlphaMultiplier( (dot-0.5) * 2)
			if dot > 0.5 then
				local y = 26
				if v[1]:IsPlayer() then
					draw.BeautyText(v[1]:Name(), "nx_hud_compat", "nx_hud_compat_shadow", pos.x, pos.y + 26, color, 0.5, 0)
					y = 42
				end
				if v[4] then
					draw.BeautyText(v[4], "nx_hud_compat", "nx_hud_compat_shadow", pos.x, pos.y + y, color, 0.5, 0)
				end
			end
			surface.SetAlphaMultiplier(1)
		end
	end
end)

hook.Add("minimap-top", "nxmarkers", function(map)
	for k, v in pairs(markers) do
		map:drawMarker(v[3], v[2], map:scalePixels(20) + 4 * math.abs(math.sin(RealTime() * 4)), color_white)
	end
end)