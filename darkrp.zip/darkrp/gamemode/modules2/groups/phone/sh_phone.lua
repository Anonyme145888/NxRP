phone = phone or {}

phone.tag = "phone"
phone.cl_tag = "phone_cl"

phone.Ringtones = {
	default = true,
	hydrogen = true,
	destinations = true,
	dopamine = true,
	kids = true,
	pursuit = true,
	fozzor = true
}

local sound_mat = Material("anonchaos/icon/position.png")

phone.SelectRingtone = function()
	return ""
end

DarkRP.declareChatCommand{
	command = "call",
	description = "Call",
	delay = 1.5
}

DarkRP.declareChatCommand{
	command = "phone_reply",
	description = "Accept call",
	delay = 0
}

DarkRP.declareChatCommand{
	command = "phone_decline",
	description = "Deny call",
	delay = 0
}

DarkRP.declareChatCommand{
	command = "ringtone",
	description = "Change ringtone",
	delay = 60
}

DarkRP.declareChatCommand{
	command = "toggleon_phone",
	description = "Toggle on a phone",
	delay = 5
}

DarkRP.declareChatCommand{
	command = "toggleoff_phone",
	description = "Toggle off a phone",
	delay = 5
}

if CLIENT then
	phone.CreateVgui = function(ply, incoming, tmr)
		if phone.vgui then phone.vgui:Remove() end
		phone.vgui = vgui.Create("Panel")
		phone.vgui:SetSize(270, 125)
		phone.vgui:SetPos(ScrW()-290)
		phone.vgui.Paint = function(self, w, h)
			vgui.blurCopypaste(self, w, h)
		    surface.SetDrawColor( 40, 40, 40, 200 )
			surface.DrawRect(0, 0, w, h)
		end

		phone.vgui:CenterVertical()

		local col = Color(255, 255, 255, 105)
		local col2 = Color(0, 255, 0, 255)

		local frame = phone.vgui
		
		local lblDir = frame:Add("DLabel")
		lblDir:Dock(TOP)
		lblDir:SetFont("DermaNotDefault")
		lblDir:SetTextColor(incoming and col2 or col)
		lblDir:SizeToContents()
		lblDir.Think = function()
			local starttime = CurTime()
			
			local ct = math.floor(CurTime() - starttime)
			local timeformat = (ct > 3600 and "%H:" or "") .. "%M:%S"
			if ct > 3600 then timeformat = "Vous appelez toute la journée ?" end
			lblDir:SetText("Téléphone - "..os.date(timeformat, ct))
		end

		local lblName = frame:Add("DLabel")
		lblName:Dock(TOP)
		lblName:SetFont("DermaNotLarge")
		lblName:SizeToContents()
		lblName:DockMargin(0, 0, 0, MediumMargin)
		lblName:SetText(ply:getJobTable().name.." "..ply:GetName())
		--[[
		local hint = frame:Add("Panel")
		hint:Dock(TOP)
		local text = incoming and "Принять звонок" or "Отклонить звонок"
		hint:SetSize(surface.GetKeyCapSize("f", text))
		hint.Paint = function(s, w, h)
			surface.DrawKeyCap(0, 0, "f", 0, 0, text)
		end
		]]
        
		local button2 = frame:Add("NxButton")
		button2:Dock(BOTTOM)
		button2:SetSize(100,30)
		button2:SetText("Raccroché")
		button2.DoClick = function()
			frame:Remove()
			RunConsoleCommand("darkrp", "phone_decline")
		end

		if incoming then

			local button1 = frame:Add("NxButton")
			button1:Dock(BOTTOM)
			button1:SetSize(100,30)
			button1:SetPrimaryMainColors()
			button1:SetText("Acceptée")
			button1.DoClick = function()
				phone.vgui:Remove()
				RunConsoleCommand("darkr", "phone_reply")
			end

		end
		
	end
	
	phone.CloseVgui = function()
		if IsValid(phone.vgui) then
			phone.vgui:Remove()
		end
	end
	
	phone.EmitRingtone = function(ply)
		if !IsValid(ply) then return end

		local snd = ply:GetNWString("phone_ringtone", "marimba") or "marimba"

		snd = "gxrp/" .. snd .. ".wav"

		if ply.ringtone then
			ply.ringtone:Stop()
			ply.ringtone = nil
		end
		
		util.PrecacheSound(snd)
		
		local VSnd = CreateSound(ply, snd)
		VSnd:SetSoundLevel(60)
		VSnd:Stop() VSnd:Play()
		VSnd:ChangePitch(100, 0)
		VSnd:ChangeVolume(0.9, 0)
		
		ply.ringtone = VSnd
	end
	
	phone.ReadStatus = function()
		local status, data = net.ReadString(), net.ReadTable()
		
		if status == "stopringtone" then
			if data.ply.ringtone then
				data.ply.ringtone:Stop()
				data.ply.ringtone = nil
			end
		end
		
		if status == "decline" then
			phone.CloseVgui()
		end
		
		if status == "started" then
			if LocalPlayer() == data.talker then
				phone.CreateVgui(data.receiver, false, true)
			else
				phone.CreateVgui(data.talker, false, true)
			end
		end
		
		if status == "calling" then
			phone.CreateVgui(data.ply, false, true)
		end
		
		if status == "incoming" then
			phone.CreateVgui(data.ply, true, true)
		end
		
		if status == "ringtone" then
			phone.EmitRingtone(data.ply)
		end
	end
	net.Receive(phone.cl_tag, phone.ReadStatus)
end