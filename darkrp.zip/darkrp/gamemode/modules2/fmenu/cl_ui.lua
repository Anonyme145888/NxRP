local PANEL = {}

function PANEL:Init()
    self:AddTitle(DarkRP.getPhrase("set_agenda"))
    self:Center()
    local input = vgui.Create("DTextEntry", self)
    input:SetMultiline(true)
    input:Dock(FILL)
    input:SetEnterAllowed(false)
    input:RequestFocus()
    input:SetValue(LocalPlayer():getDarkRPVar("agenda") or "")
    --input:SetCaretPos(input:GetValue():utf8len())
    input:SetFont("DermaLarge")
    input.Paint = nxui_DTextEntry_Paint
    input:SetDrawLanguageID(false)
    local send = vgui.Create("NxButton", self)
    send:SetText("Modifier l'agenda")
    send:SizeBig()
    send:DockMargin(LargeMargin * 2, LargeMargin, LargeMargin * 2, 0)
    send:SetPrimaryMainColors()
    send:Dock(BOTTOM)

    send.DoClick = function()
        RunConsoleCommand("darkrp", "agenda", input:GetValue():Split("\n"))
        self:Remove()
    end

end

derma.DefineControl("EditAgenda", "", PANEL, "NxGenericFrame")

function DarkRP.EditAgenda()
    vgui.Create("EditAgenda")
end

local PANEL2 = {}

function PANEL2:Init()
    self:AddTitle("Lancer un avis de recherche")
    self:SetSize(yscale(320), yscale(600))
    self:Center()
    local scroll = vgui.Create("DScrollPanel", self)
    scroll:Dock(FILL)
    fixscrollbar(scroll)

    for k, v in pairs(player.GetAll()) do
        table.sort(player.GetAll(), function(a, b) return (a:Team() > b:Team()) end)
        local but = vgui.Create("NxButton", scroll)
        but:SetText(v:Name())
        but:SetTextColor(team.GetColor(v:Team()))
        but:SetTall(32)
        but:Dock(TOP)
        but:DockMargin(5, 5, 5, 5)

        but.DoClick = function()
            local target = v
            local smallfr = vgui.Create("NxGenericFrame")
            smallfr:AddTitle("Indiquer la raison")
            smallfr:SetSize(yscale(400), yscale(250))
            smallfr:Center()
            smallfr:MakePopup()
            local input = vgui.Create("DTextEntry", smallfr)
            input:SetMultiline(true)
            input:Dock(FILL)
            input:SetValue("")
            input:RequestFocus()
            --input:SetCaretPos(input:GetValue():utf8len())
            input:SetFont("DermaNotDefault")
            input.Paint = nxui_DTextEntry_Paint
            local send = vgui.Create("NxButton", smallfr)
            send:SetText("Lancer un avis de recherche")
            send:SetTall(32)
            send:DockMargin(5, 5, 5, 0)
            send:SetPrimaryMainColors()
            send:Dock(BOTTOM)

            send.DoClick = function()
                RunConsoleCommand("darkrp", "wanted", target:Name(), input:GetValue())
                smallfr:Remove()
                self:Remove()
            end
        end
    end
end

derma.DefineControl("WantMenu", "", PANEL2, "NxGenericFrame")

function DarkRP.WantMenu()
    local debil = vgui.Create("WantMenu")
    debil:Center()
end

-----------------------------------------------------------------------------------------------
local PANEL4 = {}

function PANEL4:Init()
    self:AddTitle("Retirer la recherche")
    self:SetSize(yscale(320), yscale(600))
    self:Center()
    local scroll = vgui.Create("DScrollPanel", self)
    scroll:Dock(FILL)
    fixscrollbar(scroll)

    for k, v in pairs(player.GetAll()) do
        table.sort(player.GetAll(), function(a, b) return (a:Team() > b:Team()) end)
        local but = vgui.Create("NxButton", scroll)
        but:SetText(v:Name())
        but:SetTextColor(team.GetColor(v:Team()))
        but:SetTall(32)
        but:Dock(TOP)
        but:DockMargin(5, 5, 5, 5)

        but.DoClick = function()
            local target = v
            RunConsoleCommand("darkrp", "unwanted", target:Name())
            self:Remove()
        end
    end
end

derma.DefineControl("UnWantMenu", "", PANEL4, "NxGenericFrame")

function DarkRP.UnWantMenu()
    local debil = vgui.Create("UnWantMenu")
    debil:Center()
end

-----------------------------------------------------------------------------------------------
local PANEL3 = {}

function PANEL3:Init()
    self:AddTitle("Demander un mandat")
    self:SetSize(yscale(320), yscale(600))
    self:Center()
    local scroll = vgui.Create("DScrollPanel", self)
    scroll:Dock(FILL)
    fixscrollbar(scroll)

    for k, v in pairs(player.GetAll()) do
        table.sort(player.GetAll(), function(a, b) return (a:Team() > b:Team()) end)
        local but = vgui.Create("NxButton", scroll)
        but:SetText(v:Name())
        but:SetTextColor(team.GetColor(v:Team()))
        but:SetTall(32)
        but:Dock(TOP)
        but:DockMargin(5, 5, 5, 5)

        but.DoClick = function()
            local target = v
            local smallfr = vgui.Create("NxGenericFrame")
            smallfr:AddTitle("Indiquer la raison")
            smallfr:SetSize(yscale(400), yscale(250))
            smallfr:Center()
            smallfr:MakePopup()
            local input = vgui.Create("DTextEntry", smallfr)
            input:SetMultiline(true)
            input:Dock(FILL)
            input:SetValue("")
            input:RequestFocus()
            --input:SetCaretPos(input:GetValue():utf8len())
            input:SetFont("DermaNotDefault")
            input.Paint = nxui_DTextEntry_Paint
            local send = vgui.Create("NxButton", smallfr)
            send:SetText("Demander un mandat")
            send:SetTall(32)
            send:DockMargin(5, 5, 5, 0)
            send:SetPrimaryMainColors()
            send:Dock(BOTTOM)

            send.DoClick = function()
                RunConsoleCommand("darkrp", "warrant", target:Name(), input:GetValue())
                smallfr:Remove()
                self:Remove()
            end
        end
    end
end

derma.DefineControl("WarrantMenu", "", PANEL3, "NxGenericFrame")

function WarrantMenu()
    local debil = vgui.Create("WarrantMenu")
    debil:Center()
end

// local PANEL4 = {}

// function PANEL4:Init()
//     self:SetSize(450, 300)
//     self:AddTitle("Appeler la police")
//     self:Center()
//     local lbl = vgui.Create("DLabel", self)
//     lbl:SetText("Décrire l'incident")
//     lbl:SetFont("nx_hud")
//     lbl:SetTextColor(color_white)
//     lbl:Dock(TOP)
//     lbl:DockMargin(5, 5, 5, 5)
//     local input = vgui.Create("DTextEntry", self)
//     input:SetMultiline(true)
//     input:Dock(FILL)
//     input:SetEnterAllowed(false)
//     input:RequestFocus()
//     input:SetValue("")
//     --input:SetCaretPos(input:GetValue():utf8len())
//     input:SetFont("DermaNotDefault")
//     input.Paint = nxui_DTextEntry_Paint
//     input:SetDrawLanguageID(false)
//     local but = vgui.Create("NxButton", self)
//     but:SetPrimaryMainColors()
//     but:Dock(BOTTOM)
//     but:SetText("Appeler la police")
//     but:DockMargin(10, 10, 10, 10)

//     but.DoClick = function()
//         RunConsoleCommand("say", "/cr ".. input:GetValue())
//         self:Remove()
//     end
// end

// derma.DefineControl("PoliceCallNigger", "f", PANEL4, "NxGenericFrame")

// function DarkRP.CallPoliceNigger()
//     local debil = vgui.Create("PoliceCallNigger")
//     debil:Center()
//     debil:MakePopup()
// end

net.Receive("WarrantCMenu", function(len, ply)
    local target = net.ReadEntity()
    local smallfr = vgui.Create("NxGenericFrame")
    smallfr:AddTitle("Indiquer la raison")
    smallfr:SetSize(yscale(400), yscale(250))
    smallfr:Center()
    smallfr:MakePopup()
    local input = vgui.Create("DTextEntry", smallfr)
    input:SetMultiline(true)
    input:Dock(FILL)
    input:SetValue("")
    input:RequestFocus()
    --input:SetCaretPos(input:GetValue():utf8len())
    input:SetFont("DermaNotDefault")
    input.Paint = nxui_DTextEntry_Paint
    local send = vgui.Create("NxButton", smallfr)
    send:SetText("Demander un mandat")
    send:SetTall(32)
    send:DockMargin(5, 5, 5, 0)
    send:SetPrimaryMainColors()
    send:Dock(BOTTOM)

    send.DoClick = function()
        RunConsoleCommand("darkrp", "warrant", target:Name(), input:GetValue())
        smallfr:Remove()
    end
end)

net.Receive("WantedCMenu", function(len, ply)
    local target = net.ReadEntity()
    local smallfr = vgui.Create("NxGenericFrame")
    smallfr:AddTitle("Indiquer la raison")
    smallfr:SetSize(yscale(400), yscale(250))
    smallfr:Center()
    smallfr:MakePopup()
    local input = vgui.Create("DTextEntry", smallfr)
    input:SetMultiline(true)
    input:Dock(FILL)
    input:SetValue("")
    input:RequestFocus()
    --input:SetCaretPos(input:GetValue():utf8len())
    input:SetFont("DermaNotDefault")
    input.Paint = nxui_DTextEntry_Paint
    local send = vgui.Create("NxButton", smallfr)
    send:SetText("Lancer un avis de recherche")
    send:SetTall(32)
    send:DockMargin(5, 5, 5, 0)
    send:SetPrimaryMainColors()
    send:Dock(BOTTOM)

    send.DoClick = function()
        RunConsoleCommand("darkrp", "wanted", target:Name(), input:GetValue())
        smallfr:Remove()
    end
end)