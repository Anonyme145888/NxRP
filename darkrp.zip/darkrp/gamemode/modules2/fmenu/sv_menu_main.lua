util.AddNetworkString("BlueKnock")

net.Receive("BlueKnock", function(len, ply)
    local targetEntity = net.ReadEntity() 
    if not IsValid(targetEntity) or not targetEntity:IsPlayer() then return end

    local distance = ply:GetPos():DistToSqr(targetEntity:GetPos())
    if distance > 2500 then 
        return
    end

    targetEntity:EmitSound("physics/wood/wood_crate_impact_hard3.wav")
end)