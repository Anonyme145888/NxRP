cmenufn = {}
local RequestC = cmenufn.RequestC
local Request = cmenufn.Request
local RequestN = cmenufn.RequestN
local players = cmenufn.players

local function Spacer(test)
	return {test = test}
end
cmenufn.Spacer = Spacer


local function RequestC(config, ...)
	local t = {...}
	return function(arg)
		local frame
		if not config.number then
			frame = DarkRP.StringRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, function(s)
				ProcessAction(t, s, arg)
			end)
		else
			frame = DarkRP.NumberRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, isfunction(config.def) and config.def() or config.def, function(s)
				ProcessAction(t, s, arg)
			end, nil, nil, nil, isfunction(config.min) and config.min() or config.min, isfunction(config.max) and config.max() or config.max)
		end

		if config.warning then
			frame:SetWarning(DarkRP.getPhrase(config.warning) or config.warning)
		end

		if config.maxchar then
			frame:SetMaxCharacters(config.maxchar)
		end

		if config.price then
			frame:SetPrice(config.symbol, config.price)
		end
	end
end
cmenufn.RequestC = RequestC

local function Request(title, text, ...)
	return RequestC({title = title, text = text}, ...)
end
cmenufn.Request = Request

local function RequestN(title, text, def, min, max, ...)
	return RequestC({title = title, text = text, number = true, def = def, min = min, max = max}, ...)
end

cmenufn.RequestN = RequestN

do -- Widgets
	do -- NxCWidget_Pocket
		
		do -- NxCWidget_Pocket_Slot
			local PANEL = {}

			function PANEL:Init()
				self:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
				self.Icon = self:Add("ModelImage")
				self.Icon:SetMouseInputEnabled(false)
				self.Icon:Dock(FILL)
				self.Icon:SetVisible(false)
				self:SetText("")
				self:SetTooltip(nil)
			end

			function PANEL:Set(slot)
				self.slot = slot
				--self:SetText(slot)
				self:Refresh()
			end

			function PANEL:Think()
				if not self.slot then return end
				local items = LocalPlayer():getPocketItems()

				local item = items and items[self.slot]
				if item ~= self.lastItem then
					self.lastItem = item
					self:Refresh()
				end
			end

			function PANEL:Refresh()
				print("refresh", self)
				if not self.slot then return end
				local items = LocalPlayer():getPocketItems()
				local slot = self.slot

				if items and items[slot] then
					self.Icon:SetVisible(true)
					self.Icon:SetSize(256, 256)
					self.Icon:InvalidateLayout(true)

					local v = items[slot]

					self.Icon:SetModel(v.model)


					if not file.Exists("materials/spawnicons/" .. v.model:gsub("%.mdl$", "") .. "_256.png", "GAME") then
						self.Icon:RebuildSpawnIcon()
					end

					self:SetTooltip(v.class)
				else
					self:SetTooltip(nil)
					self.Icon:SetVisible(false)
				end
			end

			function PANEL:PaintOver(w, h)
				local items = LocalPlayer():getPocketItems()
				if items and self.slot then
					local item = items[self.slot]

					if not item then return end
					if not item.count then return end

					surface.SetFont("DermaNotDefault")
					surface.SetTextPos(0, 0)
					surface.SetTextColor(color_white)
					surface.DrawText(item.count)
				end
			end

			function PANEL:DoClick()
				net.Start("DarkRP_spawnPocket")
                   net.WriteFloat(self.slot)
                net.SendToServer()

				local items = LocalPlayer():getPocketItems()
				if items then
					items[self.slot] = nil
				end
			end

			derma.DefineControl("NxCWidget_Pocket_Slot", "", PANEL, "NxButton")
		end

		local PANEL = {}

		function PANEL:Init()
			local lbl = self:Add("DLabel")
			lbl:SetText(DarkRP.getPhrase("pocket"))
			lbl:SetFont("DermaNotLarge")
			lbl:SizeToContents()
			lbl:Dock(TOP)

			local lbl = self:Add("DLabel")
			lbl:SetText(DarkRP.getPhrase("drop_item_hint"))
			lbl:SetFont("DermaNotDefault")
			lbl:SizeToContents()
			lbl:Dock(TOP)
			lbl:DockMargin(0, 0, 0, SmallMargin)

			local inv = self:Add("DIconLayout")
			inv.SizeToChildren = function() end
			inv:Dock(TOP)
			inv:SetSpaceX(SmallMargin)
			--local h = yscale(91)
			local h = (((ScrW() * 0.55) - LargeMargin*4 - MediumMargin*2) - (GAMEMODE.Config.pocketitems-1) * SmallMargin)/GAMEMODE.Config.pocketitems
			inv:SetTall(h)



			for i = 1, GAMEMODE.Config.pocketitems do
				local x = inv:Add("NxCWidget_Pocket_Slot")
				x:SetSize(h, h)
				x:Set(i)
			end
		end

		--[[
		function PANEL:PerformLayout(w, h)
			print("layout", w, h)
		end
		]]

		derma.DefineControl("NxCWidget_Pocket", "", PANEL, "EditablePanel")
	end

	do -- NxCWidget_PhoneCall
		local PANEL = {}

		function PANEL:Init()
			self:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
			self.lblDir = self:Add("DLabel")
			self.lblDir:Dock(TOP)
			self.lblDir:SetFont("DermaNotDefault")
			self.lblDir:SizeToContents()

			self.lblName = self:Add("DLabel")
			self.lblName:Dock(TOP)
			self.lblName:SetFont("DermaNotLarge")
			self.lblName:SizeToContents()
			self.lblName:DockMargin(0, 0, 0, MediumMargin)

			local bdock = self:Add("EditablePanel")
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))

			self.butAccept = bdock:Add("NxButton")
			self.butAccept:Dock(LEFT)
			self.butAccept:DockMargin(0, 0, SmallMargin, 0)
			self.butAccept:SetText("Accepter")
			self.butAccept:SizeToContents()
			self.butAccept:SetSize(self:GetWide() + yscale(32), yscale(32))
			self.butAccept.DoClick = function()
				RunConsoleCommand("darkrp", "phone_reply")
				self:InvalidateLayout(true)
				self:InvalidateChildren(true)
			end

			self.butAccept.color = Color(0x38, 0x8E, 0x3C)
			self.butAccept.color_hover = Color(0x4C, 0xAF, 0x50)
			self.butAccept.color_down = Color(0x1B, 0x5E, 0x20)

			self.butDrop = bdock:Add("NxButton")
			self.butDrop:Dock(LEFT)
			--self.butDrop:DockMargin(0, 0, SmallMargin, 0)
			self.butDrop:SetText("Refuser")
			self.butDrop:SizeToContents()
			self.butDrop:SetSize(self:GetWide() + yscale(32), yscale(32))
			self.butDrop.DoClick = function()
				RunConsoleCommand("darkrp", "phone_decline")
				self:InvalidateLayout(true)
				self:InvalidateChildren(true)
			end

			self.butDrop.color = Color(0xD3, 0x2F, 0x2F)
			self.butDrop.color_hover = Color(0xF4, 0x43, 0x36)
			self.butDrop.color_down = Color(0xB7, 0x1C, 0x1C)

			hook.Add("PhoneStatusChanged", "NxCWidget_PhoneCall", function()
				if IsValid(self) then
					self:Refresh()
				end
			end)

			--self:InvalidateLayout(true)
			--self:InvalidateChildren(true)
			self:SizeToChildren(true, true)
			self:Refresh()
		end

		function PANEL:Refresh()
			self.lblDir:SetText("Appeler")
			self.lblName:SetText("Téléphone")
			self.butAccept:SetVisible(true)
			self.butDrop:SetVisible(!phone.ReadStatus == "decline")
		end
        
		function PANEL:ShouldBeVisible()
			return phone.ReadStatus == "incoming" or phone.ReadStatus == "calling"
		end
        
		local col = Color(255, 255, 255, 105)
		local col2 = Color(0, 255, 0, 255)

		function PANEL:Paint(w, h)
			
			self.lblDir:SetTextColor(col2)
			
			surface.SetAlphaMultiplier(0.5)
			
			surface.SetDrawColor(Color(255, 255, 255, 20))
			surface.DrawRect(0, 0, w, h)

			surface.SetAlphaMultiplier(1)
		end

		derma.DefineControl("NxCWidget_PhoneCall", "", PANEL, "EditablePanel")
	end
   
	do -- NxCWidget_Weapon
		local PANEL = {}

		function PANEL:Init()
			self.__lastWep = LocalPlayer():GetActiveWeapon()

			local lbl = self:Add("DLabel")
			self.lblWep = lbl
			lbl:SetText("")
			lbl:SetFont("DermaNotLarge")
			lbl:SizeToContents()
			lbl:Dock(TOP)
			lbl:DockMargin(0, 0, 0, MediumMargin)

			self.statdock = self:Add("EditablePanel")
			self.statdock:Dock(TOP)
			self.statdock:SetTall(0)

			self.stat1 = self.statdock:Add("DLabel")
			self.stat1:Dock(LEFT)
			self.stat1:SetFont("DermaNotDefault")
			self.stat1:SetVisible(false)

			self.dmgChart = self.statdock:Add("EditablePanel")
			self.dmgChart:Dock(FILL)
			self.dmgChart:NoClipping(true)
			self.dmgChart:DockMargin(0, 0, 0, 0)

			self.dmgChart.Paint = function(s, w, h)
				local wep = LocalPlayer():GetActiveWeapon()

				if not IsValid(wep) then return end
				if not wep.OpenCustomizationMenu then return end

				h = h - 32
				w = w * 0.5

				surface.SetDrawColor(Color(0, 0, 0, 200))
				surface.DrawRect(0, 0, w, h)


				local D1 = w * (wep.FalloffBegin/wep.TerminationDistance)
				local D2 = w * (wep.FalloffEnd/wep.TerminationDistance)
				local X1 = h * (1 - wep.Primary.DamageMin/wep.Primary.Damage)

				-- grid
				surface.SetDrawColor(Color(255, 255, 255, 20))
				surface.DrawLine(0, X1, w, X1)
				surface.DrawLine(D1, 0, D1, h)
				surface.DrawLine(D2, 0, D2, h)

				-- stk changes
				surface.SetDrawColor(Color(255, 100, 0, 150))
				local lastSTK = 0
				for i = 0, w do
					local dist = i*(wep.TerminationDistance/w)
					local mul = math.Clamp((dist-wep.FalloffBegin)/(wep.FalloffEnd-wep.FalloffBegin), 0, 1)
					local dmg = wep.Primary.Damage - (wep.Primary.Damage - wep.Primary.DamageMin) * mul
					local stk = math.ceil(100/dmg)

					if stk > lastSTK then
						lastSTK = stk
						if i > 0 then
							surface.DrawLine(i, h, i, h * (1 - dmg/wep.Primary.Damage))
						end
					end
				end

				-- dmg line
				surface.SetDrawColor(Color(0, 255, 255))
				surface.DrawLine(0, 0, D1, 0)
				surface.DrawLine(D1, 0, D2, X1)
				surface.DrawLine(D2, X1, w, X1)

				-- labels
				surface.SetFont("DermaDefault")
				surface.SetTextPos(0, 0)
				surface.SetTextColor(color_white)
				surface.DrawText(wep.Primary.Damage)

				surface.SetTextPos(0, X1)
				surface.DrawText(wep.Primary.DamageMin)

				surface.SetTextPos(D1, h)
				surface.DrawText(math.Round(wep.FalloffBegin / 52493.43832021 * 1000) .. "m")

				surface.SetTextPos(D2, h)
				surface.DrawText(math.Round(wep.FalloffEnd / 52493.43832021 * 1000) .. "m")

				surface.SetTextPos(w, h)
				surface.DrawText(math.Round(wep.TerminationDistance / 52493.43832021 * 1000) .. "m")
			end

			local bdock = self:Add("EditablePanel")
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))

			local but = bdock:Add("NxButton")
			self.butCustomize = but
			but:SetWide(150)
			but:SetText(DarkRP.getPhrase("customize_weapon_s"))
			but:Dock(LEFT)
			but:DockMargin(0, 0, SmallMargin, 0)
			but.DoClick = function()
				_G.cmenuspawnedframe:SetVisible(false)
				LocalPlayer():GetActiveWeapon():OpenCustomizationMenu()
			end

			local but = bdock:Add("NxButton")
			self.butDrop = but
			but:SetWide(150)
			but:SetText(DarkRP.getPhrase("drop_weapon_s"))
			but:Dock(LEFT)
			but.DoClick = function()
				RunConsoleCommand("darkrp", "drop")
			end

			local but = bdock:Add("NxButton")
			self.butDropAmmo = but
			but:SetWide(150)
			but:SetText(DarkRP.getPhrase("drop_ammo"))
			but:Dock(LEFT)
			but.DoClick = function()
				DarkRP.NumberRequest(
					DarkRP.getPhrase("drop_ammo"),
					DarkRP.getPhrase("how_much_ammo"),
					0, -- Valeur par défaut
					function(ammo)
						if ammo > 0 then
							RunConsoleCommand("gmod_drop_ammo", ammo)
						else
							chat.AddText(Color(255, 0, 0), "Please enter a valid number of ammo to drop.")
						end
					end,
					nil, -- Fonction annulée
					nil, -- Fonction callback si annulée
					nil, -- Valeur par défaut pour le texte
					0, -- Minimum
					1000 -- Maximum (peut être ajusté)
				)
			end


			self.attachmentLayout = self:Add("DIconLayout")
			self.attachmentLayout:Dock(TOP)
			self.attachmentLayout:SetSize(yscale(64))
			self.attachmentLayout:SetSpaceX(yscale(5))
			self.attachmentLayout:SetSpaceY(yscale(5))
			self.attachmentLayout:DockMargin(0, MediumMargin, 0, 0)

			--[[
			if not bdock:HasChildren() then
				local lbl = bdock:Add("DLabel")
				lbl:Dock(TOP)
				lbl:SetFont("DermaNotDefault")
				lbl:SetText(Blue.getPhrase("no_actions"))
				lbl:SizeToContents()
				bdock:SetTall(lbl:GetTall())
			end
			]]
		end

		function PANEL:Think()
			local __lastWep = LocalPlayer():GetActiveWeapon()
			if __lastWep ~= self.__lastWep then
				self:Refresh()
				self.__lastWep = __lastWep
			end
		end

		local function canDropWeapon(weapon)
			if not IsValid(weapon) then return false end
			local class = string.lower(weapon:GetClass())

			--if weapon.isinloadout then return false end

			if GAMEMODE.Config.DisallowDrop[class] then return false end

			if not GAMEMODE.Config.restrictdrop then return true end

			for k,v in pairs(CustomShipments) do
				if v.entity ~= class then continue end

				return true
			end

			return false
		end

		local fixicons = {
			eotech = "eotech553",
			leupold = "mk4",
			sg55x30mag = "sg55xmag",
		}

		function PANEL:Refresh()
			print("refresh", self)

			local wep = LocalPlayer():GetActiveWeapon()
			self.wep = wep

			if not wep:IsValid() then
				return
			end

			self.lblWep:SetText(wep:GetPrintName())
			self.butCustomize:SetVisible(false)
			--self.butUnload:SetVisible(not not wep.Unload)
			self.butDrop:SetVisible(canDropWeapon(wep))
			self.butDropAmmo:SetVisible(true)
			self.stat1:SetVisible(not not wep.OpenCustomizationMenu)
			self.statdock:SetVisible(not not wep.OpenCustomizationMenu)
			self.attachmentLayout:SetVisible(not not wep.OpenCustomizationMenu)

			self.statdock:SetTall(0)

			if wep.OpenCustomizationMenu then
				local stats = {}

				if wep.Primary.NumShots <= 1 then
					table.insert(stats, "Damage: " .. wep.Primary.Damage)
				else
					table.insert(stats, "Damage: " .. wep.Primary.Damage .. " * " .. wep.Primary.NumShots .. " shots = " .. wep.Primary.NumShots * wep.Primary.Damage)
				end

				table.insert(stats, "STK: " .. math.ceil(100 / (wep.Primary.Damage*(wep.Primary.NumShots or 1))))

				table.insert(stats, "Fire Rate: " .. math.ceil(60/wep.Primary.Delay) .. " RPM")

				table.insert(stats, "TTK: " .. wep.Primary.Delay * (math.ceil(100/(wep.Primary.Damage*(wep.Primary.NumShots or 1))) - 1))

				if wep.Primary.NumShots > 1 then
					table.insert(stats, "Shots: " .. wep.Primary.NumShots)
				end

				table.insert(stats, "Cone: " .. wep.ConeStayHip)
				table.insert(stats, "Cone (aim): " .. (wep.ConeStayAim or wep.ConeStayAim))

				self.stat1:SetText(
					table.concat(stats, "\n") .. "\n"
				)
				self.stat1:SizeToContents()
				self.statdock:SetTall(self.stat1:GetTall())
			end

			self.attachmentLayout:Clear()
			if wep.SupportedAttachments then for k, v in pairs(wep.SupportedAttachments) do
				if k == "BaseClass" then
					continue
				end

				local att = self.attachmentLayout:Add("DImageButton")
				att:SetTooltip(v)
				att:SetSize(yscale(64), yscale(64))
				att:SetImage("vgui/fas2atts/" .. (fixicons[v] or v))

				att.DoClick = function()
					if table.HasValue(FAS2AttOnMe, v) then
						local newState = not LocalPlayer():GetActiveWeapon():GetAttachmentState(v)
						LocalPlayer():GetActiveWeapon():SwitchAttachment(v, newState)
						surface.PlaySound(newState and "cstm/attach.wav" or "cstm/detach.wav")
					end
				end

				att.Paint = function(s, w, h)

					if IsValid(self.wep) and self.wep:GetAttachmentState(v) then
						surface.SetDrawColor(0, 255, 0, 255)
					elseif FAS2AttOnMe and not table.HasValue(FAS2AttOnMe, v) then
						surface.SetDrawColor(255, 108, 91, 255)
					else
						surface.SetDrawColor(107, 149, 255, 255)
					end

					surface.DrawOutlinedRect(0, 0, w, h)
					surface.DrawOutlinedRect(1, 1, w-2, h-2)
				end
			end end

			-- please for fuck sake autosize
			self:InvalidateChildren(true)
			self:InvalidateLayout(true)
			self:InvalidateChildren(true)
			self:SizeToChildren(true, true)
			self:InvalidateLayout()
		end

		function PANEL:ShouldBeVisible()
			local wep = LocalPlayer():GetActiveWeapon()

			return wep:IsValid() and (not not wep.OpenCustomizationMenu or not not wep.Unload or canDropWeapon(wep))
		end

		--[[
		function PANEL:PerformLayout(w, h)
			self:SizeToChildren(true, true)
		end
		]]

		derma.DefineControl("NxCWidget_Weapon", "", PANEL, "EditablePanel")
	end

	do -- NxCWidget_Phone
		local PANEL = {}

		function PANEL:Init()
			self.__lastNigger = LocalPlayer():isCP()

			--self:Refresh()

			local lbl = self:Add("DLabel")
			lbl:SetText(DarkRP.getPhrase("phone"))
			lbl:SetFont("DermaNotLarge")
			lbl:SizeToContents()
			lbl:Dock(TOP)
			lbl:DockMargin(0, 0, 0, MediumMargin)

			local bdock = self:Add("EditablePanel")
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))
			bdock:DockMargin(0, 0, 0, SmallMargin)

			local but = bdock:Add("NxButton")
			self.butOnOff = but
			but:SetWide(240)
			but:SetText("")
			but:Dock(LEFT)
			but:DockMargin(0, 0, SmallMargin, 0)
			but.DoClick = function()
				local enabled = LocalPlayer():GetNWBool("phone_status", false)
				RunConsoleCommand("darkrp", (enabled and "toggleoff" or "toggleon") .. "_phone") 
				--notification.AddLegacy(enabled and DarkRP.getPhrase"phone_is_on" or DarkRP.getPhrase"phone_is_off", NOTIFY_UNDO, 4, true)
			end

			local but = bdock:Add("NxButton")
			but:SetWide(150)
			but:SetText(DarkRP.getPhrase("call_to") .. "...")
			but:Dock(LEFT)
			but:DockMargin(0, 0, SmallMargin, 0)
			but.DoClick = function()
				local self = FixedDermaMenu()
				for k, v in pairs(player.GetAll()) do
					if v ~= LocalPlayer() then
						self:AddOption(v:Name(), function() RunConsoleCommand("darkrp", "call", v:UserID()) end):SetColor(v:getJobTable().color)
					end
				end
				self:Open()
			end

			local bdock

			for k, v in pairs({
				{nil, DarkRP.getPhrase("phone_printer_hint"), nil, function() return not LocalPlayer():isCP() end},
				{DarkRP.getPhrase"buy_printer", function() RunConsoleCommand("calldealer") end, Color(0, 100, 0), function() return not LocalPlayer():isCP() end},

				{nil, DarkRP.getPhrase("phone_cityserv_hint")},
				// {DarkRP.getPhrase"police", function() DarkRP.CallPoliceNigger() end},
	   
				{DarkRP.getPhrase("job_kill_service"), function() DarkRP.OpenCriminalSupportPanel() end, Color(123,60,60, 255)},
			
			}) do
				if v == nil then continue end

				if not bdock or v[1] == nil then
					if v[1] == nil and v[2] ~= nil then
						local lbl = self:Add("DLabel")
						lbl:SetFont("DermaNotDefault")
						lbl:SetText(v[2])
						if v[4] then
							self.really1 = lbl
						end
						lbl:SizeToContents()
						lbl:Dock(TOP)
						lbl:DockMargin(0, 0, 0, SmallMargin)
						lbl:SetWrap(true)
						lbl:SetAutoStretchVertical(true)
					end

					bdock = self:Add("EditablePanel")
					bdock:Dock(TOP)
					bdock:SetTall(yscale(32))

					bdock:DockMargin(0, 0, 0, SmallMargin)
					if v[1] == nil then continue end
				end

				local but = bdock:Add("NxButton")
				but:SetWide(150)
				but:SetText(v[1])

				if v[1] == DarkRP.getPhrase"buy_printer" then
					but:SetFont("DermaNotLarge")
					bdock:SetTall(yscale(40))
				end

				but:Dock(LEFT)
				but:DockMargin(0, 0, SmallMargin, 0)
				but.DoClick = v[2]
				if v[4] then
					self.really2 = bdock
				end
				but:SizeToContents()
				but:SetWide(but:GetWide() + yscale(32))

				if v[3] then
					local a, b, c = ColorToHSV(v[3])
					but.color = v[3]
					but.color_hover = HSVToColor(a, b, c * 1.2)
					but.color_down = HSVToColor(a, b, c * 0.8)
				end
			end
		end
		
		function PANEL:Think()
			if self.__lastIsCP ~= LocalPlayer():isCP() then
				self:Refresh()
				self.__lastIsCP = LocalPlayer():isCP()
			end
		end

		function PANEL:isPhoneOn()
			return GetConVarNumber("mutephone") == 0
		end

		function PANEL:Refresh()
			print("refresh", self)
             
			self.butOnOff:SetText(DarkRP.getPhrase("phone_off_s").."/"..DarkRP.getPhrase("phone_on_s"))
			self.butOnOff:AutoSize()
			self.really1:SetVisible(not LocalPlayer():isCP())
			self.really2:SetVisible(not LocalPlayer():isCP())

			self:InvalidateLayout(true)
			self:SizeToChildren(true, true)
		end

		--[[
		function PANEL:PerformLayout(w, h)
			print(self, w, h)
		end
		]]

		derma.DefineControl("NxCWidget_Phone", "", PANEL, "EditablePanel")
	end

	do -- NxCWidget_Agenda
		local PANEL = {}

		hook.Remove("DarkRPVarChanged", "agendaHUD")

		local agendaText
		function PANEL:Init()
			local lbl = self:Add("DLabel")
			self.lblTitle = lbl
			lbl:SetText("agenda")
			lbl:SetFont("DermaNotLarge")
			lbl:SizeToContents()
			lbl:Dock(TOP)
			lbl:DockMargin(0, 0, 0, MediumMargin)

			local lbl = self:Add("DLabel")
			self.lblText = lbl
			lbl:SetText("agendatext")
			lbl:SetFont("DermaNotDefault")
			lbl:SizeToContents()
			lbl:Dock(TOP)
			lbl:DockMargin(0, 0, 0, MediumMargin)

			local bdock = self:Add("EditablePanel")
			self.bChange = bdock
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))

			local but = bdock:Add("NxButton")
			but:SetWide(150)
			but:SetText(DarkRP.getPhrase("car_modify"))
			but:Dock(LEFT)
			but.DoClick = function()
				vgui.Create("EditAgenda")
			end

			hook.Add("DarkRPVarChanged", "agendaHUD", function(ply, var, _, new)
				if not IsValid(self) then return end
				if ply ~= LocalPlayer() then return end
				if var ~= "agenda" and var ~= "job" then return end

				self.new = new

				self:Refresh()
				timer.Simple(1, function()
					self:Refresh()
				end)
			end)
		end

		function PANEL:Refresh()
			--debug.Trace()
			local agenda = LocalPlayer():getAgendaTable()
			if not agenda then return end
			self.lblTitle:SetText(agenda.Title)
			self.lblText:SetText(self.new or LocalPlayer():getDarkRPVar("agenda") or "Agende vide")
			self.lblText:SizeToContents()
			self.bChange:SetVisible((LocalPlayer():getJobTable().mayor or LocalPlayer():getJobTable().chief) and true or false)
			self.new = nil
			self:InvalidateLayout(true)
			self:SizeToChildren(true, true)
		end

		function PANEL:ShouldBeVisible()
			return LocalPlayer():getAgendaTable() ~= nil
		end

		derma.DefineControl("NxCWidget_Agenda", "", PANEL, "EditablePanel")
	end

	do -- NxCWidget_Shop
		local PANEL = {}

		function PANEL:ShouldBeVisible()
			return LocalPlayer():Team() == TEAM_GUN or LocalPlayer():Team() == TEAM_STORE or LocalPlayer():Team() == TEAM_COOK or LocalPlayer():Team() == TEAM_MEHANIK
		end

		function PANEL:Init()
			local lbl = self:Add("DLabel")
			lbl:Dock(TOP)
			lbl:SetFont("DermaNotLarge")
			lbl:SetText(DarkRP.getPhrase("trading_merchantry"))
			lbl:SizeToContents()
			lbl:DockMargin(0, 0, 0, MediumMargin)

			local lbl = self:Add("DLabel")
			self.warnLbl = lbl
			lbl:Dock(TOP)
			lbl:SetFont("DermaNotDefault")
			lbl:SetText(DarkRP.getPhrase("shop_hint_res2"))
			lbl:SizeToContents()
			lbl:SetTextColor(Color(0xF4, 0x43, 0x36))
			lbl:DockMargin(0, 0, 0, MediumMargin)

			local bdock = self:Add("EditablePanel")
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))
			bdock:DockMargin(0, 0, 0, MediumMargin)

			local but = bdock:Add("NxButton")
			but:SetText(DarkRP.getPhrase("open_shop_gui"))
			but:Dock(LEFT)
			but:DockMargin(0, 0, SmallMargin, 0)
			but:AutoSize()
			but.DoClick = function()
				DarkRP.JobsShop()
			end
            
			local but = bdock:Add("NxButton")
			but:SetText(DarkRP.getPhrase("set_profit_margin_percent"))
			but:Dock(LEFT)
			but:DockMargin(0, 0, SmallMargin, 0)
			but:SizeToContents()
			but:SetWide(but:GetWide() + yscale(32))
			but.DoClick = function()
				RunConsoleCommand("catalogue")
			end
            
			--[[
			local bdock = self:Add("EditablePanel")
			bdock:Dock(TOP)
			bdock:SetTall(yscale(32))
			bdock.Paint = function(s, w, h)
				surface.SetDrawColor(color_white)
				surface.DrawOutlinedRect(0, 0, w, h)

				surface.SetDrawColor(0, 255, 0, 255)
				surface.DrawRect(1, 1, (w - 2) * (LocalPlayer():getShop():GetResources()/GAMEMODE.Config.maxShopResources), h - 2)
			end
			]]

		end

		function PANEL:Refresh()
			self.warnLbl:SetVisible((LocalPlayer():getDarkRPVar("resources") or 0) <= 0)
		end

		derma.DefineControl("NxCWidget_Shop", "", PANEL, "EditablePanel")
	end

	do -- NxCWidget_Radio
		local PANEL = {}

		function PANEL:Init()
			if not difm then return end
			if not istable(difm.List) then
				return
			end

			--local veh = difm.GetVehicle()

			local layout = self:Add("DIconLayout")
			layout:Dock(TOP)
			layout:SetSpaceX(SmallMargin)
			layout:SetSpaceY(SmallMargin)

			if istable(difm.List) then
				for k, v in pairs(table.Merge({{name = DarkRP.getPhrase("difm_silence"), key = ""}}, difm.List)) do
					local but = layout:Add("NxButton")
					but:SetText(v.name)
					but:SizeToContents()
					but:SetSize(but:GetWide() + yscale(16), yscale(32))
					but:DockMargin(0, 0, 0, SmallMargin)
					but.DoClick = function()
						net.Start("difm")
							net.WriteString(v.key or "")
						net.SendToServer()
					end

					--[[
					local line = list:AddLine(v.name)
					line.key = v.key
					line:SetTooltip(v.description)
					if veh:GetNWString("Stream", "") == v.key then
						line:SetSelected(true)
					end
					]]
				end
			end

			layout:InvalidateLayout(true)

			--list:SortByColumn(1)

			local volume = self:Add("NxNumSlider")
			volume:Dock(TOP)
			volume:SetText(DarkRP.getPhrase("difm_volume"))
			volume:SetMax(100)
			volume:SetDecimals(0)
			volume:SetConVar("difm_volume")
			volume.Label:SizeToContents()
		end

		function PANEL:ShouldBeVisible()
			return difm and difm.GetVehicle() ~= nil
		end

		derma.DefineControl("NxCWidget_Radio", "", PANEL, "EditablePanel")
	end
end

if IsValid(_G.cmenuspawnedframe) then
	_G.cmenuspawnedframe:Remove()
	_G.cmenuspawnedframe = nil
end