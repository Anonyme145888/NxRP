include("cl_menu_main.lua")
cmenufn = {}

local function Option(title, icon, cmd, test)
	return {title = title, icon = icon, cmd = cmd, test = test}
end
cmenufn.Option = Option

local function SubMenu(title, icon, func, test)
	return {title = title, icon = icon, func = func, test = test}
end
cmenufn.SubMenu = SubMenu

local function Spacer(test)
	return {test = test}
end
cmenufn.Spacer = Spacer

local function ProcessAction(t, s, arg)
	if type(t[1]) == "function" then
		t[1](s, arg)
	elseif t[1] == "DarkRP" then
		local t = table.Copy(t)
		table.remove(t, 1)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	elseif t[1] == "DarkRP" then
		local t = table.Copy(t)
		table.remove(t, 1)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	else
		local t = table.Copy(t)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	end
end

local function RequestC(config, ...)
	local t = {...}
	return function(arg)
		local frame
		if not config.number then
			frame = DarkRP.StringRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, function(s)
				ProcessAction(t, s, arg)
			end)
		else
			frame = DarkRP.NumberRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, isfunction(config.def) and config.def() or config.def, function(s)
				ProcessAction(t, s, arg)
			end, nil, nil, nil, isfunction(config.min) and config.min() or config.min, isfunction(config.max) and config.max() or config.max)
		end

		if config.warning then
			frame:SetWarning(DarkRP.getPhrase(config.warning) or config.warning)
		end
        

		if config.price then
			frame:SetPrice(config.symbol, config.price)
		end
	end
end
cmenufn.RequestC = RequestC

local function Request(title, text, ...)
	return RequestC({title = title, text = text}, ...)
end
cmenufn.Request = Request

local function RequestN(title, text, def, min, max, ...)
	return RequestC({title = title, text = text, number = true, def = def, min = min, max = max}, ...)
end

cmenufn.RequestN = RequestN


cmenufn.players = players

hook.Run("cmenufn")

-- conditions
	local isCP = FindMetaTable("Player").isCP

	local function isMayor()
		return LocalPlayer():getJobTable().mayor and true or false
	end
	
	local function isChief()
		return LocalPlayer():getJobTable().chief and true or false
	end

	local function isMayorOrChief()
		return (LocalPlayer():getJobTable().mayor or LocalPlayer():getJobTable().chief) and true or false
	end

	--[[
	local function canJail()
		return LocalPlayer():getJobTable().chief and GAMEMODE.Config.chiefjailpos
	end
	]]

	local function hasRadio()
		return LocalPlayer():HasWeapon("nx_radio")
	end


	local specialjobs = {}
	hook.Add("loadCustomDarkRPItems", "cmenuspecialjobs", function()
		specialjobs = {TEAM_GANG, TEAM_MOB, TEAM_TAXI, TEAM_GUN, TEAM_TRADE, TEAM_COOK, TEAM_CAR}
	end)
--


-------------------------------------------------------------------------------------------------------------------------------


do -- NxC_Character
	local function getplayermodel()
		local mdl = LocalPlayer():GetModel():lower()

		mdl = mdl:gsub("models/characters/badasses/", "models/joshers/badasses/playermodels/"):gsub("models/fearless/", "models/ccz/")

		if not nxshop.isModelAcceptable( mdl, LocalPlayer() ) or mdl == "models/player.mdl" or not util.IsValidModel(mdl) then
			mdl = player_manager.TranslatePlayerModel(GetConVarString("cl_playermodel"))
		end

		return mdl
	end

	local PANEL = {}

	function PANEL:Init()
		self.SequenceStart = RealTime()

		local butdock = self:Add("EditablePanel")
		butdock:Dock(BOTTOM)
		butdock:SetTall(yscale(32))

		local butWidth = (ScrW() * 0.25 - SmallMargin*2)/3

		local but = butdock:Add("NxButton")
		but:SetText(DarkRP.getPhrase("F4hats"))
		but:Dock(LEFT)
		but:SetWide(butWidth)
		but.DoClick = function()
			_G.cmenuspawnedframe:SetVisible(false)
			nxshop.nosound = true
			nxshop.showShop()
			nxshop.nosound = nil
			nxshop.spawnedShop:SetAlpha(255)
			nxshop.spawnedShop.alpha = 1
			nxshop.spawnedShop.listMenu:SetActiveTab(nxshop.Categories.hats.tab)
		end

		local but = butdock:Add("NxButton")
		but:SetText(DarkRP.getPhrase("animations"))
		but:Dock(LEFT)
		but:DockMargin(SmallMargin, 0, 0, 0)
		but:SetWide(butWidth)
		but.DoClick = function()
			local menu = FixedDermaMenu()

			for act, str in pairs(DarkRP.PlayerAnims) do
				menu:AddOption(str, function()
					self:PlaySequence(act)
				end)
			end

			menu:Open()
		end

		local but = butdock:Add("NxButton")
		but:SetText(DarkRP.getPhrase("edit_model"))
		but:Dock(LEFT)
		but:DockMargin(SmallMargin, 0, 0, 0)
		but:SetWide(butWidth)
		but.DoClick = function()
			RunConsoleCommand("nx_editmodel")
		end
		but:SetVisible(false)

		local pname = self:Add("DLabel")
		self.pname = pname
		pname:SetText(LocalPlayer():Name())
		pname:SetContentAlignment(5)
		pname:SetFont("DermaNotLarge")
		pname:SizeToContents()
		pname:Dock(TOP)

		local model = self:Add("DModelPanel")
		model:SetCursor("arrow")
		self.model = model
		model:Dock(FILL)
		model:SetModel(getplayermodel())

		local mt = table.Copy(debug.getmetatable(model.Entity))
		model.Entity.renderingWep = false
		mt.IsPlayer = function(s) return s.renderingWep end
		debug.setmetatable(model.Entity, mt)

		model.Entity.GetPlayerColor = function() return LocalPlayer():GetPlayerColor() end
		model.Entity.GetWeaponColor = function() return LocalPlayer():GetWeaponColor() end

		model:SetColor(color_white)
		model.Entity:SetSkin(LocalPlayer():GetSkin())

		model.LayoutEntity = function() end

		--[[
		model:SetCamPos(Vector(150, 0, 64 * 2/3))
		model:SetLookAt(vector_up * 64 * 2/3)
		model:SetFOV(30)
		]]

		model:SetCamPos(Vector(90, 0, 68/2))
		model:SetLookAt(vector_up * 68/2)
		model:SetFOV(30)

		self.__lastPlayerModel = getplayermodel()
		self.__lastWep = LocalPlayer():GetActiveWeapon()
		self:Refresh()
        
		--do return end
		model.Entity.RenderOverride = function(ent)
			local c = LocalPlayer():GetColor()
			render.SetColorModulation(c.r/255, c.g/255, c.b/255)
			ent:DrawModel()
			render.SetColorModulation(1, 1, 1)
			if ent:GetSequence() < 0 then return end
			ent:SetCycle( ( (RealTime() - self.SequenceStart)/ent:SequenceDuration() ) % 1 )
			nxshop.drawHat(ent, LocalPlayer(), true, true)
			if model.Entity.wep then
				model.Entity.renderingWep = true
				local _WEP = self._WEP
				if _WEP.DoFixWorldModel then
					_WEP.DoFixWorldModel(model.Entity.wep)
				end
				if not _WEP.DoFixWorldModel and _WEP.DrawWorldModel then
					_WEP.DrawWorldModel(model.Entity.wep)
				else
					model.Entity.wep:DrawModel()
				end
			end

			model.Entity.renderingWep = false

			for k, v in pairs(ent.CSHats) do
				v:SetNoDraw(true)

				if v:GetRenderGroup() ~= RENDERGROUP_TRANSLUCENT then
					if v.RenderOverride then
						v:RenderOverride()
					else
						v:DrawModel()
					end
				end
			end

			for k, v in pairs(ent.CSHats) do
				if v:GetRenderGroup() == RENDERGROUP_TRANSLUCENT then
					if v.RenderOverride then
						v:RenderOverride()
					else
						v:DrawModel()
					end
				end
			end
		end

		hook.Add("DarkRPVarChanged", "rpname", function(ply, var, _, new)
			if not IsValid(self) then return end
			if ply ~= LocalPlayer() then return end
			if var ~= "rpname" then return end

			--print(LocalPlayer():Name(), new)
			self.pname:SetText(new)
		end)
	end

	function PANEL:PlaySequence(act)
		RunConsoleCommand("_DarkRP_DoAnimation", act)
		local seq = self.model.Entity:SelectWeightedSequence(act)
		local orig = self.model.Entity:GetSequenceName(seq)
		seq = self.model.Entity:LookupSequence(orig .. "_base")
		if seq <= 0 then
			seq = self.model.Entity:LookupSequence(orig .. "_original")
		end
		if seq <= 0 then return end
		self.model.Entity:SetSequence(seq)
		self.SequenceStart = RealTime()
		self.SequenceEnd = RealTime() + self.model.Entity:SequenceDuration(seq)
	end

	function PANEL:Think()
		if self.SequenceEnd and RealTime() >= self.SequenceEnd then
			self:Refresh()
			self.SequenceEnd = nil
		end

		local __lastPlayerModel = getplayermodel()
		local __lastWep = LocalPlayer():GetActiveWeapon()
		if self.__lastPlayerModel ~= __lastPlayerModel or self.__lastWep ~= __lastWep then
			self:Refresh()
        
			self.__lastPlayerModel = __lastPlayerModel
			self.__lastWep = __lastWep
		end
	end

	function PANEL:Refresh()
		print("refresh", self)
		
		self.pname:SetText(LocalPlayer():Name())
		local model = self.model

		self.model.Entity:SetModel(getplayermodel())
		self.model.Entity:SetSkin(LocalPlayer():GetSkin())
		self.model.Entity:ClearPoseParameters()
		self.model.Entity:SetupBones()
		self.model.Entity:InvalidateBoneCache()

		if IsValid(model.Entity.wep) then
			model.Entity.wep:Remove()
			model.Entity.wep = nil
		end

		local _WEP = LocalPlayer():GetActiveWeapon()
		if _WEP:IsValid() and (_WEP:GetClass() == "gx_fuel" or _WEP:GetClass():find("^fas2")) then
			_WEP = NULL
		end
		self._WEP = _WEP
		if _WEP:IsValid() and _WEP:GetModel() ~= "" then
			model.Entity.wep = ClientsideModel(_WEP:GetModel() or "models/weapons/w_rif_ak47.mdl")
			model.Entity.wep:SetParent(model.Entity, model.Entity:LookupAttachment("anim_attachment_RH"))
			model.Entity.wep:SetNoDraw(true)
			model.Entity.wep:AddEffects(EF_BONEMERGE)
			model.Entity.wep.Owner = model.Entity
			model.Entity.wep.Offset = _WEP.Offset
			model.Entity.wep.FixWorldModelAng = _WEP.FixWorldModelAng
			model.Entity.wep.FixWorldModelPos = _WEP.FixWorldModelPos
			model.Entity.wep.FixWorldModelScale = _WEP.FixWorldModelScale
			model.Entity.wep:SetMaterial(_WEP:GetMaterial())
			model.Entity.wep:SetSkin(_WEP:GetSkin())
			model.Entity.wep:SetOwner(model.Entity)
		end

		if _WEP:IsValid() then
			local hdt = _WEP.PassiveHoldType or _WEP:GetHoldType()
			local seqid = model.Entity:LookupSequence("idle_" .. (hdt == "normal" and "all_01" or hdt))
			--print(hdt)
			model.Entity:SetSequence(seqid)
		else
			local seqid = model.Entity:LookupSequence("idle_all_01")
			model.Entity:SetSequence(seqid)
		end

		if model.Entity:GetSequence() < 0 then
			model.Entity:SetSequence(5)
		end
	end
	
	--[[
	function PANEL:Paint(w, h)
		vgui.blurCopypaste(self, w, h)

		surface.SetDrawColor( 40, 40, 40, 200 )
		surface.DrawRect(0, 0, w, h)
	end
	]]

	derma.DefineControl("NxC_Character", "", PANEL, "EditablePanel")
end

do -- NxC_Widgets
	local magic = function(self)
		self:InvalidateLayout(true)
		self:InvalidateChildren()
		self:SizeToChildren(true, true)
	end

	local PANEL = {}

	function PANEL:Init()
		self.widgets = {}

		self.scroll = self:Add("DScrollPanel")
		fixscrollbar(self.scroll)
		self.scroll:Dock(FILL)

		self:AddWidget("NxCWidget_Pocket", true)
		--self:AddWidget("NxCWidget_PhoneCall") Сделал но нужна переработка
		--self:AddWidget("NxCWidget_Passengers")
		self:AddWidget("NxCWidget_Radio")
		self:AddWidget("NxCWidget_Weapon")
		self:AddWidget("NxCWidget_Phone")
		self:AddWidget("NxCWidget_Agenda")
		self:AddWidget("NxCWidget_Shop")

		self:InvalidateLayout(true)
		self:InvalidateChildren(true)
	end

	local calcVis = function(pnl)
		local changed = false
		local shouldVisible = not pnl.ShouldBeVisible or pnl:ShouldBeVisible()
		if pnl.__lastshouldVisible ~= shouldVisible then
			changed = true
			pnl:SetVisible(shouldVisible)
			if pnl.Refresh then
				pnl:Refresh()
			end
			if shouldVisible then
				magic(pnl)
				timer.Simple(0.1, function()
					magic(pnl)
				end)
				timer.Simple(1, function()
					magic(pnl)
				end)
			end
		end
		pnl.__lastshouldVisible = shouldVisible
		return changed
	end

	function PANEL:AddWidget(class, bottom)
		local tgt = bottom and self or self.scroll
		local pnl = tgt:Add(class)
		self.widgets[class] = pnl
		if bottom then
			pnl:Dock(BOTTOM)
		else
			pnl:Dock(TOP)
			pnl:DockMargin(0, 0, 0, LargeMargin)
		end
		magic(pnl)
		calcVis(pnl)
	end

	function PANEL:ThinkVis()
		local changed
		for k, pnl in pairs(self.widgets) do
			changed = changed or calcVis(pnl)
		end

		if changed then
			self:InvalidateLayout(true)
			self:InvalidateChildren(true)
		end

		return changed
	end

	function PANEL:Think()
		self:ThinkVis()
	end

	--[[
	function PANEL:Paint(w, h)
		vgui.blurCopypaste(self, w, h)

		surface.SetDrawColor( 40, 40, 40, 200 )
		surface.DrawRect(0, 0, w, h)
	end
	]]

	derma.DefineControl("NxC_Widgets", "", PANEL, "EditablePanel")
end

do -- NxC_Legacy
	local Menu = {
		
		// Option("ballot_reopen", "poll", function() RunConsoleCommand("ElectionVoteMayorD425AD2") end, function() return GetGlobalBool("AEL_ElectionsActive") == true end),
	
        
		Option("drop_money", "money", RequestN("drop_money", "enter_summ", 2, 2, function() return LocalPlayer():getDarkRPVar("money") end, "darkrp", "dropmoney")),
		SubMenu("issue_cheque", "paycheque", function(self)
			for k, v in pairs(player.GetAll()) do
				self:AddOption(v:Name(), RequestN("issue_cheque", "enter_summ", 2, 2, function() return LocalPlayer():getDarkRPVar("money") end, "darkrp", "cheque", v:UserID())):SetColor(v:getJobTable().color)
			end
		end),
		--Option("drop_ammo", "ammo", DarkRP.openDropAmmoWindow),

		Spacer(),

	    // Option("write_letter", "inscription", RequestC({title = "Rédiger une note", text = "enter_text_letter"}, "say", "/write ")),

		Option("show_laws", "rules", function() RunConsoleCommand("lawsmenu") end),

		Option("fovchanger", "update-user", function() RunConsoleCommand("say", "!fov") end),
        
		Option("roll_the_dice", "dice", RequestN("roll_the_dice", "roll_sides", 6, 1, 1e14-1, "darkrp", "roll")),
		
		Option("set_hit_price", "horror", RequestN("set_hit_price", "set_hit_price_desc", 150000, 1, 1e14-1, "darkrp", "hitprice"), function() return LocalPlayer():Team() == TEAM_KILL end),
		
		SubMenu("demote_player_menu", "remove-user-group-man-man", function(self)
			for k, v in pairs(player.GetAll()) do
				if v:getJobTable().candemote ~= false then
					self:AddOption(v:Name(),
						(LocalPlayer():GetUserGroup() == "premium" or LocalPlayer():GetUserGroup() == "superadmin" or LocalPlayer():GetUserGroup() == "admin") 
                and RequestC({title = DarkRP.getPhrase("demote_player_menu"), text = "demote_enter_reason", warning = "demote_warn"}, "darkrp", "demote", v:UserID())
						or function()
							DarkRP.DermaQuery(DarkRP.getPhrase("demote_player_menu"), DarkRP.getPhrase("demote_prem"), DarkRP.getPhrase("yes"), function()
								showShop()
								timer.Simple(0, function()
									RunConsoleCommand("nxshop")
								end)
							end, DarkRP.getPhrase("no"), nil)
						end
					):SetColor(v:getJobTable().color)
				end
			end
		end),

		Spacer(),

		Option("upgrades", "update-user", function() RunConsoleCommand("permaupgrades") end),

		Option("change_name", "name-tag", function()
			vgui.Create("rpname")
		end),
		Option("set_custom_job", "new-job", RequestC({title = DarkRP.getPhrase("set_custom_job"), text = "enter_new_title"}, "darkrp", "job")),

		Spacer(),

		Option("sell_all_doors", "door", function() DarkRP.DermaQuery(DarkRP.getPhrase("sell_all_doors") .. "?", DarkRP.getPhrase("sell_all_doors") .. "?", "OK", function() RunConsoleCommand("darkrp", "unownalldoors") end, DarkRP.getPhrase("cancel")) end),

		Option("job_kill_interface", "caca-icon", function()
			DarkRP.OpenCriminalSupportPanel()  
		end, function() return LocalPlayer():isHitman() end),
		
		--Option("remove_car", "garage", function() RunConsoleCommand("deletemycars") end, function() return IsValid(LocalPlayer():GetNWEntity("currentVehicle")) end),
        --[[
		Option("turret_control", "gatling-gun", function()
			local cant = LocalPlayer():IsDisabled(1)
			if cant then
				notification.AddLegacy(cant, NOTIFY_ERROR, 4, true)
			else
				net.Start("nx_turret")
				net.WriteUInt(0, 2)
				net.SendToServer()
			end
		end, function() return ihaveturrets end),
        ]]
		Spacer(function() return LocalPlayer():isCP() or LocalPlayer():getJobTable().cook end),

		--Option("taxi_setprice", "taxi-mobile-payment", RequestN("taxi_setprice", "enter_price", nil, DarkRP.config.taxiPriceRange[1], DarkRP.config.taxiPriceRange[2], "DarkRP", "taxiprice"), function() return LocalPlayer():Team() == TEAM_TAXI and canLockUnlock(LocalPlayer(), LocalPlayer():GetVehicle(), true) and LocalPlayer():GetVehicle():GetNWBool("TaxiCar") end),

	    --	Option("hits_menu_subscriptions_title", "horror", DarkRP.Hits.openMenuSubscriptions, function() return LocalPlayer():Team() == TEAM_MERC or LocalPlayer():Team() == TEAM_MOB end),

		SubMenu("make_someone_wanted", "siren", function(self)
			DarkRP.WantMenu()
		end, isCP),
		SubMenu("remove_wanted_status", "siren", function(self)
			DarkRP.UnWantMenu()
		end, isCP),
		SubMenu("get_a_warrant", "search", function(self)
			DarkRP.WarrantMenu()
		end, function(me) return me:isCP() and not me:isMayor() end),
		


		Option("initiate_lockdown", "smart-home-error", Request(DarkRP.getPhrase("initiate_lockdown"), "enter_reason", "say", "/lkd "), function() return isMayor() and not GetGlobalBool("LockDown1") == true end),
		Option("stop_lockdown", "smart-home-error", {"say", "/unlkd "}, function() return isMayor() and GetGlobalBool("LockDown1") == true end),
		Option("start_lottery", "win", Request(DarkRP.getPhrase("start_lottery"), "enter_entry_cost", "darkrp", "lottery"), function() return GAMEMODE.Config.lottery and isMayor() end),
		Option("cc_cityman", "law", function() RunConsoleCommand("citycontrolmenu") end, isMayor),
		Option("cc_copman", "police", function() RunConsoleCommand("citycontrolmenu") end, isChief),
	
		Option("create_group", "black-ski-mask", function() RunConsoleCommand("gang_create") end, function() return LocalPlayer():Team() == TEAM_GANG and LocalPlayer():GetNWString("gang_name") == "None" end),
		Option("manage_group", "black-ski-mask", function() RunConsoleCommand("gang_menu") end, function() return LocalPlayer():Team() == TEAM_MOB end),
		Option("leave_group", "black-ski-mask", function() DarkRP.DermaQuery(DarkRP.getPhrase("leave_group") .. "?", DarkRP.getPhrase("leave_group") .. "?", "OK", function() net.Start("NXGroupLeave") net.SendToServer() end, DarkRP.getPhrase("cancel")) end, function() return LocalPlayer():GetNWString("gang_name") ~= "None" and LocalPlayer():Team() ~= TEAM_MOB end)
	}

	local PANEL = {}

	function PANEL:Init()
		local scroll = self:Add("DScrollPanel")
		fixscrollbar(scroll)
		self.scroll = scroll
		scroll:Dock(FILL)

		local lbl = scroll:Add("DLabel")
		lbl:Dock(TOP)
		lbl:SetFont("DermaNotLarge")
		lbl:SetText(DarkRP.getPhrase("actions"))
		lbl:SizeToContents()
		lbl:DockMargin(0, 0, 0, MediumMargin)

		for _, v in pairs(Menu) do
			if v.cmd or v.func then
				local ok, ret = pcall(DarkRP.getPhrase, v.title)
				// print("v.title:", v.title)
				// print("ok:", ok, "ret:", ret)
				local but = scroll:Add("NxButton")

				but.__TEST = v.test
				if v.cmd then
					but:SetText(ok and ret or v.title or "kaka")
				else
					but:SetText((ok and ret or v.title) .. " >")
				end

				if v.icon then
					but:SetImage("nxrp/icons8_64t/icons8-" .. v.icon .. "-64.png")
					if but.m_Image:GetMaterial():IsError() then
						but:SetImage("icon16/asterisk_yellow.png")
					end
					but.m_Image:Dock(LEFT)
					but.m_Image:DockMargin(SmallMargin, SmallMargin, SmallMargin, SmallMargin)
					but.m_Image:SetSize(yscale(32) - SmallMargin * 2, yscale(32) - SmallMargin * 2)
					but:SetContentAlignment(4)
					but:SetTextInset(but.m_Image:GetWide() + SmallMargin * 2, 0)
				end
				if v.title == DarkRP.getPhrase"drop_money" then
					but:SetPrimaryMainColors()
				end

				--but:SetFont("DermaNotLarge")
				but.PerformLayout = DLabel.PerformLayout
				but:SizeToContents()
				but:SetSize(but:GetWide() + yscale(10), yscale(32))
				but:Dock(TOP)

				if v.cmd then
					but.DoClick = isfunction(v.cmd) and v.cmd or function()
						if v.cmd[1] == "DarkRP" then
							RunConsoleCommand(select(2, unpack(v.cmd)))
						else
							RunConsoleCommand(unpack(v.cmd))
						end
					end
				else
					but.DoClick = function()
						local menu = FixedDermaMenu()
						v.func(menu)
						menu:Open()
					end
				end

				but:DockMargin(0, 0, 0, 5)
			else
				local line = scroll:Add("DPanel")
				line.__TEST = v.test
				line:SetTall(2)
				line:Dock(TOP)
				line:DockMargin(0, 10, 0, 15)
			end
		end

		self:Refresh()
	end

	function PANEL:Think()
		if SysTime() - (self.lastThink or -math.huge) > 1 then
			self:Refresh()

			self.lastThink = SysTime()
		end
	end

	function PANEL:Refresh()
		local scroll = self.scroll

		local changedAnything

		for k, v in pairs(scroll:GetCanvas():GetChildren()) do
			local shouldvis = not v.__TEST or v.__TEST(LocalPlayer())
			--print(v, shouldvis)
			if v:IsVisible() ~= shouldvis then
				v:SetVisible(shouldvis)
				changedAnything = true
			end
		end

		if changedAnything then
			scroll:Rebuild()
		end
	end

	--[[
	function PANEL:Paint(w, h)
		vgui.blurCopypaste(self, w, h)

		surface.SetDrawColor( 40, 40, 40, 200 )
		surface.DrawRect(0, 0, w, h)
	end
	]]

	derma.DefineControl("NxC_Legacy", "", PANEL, "EditablePanel")
end

do -- NxMainMenu
	local PANEL = {}

	function PANEL:Init()
		esc.RegisterPanel(self, function()
			if self:IsVisible() then
				self:SetVisible(false)
				return true
			end

			return false
		end)

		--self:SetAlpha(0)
		self:DockPadding(LargeMargin*2, LargeMargin, LargeMargin*2, LargeMargin)
		self:SetKeyBoardInputEnabled(false)
		self:SetSize(ScrW(), ScrH())
		self:Center()



		self.sheet = self:Add("DPropertySheet")
		self.sheet:Dock(FILL)
		self.sheet.Paint = function(s,w,h) --[[surface.SetDrawColor(Color(255, 0, 0)) surface.DrawOutlinedRect(0, 0, w, h)]] end
		self.sheet:SetPadding(0)
		self.sheet.tabScroller:SetVisible(false)
		self.sheet.tabScroller:DockMargin(0, 0, 0, 0)
		self.sheet.tabScroller:SetTall(0)
		self.sheet:DockPadding(0, 0, 0, 0)
		self.sheet:DockMargin(0, 0, 0, 0)
		self.sheet.GetPadding = function() return 0 end

		local tabScroller = self:Add("NxTabScroller")

		local tblTabs = table.Copy(nxshop.CategoriesOrdered)

		local MainScreen = self.sheet:Add("EditablePanel")
		MainScreen:Dock(FILL)
		local retM = self.sheet:AddSheet("MainScreen", MainScreen)

		local JobsScreen = self.sheet:Add("F4MenuJobs")
		self.JobsScreen = JobsScreen
		JobsScreen:Dock(FILL)
		local retJ = self.sheet:AddSheet("JobsScreen", JobsScreen)

		table.insert(tblTabs, 1, {title = DarkRP.getPhrase("jobs"), tab = retJ.Tab, inside = true})
		table.insert(tblTabs, 1, {title = DarkRP.getPhrase("menu"), tab = retM.Tab, inside = true})



		local widgets = MainScreen:Add("NxC_Widgets")
		widgets:Dock(FILL)
		widgets:DockMargin(MediumMargin, 0, MediumMargin, 0)

		local legacy = MainScreen:Add("NxC_Legacy")
		legacy:Dock(RIGHT)
		legacy:SetWide(self:GetWide() * 0.2)

		self.BackButton:GetParent():SetParent(legacy)

		local character = MainScreen:Add("NxC_Character")
		character:Dock(LEFT)
		character:SetWide(self:GetWide() * 0.25)



		for id, data in pairs(tblTabs) do
			if data.class == "drp_menu" or data.class == "drp_jobs" then
				continue
			end

			if data.outside then
				continue
			end

			local b = tabScroller:AddTab(data.title, self.sheet, data.tab)

			b.DoClick = function()
				surface.PlaySound("gxrp/tap-resonant.wav")
				--self.listMenu:SetActiveTab(data.tab)
				if data.inside then
					self.sheet:SetActiveTab(data.tab)
					self.JobsScreen:Refresh()
				else
					self:SetVisible(false)
					nxshop.nosound = true
					nxshop.showShop()
					nxshop.nosound = nil
					nxshop.spawnedShop:SetAlpha(255)
					nxshop.spawnedShop.alpha = 1
					nxshop.spawnedShop.listMenu:SetActiveTab(nxshop.Categories[data.class].tab)
				end
			end

			if next(tblTabs, id) then
			if data.class == "drp_menu" or data.class == "drp_jobs" then
				continue
			end
				tabScroller:AddSeparator()
			end
		end
	end

	function PANEL:PaintOver()
		--self:SetAlpha(math.min(255, self:GetAlpha() + 20))
		--hook.GetTable().HUDPaint.Notices()
	end

	function PANEL:Paint(w, h)
		surface.SetDrawColor( 50, 50, 50, 200 )
		surface.DrawRect(0, 0, w, h)
	end

	derma.DefineControl("NxMainMenu", "", PANEL, "NxGenericFrame")
end

if IsValid(_G.cmenuspawnedframe) then
	_G.cmenuspawnedframe:Remove()
	_G.cmenuspawnedframe = nil
end

local SHOULDWRITEDOWN
local spawnedFrame


local function TOGGLE()
	if SHOULDWRITEDOWN then
		hook.Remove("HUDPaint", "contextmenu_hint")
		cookie.Set("NXCMenu_seen_hud2", os.time())
		SHOULDWRITEDOWN = nil
	end

	if not IsValid(_G.cmenuspawnedframe) then
		_G.cmenuspawnedframe = vgui.Create("NxMainMenu")
		spawnedFrame = _G.cmenuspawnedframe
	else
		spawnedFrame:ToggleVisible()
		--[[
		if spawnedFrame:IsVisible() then
			spawnedFrame:InvalidateLayout(true)
		end
		]]
		--spawnedFrame:MoveTo(-250, 0, 0.1, 0, -1)
	end

	--[[
	if IsValid(_G.fmenuspawnedframe) and _G.fmenuspawnedframe.isOpen then
		_G.fmenuspawnedframe:Close()
	end
	]]

	if g_ContextMenu:IsVisible() then
		hook.Call( "OnContextMenuClose", GAMEMODE )
	end

	--[[
	if spawnedFrame.isOpen then
		spawnedFrame:Close()
	else
		spawnedFrame:Open()
	end
	]]
end

hook.Add("PlayerBindPress", "FContextMenu", function(pl, bind, pressed)
	if IsValid(LocalPlayer().Instrument) then
		return
	end

	if bind == "impulse 100" and pressed then
		TOGGLE()

		return true
	end
end)

hook.Add("NxShopOutsideTab", "CMenuFMenu", function(class)
	if IsValid(nxshop.spawnedShop) then
		surface.PlaySound("gxrp/tap-resonant.wav")
		nxshop.spawnedShop:Remove()
		TOGGLE()
		spawnedFrame:SetVisible(true)
		spawnedFrame.sheet:SwitchToName(class == "drp_menu" and "MainScreen" or "JobsScreen")
		spawnedFrame.JobsScreen:Refresh()
	end
end)

local t = cookie.GetNumber("NXCMenu_seen_hud2", -1)
if t and t < 0 then
	SHOULDWRITEDOWN = true
	hook.Add("HUDPaint", "contextmenu_hint", function()
		if hook.Run("HUDShouldDraw", "contextmenu_hint") ~= false then
			surface.DrawKeyCap(ScrW() * 0.5, ScrH() - 300 + math.sin(RealTime() * 4) * 8, input.LookupBinding("impulse 100"), .5, .5, DarkRP.getPhrase("cmenu_hint"))
		end
	end)
end