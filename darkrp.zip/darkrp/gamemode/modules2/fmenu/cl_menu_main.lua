local function find(ent)
	local group = ent:GetDoorGroup()
	if group then
		local count = 0
		for k, v in ipairs(ents.GetAll()) do
			if v:isKeysOwnable() and not v:IsVehicle() and v:GetDoorGroup() == group then
				count = count + 1
			end
		end
		return " (" .. count .. ")"
	end
end

local function deployable_pack(ent)
	net.Start("deployable_pack")
	net.WriteEntity(ent)
	net.SendToServer()
end


cmenufn = {}

local function Option(title, icon, cmd, test)
	local ok, ret = pcall(DarkRP.getPhrase, title)
	return {title = ok and ret or title, icon = icon, cmd = cmd, test = test}
end
cmenufn.Option = Option

local function SubMenu(title, icon, func, test)
	return {title = title, icon = icon, func = func, test = test}
end
cmenufn.SubMenu = SubMenu

local function Spacer(test)
	return {test = test}
end
cmenufn.Spacer = Spacer

local function ProcessAction(t, s, arg)
	if type(t[1]) == "function" then
		t[1](s, arg)
	elseif t[1] == "DarkRP" then
		local t = table.Copy(t)
		table.remove(t, 1)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	elseif t[1] == "DarkRP" then
		local t = table.Copy(t)
		table.remove(t, 1)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	else
		local t = table.Copy(t)
		table.insert(t, s)
		RunConsoleCommand(unpack(t))
	end
end

local function RequestC(config, ...)
	local t = {...}
	return function(arg)
		local frame
		if not config.number then
			frame = DarkRP.StringRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, function(s)
				ProcessAction(t, s, arg)
			end)
		else
			frame = DarkRP.NumberRequest(DarkRP.getPhrase(config.title) or config.title, DarkRP.getPhrase(config.text) or config.text, isfunction(config.def) and config.def() or config.def, function(s)
				ProcessAction(t, s, arg)
			end, nil, nil, nil, isfunction(config.min) and config.min() or config.min, isfunction(config.max) and config.max() or config.max)
		end

		if config.warning then
			frame:SetWarning(DarkRP.getPhrase(config.warning) or config.warning)
		end
        

		if config.price then
			frame:SetPrice(config.symbol, config.price)
		end
	end
end
cmenufn.RequestC = RequestC

local function Request(title, text, ...)
	return RequestC({title = title, text = text}, ...)
end
cmenufn.Request = Request

local function RequestN(title, text, def, min, max, ...)
	return RequestC({title = title, text = text, number = true, def = def, min = min, max = max}, ...)
end

cmenufn.RequestN = RequestN


cmenufn.players = players

hook.Run("cmenufn")

function DarkRP.WarrantRequest(tar)
	local request = DarkRP.StringRequest(DarkRP.getPhrase(LocalPlayer():isMayor() and "give_warrant" or "get_a_warrant"), DarkRP.getPhrase("enter_reason_suspect", tar:Name()), function(str)
		RunConsoleCommand("darkrp", "warrant", tar, str)
	end)
end

net.Receive("WarrantCMenu", function(len,ply)
    local target = net.ReadEntity()
    
    self:AddTitle("Demander un mandat")
    self:SetSize(yscale(320), yscale(600))
    self:Center()
    local scroll = vgui.Create("DScrollPanel", self)
    scroll:Dock(FILL)
    fixscrollbar(scroll)

    local smallfr = vgui.Create("NxGenericFrame")
    smallfr:AddTitle("Indiquer la raison")
    smallfr:SetSize(yscale(400), yscale(250))
    smallfr:Center()
    smallfr:MakePopup()

    local input = vgui.Create("DTextEntry", smallfr)
    input:SetMultiline(true)
    input:Dock(FILL)
    input:SetValue("")
    input:RequestFocus()
    --input:SetCaretPos(input:GetValue():utf8len())
    input:SetFont("DermaNotDefault")
    input.Paint = nxui_DTextEntry_Paint

    
    local send = vgui.Create("NxButton", smallfr)
    send:SetText("Demander un mandat")
    send:SetTall(32)
    send:DockMargin(5, 5, 5, 0)
    send:SetPrimaryMainColors()
    send:Dock(BOTTOM)

    send.DoClick = function()

        RunConsoleCommand("darkrp", "warrant", target, input:GetValue() )
        
        smallfr:Remove()
        self:Remove()
    end


end)

net.Receive("WantedCMenu", function(len,ply)
    local target = net.ReadEntity()
    
    self:AddTitle("Émettre un avis de recherche")
    self:SetSize(yscale(320), yscale(600))
    self:Center()
    local scroll = vgui.Create("DScrollPanel", self)
    scroll:Dock(FILL)
    fixscrollbar(scroll)

    local smallfr = vgui.Create("NxGenericFrame")
    smallfr:AddTitle("Indiquer la raison")
    smallfr:SetSize(yscale(400), yscale(250))
    smallfr:Center()
    smallfr:MakePopup()

    local input = vgui.Create("DTextEntry", smallfr)
    input:SetMultiline(true)
    input:Dock(FILL)
    input:SetValue("")
    input:RequestFocus()
    --input:SetCaretPos(input:GetValue():utf8len())
    input:SetFont("DermaNotDefault")
    input.Paint = nxui_DTextEntry_Paint

    
    local send = vgui.Create("NxButton", smallfr)
    send:SetText("Émettre un avis de recherche")
    send:SetTall(32)
    send:DockMargin(5, 5, 5, 0)
    send:SetPrimaryMainColors()
    send:Dock(BOTTOM)

    send.DoClick = function()

        RunConsoleCommand("darkrp", "wanted", target, input:GetValue() )
        
        smallfr:Remove()
        self:Remove()
    end


end)

local menttest = function(me, ent) return me:isCP() and ent:getDoorOwner() and ent:getDoorOwner():IsValid() end

local ContextMenu = {}
hook.Add("cmenufn", "context", function()
	local RequestC = cmenufn.RequestC
	local Request = cmenufn.Request
	local RequestN = cmenufn.RequestN
	local Spacer = cmenufn.Spacer
	local Option = cmenufn.Option
	local SubMenu = cmenufn.SubMenu

ContextMenu = {
	player = {
		title = function(ent) return ent:getJobTable().name .. " " .. ent:Name() end,
		test = function(me, ent) return ent:Alive() end,
		{
			title = DarkRP.getPhrase("give_money"),
			icon = "money",
			cmd = RequestN("give_money", "enter_summ", 2, 2, function() return LocalPlayer():getDarkRPVar("money") end, function(n, ent) RunConsoleCommand("darkrp", "give", n, ent) end)
		},
		Spacer(isCP),
		{
			title = DarkRP.getPhrase("make_someone_wanted"),
			icon = "exclamation",
			cmd = function()
				DarkRP.WantMenu()
			end,
			test = function(me, ent) return me:isCP() and not ent:isWanted() and not ent:isArrested() end
		},
		{
			title = DarkRP.getPhrase("remove_wanted_status"),
			icon = "flag_green",
			cmd = function(ent) DarkRP.UnWantMenu() end,
			test = function(me, ent) return me:isCP() and ent:isWanted() end
		},
		{
			title = DarkRP.getPhrase("get_a_warrant"),
			icon = "door_in",
			cmd = function()
				DarkRP.WarrantMenu()
			end,
			test = function(me, ent) return me:isCP() and not me:isMayor() and not ent:isArrested() end
		},
		{
			title = DarkRP.getPhrase("give_warrant"),
			icon = "door_in",
			cmd = function()
				DarkRP.WarrantMenu()
			end,
			test = function(me, ent) return me:isMayor() and not ent:isArrested() end
		},
		{
			title = function(ent) return DarkRP.getPhrase("jail") .. " " .. ent:Name() end,
			icon = "door_in",
			cmd = function(ent)
				DarkRP.StringRequestHandcuff("La raison de l'arrestation", "L'appréhendé " .. ent:GetName(), default, function(percentage)
                    net.Start('ArrestPlayer')
                    net.WriteEntity( ent )
                    net.WriteString( percentage )
                    net.SendToServer()
                    surface.PlaySound("nxserv/tap-resonant.wav")
            end, nil, nil, nil, 0, 100)
			end,
			test = function(me, ent) return me:isCP() and ent:IsHandcuffed() and not me:isMayor() and not ent:isArrested() end
		},
		{
			title = DarkRP.getPhrase("give_license_lookingat"),
			icon = "page_edit",
			cmd = function(ent) RunConsoleCommand("darkrp", "givelicense", tostring(ent:UserID())) end,
			test = function(me, ent)
				local noMayorExists = fn.Compose{fn.Null, fn.Curry(fn.Filter, 2)(me.isMayor), player.GetAll}
				local noChiefExists = fn.Compose{fn.Null, fn.Curry(fn.Filter, 2)(me.isChief), player.GetAll}
				local canGiveLicense = fn.FOr{
					me.isMayor,
					fn.FAnd{me.isChief, noMayorExists},
					fn.FAnd{me.isCP, noChiefExists, noMayorExists}
				}
				return canGiveLicense(me) and not ent:getDarkRPVar("HasGunlicense") and not ent:isArrested()
			end
		},
		{
			title = DarkRP.getPhrase("unarrest_player"),
			icon = "flag_green",
			cmd = function(ent)
				if not IsValid(ent) then
					print("Erreur : 'ent' est invalide ou nil.")
					return
				end
				print(ent)
				RunConsoleCommand("darkrp", "unarrest", ent:SteamID())
			end,
			test = function(me, ent)
				return me:isCP() and IsValid(ent) and ent:isArrested()
			end
		},
		
	},
	prop_door_rotating = {
		title = function(ent)
			local entType = DarkRP.getPhrase(ent:IsVehicle() and "car" or "door_single")
			return entType .. " " .. (IsValid(ent:getDoorOwner()) and ent:getDoorOwner():Name() or "")
		end,
		--test = function(me, ent) return not ent:getKeysNonOwnable() end,
		{
			title = "Knock-knock",
			cmd = function()
				net.Start("BlueKnock")
                net.WriteEntity(LocalPlayer())
                net.SendToServer()
			end,
			cmd2 = function()
				net.Start("BlueKnock")
                net.WriteEntity(LocalPlayer())
                net.SendToServer()
			end,
			test = function(me, ent) return not ent:IsVehicle() end,
		},
		{
			title = DarkRP.getPhrase("get_a_warrant"),
			icon = "door_in",
			cmd = function()
				DarkRP.WarrantMenu()
			end,
			test = function(me, ent) return menttest(me, ent) and me:isCP() and not me:isMayor() and not ent:getDoorOwner():isArrested() end
		},
		{
			title = DarkRP.getPhrase("give_warrant"),
			icon = "door_in",
			cmd = function()
				DarkRP.WarrantMenu()
			end,
			test = function(me, ent) return menttest(me, ent) and me:isMayor() and not ent:getDoorOwner():isArrested() end
		},


		{
			title = function(ent)
				local entType = DarkRP.getPhrase(ent:IsVehicle() and "vehicle" or "doorcmenu")
				return ent:GetDoorGroup() and (DarkRP.getPhrase("sell_x", entType) .. find(ent)) or DarkRP.getPhrase("sell_x", entType)
			end,
			icon = "door_in",
			cmd = function() RunConsoleCommand("darkrp", "toggleown") end,
			test = function(me, ent) return ent:isKeysOwnedBy(me) and not ent:IsCar() end,
		},
		{
			title = function(ent)
				return ent:GetDoorGroup() and (DarkRP.getPhrase("add_owner") .. find(ent)) or DarkRP.getPhrase("add_owner")
			end,
			func = function(menu, ent)
				for k,v in pairs(DarkRP.nickSortedPlayers()) do
					if not ent:isKeysOwnedBy(v) and not ent:isKeysAllowedToOwn(v) then
						local steamID = v:SteamID()
						menu.found = true
						menu:AddOption(v:Nick(), function() RunConsoleCommand("darkrp", "ao", steamID) end)
					end
				end
				if not menu.found then
					menu:AddOption(DarkRP.getPhrase("noone_available"), function() end)
				end
			end,
			test = function(me, ent) return ent:isKeysOwnedBy(me) end,
		},
		{
			title = function(ent)
				return ent:GetDoorGroup() and (DarkRP.getPhrase("remove_owner") .. find(ent)) or DarkRP.getPhrase("remove_owner")
			end,
			func = function(menu, ent)
				for k,v in pairs(DarkRP.nickSortedPlayers()) do
					if (ent:isKeysOwnedBy(v) and not ent:isMasterOwner(v)) or ent:isKeysAllowedToOwn(v) then
						local steamID = v:SteamID()
						menu.found = true
						menu:AddOption(v:Nick(), function() RunConsoleCommand("darkrp", "ro", steamID) end)
					end
				end
				if not menu.found then
					menu:AddOption(DarkRP.getPhrase("noone_available"), function() end)
				end
			end,
			test = function(me, ent) return ent:isKeysOwnedBy(me) end,
		},
		{
			title = function(ent)
				local entType = DarkRP.getPhrase(ent:IsVehicle() and "vehicle" or "doorcmenu")
				return DarkRP.getPhrase("set_x_title", entType)
			end,
			func = function(menu, ent)
				local entType = DarkRP.getPhrase(ent:IsVehicle() and "vehicle" or "doorcmenu")
				DarkRP.StringRequest(DarkRP.getPhrase("set_x_title", entType), DarkRP.getPhrase("set_x_title_long", entType), function(s)
					RunConsoleCommand("darkrp", "title", s)
				end)
			end,
			test = function(me, ent) return ent:isKeysOwnedBy(me) end,
		},
		{
			title = function(ent)
				local entType = DarkRP.getPhrase(ent:IsVehicle() and "vehicle" or "doorcmenu")
				return ent:GetDoorGroup() and (DarkRP.getPhrase("buy_x", entType) .. find(ent)) or DarkRP.getPhrase("buy_x", entType)
			end,
			cmd = function() RunConsoleCommand("darkrp", "toggleown") end,
			test = function(me, ent) return not ent:isKeysOwnedBy(me) and not ent:isKeysOwned() and not ent:getKeysNonOwnable() and not ent:getKeysDoorGroup() and not ent:getKeysDoorTeams() end,
		},
		{
			title = function(ent)
				local entType = DarkRP.getPhrase(ent:IsVehicle() and "vehicle" or "doorcmenu")
				return ent:GetDoorGroup() and (DarkRP.getPhrase("coown_x", entType) .. find(ent)) or DarkRP.getPhrase("coown_x", entType)
			end,
			cmd = function(ent) RunConsoleCommand("darkrp", "toggleown") end,
			test = function(me, ent) return not ent:isKeysOwnedBy(me) and ent:isKeysAllowedToOwn(me) end,
		},
		{
			title = DarkRP.getPhrase("lock"),
			cmd = function(ent) RunConsoleCommand("darkrp", "forcelock") end,
			test = function(me, ent) return me:canKeysLock(ent) and not ent:GetNWBool("islocked") end,
		},
		{
			title = DarkRP.getPhrase("unlock"),
			cmd = function(ent) RunConsoleCommand("darkrp", "forceunlock") end,
			test = function(me, ent) return me:canKeysLock(ent) end,
		},
		{
			title = "Ouvrir le coffre",  -- Titre du bouton
			cmd = function(ent)
				-- Envoie une demande au serveur pour ouvrir le coffre du véhicule
				net.Start("Seefox:CarTrunk:RequestOpen")
				net.WriteEntity(ent)  -- Envoie l'entité du véhicule au serveur
				net.SendToServer()    -- Envoie le message au serveur
			end,
			test = function(me, ent)
				-- Vérifie si le joueur peut interagir avec le véhicule
				return me:Alive() and ent:IsVehicle() and ent:getDoorOwner() == me
			end,
		},		
		
	},
    gx_turret = {
        title = function(ent) return "Tourelle" end,
        test = function(me, ent) return ent:GetClass() == "gx_turret" end,
        {
            title = "Emballer la tourelle",
            icon = "icon16/box.png",
            cmd = function(ent)
                net.Start("gx_turret_pack")
                net.WriteEntity(ent)
                net.SendToServer()
            end,
            test = function(me, ent) return ent.Loaded end,
        },
        {
            title = "Réparer la tourelle",
            icon = "icon16/box.png",
            cmd = function(ent)
                net.Start("gx_turret_repair")
                net.WriteEntity(ent)
                net.SendToServer()
            end,
            test = function(me, ent) return ent.Loaded end,
        },
    },
}

ContextMenu.func_door = ContextMenu.prop_door_rotating
ContextMenu.func_door_rotating = ContextMenu.prop_door_rotating
ContextMenu.func_platrot = ContextMenu.prop_door_rotating
ContextMenu.prop_door_rotating = ContextMenu.prop_door_rotating
ContextMenu.helicopter = ContextMenu.prop_door_rotating
ContextMenu.prop_vehicle_jeep = ContextMenu.prop_door_rotating
end)

if cmenufn then
	hook.GetTable().cmenufn.context()
end

local green_is_my_pepper = Color(0, 255, 0)

local highlightEnts = {}
local chosenEnt = NULL
local cntF = 0
hook.Add("PreDrawHalos", "FContextMenu", function()
	if chosenEnt:IsValid() then
		halo.Add({chosenEnt}, green_is_my_pepper, 4, 4, 10, true, true, true)
	end

	if next(highlightEnts) then
		halo.Add(highlightEnts, color_white, 2, 2, 1, true, true, true)
	end
end)

local interactionCache = {}
local cntF = 0

local function refillCache()
	table.Empty(interactionCache)
	cntF = 0

	for _, ent in ipairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 130)) do
		if ent ~= LocalPlayer() and not ent:GetNoDraw() then
			local tbl = ContextMenu[ent:GetClass()]
			if tbl and (not tbl.test or tbl.test(LocalPlayer(), ent)) then
				local pos = ent:LocalToWorld(ent:OBBCenter()):ToScreen()
				if pos.visible and pos.x > 0 and pos.y > 0 and pos.x < ScrW() and pos.y < ScrH() then
					cntF = cntF + 1

					table.insert(interactionCache, ent)
				end
			end
		end
	end
end

local lastRefill = -math.huge
hook.Add("Think", "FContextMenu", function()
	if (SysTime() - lastRefill) >= 0.1 then
		refillCache()
		lastRefill = SysTime()
	end
end)

local cbind = input.LookupBinding("menu_context")

hook.Add("HUDPaint", "FContextMenu", function()
	if LocalPlayer():IsValid() then return end
	if LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
	for _, ent in next, interactionCache do
		if not ent:IsValid() or (LocalPlayer():InVehicle() and ent:IsVehicle()) then
			continue
		end

		local pos = ent:LocalToWorld(ent:OBBCenter()):ToScreen()
		if pos.visible and pos.x > 0 and pos.y > 0 and pos.x < ScrW() and pos.y < ScrH() then
			surface.DrawKeyCap(pos.x, pos.y, cbind, 0.5, 0.5)
		end
	end

	if cntF > 0 then
		--surface.DrawKeyCap(ScrW() / 2 + 1, ScrH() - 256 + 1, "f", 0.5, 0, cntF .. " взаимодействий", color_black)
		--surface.DrawKeyCap(ScrW() / 2 - 1, ScrH() - 256 - 1, "f", 0.5, 0, cntF .. " взаимодействий", color_black)
		surface.DrawKeyCap(ScrW() / 2, ScrH() - 256, cbind, 0.5, 0, DarkRP.getPhrase("x_interactions", cntF))
	end
end)

do -- FContextMenu
	local PANEL = {}

	function PANEL:Init()
		if IsValid(_G.SpawnedFContextMenu) then
			_G.SpawnedFContextMenu:Remove()
			_G.SpawnedFContextMenu = nil
		end
		_G.SpawnedFContextMenu = self

		self:SetKeyBoardInputEnabled(false)
		self:SetTall(ScrH())
		self:SetWide(0)
		self:Center()
	end

	function PANEL:Set(ent, tbl)
		self.ent = ent

		local lbl = self:Add("DLabel")
		lbl:SetFont("DermaNotLarge")
		lbl:SetText(tbl.title(ent))
		lbl:SizeToContents()
		lbl:Dock(TOP)
		lbl:DockMargin(0, 0, 0, LargeMargin)

		for k, v in pairs(tbl) do
			if k ~= "title" and k ~= "test" then
				local testedVis = not v.test or v.test(LocalPlayer(), ent)
				if v.cmd then
					if v.state then
						--local option = menuc:AddOption(type(v.title) == "function" and v.title(ent) or v.title, function(self) v.cmd(ent, self:GetChecked()) end)
						--option:SetIsCheckable(true)
						--option:SetChecked(v.state(ent))

						local but = self:Add("DCheckBoxLabel")
						but.__VIS = testedVis
						but.__TEST = v.test
						but:SetVisible(testedVis)
						but:Dock(TOP)
						but:SetTall(yscale(32))
						but:SetText(type(v.title) == "function" and v.title(ent) or v.title)
						but:DockMargin(0, 0, 0, SmallMargin)
						but:SetChecked(v.state(ent))
						but.OnChange = function()
							v.cmd(ent, but:GetChecked())
						end
						but:SetFont("DermaNotDefault")
					else
						--menuc:AddOption(type(v.title) == "function" and v.title(ent) or v.title, function() v.cmd(ent) end):SetImage("icon16/" .. v.icon .. ".png")
						local but = self:Add("NxButton")
						but.__VIS = testedVis
						but.__TEST = v.test
						but:SetVisible(testedVis)
						but:Dock(TOP)
						but:SetTall(yscale(32))
						but:SetText(type(v.title) == "function" and v.title(ent) or v.title or "Joueur")
						but.DoClick = function() v.cmd(ent) end
						if v.cmd2 then
							but.DoRightClick = function() v.cmd2(ent) end
						end
						but:DockMargin(0, 0, 0, SmallMargin)
					end
				elseif v.func then
					local ok, ret
					if type(v.title) == "function" then
						ok, ret = true, v.title(ent)
					else
						ok, ret = pcall(DarkRP.getPhrase, v.title)
					end
					--[[
					local new, sub = menuc:AddSubMenu(ok and ret or v.title)
					sub:SetImage("icon16/" .. v.icon .. ".png")
					v.func(new)
					]]

					local but = self:Add("NxButton")
					but.__VIS = testedVis
					but.__TEST = v.test
					but:SetVisible(testedVis)
					but:Dock(TOP)
					but:SetTall(yscale(32))
					but:SetText(ok and ret or v.title)
					but:DockMargin(0, 0, 0, SmallMargin)

					but.DoClick = function()
						local menu = FixedDermaMenu()
						v.func(menu, ent)
						menu:Open()
					end
				else
					--menuc:AddSpacer()
				end
			end
		end

		self:AutoSize()
	end

	function PANEL:Think()
		self:Refresh()
	end

	function PANEL:Refresh()
		if not self.ent:IsValid() then
			self:Remove()
			return
		end

		local changedAnything
		--local couldUse = LocalPlayer():canTouch(self.ent)

		for k, v in pairs(self:GetChildren()) do
			if k > 2 then
				local testedVis = not v.__TEST or v.__TEST(LocalPlayer(), self.ent)
				--testedVis = tobool(testedVis)

				if v.__VIS ~= testedVis then
					v.__VIS = testedVis
					v:SetVisible(testedVis)

					changedAnything = true
				end

				--v:SetDisabled()
			end
		end

		if changedAnything then
			self:AutoSize()
		end
	end

	function PANEL:AutoSize()
		local left, top, right, bottom = self:GetDockPadding()
		local tall = top + bottom
		local wide = 0

		self:InvalidateLayout(true)
		self:InvalidateChildren(true)

		for k, v in pairs(self:GetChildren()) do
			if not v:IsVisible() then
				continue
			end
			v:InvalidateLayout(true)
			v:SizeToContents()
			if k ~= 1 then
				v:SetSize(v:GetWide() + yscale(32), yscale(32))
			end
			wide = math.max(v:GetWide() + LargeMargin*2, wide)
			local left, top, right, bottom = v:GetDockMargin()
			tall = tall + v:GetTall() + top + bottom
		end

		self:SetTall(tall)
		self:SetWide(wide)
		self:Center()
	end

	derma.DefineControl("FContextMenu", "", PANEL, "NxGenericFrame")
end

do -- FSlidingPanel
	local PANEL = {}

	function PANEL:Init()
		esc.RegisterPanel(self, function()
			if self.isOpen then
				self:Close()
				hook.Run("OnContextMenuClose")
				return true
			end

			return false
		end)

		self:SetMouseInputEnabled(false)
		self:SetKeyBoardInputEnabled(false)

		self:SetSize(ScrW(), yscale(150))
		self:SetPos(0, ScrH())

		self.isOpen = false

		self:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)

		self.ents = {}
	end

	function PANEL:Open()
		self:MakePopup()
		self:SetMouseInputEnabled(true)
		self:SetKeyBoardInputEnabled(false)
		self:SetVisible(true)
		self.m_AnimList = nil
		self:MoveTo(0, ScrH() - self:GetTall(), 0.1, 0, -1)
		self.isOpen = true
		self:FillEntities()
		input.SetCursorPos(SmallMargin + yscale(300)/2, ScrH() - yscale(150)/2)
	end

	function PANEL:Close()
		chosenEnt = NULL
		table.Empty(highlightEnts)

		self:SetMouseInputEnabled(false)
		self:SetKeyBoardInputEnabled(false)
		self.m_AnimList = nil
		self:MoveTo(0, ScrH(), 0.1, 0, -1, function()
			self:SetVisible(false)
		end)
		self.isOpen = false
	end

	function PANEL:Paint(w, h)
		vgui.blurCopypaste(self, w, h)
		surface.SetDrawColor( 40, 40, 40, 200 )
		surface.DrawRect(0, 0, w, h)
	end

	function PANEL:OnClickEntity(ent)
		self:Close()
		input.SetCursorPos(ScrW() / 2, ScrH() / 2)
		chosenEnt = NULL
		table.Empty(highlightEnts)

		if ent:IsValid() and not ent:GetNoDraw() then
			local tbl = ContextMenu[ent:GetClass()]
			if tbl and (not tbl.test or tbl.test(LocalPlayer(), ent)) then
				local x = vgui.Create("FContextMenu")
				x:Set(ent, tbl)
			end
		end

		hook.Run("OnContextMenuClose")
	end

	function PANEL:Think()
		if self.isOpen and self.lastRefillReaded ~= lastRefill then
			local toRemove = {}

			for ent, but in next, self.ents do
				toRemove[ent] = but
			end

			for _, ent in next, interactionCache do
				toRemove[ent] = nil
				self:AddEntity(ent)
			end

			for ent, but in next, toRemove do
				if but:IsHovered() then
					but:SetDisabled(true)
				else
					but:Remove()
					self.ents[ent] = nil
				end
			end

			self.lastRefillReaded = lastRefill
		end

		if self.isOpen and not vgui.GetKeyboardFocus() then
			self:MakePopup()
			self:SetMouseInputEnabled(true)
			self:SetKeyBoardInputEnabled(false)
		end
	end

	function PANEL:AddEntity(ent)
		if self.ents[ent] then
			self.ents[ent]:SetDisabled(false)
			return
		end

		local tbl = ContextMenu[ent:GetClass()]

		local but = self:Add("NxButton")
		but:DockMargin(0, 0, SmallMargin, 0)
		but:Dock(LEFT)
		but:SetWide(yscale(300))
		but:SetText(tbl.title(ent))

		table.insert(highlightEnts, ent)

		but.DoClick = function()
			self:OnClickEntity(ent)
		end
		but.OnCursorEntered = function()
			chosenEnt = ent
		end
		but.OnCursorExited = function()
			chosenEnt = NULL
		end

		self.ents[ent] = but
	end

	function PANEL:FillEntities()
		table.Empty(highlightEnts)

		table.Empty(self.ents)
		self:Clear()


		local center = Vector(ScrW()/2, ScrH()/2)
		table.sort(interactionCache, function(a, b)
			local pos1 = a:LocalToWorld(a:OBBCenter()):ToScreen()
			pos1 = Vector(pos1.x, pos1.y)

			local pos2 = b:LocalToWorld(b:OBBCenter()):ToScreen()
			pos2 = Vector(pos2.x, pos2.y)

			return pos1:Distance(center) < pos2:Distance(center)
		end)

		for _, ent in next, interactionCache do
			self:AddEntity(ent)
		end
	end

	derma.DefineControl("FSlidingPanel", "", PANEL, "EditablePanel")
end

if IsValid(_G.fmenuspawnedframe) then
	_G.fmenuspawnedframe:Remove()
	_G.fmenuspawnedframe = nil
end

local spawnedFrame
hook.Add("OnContextMenuOpen", "FSlidingPanel", function()
	--if IsValid(_G.cmenuspawnedframe) and _G.cmenuspawnedframe:IsVisible() then
	--	return
	--end

	if not IsValid(_G.fmenuspawnedframe) then
		_G.fmenuspawnedframe = vgui.Create("FSlidingPanel")
		spawnedFrame = _G.fmenuspawnedframe
	end

	refillCache()

	--[[
	if cntF == 0 and not spawnedFrame.isOpen then
		surface.PlaySound("player/suit_denydevice.wav")
		return
	end
	]]

	if not spawnedFrame.isOpen then
		--[[
		local orig = g_ContextMenu.Open
		g_ContextMenu.Open = function(self, ...)
			self.Open = orig
			orig(self, ...)

			spawnedFrame:Open()
		end
		]]

		spawnedFrame:Open()
	end

	return
end)



local function CloseIfOpen()
	if IsValid(spawnedFrame) and spawnedFrame.isOpen then
		spawnedFrame:Close()
	end
end

hook.Add("OnContextMenuClose", "FSlidingPanel", CloseIfOpen)
hook.Add("OnSpawnMenuClose", "FSlidingPanel", function()
	if g_SpawnMenu:IsVisible() then
		CloseIfOpen()
	end
end)