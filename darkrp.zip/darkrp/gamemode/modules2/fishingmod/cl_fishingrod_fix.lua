hook.Add("InitPostEntity", "NxFishingRodFix", function()
	if scripted_ents.GetStored("entity_fishing_rod") then
		local old = scripted_ents.GetStored("entity_fishing_rod").t.HUDPaint
		scripted_ents.GetStored("entity_fishing_rod").t.HUDPaint = function(self)
			if self:GetPlayer() and (self:GetPlayer() == LocalPlayer() or LocalPlayer():Team() == TEAM_FISH) then
				return old(self)
			end
		end
	end
end)