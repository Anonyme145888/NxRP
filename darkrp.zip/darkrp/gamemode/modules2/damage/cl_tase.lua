hook.Add("IsDisabled", "Taser", function(level, pl)
	if level <= 3 and pl:GetNWBool("IsTased") then
		return "disabled_tased"
	end
end)