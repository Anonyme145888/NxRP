--[[
gamemodes/darkrp/gamemode/modules/f4menu/cl_jobstab.lua
--]]
hook.Add("loadCustomDarkRPItems", "joblimits", function()
	joblimits = {}
	for k, v in next, RPExtraTeams do
		if v.max > 0 and v.max < 1 then
			joblimits[k] = math.min(1, v.max * GAMEMODE.Config.joblimitmul)
		end
	end

net.Receive("joblimits", function()
		for k, v in next, RPExtraTeams do
			v.max = net.ReadUInt(7)
		end
	end)
end)


do -- F4MenuJobs
	local PANEL = {}

	function PANEL:Init()
		local freeW = ScrW() - LargeMargin * 4
		local padding = math.max(0, (freeW - yscale(1500))/2)
		--print(padding)
		self:DockPadding(padding, 0, padding, 0)

		self.list = self:NewSheet("list", "F4MenuJobs_List")
		self.list.tabizator = self
		fixscrollbar(self.list)

		self.details = self:NewSheet("details", "F4MenuJobs_Details")
		self.details.tabizator = self
	end


	function PANEL:Think() -- fix it properly
		if self.lastcnt and self.lastcnt ~= os.time() then
			--print("refreshong")
			self:Refresh()
		end

		self.lastcnt = os.time()
	end

	function PANEL:Paint()
	end

	function PANEL:Refresh()
		self.list:Refresh()
		self.details:Refresh()
	end

	derma.DefineControl("F4MenuJobs", "", PANEL, "NxEditablePanelPaged")
end

surface.CreateFont("NxServF4Job2", {
	font = NX_ICONFONT,
	size = math.min(yscale(100), 100),
	antialias = true,
	shadow = true,
})

do -- F4MenuJobs_JobButton
	local PANEL = {}

	local function getMaxOfTeam(job)
		if not job.max or job.max == 0 then return "∞" end
		if job.max % 1 == 0 then return tostring(job.max) end

		return tostring(math.floor(job.max * #player.GetAll()))
	end

	function PANEL:Init()
		self:SetText("")
		self:SetSize(300, math.min(yscale(100), 100))

		self.color = Color(0x4c, 0xaf, 0x50)

		local icon = self:Add("DLabel")
		icon:SetTextColor(color_white)
		self.icon = icon
		icon:SetFont("NxServF4Job2")
		icon:SetText("J")
		icon:SetContentAlignment(4)
		icon:SetSize(math.min(yscale(100), 100), math.min(yscale(100), 100))
		icon:Dock(LEFT)

		local desc = self:Add("DLabel")
		desc:SetTextColor(color_white)
		self.desc = desc
		desc:SetFont("DermaNotDefault")
		desc:SetText("Some job\n0/0")
		desc:SetContentAlignment(4)
		desc:Dock(FILL)
	end

	function PANEL:setItem(item)
		self.item = item

		self.color = item.color

		local h, s, v = ColorToHSV(item.color)

		self.color_hover = HSVToColor(h, s * 0.8, math.min(1, v * 1.2))
		self.color_down = HSVToColor(h, s * 0.8, v * 0.8)

		self.icon:SetText(item.icon)
		self.desc:SetText(("%s\n%s/%s"):format(item.name, GetGlobalBool("reElection_" .. item.team) and 0 or team.NumPlayers(item.team), getMaxOfTeam(item)))
	end

	function PANEL:Refresh()
		local item = self.item
		self.desc:SetText(("%s\n%s/%s"):format(item.name, GetGlobalBool("reElection_" .. item.team) and 0 or team.NumPlayers(item.team), getMaxOfTeam(item)))
	end

	function PANEL:DoClick()
		self:OnClick()
	end

	--[[
	function PANEL:Paint(w, h)
		surface.SetDrawColor(self.color)
		surface.DrawRect(0, 0, w, h)

		if self:IsDown() or self.m_bSelected then
			surface.SetDrawColor(Color(0, 0, 0, 200))
			surface.DrawRect(0, 0, w, h)
		elseif self.Hovered then
			surface.SetDrawColor(Color(255, 255, 255, 20))
			surface.DrawRect(0, 0, w, h)
		end
	end
	]]

	derma.DefineControl("F4MenuJobs_JobButton", "", PANEL, "NxButton")
end

do -- F4MenuJobs_List
	local PANEL = {}

	function PANEL:Init()

		--print("AAHHH", self:GetSize())

		self.notice = self:Add("DLabel")
		self.notice:SetContentAlignment(5)
		self.notice:SetFont("DermaNotDefault")
		self.notice:Dock(TOP)
		self.notice:DockMargin(0, 0, 0, 5)

		local col = Color(250, 150, 0, 150)
		self.notice.Paint = function(s, w, h)
			surface.SetDrawColor(col)
			surface.DrawRect(0, 0, w, h)
		end

		self.notice:SetText(DarkRP.getPhrase("quota_notice"))
		self.notice:SizeToContents()
		self.notice:SetTall(self.notice:GetTall() + 16)
		self.notice:SetVisible(false)

		for k, cat in pairs(DarkRP.getCategories().jobs) do
			local lbl = self:Add("DLabel")
			lbl:SetTextColor(color_white)
			lbl:SetFont("DermaNotLarge")
			lbl:SetText(cat.name)
			lbl:SizeToContents()
			lbl:DockMargin(0, 0, 0, yscale(5))

			lbl:Dock(TOP)

			local iconLayout = self:Add("DIconLayout")
			iconLayout:Dock(TOP)
			iconLayout:DockMargin(0, 0, 0, yscale(5))
			iconLayout:SetSpaceX(yscale(5))
			iconLayout:SetSpaceY(yscale(5))

			for k, item in pairs(cat.members) do
				if item.disabled then continue end

				local button = iconLayout:Add("F4MenuJobs_JobButton")
				button:setItem(item)
				button.OnClick = function()
					self.tabizator.details:setItem(item)
					self.tabizator.sheet:SwitchToName("details")
				end
			end
		end
	end

	function PANEL:Refresh()
		for k, v in pairs(self:GetChildren()[1]:GetChildren()) do
			if v.ClassName == "DIconLayout" then
				for i, j in pairs(v:GetChildren()) do
					j:Refresh()
				end
			end
		end
	end

	function PANEL:PerformLayout()
--		print("Layouuuuttyttt")

		local w, h = self:GetCanvas():GetSize()
		local width = w/3 - 4

		--[[
		if width < 260 then
			width = w - yscale(5)
		end
		]]

		for k, v in pairs(self:GetChildren()[1]:GetChildren()) do
			if v.ClassName == "DIconLayout" then
				for i, j in pairs(v:GetChildren()) do
					j:SetWide(width)
				end
			end
		end

		self.BaseClass.PerformLayout(self, w, h)
	end

	derma.DefineControl("F4MenuJobs_List", "", PANEL, "DScrollPanel")
end

do -- F4MenuJobs_Details
	local PANEL = {}

	function PANEL:Init()
		self.color = Color(0x4c, 0xaf, 0x50)

		local ddd = self:Add("EditablePanel")
		ddd:Dock(TOP)
		ddd:SetTall(yscale(32))

		local backButton = ddd:Add("NxButton")
		backButton:Dock(LEFT)
		backButton:SetText(DarkRP.getPhrase("v_back"))
		backButton:SetSize(yscale(200), yscale(32))
		backButton.DoClick = function()
			self.tabizator.list:Refresh()
			self.tabizator.sheet:SwitchToName("list")
		end
		backButton:SetPrimaryMainColors()

		local ddd = self:Add("EditablePanel")
		ddd:Dock(TOP)

		local icon = ddd:Add("DLabel")
		icon:SetTextColor(color_white)
		self.icon = icon
		icon:SetFont("NxServF4Job2")
		icon:SetText("J")
		icon:Dock(LEFT)
		icon:SetSize(math.min(yscale(100), 100), math.min(yscale(100), 100))

		local title = ddd:Add("DLabel")
		title:SetTextColor(color_white)
		self.title = title
		title:SetFont("DermaNotLarge")
		title:SetText("Some job")
		title:Dock(LEFT)
		title:SizeToContents()

		ddd:SizeToChildren(true, true)

		local horizontalLine = self:Add("EditablePanel")
		horizontalLine:Dock(TOP)
		horizontalLine:DockMargin(0, 0, 0, 20)

		horizontalLine.Paint = function(s, w, h)
			surface.SetDrawColor(self.color)
			surface.DrawRect(0, 0, w, h)
		end

		horizontalLine:SetTall(2)

		local dsc = self:Add("DScrollPanel")
		fixscrollbar(dsc)
		self.descScroll = dsc
		dsc:Dock(FILL)

		local desc = dsc:Add("DLabel")
		desc:SetTextColor(color_white)
		self.desc = desc
		desc:SetAutoStretchVertical(true)
		desc:SetFont("DermaNotDefault")
		desc:SetWrap(true)
		desc:Dock(FILL)

		dsc:DockMargin(0, 0, 0, 20)

		self.btnGetJob = self:Add("F4MenuJobBecomeButton")
		self.btnGetJob:Dock(BOTTOM)

		self.pnlChooseMdl = self:Add("F4MenuChooseJobModel")
		self.pnlChooseMdl:Dock(BOTTOM)

		self.pnlChooseMdl:DockMargin(0, 0, 0, 20)
	end

	local function canGetJob(job)
		local ply = LocalPlayer()

		if isnumber(job.NeedToChangeFrom) and ply:Team() ~= job.NeedToChangeFrom then return false, true end
		if istable(job.NeedToChangeFrom) and not table.HasValue(job.NeedToChangeFrom, ply:Team()) then return false, true end
		if job.customCheck and not job.customCheck(ply) then return false, true end
		if ply:Team() == job.team then return false, true end
		if not GetGlobalBool("reElection_" .. job.team) and joblimits and job.max ~= 0 and (job.max == 1 or not ply:GetNWBool("DARKRP_PREMIUM")) and ((job.max % 1 == 0 and team.NumPlayers(job.team) >= job.max) or (job.max % 1 ~= 0 and (team.NumPlayers(job.team) + 1) / #player.GetAll() > job.max)) then return false, false end
		if job.admin == 1 and not ply:IsAdmin() then return false, true end
		if job.admin > 1 and not ply:IsSuperAdmin() then return false, true end

		return true
	end

	local function canChangeFromCurrent(job)
		local ply = LocalPlayer()

		if isnumber(job.NeedToChangeFrom) and ply:Team() ~= job.NeedToChangeFrom then return false, {job.NeedToChangeFrom} end
		if istable(job.NeedToChangeFrom) and not table.HasValue(job.NeedToChangeFrom, ply:Team()) then return false, job.NeedToChangeFrom end

		return true
	end

	-- functions for getting the weapon names from the job table
	local getWepName = fn.FOr{fn.FAnd{weapons.Get, fn.Compose{fn.Curry(fn.GetValue, 2)("PrintName"), weapons.Get}}, fn.Id}
	local getWeaponNames = fn.Curry(fn.Map, 2)(getWepName)
	local weaponString = fn.Compose{fn.Curry(fn.Flip(table.concat), 2)(", "), fn.Curry(fn.Seq, 2)(table.sort), getWeaponNames, table.Copy}

	function PANEL:setItem(item)
		local ply = LocalPlayer()

		self.item = item

		self.color = item.color

		self.icon:SetText(item.icon)

		local quota = joblimits[item.team]

		local weps
		if not item.weapons then
			weps = ""
		else
			weps = weaponString(item.weapons)
		end

		local t = item.description --self.item.team == 1 and item.description or ("a\n"):rep(9000)

		-- item.description
		local text = t:gsub('\t', '') ..
			"\n\n" .. DarkRP.getPhrase("salary", DarkRP.formatMoney(item.salary), "") .. " / " .. GAMEMODE.Config.paydelay .. DarkRP.getPhrase("sec") ..
			"\n" .. (quota and DarkRP.getPhrase("quota", math.ceil(quota * 100)) or (
				item.max == 1 and DarkRP.getPhrase("quota_one_man") or DarkRP.getPhrase("no_quota")
			)) ..
			(weps and weps ~= "" and ("\n\n" .. DarkRP.getPhrase("F4guns") .. ": ") or ("\n\n" .. DarkRP.getPhrase("no_extra_weapons"))) .. weps

		self.desc:SetText(text)
		self.desc:SizeToContents()

		self.title:SetText(item.name)
		self.title:SizeToContents()

		if istable(item.model) and #item.model > 1 then
			self.pnlChooseMdl:updateInfo(item)
			self.pnlChooseMdl:SetVisible(true)
		else
			self.pnlChooseMdl:SetVisible(false)
		end

		local closeFunc = function()
			self.tabizator:SwitchToName("list")
			--self.tabizator:GetParent():Hide()
			_G.cmenuspawnedframe:SetVisible(false)
		end
		self.btnGetJob:setJob(item, closeFunc)
		self.btnGetJob:SetEnabled(true)
  
		if item.team == TEAM_STURM then
            if not LocalPlayer():GetPos():WithinAABox(Vector(-3440.031250, -4975.031250, 72.031250), Vector(-5150.949707, -6211.019531, 483.526703)) then
                self.btnGetJob:SetText(DarkRP.getPhrase("police_office"))
                self.btnGetJob:SetEnabled(false)
            else
                self.btnGetJob:SetText(DarkRP.getPhrase("police_officer"))
                self.btnGetJob:SetEnabled(true)
            end
		elseif item.team == TEAM_MOB then
			self.btnGetJob:SetText(DarkRP.getPhrase("become_mob"))
			self.btnGetJob:SetEnabled(false)
		else
		local alreadyHasJob = ply:Team() == item.team
		local canGet, important = canGetJob(item)

		self.btnGetJob:SetEnabled(canGet)
		
		if not canGet and not item.team == TEAM_MAYOR then
			if alreadyHasJob then
				self.btnGetJob:SetText(DarkRP.getPhrase("job_already"))
			else
				local canChange, needFrom = canChangeFromCurrent(item)
				self.btnGetJob:SetText(canChange and DarkRP.getPhrase("job_singleman_occupied") or 
					DarkRP.getPhrase("need_to_be_x", (needFrom and table.concat(fn.Map(function(x) return team.GetName(x) end, table.Copy(needFrom)), DarkRP.getPhrase("joining_or")) or ""))
				)
			end
		else	
		    self.btnGetJob:SetText("Choisir ce métier")
		end
		

		self.descScroll:Rebuild()
		self.descScroll.VBar:SetScroll(0)
		--[[
		self:InvalidateLayout()
		self.desc:InvalidateLayout()
		self.descScroll:InvalidateLayout()
		]]
		end
	end

	function PANEL:PerformLayout()
		self.descScroll:Rebuild()
		self.descScroll.VBar:SetScroll(0)
	end

	function PANEL:Refresh()
		if self.item then
			self:setItem(self.item)
		end
	end

	derma.DefineControl("F4MenuJobs_Details", "", PANEL, "EditablePanel")
end

do -- choose model shit, dont bother to read it
	local red, dark = Color(140, 0, 0, 180), Color(0, 0, 0, 200)

	--[[-------------------------------------------------------------------------
	Icon for the model choose panel
	---------------------------------------------------------------------------]]
	PANEL = {}

	AccessorFunc(PANEL, "selected", "Selected", FORCE_BOOL)
	AccessorFunc(PANEL, "depressed", "Depressed", FORCE_BOOL)
	function PANEL:Init()
		self:SetSize(60, 60)
		self:SetText("")

		self.model = self.model or vgui.Create("ModelImage", self)
		self.model:SetSize(60, 60)
		self.model:SetPos(0, 0)
		self.model.OnMousePressed = fn.Partial(self.OnMousePressed, self)
		self.model.OnMouseReleased = fn.Partial(self.OnMouseReleased, self)
	end

	local gray = Color(140, 140, 140, 255)
	function PANEL:Paint(w, h)
		if self:GetSelected() then
			draw.RoundedBox(4, 0, 0, w, h, red)
			draw.RoundedBox(4, 3, 3, w - 6, h - 6, gray)
			return
		end
		local depressed = self:GetDepressed()
		local x, y = depressed and 3 or 0, depressed and 3 or 0
		w, h = depressed and w - 6 or w, depressed and h - 6 or h
		draw.RoundedBox(4, x, y, w, h, gray)
	end

	function PANEL:OnMousePressed()
		self:SetDepressed(true)
		self.model:SetSize(50, 50)
		self.model:SetPos(5, 5)
	end

	function PANEL:OnMouseReleased()
		self:SetSelected(true)
		self:SetDepressed(false)
		self.hostPanel:onSelected(self)
		DarkRP.setPreferredJobModel(self.job.team, self.strModel)
	end

	function PANEL:updateInfo(job, model, host)
		self.hostPanel = host
		self.strModel = model
		self.model:SetModel(model, 1, "000000000")
		self.job = job
		self:SetTooltip(model)
	end

	derma.DefineControl("F4MenuChooseJobModelIcon", "", PANEL, "DButton")

	--[[-------------------------------------------------------------------------
	Choose model panel
	---------------------------------------------------------------------------]]
	PANEL = {}

	function PANEL:Rebuild()
		if #self.iconList.Items == 0 then return end

		local x = 0
		for i, item in pairs(self.iconList.Items) do
			item:SetPos(x)

			x = x + item:GetWide() + 2
		end
		self.iconList:GetCanvas():SetWide(x)
	end

	function PANEL:getScroll()
		return self.scroll
	end

	function PANEL:setScroll(scroll)
		local canvas = self.iconList:GetCanvas()
		local x, y = canvas:GetPos()
		local minScroll = 0
		local maxScroll = math.Max(self.iconList:GetWide(), canvas:GetWide()) - self.iconList:GetWide()

		self.scroll = math.Max(0, scroll)
		local scrollPos = math.Clamp(scroll * -62, -maxScroll, -minScroll)

		if scrollPos == x then
			self.scroll = math.Max(self.scroll - 1, 0)
			return
		end

		canvas:SetPos(scrollPos, y)
	end

	function PANEL:Init()
		self:SetTall(70)
		self:StretchRightTo(self:GetParent())

		self.scroll = 0

		self.leftButton = vgui.Create("NxButton", self)
		self.leftButton:SetText("<")
		self.leftButton:SetWide(40)
		self.leftButton:Dock(LEFT)
		self.leftButton.DoClick = function(btn) self:setScroll(self:getScroll() - 1) end

		self.rightButton = vgui.Create("NxButton", self)
		self.rightButton:SetText(">")
		self.rightButton:SetWide(40)
		self.rightButton:Dock(RIGHT)
		self.rightButton.DoClick = function(btn) self:setScroll(self:getScroll() + 1) end

		self.iconList = vgui.Create("DPanelList", self)

		self.iconList:EnableHorizontal(true)
		self.iconList.PerformLayout = fn.Partial(self.PerformLayout, self)
		self.iconList.Rebuild = fn.Curry(self.Rebuild, 2)(self)
	end

	function PANEL:PerformLayout()
		self.iconList:SetPos(40, 5)
		self.iconList:SetSize(self:GetWide() - 2 * 40, 60)
		self.iconList:GetCanvas():SetTall(60)
		self.iconList:Rebuild()
	end

	function PANEL:Paint(w, h)
		draw.RoundedBox(4, 0, 0, w, h, dark)
	end

	function PANEL:onSelected(item)
		for k,v in pairs(self.iconList.Items) do
			if v == item then continue end
			v:SetSelected(false)
			v.model:SetSize(60, 60)
			v.model:SetPos(0, 0)
		end
	end

	function PANEL:updateInfo(job)
		self.iconList:Clear()
		if not istable(job.model) then return end

		local preferredModel = DarkRP.getPreferredJobModel(job.team)
		for i, mdl in ipairs(job.model) do
			local btn = vgui.Create("F4MenuChooseJobModelIcon", self.iconList)
			btn:updateInfo(job, mdl, self)
			if preferredModel == mdl then
				btn:SetSelected(true)
				btn.model:SetSize(50, 50)
				btn.model:SetPos(5, 5)
			end
			self.iconList:AddItem(btn)
		end

		self.iconList:InvalidateLayout()
	end

	derma.DefineControl("F4MenuChooseJobModel", "", PANEL, "DPanel")

	--[[-------------------------------------------------------------------------
	Vote/become job button
	---------------------------------------------------------------------------]]
	local PANEL = {}

	function PANEL:Init()
		self.BaseClass.Init(self)
		self:SetTall(yscale(60))
		self:SetPrimaryMainColors()
	end

	function PANEL:setJob(job, closeFunc)
		if not job.team then
			self:SetVisible(false)
		elseif job.vote or job.RequiresVote and job.RequiresVote(LocalPlayer(), job.team) then
			self:SetVisible(true)
			self:SetText(DarkRP.getPhrase("create_vote_for_job"))
			self.DoClick = function()
				RunConsoleCommand("darkrp", "vote" .. job.command) 
			end
		else
			self:SetVisible(true)
			self:SetText(DarkRP.getPhrase("become_job"))
			self.DoClick = function()
				RunConsoleCommand("darkrp", job.command) 
			end
		
		end
	end

	--[[
	local red, dark = Color(140, 0, 0, 180), Color(0, 0, 0, 200)
	function PANEL:Paint(w, h)
		draw.RoundedBox(4, 0, 0, w, h, dark)
		draw.RoundedBox(4, 5, 5, w - 10, h - 10, red)
	end
	]]

	derma.DefineControl("F4MenuJobBecomeButton", "", PANEL, "NxButton")
end

if IsValid(_G.cmenuspawnedframe) then
	_G.cmenuspawnedframe:Remove()
	_G.cmenuspawnedframe = nil
end