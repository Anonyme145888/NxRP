--[[-------------------------------------------------------------------------
F4 tab
---------------------------------------------------------------------------]]
local PANEL = {}

function PANEL:Init()
	self.BaseClass.Init(self)
	self:SetTextInset( 0, 0 )
	self:SetTall(32)
	self:SetContentAlignment(5)
end

local gray = Color(110, 110, 110, 255)
function PANEL:Paint(w, h)
	if self:IsActive() then
		surface.SetDrawColor(Color(0, 0, 200, 200))
		surface.DrawRect(0, 0, w, h)
	else
	end
end

function PANEL:ApplySchemeSettings()
	
end

derma.DefineControl("F4MenuTab", "", PANEL, "DTab")



--[[-------------------------------------------------------------------------
F4 tab sheet
---------------------------------------------------------------------------]]

PANEL = {}

local mouseX, mouseY = ScrW() / 2, ScrH() / 2
function PANEL:Init()
	self.F4Down = true

	self:RegisterGamePanel(function(self)
		self:Hide()
		return true
	end)

	self:StretchToParent(0, 0, 0, 0)
	self:Center()
	self:SetVisible(true)
	self:MakePopup()
	self:SetupCloseButton(fn.Curry(self.Hide, 2)(self))

	self.titlebar = self:Add("Panel")
	self.titlebar:Dock(TOP)
	self.titlebar:DockMargin(0, -5, 0, 5)
	self.titlebar:SetTall(22)

	self.close = self.titlebar:Add("DButton")
	self.close:SetWide(64)
	self.close:Dock(RIGHT)
	self.close:SetTextColor(color_white)
	if system.IsWindows() then
		self.close:SetFont("Marlett")
		self.close:SetText("r")
	else
		self.close:SetText("✖")
	end

	self.close.Paint = function(s, w, h)
		if s.Depressed then
			surface.SetDrawColor(Color(150, 0, 0, 255))
		elseif s.Hovered then
			surface.SetDrawColor(Color(255, 0, 0, 255))
		else
			surface.SetDrawColor(Color(200, 0, 0, 255))
		end

		surface.DrawRect(0, 0, w, h)
	end

	self.close.DoClick = fn.Curry(self.Hide, 2)(self)


	self.tabScroller:Remove()

	self.scrollPanel = self:Add("DScrollPanel")
	self.scrollPanel:Dock(LEFT)
	self.scrollPanel:SetWide(200)
	self.scrollPanel:DockMargin(0, 0, 5, 0)
	self.scrollPanel.Paint = function(s, w, h)
		--surface.SetDrawColor(Color(0, 0, 0, 150))
		--surface.DrawRect(0, 0, w, h)
	end

	self.tabScroller = self.scrollPanel:Add("DListLayout")
	self.tabScroller:Dock(FILL)

	self:DockPadding(5, 5, 5, 5)
end

function PANEL:SetupCloseButton(func)
	self.CloseButton = self.tabScroller:Add("DButton")
	self.CloseButton:SetText("")
	self.CloseButton.DoClick = func
	self.CloseButton.Paint = function(panel, w, h) derma.SkinHook("Paint", "WindowCloseButton", panel, w, h) end
	self.CloseButton:Dock(RIGHT)
	self.CloseButton:DockMargin(0, 0, 0, 8)
	self.CloseButton:SetSize(32, 32)
end

function PANEL:AddSheet(label, panel, material, NoStretchX, NoStretchY, Tooltip)
	if not IsValid(panel) then return end

	local sheet = {}

	sheet.Name = label

	sheet.Tab = vgui.Create("F4MenuTab", self)
	sheet.Tab:Setup(label, self, panel, material)
	sheet.Tab:SetTooltip(Tooltip)
	sheet.Tab:SetFont("DarkRPHUD2")

	sheet.Panel = panel
	sheet.Panel.tab = sheet.Tab
	--sheet.Panel.NoStretchX = NoStretchX
	--sheet.Panel.NoStretchY = NoStretchY
	--sheet.Panel:SetPos(self:GetPadding(), sheet.Tab:GetTall() + 8 + self:GetPadding())
	sheet.Panel:SetVisible(false)
	if sheet.Panel.shouldHide and sheet.Panel:shouldHide() then sheet.Tab:SetDisabled(true) end

	panel:SetParent(self)

	table.insert(self.Items, sheet)
	local index = #self.Items

	if not self:GetActiveTab() then
		self:SetActiveTab(sheet.Tab)
		sheet.Panel:SetVisible(true)
	end

	self.tabScroller:Add(sheet.Tab)

	if panel.Refresh then panel:Refresh() end

	return sheet, index
end

function PANEL:PerformLayout()

	local ActiveTab = self:GetActiveTab()
	local Padding = self:GetPadding()
	
	if ( not ActiveTab ) then return end
	
	-- Update size now, so the height is definitiely right.
	ActiveTab:InvalidateLayout( true )
		
	--self.tabScroller:StretchToParent( Padding, 0, Padding, nil )
	--self.tabScroller:SetTall( ActiveTab:GetTall() )
	
	
	
	local ActivePanel = ActiveTab:GetPanel()
	
	ActivePanel:Dock(FILL)
	ActivePanel:InvalidateLayout()

	-- Give the animation a chance
	self.animFade:Run()
	
end

local matBlurScreen = Material("pp/blurscreen")
function PANEL:Paint(w, h)
	if true then
		local x, y = self:LocalToScreen(0, 0)
		render.SetScissorRect(x, y, x + self:GetWide(), y + self:GetTall(), true)

		surface.SetMaterial( matBlurScreen )
		surface.SetDrawColor( 255, 255, 255, 255 )

		for i=0.33, 1, 0.33 do
			matBlurScreen:SetFloat( "$blur", 5 * i )
			matBlurScreen:Recompute()
			render.UpdateScreenEffectTexture()
			surface.DrawTexturedRect( x * -1, y * -1, ScrW(), ScrH() )
		end

		surface.SetDrawColor( 0, 0, 0, 200 )
		surface.DrawRect(0, 0, w, h)

		render.SetScissorRect(0, 0, 0, 0, false)
	else
		surface.SetDrawColor( 255, 255, 255, 15 )
		surface.DrawRect(0, 0, w, h)
	end
end

local F4Bind
function PANEL:Think()
	--self.CloseButton:SetVisible(not self.tabScroller.btnRight:IsVisible())

	F4Bind = F4Bind or input.KeyNameToNumber(input.LookupBinding("gm_showspare2"))
	if not F4Bind then return end

	if self.F4Down and not input.IsKeyDown(F4Bind) then
		self.F4Down = false
		return
	elseif not self.F4Down and input.IsKeyDown(F4Bind) then
		self.F4Down = true
		self:Hide()
	end

	self.animFade:Run()
end

hook.Add("PlayerBindPress", "DarkRPF4Bind", function(ply, bind, pressed)
	if string.find(bind, "gm_showspare2", 1, true) then
		F4Bind = input.KeyNameToNumber(input.LookupBinding(bind))
	end
end)

function PANEL:Refresh()
	for k,v in pairs(self.Items) do
		if v.Panel.shouldHide and v.Panel:shouldHide() then v.Tab:SetDisabled(true)
		else v.Tab:SetDisabled(false) end
		if v.Panel.Refresh then v.Panel:Refresh() end
	end
end

function PANEL:Show()
	self:Refresh()
	if #self.Items > 0 and self:GetActiveTab() and self:GetActiveTab():GetDisabled() then
		self:SetActiveTab(self.Items[1].Tab) --Jobs
	end
	self.F4Down = true
	self:SetVisible(true)
	gui.SetMousePos(mouseX, mouseY)
	self:MakePopup()
end

function PANEL:Hide()
	mouseX, mouseY = gui.MousePos()
	self:SetVisible(false)
end

function PANEL:Close()
	self:Hide()
end

function PANEL:createTab(name, panel)
	local sheet, index = self:AddSheet(name, panel)
	return index, sheet
end

function PANEL:removeTab(name)
	for k, v in pairs(self.Items) do
		if v.Tab:GetText() ~= name then continue end
		return self:CloseTab(v.Tab, true)
	end
end

function PANEL:switchTabOrder(tab1, tab2)
	error("Not supported!")

	self.Items[tab1], self.Items[tab2] = self.Items[tab2], self.Items[tab1]
	self.tabScroller.Panels[tab1], self.tabScroller.Panels[tab2] = self.tabScroller.Panels[tab2], self.tabScroller.Panels[tab1]
	self.tabScroller:InvalidateLayout(true)
end


function PANEL:generateTabs()
	DarkRP.F4MenuTabs()
	hook.Call("F4MenuTabs")
	self:SetSkin(GAMEMODE.Config.DarkRPSkin)
end

derma.DefineControl("F4EditablePropertySheet", "", vgui.GetControlTable("DPropertySheet"), "EditablePanel")
derma.DefineControl("F4MenuFrame", "", PANEL, "F4EditablePropertySheet")
