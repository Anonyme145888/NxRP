hook.Add("UpdateAnimation", "Radio", function(ply)
	if ply:IsPlayingTaunt() then return end

	local weight = math.Approach(ply.RadioChatGestureWeight or 0, (ply:GetNWBool("Radio") or ply:GetNWInt("PhoneCall") ~= 0) and 1 or 0, FrameTime() * 5)
	ply.RadioChatGestureWeight = weight

	if weight > 0 then
		ply:AnimRestartGesture(GESTURE_SLOT_VCD, ACT_GMOD_IN_CHAT, true)
		ply:AnimSetGestureWeight(GESTURE_SLOT_VCD, weight)
	end
end)