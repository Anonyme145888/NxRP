--[[-------------------------------------------------------------------------
This module finds out for you who can see you talk or speak through the microphone
---------------------------------------------------------------------------]]

local receivers
local currentChatText = ""
local receiverConfigs = {}
local currentConfig = {text = "", hearFunc = fn.Id} -- Default config is not loaded yet

--[[-------------------------------------------------------------------------
addChatReceiver
Add a chat command with specific receivers

prefix: the chat command itself ("/pm", "/ooc", "/me" are some examples)
text: the text that shows up when it says "Some people can hear you X"
hearFunc: a function(ply, splitText) that decides whether this player can or cannot hear you.
    return true if the player can hear you
           false if the player cannot
           nil if you want to prevent the text from showing up temporarily
---------------------------------------------------------------------------]]
function DarkRP.addChatReceiver(prefix, text, hearFunc)
    receiverConfigs[prefix] = {
        text = text,
        hearFunc = hearFunc
    }
end

--[[-------------------------------------------------------------------------
removeChatReceiver
Remove a chat command.

prefix: the command, like in addChatReceiver
---------------------------------------------------------------------------]]
function DarkRP.removeChatReceiver(prefix)
    receiverConfigs[prefix] = nil
end

--[[-------------------------------------------------------------------------
Draw the results to the screen
---------------------------------------------------------------------------]]
local function drawChatReceivers()
    if not receivers then return end

    local x, y = chat.GetChatBoxPos()
    y = y - 21

    if minimap then
        x = minimap.x
        y = minimap.y - 80
    end

    -- No one hears you
    if #receivers == 0 then
        draw.WordBox(2, x, y, DarkRP.getPhrase("hear_noone", currentConfig.text), "DarkRPHUD1", Color(0,0,0,160), Color(255,0,0,255))
        return
    -- Everyone hears you
    elseif #receivers == #player.GetAll() - 1 then
        draw.WordBox(2, x, y, DarkRP.getPhrase("hear_everyone"), "DarkRPHUD1", Color(0,0,0,160), Color(0,255,0,255))
        return
    end

    draw.WordBox(2, x, y - (#receivers * 21), DarkRP.getPhrase("hear_certain_persons", currentConfig.text), "DarkRPHUD1", Color(0,0,0,160), Color(0,255,0,255))
    for i = 1, #receivers, 1 do
        if not IsValid(receivers[i]) then
            receivers[i] = receivers[#receivers]
            receivers[#receivers] = nil
            continue
        end

        draw.WordBox(2, x, y - (i - 1) * 21, receivers[i]:Nick(), "DarkRPHUD1", Color(0, 0, 0, 160), Color(255, 255, 255, 255))
    end
end


local stopFind
local startFind

--[[-------------------------------------------------------------------------
Find out who could hear the player if they were to speak now
---------------------------------------------------------------------------]]
local function chatGetRecipients()
    if not currentConfig then return end

    if not (LocalPlayer():IsValid() and LocalPlayer():Alive()) then
        stopFind()
    end

    receivers = {}
    for _, ply in ipairs(player.GetAll()) do
        if ply == LocalPlayer() then continue end

        local val = currentConfig.hearFunc(ply, currentChatText)

        -- Return nil to disable the chat recipients temporarily.
        if val == nil then
            receivers = nil
            return
        elseif val == true then
            table.insert(receivers, ply)
        end
    end
end

function startFind(config)
    if not (LocalPlayer():IsValid() and LocalPlayer():Alive()) then return end
    currentConfig = config
    hook.Add("Think", "DarkRP_chatRecipients", chatGetRecipients)
    hook.Add("HUDPaint", "DarkRP_DrawChatReceivers", drawChatReceivers)
end
function stopFind()
    hook.Remove("Think", "DarkRP_chatRecipients")
    hook.Remove("HUDPaint", "DarkRP_DrawChatReceivers")
end


hook.Add("StartChat", "DarkRP_StartFindChatReceivers", function()
    startFind(receiverConfigs[""])
end)
hook.Add("FinishChat", "DarkRP_StopFindChatReceivers", stopFind)


local function findConfig(text)
    local split = string.Explode(' ', text)
    local prefix = string.lower(split[1])

    currentChatText = text

    currentConfig = receiverConfigs[prefix] or receiverConfigs[""]
end
hook.Add("ChatTextChanged", "DarkRP_FindChatRecipients", findConfig)


local function loadChatReceivers()
    -- Default talk chat receiver has no prefix
    DarkRP.addChatReceiver("", DarkRP.getPhrase("talk"), function(ply, text)
        local chatType = wChat and wChat.MainTab.chatType or "local"

        if chatType == "local" then
            if ply:GetNoDraw() then
                return false
            end

            local range = 0

            if text and text:find("%!") then
                range = 550
            elseif text and text:find("%.%.%.") then
                range = 90
            else
                range = 250
            end

            return LocalPlayer():GetPos():Distance(ply:GetPos()) < range
        elseif chatType == "city" or chatType == "advert" then
            return true
        elseif chatType == "group" then
            for _, func in pairs(GAMEMODE.DarkRPGroupChats) do
                if func(LocalPlayer()) and func(ply) then
                    return true
                end
            end
            return false
        end
    end)

    DarkRP.addChatReceiver("/me", DarkRP.getPhrase("perform_your_action"), function(ply) return not ply:GetNoDraw() and LocalPlayer():GetPos():Distance(ply:GetPos()) < 250 end)

    --[[-------------------------------------------------------------------------
    Voice chat receivers
    ---------------------------------------------------------------------------]]
    DarkRP.addChatReceiver("speak", DarkRP.getPhrase("speak"), function(ply)
        if ply:GetNoDraw() then return false end

        local lp = LocalPlayer()

        if lp:GetNWBool("Radio") then
            return getRadioMates(lp)[ply] or false
        end

        if lp:GetNWInt("PhoneCall") ~= 0 then
            return Player(lp:GetNWInt("PhoneCall")) == ply
        end

        if lp:GetPos():DistToSqr(ply:GetPos()) > 302500 then return false end

        return ply:isInRoom()
    end)
end
hook.Add("loadCustomDarkRPItems", "loadChatListeners", loadChatReceivers) -- Load after the custom languages have been loaded


hook.Add("PlayerStartVoice", "DarkRP_VoiceChatReceiverFinder", function(ply)
    if ply ~= LocalPlayer() then return end

    startFind(receiverConfigs["speak"])
end)

hook.Add("PlayerEndVoice", "DarkRP_VoiceChatReceiverFinder", function(ply)
    if ply ~= LocalPlayer() then return end

    stopFind()
end)