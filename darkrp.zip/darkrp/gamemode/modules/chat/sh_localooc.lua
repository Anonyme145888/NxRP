if CLIENT then
	DarkRP.addChatReceiver("/l", " Local OOC", function(ply) return LocalPlayer():GetPos():Distance(ply:GetPos()) < 550 end)
else
	local function LocalOOC(ply, args)
		local DoSay = function(text)
			if text == "" then
				DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("invalid_x", "argument", ""))
				return ""
			end
			DarkRP.talkToRange(ply, "(LOOC) " .. ply:Nick(), text, 550)
		end
		return args, DoSay
	end
	DarkRP.defineChatCommand("l", LocalOOC, 1.5)
end

DarkRP.declareChatCommand{
	command = "l",
	description = "Local OOC.",
	delay = 1.5
}