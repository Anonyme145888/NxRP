local isMuting = CreateClientConVar("mutegroup", 0, false, true)
DarkRP.cvarMuteGroup = isMuting

net.Receive("GroupRadioVoice", function()
	if net.ReadEntity() ~= LocalPlayer() and not isMuting:GetBool() then
		LocalPlayer():EmitSound(net.ReadBool() and
			"npc/metropolice/vo/on" .. math.random(1, 2) .. ".wav"
			or
			-- "npc/metropolice/vo/off" .. math.random(1, 4) .. ".wav"
			"npc/metropolice/vo/off" .. (chance(0.5) and 4 or 1) .. ".wav"
		, 45)
	end
end)

hook.Add("PlayerBindPress", "GroupRadioVoice", function(ply, bind, pressed)
	if bind:find("noclip", nil, true) then
		if not ply:HasWeapon("nx_radio") then return end
		if ray.HasAccess("noclip") then return end -- this is affected by 'power' state

		if pressed then
			if not next(getRadioMates(ply)) then
				darkrp.notify(NOTIFY_ERROR, 6, DarkRP.getPhrase("channel_not_set"), true)
				return true
			end

			local cant = ply:IsDisabled(1)
			if cant then
				darkrp.notify(NOTIFY_ERROR, 4, "Can't use radio now", true)
				return true
			end

			RunConsoleCommand("+voicegroup")
		--	RunConsoleCommand("+voicerecord")
		else
			RunConsoleCommand("-voicegroup")
			RunConsoleCommand("-voicerecord")

			local wep = ply:GetActiveWeapon()
			if wep:IsValid() and wep:GetClass() == "nx_radio" then
				RunConsoleCommand("lastinv")
			end
		end

		ply:EmitSound(pressed and
			"npc/metropolice/vo/on" .. math.random(1, 2) .. ".wav"
			or
			-- "npc/metropolice/vo/off" .. math.random(1, 4) .. ".wav"
			"npc/metropolice/vo/off" .. (chance(0.5) and 4 or 1) .. ".wav"
		, 45)

		return true
	end
end)

function selectradiochannel(ch)
	if not ch then
		ch = LocalPlayer():GetNWInt("radiochannel", 0)
	end

	local frame = vgui.Create("NxGenericFrame")

	local title = frame:AddTitle(DarkRP.getPhrase("radio_title"))

	local check
	if hasRadioGroup(LocalPlayer()) then
		check = frame:Add("DCheckBoxLabel")
		check:Dock(TOP)
		check:SetFont("DermaNotDefault")
		check:SetText(DarkRP.getPhrase("radio_group_chan"))
		check:SizeToContents()
		check:SetChecked(ch == 0)
	end

	local wang, wanga
	if not check or not check:GetChecked() then
		wanga = frame:Add("EditablePanel")
		wanga:Dock(TOP)
		wanga:SetTall(yscale(40))
		wanga:DockMargin(0, MediumMargin, 0, 0)

		local label = wanga:Add("DLabel")
		label:SetFont("DermaNotDefault")
		label:Dock(LEFT)
		label:SetText(DarkRP.getPhrase("radio_chan"))
		label:SizeToContents()

		wang = wanga:Add("DNumberWang")
		wang:SetFont("DermaNotLarge")
		wang.Paint = nxui_DTextEntry_Paint
		wang:Dock(FILL)
		wang:SetMinMax(1, 999)
		wang:SetDecimals(0)
		if ch > 0 then
			wang:SetValue(tostring(ch))
		end
		function wang:OnGetFocus()
			frame:SetKeyboardInputEnabled(true)
		end
		function wang:OnLoseFocus()
			frame:SetKeyboardInputEnabled(false)
		end
		wang:RequestFocus()
	end

	if check then
		function check:OnChange(state)
			local ch
			if wang then
				ch = tonumber(wang:GetValue())
				if not ch or ch < 1 or ch > 999 then
					darkrp.notify(NOTIFY_ERROR, 6, DarkRP.getPhrase("radio_chan_fail"), true)
					return
				end
			end
			ch = check:GetChecked() and 0 or ch or 1
			net.Start("radiochannel")
				net.WriteUInt(ch, 10)
			net.SendToServer()
			frame:Remove()
			selectradiochannel(ch)
		end
	end

	local apply = vgui.Create("NxButton", frame)
	apply:Dock(TOP)
	apply:SetText(DarkRP.getPhrase("apply"))
	apply:SizeBig()
	apply:SetPrimaryMainColors()
	apply:DockMargin(0, LargeMargin, 0, 0)
	function apply:DoClick()
		local ch
		if wang then
			ch = tonumber(wang:GetValue())
			if not ch or ch < 1 or ch > 999 then
				darkrp.notify(NOTIFY_ERROR, 6, DarkRP.getPhrase("radio_chan_fail"), true)
				return
			end
		end
		net.Start("radiochannel")
			net.WriteUInt(wang and ch or check and check:GetChecked() and 0 or 1, 10)
		net.SendToServer()
		frame:Remove()
	end

	if wang then
		wang.OnEnter = apply.DoClick
	end

	frame:SetWide(LargeMargin + title:GetWide() + LargeMargin)
	frame:SetTall(LargeMargin + title:GetTall() + MediumMargin + (check and check:IsVisible() and check:GetTall() or 0) + (wanga and (MediumMargin + wanga:GetTall()) or 0) + LargeMargin + apply:GetTall() + MediumMargin + yscale(32) + LargeMargin)
	frame:Center()
end
