function getRadioMates(ply)
	local channel = ply:GetNWInt("radiochannel")

	local ret = {}

	if channel > 0 then
		for _, listener in ipairs(player.GetAll()) do
			if listener:GetNWInt("radiochannel") == channel then
				ret[listener] = true
			end
		end
	else
		for _, func in next, GAMEMODE.DarkRPGroupChats do
			if func(ply) then
				for _, listener in ipairs(player.GetAll()) do
					if func(listener) and listener:GetNWInt("radiochannel") == 0 then
						ret[listener] = true
					end
				end
				break
			end
		end
	end
	
	return ret
end

function hasRadioGroup(ply)
	for _, func in next, GAMEMODE.DarkRPGroupChats do
		if func(ply) then
			return true
		end
	end
end