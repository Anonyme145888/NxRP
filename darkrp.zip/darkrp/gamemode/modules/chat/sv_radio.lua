util.AddNetworkString('GroupRadioVoice')
util.AddNetworkString('radiochannel')
