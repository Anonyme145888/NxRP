local VM_Hand, VM_Radio

local HandAngle = Angle(40, 0, 0)
local fas_hack = Vector()
local Model = "models/dean/sh5/radio.mdl"

local fixup = {
	["models/weapons/c_arms_cop.mdl"] = "models/viewmodels/c_arms_cop.mdl"
}

local ptrVec = Vector()
hook.Add("PreDrawViewModel", "Radio", function(vm, pl, wep)
	if vm then
		local hands = pl:GetHands()
		if not hands:IsValid() then return end

		local mdl = hands:GetModel()
		mdl = fixup[mdl] or mdl
		if IsValid(VM_Hand) and VM_Hand:GetModel() ~= mdl or not IsValid(VM_Hand) then
			if IsValid(VM_Hand) then
				VM_Hand:SetModel(mdl)
			else
				VM_Hand = ClientsideModel(mdl)
			end

			VM_Hand:SetNoDraw(true)
			VM_Hand:SetSequence(7)
			VM_Hand:SetupBones()

			for i = 1, VM_Hand:GetNumBodyGroups() do
				VM_Hand:SetBodygroup(i, hands:GetBodygroup(i))
			end
		end

		if pl:GetNWBool("Radio") then
			Model = "models/dean/sh5/radio.mdl"
		
		--"models/dean/sh5/radio.mdl"
		elseif pl:GetNWInt("PhoneCall") ~= 0 then
			Model = "models/weapons/w_camphone.mdl"
		end

		if not IsValid(VM_Radio) then
			VM_Radio = ClientsideModel(Model)
			VM_Radio:SetNoDraw(true)
		elseif VM_Radio:GetModel() ~= Model then
			VM_Radio:SetModel(Model)
		end

		-- lerp animations
		local yes = pl:GetNWBool("Radio") or pl:GetNWInt("PhoneCall") ~= 0
		HandAngle = LerpAngle(FrameTime() * 10, HandAngle, yes and Angle() or Angle(40, 0, 0))
		fas_hack = LerpVector(FrameTime() * 10, fas_hack, yes and Vector(0, 0, -16) or Vector())

		if HandAngle ~= Angle(40, 0, 0) or fas_hack ~= Vector() then
			-- hide right hand
			VM_Hand:ManipulateBonePosition(20, Vector(0, -16384, 0))

			-- rotate left hand
			VM_Hand:ManipulateBoneAngles(4, Angle(-30, -60, -60) + Angle(math.sin(RealTime()), math.cos(RealTime()), 0) * 2)

			-- rotate fingers
			for i = 5, 16 do
				VM_Hand:ManipulateBoneAngles(i, Angle(0, 50, 0))
			end

			for i = 8, 13 do
				VM_Hand:ManipulateBoneAngles(i, Angle(0, 40, 0))
			end

			for i = 17, 19 do
				VM_Hand:ManipulateBoneAngles(i, Angle(0, -20, 0))
			end

			local vm = LocalPlayer():GetViewModel()
			ptrVec:Set(EyePos())
			local pos, ang = GetNXWeaponShake(ptrVec, LocalPlayer():EyeAngles())

			cam.Start3D(EyePos(), EyeAngles(), 72)
				render.ClearDepth()
				VM_Hand:SetPos(pos)
				VM_Hand:SetAngles(ang + HandAngle)
				VM_Hand:DrawModel()

				local pos, ang = VM_Hand:GetBonePosition(4)

				if Model == "models/dean/sh5/radio.mdl" then
					ang:RotateAroundAxis(ang:Up(), -90)
					ang:RotateAroundAxis(ang:Forward(), -12)
					VM_Radio:SetRenderOrigin(pos + ang:Right() * -3 + ang:Forward() * 1.6)
				elseif Model == "models/weapons/w_camphone.mdl" then
					ang:RotateAroundAxis(ang:Up(), 90)
					VM_Radio:SetRenderOrigin(pos + ang:Right() * 4 - ang:Forward() * 5 + ang:Up() * 2)
				end

				VM_Radio:SetAngles(ang)
				VM_Radio:DrawModel()
			cam.End3D()
			cam.IgnoreZ(true)

			if wep.Wep then -- is it fas2
				wep.Wep:ManipulateBonePosition(wep.Wep:LookupBone("Left Hand"), fas_hack)
			elseif vm:LookupBone("Left Hand") then -- is it fas2
				vm:ManipulateBonePosition(vm:LookupBone("Left Hand"), fas_hack)
			else
				vm:ManipulateBoneAngles(1, (Angle(80, 0, 0) - HandAngle * 2) * (wep:IsValid() and wep:GetClass() == "nxw_mp5" and -1 or 1) )
			end
		end
	end
end)

hook.Add("PrePlayerDraw", "Radio", function(pl)
	if pl:GetNWBool("Radio") then
		Model = "models/dean/sh5/radio.mdl"
		
		--"models/dean/sh5/radio.mdl"
	elseif pl:GetNWInt("PhoneCall") ~= 0 then
		Model = "models/weapons/w_camphone.mdl"
	else
		return
	end

	if not IsValid(pl.WM_Radio) then
		pl.WM_Radio = ClientsideModel(Model)
		pl.WM_Radio:SetNoDraw(true)
	elseif pl.WM_Radio:GetModel() ~= Model then
		pl.WM_Radio:SetModel(Model)
	end

	local pos, ang = pl:GetBonePosition(pl:LookupBone("ValveBiped.Bip01_L_Hand") or 0)

	if Model == "models/dean/sh5/radio.mdl" then
		pl.WM_Radio:SetPos(pos + ang:Forward() * 2.5 + ang:Right() * 1.5)
		ang:RotateAroundAxis(ang:Up(), -90)
		ang:RotateAroundAxis(ang:Forward(), -40)
	elseif Model == "models/weapons/w_camphone.mdl" then
		pl.WM_Radio:SetPos(pos + ang:Forward() * 3 + ang:Right() * 4.5 - ang:Up())
		ang:RotateAroundAxis(ang:Up(), 90)
		ang:RotateAroundAxis(ang:Forward(), 45)
	end

	pl.WM_Radio:SetAngles(ang)
	pl.WM_Radio:DrawModel()
end)

hook.Add("PlayerSwitchWeapon", "FixViewModel", function()
	if IsFirstTimePredicted() then
		local vm = LocalPlayer():GetViewModel()
		for i = 0, 100 do
			vm:ManipulateBoneAngles(i, Angle())
			vm:ManipulateBonePosition(i, Vector())
		end
	end
end)