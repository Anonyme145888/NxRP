local Response = {}

Response.blocked = {
	physgun = {
		"vc_npc_cardealer",
		"fire_node",
		"letter",
	},
	toolgun = {
		"vc_npc_cardealer",
		"player",
	},
}

function Response.Physgun(ply, ent)
	if ent.PhysgunPickup ~= nil then
		if type(ent.PhysgunPickup) == "function" then
			local result = ent:PhysgunPickup(ply, ent)
			if result ~= nil then
				return result
			end
		else
			return ent.PhysgunPickup
		end
	end

	if ent:IsPlayer() then return end -- for admin system to decide

	if ent:GetClass() == "vc_npc_cardealer" or ent:GetClass() == "printer_package" or ent:GetClass() == "printer_package_premium" or ent:GetClass() == "money_printer_premium" or ent:GetClass() == "money_printer" or ent:GetClass() == "sent_sakariashelicopter" or ent:GetClass() == "sent_helicopter_nonadmin" or ent:GetClass() == "fire_node" or ent:GetClass() == "letter" or ent:GetClass() == "prop_door_rotating" or ent:GetClass() == "func_platrot" or ent:GetClass() == "func_door_rotating" or ent:GetClass() == "func_door" or ent:GetClass() == "func_button" or ent:GetClass() == "func_brush" or ent:GetClass() == "func_breakable_surf" then
		return false
	end

	-- can only be checked serverside - bad for prediction + 'blocked' list is bigger than is has to be - solution?
	--[[
	if ent:CreatedByMap() or ent.mf_entdata then
		return false
	end
	]]

	if ply:IsAdmin() then
		return true
	end

	local owner = ent:GetNW2Int("PropOwner", 0)
	if owner == 0 then
		owner = nil
	end

	if owner then
		if ply:AccountID() == owner then
			return true
		end

		local buddy = FPP.BuddiedMe[owner]
		if buddy and buddy.Physgun then
			return true
		end
	end

	return false
end

function Response.Toolgun(ply, ent, tool)
	if ent.CanTool ~= nil and ent:GetClass() ~= "gmod_cameraprop" then
		if type(ent.CanTool) == "function" then
			local result = ent:CanTool(ply, trace, tool)
			if result ~= nil then
				return result
			end
		else
			return ent.CanTool
		end
	end
	if ent:GetClass() == "vc_npc_cardealer" or ent:GetClass() == "player" or ent:GetClass() == "printer_package" or ent:GetClass() == "printer_package_premium" or ent:GetClass() == "money_printer_premium" or ent:GetClass() == "money_printer" or ent:GetClass() == "sent_sakariashelicopter" or ent:GetClass() == "sent_helicopter_nonadmin" or ent:GetClass() == "fire_node" or ent:GetClass() == "letter" or ent:GetClass() == "prop_door_rotating" or ent:GetClass() == "func_platrot" or ent:GetClass() == "func_door_rotating" or ent:GetClass() == "func_door" or ent:GetClass() == "func_button" or ent:GetClass() == "func_brush" or ent:GetClass() == "func_breakable_surf" then
		return false
	end

	-- can only be checked serverside - bad for prediction + 'blocked' list is bigger than is has to be - solution?
	--[[
	if ent:CreatedByMap() or ent.mf_entdata then
		return false
	end
	]]

	local owner = ent:GetNW2Int("PropOwner", 0)
	if owner == 0 then
		owner = nil
	end

	if ply:IsAdmin() then
		if owner or tool == "remover" or ply:IsSuperAdmin() then -- hard protection against admin abuse
			return true
		end
	end

	if owner then
		if ply:AccountID() == owner then
			return true
		end

		local buddy = FPP.BuddiedMe[owner]
		if buddy and buddy.Toolgun then
			return true
		end
	end

	return false
end

local both = {
	"func_breakable_surf",
	"func_brush",
	"func_button",
	"func_door",
	"func_door_rotating",
	"func_platrot",
	"prop_door_rotating",
}
table.Add(Response.blocked.physgun, both)
table.Add(Response.blocked.toolgun, both)

hook.Add("PhysgunPickup", "FPP", function(ply, ent)
	if ent:IsPlayer() then return end -- for admin system to decide

	if not Response.Physgun(ply, ent) then
		return false
	end
end)

hook.Add("CanTool", "FPP", function(ply, trace, tool)
	local ent = trace.Entity
	if not ent:IsValid() then return end

	if not Response.Toolgun(ply, ent, tool) then
		return false
	end
end)

hook.Add("CanProperty", "FPP", function(ply, name, ent)
	if not Response.Toolgun(ply, ent) then
		return false
	end
end)

FPP.Response = Response
return Response

