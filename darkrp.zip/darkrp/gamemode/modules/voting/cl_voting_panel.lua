local Tex_Corner8 	= surface.GetTextureID("gui/corner8")
local Tex_Corner16 	= surface.GetTextureID("gui/corner16")
local function RoundedBox(bordersize, x, y, w, h, color)
	w = math.Round(w)
	h = math.Round(h)

	surface.SetDrawColor(color.r, color.g, color.b, color.a)

	surface.DrawRect(x, y + bordersize, bordersize, h - bordersize * 2)
	surface.DrawRect(x + bordersize, y, w - bordersize * 2, bordersize)
	surface.DrawRect(x + w - bordersize, y + bordersize, bordersize, h - bordersize * 2)
	surface.DrawRect(x + bordersize, y + h - bordersize, w - bordersize * 2, bordersize)

	surface.SetTexture(bordersize > 8 and Tex_Corner16 or Tex_Corner8)

	surface.DrawTexturedRectRotated(x + bordersize / 2, y + bordersize / 2, bordersize, bordersize, 0)
	surface.DrawTexturedRectRotated(x + w - bordersize / 2, y + bordersize / 2, bordersize, bordersize, 270)
	surface.DrawTexturedRectRotated(x + bordersize / 2, y + h - bordersize / 2, bordersize, bordersize, 90)
	surface.DrawTexturedRectRotated(x + w - bordersize / 2, y + h - bordersize / 2, bordersize, bordersize, 180)
end

local function hex2rgb(hex, a)
	return Color(tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16), a)
end

local bgColor		= hex2rgb("7F7F7F", 100)
local bgQuesColor	= hex2rgb("7F7FAF", 100)
local fgColor		= hex2rgb("DEDEDE")
local pgBgColor		= hex2rgb("223C4C")
local pgFgColor		= hex2rgb("539DCB")
local yesColor		= Color(5, 178, 78)
local noColor		= Color(255, 81, 68)

local PANEL = {}

function PANEL:Init()
	self.QuestionLabel = vgui.Create("DLabel", self)
	self.QuestionLabel:SetPos(yscale(5), yscale(5))
	self.QuestionLabel:SetFont("DermaNotDefault")
	self.QuestionLabel:SetTextColor(fgColor)

	self.YesButton = vgui.Create("DButton", self)
	self.YesButton:SetPos(yscale(5), yscale(2))
	self.YesButton:SetFont("DermaNotDefault")
	self.YesButton:SetText(DarkRP.getPhrase("yes"))
	self.YesButton:SetSize(yscale(40), yscale(26))
	self.YesButton:SetColor(fgColor)
	self.YesButton.DoClick = function()
		if self.OnYes then
			if self.dangerous then
				if IsValid(self.AlertPanel) then
					self.AlertPanel:Remove()
					self.AlertPanel = nil
				end

				self.AlertPanel = DarkRP.DermaQuery("!!!", self.QuestionLabel:GetText(), "OK", function()
					if IsValid(self) then
						self:OnYes()
						self:HideAndRemove()
					end
				end, DarkRP.getPhrase("cancel"))
			else
				self:OnYes()
				self:HideAndRemove()
			end
		end
	end

	function self.YesButton:Paint(w, h)
		RoundedBox(2, 0, 0, w, h, yesColor)
	end

	self.NoButton = vgui.Create("DButton", self)
	self.NoButton:SetFont("DermaNotDefault")
	self.NoButton:SetText(DarkRP.getPhrase("no"))
	self.NoButton:SetSize(yscale(40), yscale(26))
	self.NoButton:SetColor(fgColor)
	self.NoButton.DoClick = function ()
		if self.OnNo then
			self:OnNo()
			self:HideAndRemove()
		end
	end

	function self.NoButton:Paint(w, h)
		RoundedBox(2, 0, 0, w, h, noColor)
	end

	self:SetDuration(10)
	self:UpdatePanelSize()
	self:SetKeyboardInputEnabled(false)
	self:SetMouseInputEnabled(true)
end

function PANEL:SetQuestion(question)
	self.QuestionLabel:SetText(question)
	self.QuestionLabel:SizeToContents()
end

function PANEL:SetDuration(duration, dontResetTimeCreated)
	self.Duration = duration

	if not dontResetTimeCreated then
		self.TimeCreated	= CurTime()
		self.ExpiresOn		= CurTime() + self.Duration
	end
end

function PANEL:UpdatePanelSize()
	self.YesButton:SetPos(self.QuestionLabel:GetWide() + yscale(10), yscale(2))
	self.NoButton:SetPos(self.YesButton.x + self.YesButton:GetWide() + yscale(5), self.YesButton.y)

	self:SetSize(self.NoButton.x + self.NoButton:GetWide() + yscale(5), self.QuestionLabel:GetTall() + yscale(15))
end

function PANEL:GetRemaining(noRound)
	local rem = self.TimeCreated + self.Duration - CurTime()
	return rem < 0 and 0 or (noRound and rem or math.Round(rem))
end

function PANEL:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, self.ques and bgQuesColor or bgColor)
	draw.RoundedBox(0, 0, self:GetTall() - 5, w, h - 5, pgBgColor)
	draw.RoundedBox(0, 0, self:GetTall() - 5, w * (self:GetRemaining(true) / self.Duration), h - 5, pgFgColor)
end

function PANEL:Think()
	if self:GetRemaining() == 0 then
		self:HideAndRemove()
	end
end

function PANEL:HideAndRemove()
	if IsValid(self.AlertPanel) then
		self.AlertPanel:Remove()
		self.AlertPanel = nil
	end

	if self.anim then return end
	self.anim = true
	
	if self.OnHide then
		self:OnHide()
	end

	self:MoveTo(ScrW(), self.y, 1, 0, .6, function(_, s)
		s:Remove()
	end)
end

vgui.Register("DarkRPX_Vote", PANEL, "DPanel")