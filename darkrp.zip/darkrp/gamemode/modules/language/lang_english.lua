return "en", {
	looking_your_shop = "Visits your shop",

	-- Admin things
	need_admin = "You need admin privileges in order to be able to %s",
	need_sadmin = "You need super admin privileges in order to be able to %s",
	no_privilege = "You don't have the right privileges to perform this action",
	no_jail_pos = "No jail position",
	invalid_x = "Invalid %s! %s",

	-- F1 menu
	f1ChatCommandTitle = "Chat commands",
	f1Search = "Search...",

    shop_shipment_ak47 = "AK-47",
	shop_shipment_ak74 = "AK-74",
	shop_shipment_g3 = "G3A3",
	shop_shipment_sks = "SKS",
	shop_shipment_ragebull = "Raging Bull",
	shop_shipment_mac11 = "MAC11",
    shop_shipment_deagle = "IMI Desert Eagle",
    shop_shipment_glock20 = "Glock-20",
    shop_shipment_m1911 = "M1911",
    shop_shipment_m24 = "M-24",
    shop_shipment_m3super90 = "M3SUPER90",
    shop_shipment_m4a1 = "M4A1",
    shop_shipment_mp5a5 = "MP5A5",
    shop_shipment_p226 = "P-226",
    shop_shipment_rk95 = "Sako RK-95",
    shop_shipment_sg552 = "SG-552",
    shop_shipment_pp19 = "PP-19",
    shop_shipment_uzi = "IMI Uzi",
    shop_shipment_c4 = "C4",
    shop_shipment_m67 = "Граната M67",
    shop_shipment_dv2 = "Нож DV2",
    shop_shipment_machete = "Мачете",
    shop_shipment_rpg = "RPG",

	-- Money things:
	price = "Price: %s%d",
	priceTag = "Price: %s",
	reset_money = "%s has reset all players' money!",
	has_given = "%s has given you %s",
	you_gave = "You gave %s %s",
	npc_killpay = "%s for killing an NPC!",
	profit = "profit",
	loss = "loss",

	-- backwards compatibility
	deducted_x = "Deducted %s%d",
	need_x = "Need %s%d",

	deducted_money = "Deducted %s",
	need_money = "Need %s",

	payday_message = "Payday! You received %s!",
	payday_unemployed = "You received no salary because you are unemployed!",
	payday_missed = "Pay day missed! (You're Arrested)",

	property_tax = "Property tax! %s",
	property_tax_cant_afford = "You couldn't pay the taxes! Your property has been taken away from you!",
	taxday = "Tax Day! %s%% of your income was taken!",

	found_cheque = "You have found %s%s in a cheque made out to you from %s.",
	cheque_details = "This cheque is made out to %s.",
	cheque_torn = "You have torn up the cheque.",
	cheque_pay = "Pay: %s",
	signed = "Signed: %s",

	found_cash = "You have found %s%d!", -- backwards compatibility
	found_money = "You have found %s!",

	owner_poor = "The %s owner is too poor to subsidize this sale!",

	-- Police
	Wanted_text = "Wanted!",
	he_wanted = "Wanted by Police!\nReason: %s",
	youre_unarrested_by = "You were unarrested by %s.",
	hes_arrested = "%s has been arrested for %d seconds!",
	hes_unarrested = "%s has been released from jail!",
	warrant_request = "%s requests a search warrant for %s\nReason: %s",
	warrant_request2 = "Search warrant request sent to Mayor %s!",
	warrant_approved = "Search warrant approved for %s!\nReason: %s\nOrdered by: %s",
	warrant_approved2 = "You are now able to search his house.",
	warrant_denied = "Mayor %s has denied your search warrant request.",
	warrant_expired = "The search warrant for %s has expired!",
	warrant_required = "You need a warrant in order to be able to open this door.",
	warrant_required_unfreeze = "You need a warrant in order to be able to unfreeze this prop.",
	warrant_required_unweld = "You need a warrant in order to be able to unweld this prop.",
	wanted_by_police = "%s is wanted by the police!\nReason: %s\nOrdered by: %s",
	wanted_by_police_noactor = "%s is wanted by the police!\nReason: %s",
	wanted_expired = "%s is no longer wanted by the Police.",
	wanted_revoked = "%s is no longer wanted by the Police.\nRevoked by: %s",
	cant_arrest_other_cp = "You cannot arrest other CPs!",
	must_be_wanted_for_arrest = "The player must be wanted in order to be able to arrest them.",
	cant_arrest_no_jail_pos = "You cannot arrest people since there are no jail positions set!",
	cant_arrest_spawning_players = "You cannot arrest players who are spawning.",
	escape_from_jail = "escape from jail",
	need_policeres = "Need %d police tokens",

	suspect_doesnt_exist = "Suspect does not exist.",
	actor_doesnt_exist = "Actor does not exist.",
	get_a_warrant = "Get a warrant",
	give_warrant = "Give a warrant",
	make_someone_wanted = "Make someone wanted",
	remove_wanted_status = "Remove wanted status",
	already_a_warrant = "There already is a search warrant for this suspect.",
	already_wanted = "The suspect is already wanted.",
	not_wanted = "The suspect is not wanted.",
	need_to_be_cp = "You have to be a member of the police force.",
	suspect_must_be_alive_to_do_x = "The suspect must be alive in order to %s.",
	suspect_already_arrested = "The suspect is already in jail.",

	-- Mayor
	curfew = "Mayor has issued a curfew: ",

	-- Players
	health = "Health: %s",
	job = "Job: %s",
	job_s = "Job",
	salary = "Salary: %s%s",
	wallet = "Wallet: %s%s",
	weapon = "Weapon: %s",
	kills = "Kills: %s",
	deaths = "Deaths: %s",
	rpname_changed = "%s changed their RPName to: %s",
	disconnected_player = "Disconnected player",
	hunger = "Hunger: ",
	starving = "STARVING",
	armor = "Armor: ",
	in_jail = "In jail%s. Time left: %d seconds",
	with_license = "With license",
	radio_disabled = "Radio is disabled",
	wanted = "Wanted: ",

	-- Cars
	rented_car_tag = "Rent",
	path = "Path: ",
	m = "%d m",
	km = "%.1f km",
	speed = "Speed: ",
	kmh = "%d km/h",

	-- Teams
	need_to_be_before = "You need to be %s first in order to be able to become %s",
	need_to_make_vote = "You need to make a vote to become a %s!",
	team_limit_reached = "Can not become %s as the limit is reached",
	wants_to_be = "%s\nwants to be\n%s",
	has_not_been_made_team = "%s has not been made %s!",
	job_has_become = "%s has been made a %s!",

	-- Keys, vehicles and doors
	keys_allowed_to_coown = "You are allowed to co-own this\n(Press C to co-own)\n",
	keys_other_allowed = "Allowed to co-own:",
	keys_allow_ownership = "(Press C to allow ownership)",
	keys_disallow_ownership = "(Press C to disallow ownership)",
	keys_owned_by = "Owned by:",
	keys_unowned = "Unowned\n(Press C to own)",
	keys_everyone = "(Press C to enable for everyone)",
	door_unown_arrested = "You can not own or unown things while arrested!",
	door_unownable = "This door cannot be owned or unowned!",
	door_sold = "You have sold this for %s",
	door_already_owned = "This door is already owned by someone!",
	door_cannot_afford = "You can not afford this door!",
	door_hobo_unable = "You can not buy a door if you are a hobo!",
	vehicle_cannot_afford = "You can not afford this vehicle!",
	door_bought = "You've bought this door for %s%s",
	vehicle_bought = "You've bought this vehicle for %s%s",
	door_need_to_own = "You need to own this door in order to be able to %s",
	door_rem_owners_unownable = "You can not remove owners if a door is non-ownable!",
	door_add_owners_unownable = "You can not add owners if a door is non-ownable!",
	rp_addowner_already_owns_door = "%s already owns (or is already allowed to own) this door!",
	add_owner = "Add owner",
	remove_owner = "Remove owner",
	coown_x = "Co-own %s",
	allow_ownership = "Allow ownership",
	disallow_ownership = "Disallow ownership",
	edit_door_group = "Edit door group",
	door_groups = "Door groups",
	door_group_doesnt_exist = "Door group does not exist!",
	door_group_set = "Door group set successfully.",
	sold_x_doors_for_y = "You have sold %d doors for %s%d!", -- backwards compatibility
	sold_x_doors = "You have sold %d doors for %s!",

	-- Entities
	gmod_camera = "Camera",
	gmod_tool = "Tool Gun",
	weapon_bugbait = "Pile of Trash",
	weapon_physcannon = "Gravity Gun",
	weapon_physgun = "Physgun",

	drugs = "Drugs",
	drug_lab = "Drug Lab",
	gun_lab = "Gun Lab",
	gun = "gun",
	microwave = "Microwave",
	food = "Food",
	money_printer = "Money Printer",

	write_letter = "Write a letter...",
	send = "Send",
	sign_this_letter = "Sign this letter",
	signed_yours = "Yours,",

	money_printer_exploded = "Your money printer has exploded!",
	money_printer_overheating = "Your money printer is overheating!",

	previous_owner_nof = "Previous: ",
	microwave_steal = "Press here to steal",
	microwave_hacking = "Hacking...",
	microwave_alreadyown = "You already own this microwave!",
	microwave_alert = "Your microwave is getting stolen!",

	camera_destroyed = "Your camera was destroyed!",

	contents = "Contents: ",
	amount = "Amount: ",

	picking_lock = "Picking lock",

	cannot_pocket_x = "You cannot put this in your pocket!",
	object_too_heavy = "This object is too heavy.",
	pocket_full = "Your pocket is full!",
	pocket_no_items = "Your pocket contains no items.",
	drop_item = "Drop item",
	drop_ammo = "Drop ammo/attachments",

	pickup_item = "Pick up item",
	put_item_in_pocket = "Put item in pocket",
	drop_last_item = "Drop last item",
	inventory = "Inventory",

	bonus_destroying_entity = "destroying this illegal entity.",

	switched_burst = "Switched to burst-fire mode.",
	switched_fully_auto = "Switched to fully automatic fire mode.",
	switched_semi_auto = "Switched to semi-automatic fire mode.",

	keypad_checker_shoot_keypad = "Shoot a keypad to see what it controls.",
	keypad_checker_shoot_entity = "Shoot an entity to see which keypads are connected to it",
	keypad_checker_click_to_clear = "Right click to clear.",
	keypad_checker_entering_right_pass = "Entering the right password",
	keypad_checker_entering_wrong_pass = "Entering the wrong password",
	keypad_checker_after_right_pass = "after having entered the right password",
	keypad_checker_after_wrong_pass = "after having entered the wrong password",
	keypad_checker_right_pass_entered = "Right password entered",
	keypad_checker_wrong_pass_entered = "Wrong password entered",
	keypad_checker_controls_x_entities = "This keypad controls %d entities",
	keypad_checker_controlled_by_x_keypads = "This entity is controlled by %d keypads",
	keypad_on = "ON",
	keypad_off = "OFF",
	seconds = "seconds",

	persons_weapons = "%s's illegal weapons:",
	returned_persons_weapons = "Returned %s's confiscated weapons.",
	no_weapons_confiscated = "%s had no weapons confiscated!",
	no_illegal_weapons = "%s had no illegal weapons.",
	confiscated_these_weapons = "Confiscated these weapons:",
	checking_weapons = "Checking weapons",

	shipment_antispam_wait = "Please wait before spawning another shipment.",
	shipment_cannot_split = "Cannot split this shipment.",

	-- Talking
	hear_noone = "No-one can hear you %s!",
	hear_everyone = "Everyone can hear you!",
	hear_certain_persons = "Players who can hear you %s: ",

	whisper = "whisper",
	yell = "yell",
	advert = "[Advert]",
	broadcast = "[Broadcast!]",
	radio = "radio",
	request = "(REQUEST!)",
	group = "(group)",
	demote = "(DEMOTE)",
	ooc = "City",
	chat_in_region = "Region",
	radio_x = "Radio %d",

	talk = "talk",
	speak = "speak",

	speak_in_ooc = "city feed",
	perform_your_action = "perform your action",
	talk_to_your_group = "talk to your group",

	channel_set_to_x = "Channel set to %s!",
	channel_not_set = "Radio channel not set (use F-menu to set).",

	-- Notifies
	disabled = "%s has been disabled! %s",
	gm_spawnvehicle = "The spawning of vehicles",
	gm_spawnsent = "The spawning of scripted entities (SENTs)",
	gm_spawnnpc = "The spawning of Non-Player Characters (NPCs)",
	see_settings = "Please see the DarkRP settings.",
	limit = "You have reached the %s limit!",
	have_to_wait = "You need to wait another %d seconds before using %s!",
	must_be_looking_at = "You need to be looking at a %s!",
	incorrect_job = "You do not have the right job to %s",
	unavailable = "This %s is unavailable",
	unable = "You are unable to %s. %s",
	cant_afford = "You cannot afford this %s",
	cleaned_up = "Your %s were cleaned up.",
	you_bought_x = "You have bought %s for %s%d.", -- backwards compatibility
	you_bought = "You have bought %s for %s.",
	you_received_x = "You have received %s for %s.",

	created_first_jailpos = "You have created the first jail position!",
	added_jailpos = "You have added one extra jail position!",
	reset_add_jailpos = "You have removed all jail positions and you have added a new one here.",
	created_spawnpos = "%s's spawn position created.",
	updated_spawnpos = "%s's spawn position updated.",
	do_not_own_ent = "You do not own this entity!",
	cannot_drop_weapon = "Can't drop this weapon!",
	job_switch = "Jobs switched successfully!",
	job_switch_question = "Switch jobs with %s?",
	job_switch_requested = "Job switch requested.",

	cooks_only = "Cooks only.",

	-- Misc
	unknown = "Unknown",
	arguments = "arguments",
	no_one = "no one",
	door = "door",
	vehicle = "vehicle",
	door_or_vehicle = "door/vehicle",
	name = "Name: %s",
	lock = "Lock",
	locked = "Locked",
	unlock = "Unlock",
	unlocked = "Unlocked",
	player_doesnt_exist = "Player does not exist.",
	job_doesnt_exist = "Job does not exist!",
	must_be_alive_to_do_x = "You must be alive in order to %s.",
	banned_or_demoted = "Banned/demoted",
	wait_with_that = "Wait with that.",
	could_not_find = "Could not find %s",
	f3tovote = "Hit F3 to vote",
	listen_up = "Listen up:", -- In rp_tell or rp_tellall
	nlr = "New Life Rule: Do Not Revenge Arrest/Kill.",
	reset_settings = "You have reset all settings!",
	must_be_x = "You must be a %s in order to be able to %s.",
	agenda_updated = "The agenda has been updated",
	job_set = "%s has set his/her job to '%s'",
	demoted = "%s has been demoted",
	demoted_not = "%s has not been demoted",
	demoted_not_quorum = "%s has not been demoted (no quorum)",
	demote_vote_started = "%s has started a vote for the demotion of %s",
	demote_vote_text = "Demotion nominee:\n%s", -- '%s' is the reason here
	cant_demote_self = "You cannot demote yourself.",
	i_want_to_demote_you = "I want to demote you. Reason: %s",
	x_wants_to_demote_you_for_x = "wants to demote you for",
	tried_to_avoid_demotion = "You tried to escape demotion. You failed and have been demoted.", -- naughty boy!
	lockdown_started = "The mayor has initiated a Lockdown, please return to your homes!",
	lockdown_ended = "The lockdown has ended",
	gunlicense_requested = "%s has requested %s a gun license",
	gunlicense_granted = "%s has granted %s a gun license",
	gunlicense_denied = "%s has denied %s a gun license",
	gunlicense_question_text = "Grant %s a gun license?",
	gunlicense_remove_vote_text = "%s has started a vote for the gun license removal of %s",
	gunlicense_remove_vote_text2 = "Revoke gunlicense:\n%s", -- Where %s is the reason
	gunlicense_removed = "%s's license has been removed!",
	gunlicense_not_removed = "%s's license has not been removed!",
	vote_specify_reason = "You need to specify a reason!",
	vote_started = "The vote is created",
	vote_alone = "You have won the vote since you are alone in the server.",
	you_cannot_vote = "You cannot vote!",
	x_cancelled_vote = "%s cancelled the last vote.",
	cant_cancel_vote = "Could not cancel the last vote as there was no last vote to cancel!",
	jail_punishment = "Punishment for disconnecting! Jailed for: %d seconds.",
	frozen = "Frozen.",
	yes_demote = "Yes, demote them",
	no_demote = "No, don't demote",
	dont_vote = "Don't vote",
	demote_rule = [[Vote wisely, don't randomly press "yes" or "no" in votes. If you're unsure - press "not voting".]],

	dead_in_jail = "You now are dead until your jail time is up!",

	credits_for = "CREDITS FOR %s\n",
	credits_see_console = "DarkRP credits printed to console.",

	data_not_loaded_one = "Your data has not been loaded yet. Please wait.",
	data_not_loaded_two = "If this persists, try rejoining or contacting an admin.",

	cant_spawn_weapons = "You cannot spawn weapons.",
	drive_disabled = "Drive disabled for now.",
	property_disabled = "Property disabled for now.",

	not_allowed_to_purchase = "You are not allowed to purchase this item.",

	already_taken = "Already taken.",

	-- The lottery
	lottery_started = "There is a lottery! Participate for %s%d?", -- backwards compatibility
	lottery_has_started = "There is a lottery! Participate for %s?",
	lottery_entered = "You entered the lottery for %s",
	lottery_not_entered = "%s did not enter the lottery",
	lottery_noone_entered = "No-one has entered the lottery",
	lottery_won = "%s has won the lottery! He has won %s",
	lottery_you_won = "You won the lottery!",
	lottery_msg = "Lottery %s has started",

	-- Animations
	custom_animation = "Custom animation!",
	bow = "Bow",
	dance = "Dance 'Flex'",
	follow_me = "Follow me!",
	laugh = "Laugh",
	lion_pose = "Lion pose",
	nonverbal_no = "Non-verbal no",
	thumbs_up = "Thumbs up",
	wave = "Wave",
	dance2 = "Dance",
	cheer = "Cheer",
	salute = "Salute",
	robot = "Robot",
	animations = "Gestures",

	-- AFK
	afk_mode = "AFK Mode",
	salary_frozen = "Your salary has been frozen.",
	salary_restored = "Welcome back, your salary has now been restored.",
	no_auto_demote = "You will not be auto-demoted.",
	youre_afk_demoted = "You were demoted for being AFK for too long. Next time use /afk.",
	hes_afk_demoted = "%s has been demoted for being AFK for too long.",
	afk_cmd_to_exit = "Type /afk again to exit AFK mode.",
	player_now_afk = "%s is now AFK.",
	player_no_longer_afk = "%s is no longer AFK.",

	-- Hitmenu
	hit = "hit",
	hitman = "Hitman",
	current_hit = "Hit: %s",
	cannot_request_hit = "Cannot request hit! %s",
	hitmenu_request = "Request",
	player_not_hitman = "This player is not a hitman!",
	distance_too_big = "Distance too big.",
	hitman_no_suicide = "The hitman won't kill himself.",
	hitman_no_self_order = "A hitman cannot order a hit for himself.",
	hitman_already_has_hit = "The hitman already has a hit ongoing.",
	price_too_low = "Price too low!",
	hit_target_recently_killed_by_hit = "The target was recently killed by a hit,",
	customer_recently_bought_hit = "The customer has recently requested a hit.",
	accept_hit_question = "Accept hit from %s\nregarding %s for %s%d?", -- backwards compatibility
	accept_hit_request = "Accept hit from %s\nregarding %s for %s?",
	hit_requested = "Hit requested!",
	hit_aborted = "Hit aborted! %s",
	hit_accepted = "Hit accepted!",
	hit_declined = "The hitman declined the hit!",
	hitman_left_server = "The hitman has left the server!",
	customer_left_server = "The customer has left the server!",
	target_left_server = "The target has left the server!",
	hit_price_set_to_x = "Hit price set to %s%d.", -- backwards compatibility
	hit_price_set = "Hit price set to %s.",
	hit_complete = "Hit by %s complete!",
	hitman_died = "The hitman died!",
	target_died = "The target has died!",
	hitman_arrested = "The hitman was arrested!",
	hitman_changed_team = "The hitman changed team!",
	x_had_hit_ordered_by_y = "%s had an active hit ordered by %s",

	-- Hits
	hit_errors = {
		no_access = "no access",
		not_found = "contract not found",
		same_request = "contract is similar to existing",
		same_subscribe = "you are already subscribed",
		cant_subscribe = "can't subscribe",
		too_many = "subscriptions limit hit",
		bad_reward = "reward doesn't meet requirements",
		cant_afford = "not enough money",
		no_clients = "clients cancelled contract",
		victim_left = "victim left the city",
		victim_changed_team = "victim changed their profession and contract's minimal reward has increased",
		victim_cooldown = "this target has already been eliminated by a recent contract, please wait %s",
	},

	hits_menu_subscriptions_title = "Mercenary orders",
	hits_menu_subscriptions_hint = "You subscribe up to 3 hits simultaneously.\nIf you have allies, they can help you with completing these contracts.",
	hits_menu_subscriptions_empty = "There's no contracts yet, watch for notifications.",
	hits_menu_subscriptions_subscribe =  "Subscribe",
	hits_menu_subscriptions_unsubscribe =  "Unsubscribe",

	hits_menu_makehit_title = "Order Mercenary Services",
	hits_menu_makehit_target = "Target",
	hits_menu_makehit_reason = "Reason",
	hits_menu_makehit_reason_hint = "Any hit request should follow with adequate reason. Hit without reason is RDM.\nClient is responsible in case of Hit-RDM, not mercenary.",
	hits_menu_makehit_reward = "Reward",
	hits_menu_makehit_reward_minam = "Minimal amount: %s. Higher reward makes your contract more likely to be completed soon.",
	hits_menu_makehit_reward_job = " (depends on victim's job)",
	hits_menu_makehit_submit = "Make a hit!",

	hits_menu_ctrlhit_title = "My Contracts",
	hits_menu_ctrlhit_empty = "You haven't ordered mercenary services yet. Maybe it's just about time to do so?",
	hits_menu_ctrlhit_empty_makeone = "Make a contract",

	hits_msg_created = "%s was created!",
	hits_msg_new_available = "%s is now available!",
	hits_msg_create_fail = "Couldn't create contract, %s",
	hits_msg_removed = "%s was removed!",
	hits_msg_remove_fail = "Couldn't remove contract, %s",
	hits_msg_subscribed = "Subscribed to %s!",
	hits_msg_subscribed_boss = "Mob Boss has subscribed to %s!",
	hits_msg_subscribe_fail = "Couldn't subscribe, %s",
	hits_msg_unsubbed = "Unsubscribed from %s!",
	hits_msg_unsubbed_boss = "Mob Boss has unsubscribed from %s!",
	hits_msg_unsub_fail = "Couldn't unsubscribe, %s",
	hit_msg_completed_client = "%s has been completed!",
	hit_msg_completed_for = "%s completed for %s!",
	hit_msg_completed_for_boss = "%s completed %s! You gain %s",
	hit_msg_completed = "%s is complete! You gain %s",
	hit_msg_aborted = "%s was cancelled, %s",
	hit_msg_finished_by_other = "%s was finished by other mercenary!",
	hits_msg_need_target = "Pick a target!",
	hits_msg_need_reason = "Specify a reason!",
	hits_msg_cop_fail = "Fail, police killed mercenary with necessary clues",
	hits_msg_cop_success = "Success! Police has arrested mercenary. Conducting search for clients!",
	hits_msg_cop_found = "Customers of crime were found, arrest them!",
	hits_msg_you_dead = "You were assassinated by hitman!",

	hit_selfdesc_kill = "Contract to eliminate %s",
	hit_selfdescobj_kill = "Eliminate %s",

	hit_letter_title = "Hit list",

	dealer_title = "Criminal Services",
	dealer_buy_printer = "Purchase Printer",

	hits_hud_target = "Targets",
	hits_hud_hint = "Subscribe to %d contracts from %d available",

	hits_wanted_reason = "Customer of crime",

	dealer_sellgoods = "Sell Illegal Goods",
	sold_x_goods = "You have sold %d goods for %s!",
	goods_onlygang = "Only mobsters can sell illegal goods!",

	-- Shops

	shop_hint_res = "You don't have enough resources to sell goods to your customers\nVisit any $ checkpoint on map to get resources",
	shop_hint_location = "Set your shop in appropriate place and seek for customers",
	open_shop_gui = "Open shop",
	finish_purchase = "Finish purchase",
	set_profit_margin_percent = "Set profit margin percent",
	trading_merchantry = "Shop Management",

	finish_purchase_hint = "Press E on trader again to finish purchase",
	purchase_sent = "Request sent to trader",
	purchase_ques = "Do you confirm %s's purchase?",
	purchase_ques_fail = "Trader couldn't confirm your purchase",
	deal_fail_space = "Nowhere to place items!",
	deal_fail_res = "Shop can not produce these items!",

	shops_finish_purchase = "Finish purchase",
	shops_total_stat = "Total: %s",

	resdealer_but = "Get %d RES for %s",
	resdealer_msg = "Got %d RES for %s",
	resdealer_title = "Resource Dealer",
	resdealer_subtitle = "Resources for your shop",

	remove_current_ammo = "Eject ammo",

	shop_equipment = "Equipment",
	shop_foodstuffs = "Foodstuffs",

	floor = "Floor",
	ground = "Ground",

	deployable = "Deployable",
	stackable = "Stackable",
	canpocket = "Fits in pocket",

	no_place_excl = "No space!",

	-- Vote Restrictions
	hobos_no_rights = "Hobos have no voting rights!",
	gangsters_cant_vote_for_government = "Gangsters cannot vote for government things!",
	government_cant_vote_for_gangsters = "Government officials cannot vote for gangster things!",

	-- VGUI and some more doors/vehicles
	vote = "Vote",
	time = "Time: %d",
	yes = "Yes",
	no = "No",
	ok = "Okay",
	cancel = "Cancel",
	add = "Add",
	remove = "Remove",
	none = "None",
	none_alt = "none",
	confirmed = "Confirmed",
	v_back = "< Back",
	esc_back = "[ESC] Back",

	x_options = "%s options",
	sell_x = "Sell %s",
	set_x_title = "Set %s title",
	set_x_title_long = "Set the title of the %s you are looking at.",
	jobs = "Jobs",
	menu = "Menu",
	buy_x = "Buy %s",

	-- F4menu
	no_extra_weapons = "This job has no extra weapons.",
	become_job = "Become job",
	create_vote_for_job = "Create vote",
	participate_in_elections = "Participate in election",
	shipments = "Shipments",
	F4guns = "Weapons",
	F4entities = "Devices and Items",
	F4ammo = "Ammo",
	F4vehicles = "Vehicles",
	F4premium = "Premium-offers",
	F4cars = "Automobiles",
	F4hats = "Apparel",
	F4attachments = "Attachments",

	-- Tab 1
	give_money = "Give money",
	drop_money = "Drop money",
	change_name = "Change your roleplay name",
	go_to_sleep = "Go to sleep/wake up",
	drop_weapon = "Drop current weapon",
	drop_weapon_s = "Drop",
	customize_weapon = "Customize this weapon",
	customize_weapon_s = "Customize",
	buy_health = "Buy health(%s)",
	request_gunlicense = "Request gunlicense",
	demote_player_menu = "Demote a player",


	searchwarrantbutton = "Make a player wanted",
	unwarrantbutton = "Remove the wanted status from a player",
	noone_available = "No one available",
	request_warrant = "Request a search warrant for a player",
	make_wanted = "Make someone wanted",
	make_unwanted = "Make someone unwanted",
	set_jailpos = "Set the jail position",
	add_jailpos = "Add a jail position",

	set_custom_job = "Set a custom job",

	set_agenda = "Set the agenda",

	initiate_lockdown = "Initiate a lockdown",
	stop_lockdown = "Stop the lockdown",
	start_lottery = "Start a lottery",
	give_license_lookingat = "Give license",

	laws_of_the_land = "LAWS OF THE LAND",
	law_added = "Law added.",
	law_removed = "Law removed.",
	law_reset = "Laws reset.",
	laws_full = "The laws are full.",
	default_law_change_denied = "You are not allowed to change the default laws.",

	-- Second tab
	job_name = "Name: ",
	job_description = "Description: ",
	job_weapons = "Weapons: ",

	-- Entities tab
	buy_a = "Buy %s: %s",

	-- Licenseweaponstab
	license_tab = [[License weapons

	Tick the weapons people should be able to get WITHOUT a license!
	]],
	license_tab_other_weapons = "Other weapons:",

	-- Car Terminal
	car_terminal = "Car Terminal",

	-- Destroyer
	destroyer_message = "Destroyer: Drop here money printers, drugs or weapons to obtain reward.",
	destroyer_reward = "Reward for destroying an illegal item: %s!",
	destroyer_bringthis = "Bring this to the Destroyer in Police Department to obtain your reward.",

	-- Printer
	printer_disabled = "Printer is disabled. Bring it to the Destroyer in Police Department to obtain your reward.",
	printer_fixed = "Police block is withdrawn. Printer is functional now.",
	printer_warning = "Warning!\nCareless use may lead to ignition!",
	printer_error = "Printing not possible!\nNo space for money ejection.",
	printer_speed = "Speed",
	printer_speed_upgrade = "Speed Upgrade",
	printer_rely = "Reliability",
	printer_rely_upgrade = "Reliability Upgrade",
	printer_start = "Start printing",
	printer_stop = "Stop printing",
	printer_auto = "Auto-repeat",
	printer_update = "Upgrade for %s",
	printer_collect = "Collect money",
	printer_printed = "Printed: %s",
	printer_onlygang_use = "Only mobsters can use money printers!",
	printer_onlygang_buy = "Only mobsters can purchase money printers!",
	printer_already_x = "You already have %d running printers!",

	-- Jobs
	citizens = "Citizens",
	law_enforcement = "Law Enforcement",
	criminal = "Criminal Elements",
	criminal_business = "Criminal Business",
	city_service = "City Services",
	business = "Business",

	citizen = "Citizen",
	citizen_desc = [[Citizen is the most basic social level which you can occupy.
	You don't have specific role in city life.
	You can think of your own job and do your own business.]],

	hobo = "Homeless",
	hobo_desc = [[Homeless is the lowest member of society. Everyone laughs at you.
	You don't have a home, you're obliged to ask for food and money.
	Build your house out of cardboards and trash, to save yourself from cold.]],

	fishman = "Fishman",
	fishman_desc = [[Use your skills to catch loot for sale.
	Buy baits and upgrade your rod to get more loot.

	Press B, while holding Fishing Rod, to open Fishing Mod menu.]],

	cp = "Police Officer",
	cp_desc = [[Police Officer protects every citizen in the city.
	You have the power to arrest criminals and protect innocents.
	Crush offenders with your StunStick to make them behave.
	Battering Ram can break any door, with appropriate warrant.
	Battering Ram also unfreezes any props.
	Press F to use your abilities.

	Respect the law and be a good example for other citizens.]],
	cp_msg_pos = "Visit Police Department to become a Police Officer.",
	cp_msg_wanted = "Can't become a Police Officer while being wanted.",

	chief = "Chief of Police",
	chief_desc = [[Chief is the head of Police.
		Coordinate your teammates to enforce law in the city.
		Crush offenders with your StunStick to make them behave.
	Battering Ram can break any door, with appropriate warrant.
	Battering Ram also unfreezes any props.
	Press F to use your abilities.

	Respect the law and be a good example for other citizens.]],

	mayor = "City Mayor",
	mayor_desc = [[City Mayor makes laws to improve life of citizens living in this city.
	While you're a mayor, you can create and accept search warrants.
	Press F to use your mayor abilities.

	Write laws in such manner that they don't violate the rules.

	Term of office: 45 minutes]],

	gangster = "Mobster",
	gangster_desc = [[Default class in criminal hierarchy.
	Mobster usually works on Mob Boss, who rules their business.
	Steal, rob, kill for money and follow Boss agenda, or otherwise you'll get punished, probably.]],

	mobboss = "Mob Boss",
	mobboss_desc = [[Mob Boss is the main criminal in the city.
	He leads his mobsters and forms effective criminal groups.
	He's able to ransack appartments and unarrest people.]],
	mobboss_msg = "Become a mobster and create your gang through F-Menu to get this job.",

	merc = "Mercenary",
	merc_desc = [[Mercenary does various job for determined price.
	Your job can be anything: assassination, robbery, scouting and etc.
	Everyone can use your services, including Police, regular citizens and gangsters.]],

	medic = "Medic",
	medic_desc = [[Medic is able to use his medical skills to heal people.
	Use the medkit to heal patients' health and repair broken bones.]],

	gundealer = "Gun Dealer",
	gundealer_desc = [[Gun Dealer is the only person who can legally sell weapons.
	Make sure than you're not selling illegal weaponry in public, so you don't get arrested!]],

	trader = "Trader",
	trader_desc = [[Trader sells variety of useful things like Lockpicks, Chargers and etc.
	Outbid items and weapons. Open your shop and start selling your loot.]],

	bar = "Bartender",
	bar_desc = [[Bartender sells food, drinks and drugs to citizens.
	Open a bar and serve clients. Hire Security to kick off drunk clients.]],

	carmaster = "Car Mechanic",
	carmaster_desc = [[You have skills to fix any car.
	Open a garage, wheere you will offer services to car owners.
	You're also able to refill cars and sell fuel.]],

	security = "Security",
	security_desc = [[Become a securiry guard of local shop or bank. You can also service as bodyguard.
	You must protect establishments from bullies and noob stealers.
	If situation escalates: call the police.
	You're given stunstick by default, so don't risk and thread lightly.]],

	taxidriver = "Taxi Driver",
	taxidriver_desc = [[Lift people on car and get money from it.]],

	fireman = "Firefighter",
	fireman_desc = [[Responsible and very dangerous job.
	Without you our town would be burnt to ashes.
	You get money rewards for extinguishing fires.]],

	busdriver = "Bus Driver",
	busdriver_desc = [[You will be driving a city bus.
	Pick a route from the list and follow it.
	Pick people at bus stops.
	Get rewarded for each completed point.]],

	extinguish_fire = "%s for extinguishing a fire!",
	extinguish_prop = "%s for extinguishing a prop!",
	extinguish_player = "%s for extinguishing a human!",
	extinguish_vehicle = "%s for extinguishing a vehicle!",

	-- Weapons
	wep_nx_c4 = "C4 Charge",
	nx_c4_ammo = "Bomb",
	lockpick = "Lockpick",
	weapon_extinguisher = "Extinguisher",
	nx_radio = "Radio",
	nx_fuel = "Fuel Canister",
	fuel_ammo = "Fuel",
	fas2_ifak = "Infantry Healthkit",
	stunstick = "Stunstick",
	fas2_dv2 = "Combat Knife DV2",
	fas2_machete = "Machete",
	fas2_ots33 = "OTs-33 \"Pernach\"",
	weapon_rpg = "RPG",
	fas2_m67 = "M67 Grenade",
	molotov = "Molotov Cocktail",

	-- Ammo
	ammo = "Ammo",
	RPG_Round = "RPG Round",
	bandages = "Bandages",
	hemostats = "Hemostats",
	quikclots = "Quikclots",

	-- Categories
	devices = "Devices",
	other = "Other",
	pistols = "Pistols",
	smg = "Submachine guns",
	rifles = "Rifles",
	sniper_rifles = "Sniper rifles",
	shotguns = "Shotguns",

	-- Attachments
	sights = "%s Sight",
	tritium_sights = "Tritium Sights",
	foregrip = "Foregrip",
	bipod = "Bipod",
	silencer = "Silencer",
	clip = "%s Clip",

	-- Entities
	soccer_ball = "Soccer Ball",
	piano = "Piano",
	drums = "Drums",
	wepdetector = "Weapon Detector",
	turret = "Turret",
	playxradio = "PlayX Radio",
	playxtv = "PlayX TV",
	playxbillboard = "PlayX Billboard",
	charger_medkit = "Health Charger",
	charger_suit = "Armor Charger",
	radar = "Radar",

	-- Drugs
	beer = "Beer",
	cigarettes = "Cigarettes",
	weed = "Weed",

	-- SWEPs
	keys = "Keys",
	pocket = "Pocket",
	arrest_stick = "Arrest Stick",
	weaponchecker = "Weapon Checker",
	nx_speedmeter = "Speedmeter",
	deployable_tool = "Unpacker",
	nx_repair = "Repair Tool",
	door_ram = "Door Ram",
	binoculars = "Binoculars",
	weapon_popcorn = "Popcorn",

	-- Hints
	bomb_instructions1 = "Drop the bomb",
	bomb_instructions2 = "Put bomb on the wall or car",
	bomb_cant = "Cannot be placed here",

	unpacker_instructions1 = "Place item",
	unpacker_instructions2 = "Rotate item",
	unpacker_instructions3 = "Cancel",
	unpacker_instructions4 = "Hold %s after unpacking",
	unpacker_instructions5 = "to pack item back",

	respawn_timer = "%d seconds remaining until spawn",
	respawn_fee = "You paid %s for medical service",
	premium_only = "This feature is Premium only!",

	hitman_use = "Request a hit",

	rules = "Rules",
	read_rules = "Be sure to read the rules, press ",
	nobind = "[NO BIND]",

	-- Cars
	car_on_fire = "Your car is on fire, evacuation is not possible",
	car_cant_enter_destroyed = "This car is completely destroyed, the door cannot be opened.\nContact Car Mechanic for repair.",
	car_bought = "Car has been bought",
	car_buymsg = "You bought %s.\nUse nearest terminal to spawn this car.",
	car_rentmsg = "You rented %s.\nUse nearest terminal to spawn this car.",
	car_nomoney = "Insufficient funds",
	car_modified = "Car has been modified",
	car_sold = "Car has been sold",
	car_hobos = "Hobos don't have any cars",
	car_coplimit = "Police Car limit reached",
	car_stolen = "Your car was stolen",
	car_spawned = "Car has been spawned",
	car_removed = "Car has been removed",
	car_request = "Let %s in your car?",
	car_request_sent = "Request sent",
	car_request_sent_already = "Request already sent",
	car_ok_but_distance = "Driver has accepted your request, buy you're too far from car now",
	car_ok_but_distance_owner = "Passenger is too far from car now",
	car_retrieved = "Car ownership was returned",
	car_alarm = "Car Alarm!",
	car_lockpick_success = "Successfully stole car!",
	need_warrant = "Warrant required",
	car_rent_broken = "This car is damaged, ask Car Mechanic to repair it",
	car_rent_end = "You no longer rent this car",
	car_rent_premium = "Only Premium users are able to use rented cars.",
	car_rent_need_premium = "Only Premium users are able to rent cars.\nYou can get yourself one in Subscriptions tab.",
	car_rent_limit = "You already have a rented car!",
	car_rent_start = "You can start using your rented car",
	car_rent_stop = "Stop renting this car",
	car_rent_stop_ask = "Do you want to return car to lessor?",

	my_cars = "My cars",
	buy = "Buy",
	car_spawn = "Spawn",
	car_modify = "Modify",
	car_sell_for = "Sell: ",
	sell_x_for_x = "Sell %s for %s?",
	modify_x_for_x = "Modify %s for %s?",
	car_sell = "Sell car",
	car_modification = "Modify car",
	car_apply = "Apply: ",
	car_driver = "Driver:",
	car_passenger = "Passenger %d:",
	car = "Car",
	car_kick = "Kick",
	previous_owner = "Previous owner: %s",
	taxi_popup = "Taxi %s/km",
	car_retrieval = "Returning car back",

	car_destroyed_fine = "%s fine for destroying vehicle!",
	car_rent_stopped = "Insufficient funds to pay for car rent, rent stopped",
	car_rent_paid = "Car rent paid: %s",
	car_rent_paid_fine = "Fine has been paid, now you can rent a vehicle again",
	car_rent_cant_pay_fine = "Insufficient funds to pay for fine",
	car_rent_banned = "You were banned from rent for %s",

	cars_unavail = "You have no cars available",
	cars_unavail_hint = "Cars can be purchased for money or given from some jobs",

	-- Laws
	laws_title = "Laws of the land",
	laws_speedlimit = "Speed limit for vehicles: ",
	laws_kmh = " km/h",
	laws_legal = "Legal",
	laws_license = "Requires license",
	laws_illegal = "Illegal",
	close = "Close",
	close_and_dont_show_for_week = "Close and don't show for a week",
	apply = "Apply",
	laws_added = "City Mayor added law no. ",
	laws_edited = "City Mayor edited law no. ",
	laws_removed = "City Mayor removed law no. ",
	laws_set = "Setting laws of ",
	laws_clear = "City Mayor cleared laws.",
	laws_reset = "City Mayor reset laws.",
	laws_default = "Default laws were restored.",

	-- City Management
	cc_cityman = "City Management",
	cc_copman = "Police Management",
	cc_laws = "Laws",
	cc_limits = "Restrictions",
	cc_orders = "Orders",
	cc_upgrades = "Upgrades",
	cc_points = "Government Credits: ",
	cc_save = "<Enter> - save changes",
	cc_resetlaws = "Reset laws to defaults",
	cc_clearlaws = "Clear all laws",
	cc_addlaw = "Add a law",
	cc_lawlimit = "Law limit hit!",
	cc_lawtext = "Text of law",
	cc_invitecop = "Invite to the Police",
	cc_kickcop = "Kick from the Police",
	cc_assignchief = "Promote to Chief of the Police",
	cc_helicopter = "Purchase helicopter",

	-- City Management SV
	cc_limitschanged = "City Mayor has edited restrictions.",
	cc_invitetext = "%s asks you to join the Police",
	cc_invited = "City Mayor invited %s in the Police.",
	cc_invite_fail_ban = "%s is unable to become a police officer.",
	cc_nopoints = "Insufficient Government Credits",
	cc_kicked = "%s has relieved %s of duty. Reason: %s",
	cc_chiefassigned = "City Mayor promoted %s to Chief of the Police.",
	cc_upgradedalready = "Upgrade already bought",
	cc_upgraded = "You've bought '%s' upgrade",
	cc_mayor_upgraded = "%s bought '%s' upgrade",
	cc_helicopter_spawned = "Helicopter delivered to helipad",
	cc_helicopter_obstructed = "Helicopter pad is obstructed!",

	lockdown_reason = "Reason: %s",
	door_cp = "Law Enforcement",
	agenda_cp = "Police Agenda",

	police_halo = "Police Radar",
	gang_halo = "Gang Radar",
	door_upgrade = "Enhanced Doors",

	charger_medkit_desc = "Health Charger appears in Police Department.",
	charger_suit_desc = "Armor Charger appears in Police Department.",
	door_upgrade_desc = "Government doors receive touch lock/unlock screen.",
	police_halo_desc = "Teammates receive green outline through walls. If teammate talks into radio, his outline becomes blue. If teammate gets hurt, his outline becomes red for a moment.",
	microwave_desc = "Microwave appears in Police Department.",
	radio_desc = "All gang members automatically receive a radio.",

	-- CMenu
	actions = "Actions",
	quick_actions = "Quick actions",
	issue_cheque = "Issue a cheque",
	buy_current_ammo = "Buy ammo for current weapon",
	buy_current_ammo_s = "Buy ammo",
	call_to = "Make a call",
	call_emergency = "Call an Emergency",
	call_service = "Call an Emergency or Service",
	police = "Police",
	police_call = "Call the Police",
	ambulance = "Ambulance",
	ambulance_call = "Call an Ambulance",
	fire_service = "Fire Service",
	call_fire_service = "Call Fire Service",
	describe_problem = "Describe your problem",
	buy_printer = "Contact Printer Seller",
	phone_off = "Turn off phone",
	phone_on = "Turn on phone",
	phone_off_s = "Turn off",
	phone_on_s = "Turn on",
	phone_is_off = "Phone turned off",
	phone_is_on = "Phone turned on",
	option_gang = "- Gang -",
	call_taxi = "Call a taxi",
	write_letter = "Write a letter",
	show_laws = "Read laws",
	upgrades = "Upgrades",
	roll_the_dice = "Roll the dice",
	roll_sides = "Number of sides",
	demote_warn = "Use demote only if you're 100%% convinced of your rightness.\n\nEvery demote vote should have an appropriate, truthful reason in accordance with rules, without insults.\nYou are not allowed to initiate demote votes if there's no rule breaking.\n\nDemote abuse may lead to ban.",
	demote_reason = "Enter reason:",
	demote_prem = "This feature is Premium only!\n\nDo you want to know more about Premium subscription?",
	sell_all_doors = "Sell all doors",
	enter_new_title = "Enter new title",
	edit_model = "Setup your model",
	remove_car = "Remove car",
	turret_control = "Turret control",
	set_shop_pos = "Set shop position",
	shop_pos_set = "Your shop position was updated",
	microwave_setprice = "Set price for microwave use",
	taxi_setprice = "Set price for kilometer",
	hitman_setprice = "Set price for hit",
	enter_price = "Enter price",
	enter_reason = "Enter reason",
	enter_reason_suspect = "Suspect: %s\n\nEnter reason",
	stop_dna_scan = "Stop DNA scan",
	enter_entry_cost = "Enter entry cost",
	select_radio_channel = "Change radio channel",
	radio_off = "Turn off radio",
	radio_on = "Turn on radio",
	ballot_reopen = "Open election ballot",
	phone_printer_hint = "Need money? Money printers — easy but criminal way to get money.",
	phone_printer_hint_new = "Need money? Money printers — easy but criminal way to get money.\nYou need to be mobster to buy and use printers.",
	phone_business_hint = "Various businessmen can satisfy your needs. Some of them aren't so legal.",
	phone_cityserv_hint = "Contact city services",
	no_actions = "No actions",
	drop_item_hint = "Click an item to drop",
	x_interactions = "%d interactions",

	create_group = "Create new gang",
	manage_group = "Manage your gang",
	leave_group = "Leave gang",
	enter_summ = "Enter summ",
	unarrest_player = "Unarrest from jail",
	split_shipment = "Split shipment",
	make_shipment = "Make shipment from weapon",
	pack = "Pack",

	cmenu_hint = "Press it to see possible actions",
	hint = "Hint",

	-- bomb
	bomb_code = "Code:",
	timer_until = "Timer (seconds):",
	start_timer = "Start timer",
	take_bomb = "Take bomb",
	stop_timer = "Stop timer",
	wrong_code = "Wrong code",
	letter_code = "Bomb code is ",
	disarm = "Disarm",

	-- weplocker
	pwl_title = "Police Weapon Locker",
	pwl_count = "Police arms taken: ",
	pwl_warn = "You won't be able to take weapons, if you hurt other police officers.",
	pwl_wep = "Weapon",
	pwl_avail_c = "Availability",
	pwl_taken = "taken",
	pwl_avail = "available",
	pwl_unavail = "unavailable",
	pwl_giveme = "Take selected weapon",
	pwl_timer = "Time until next issue: ",
	pwl_return = "Return taken weapon",
	pwl_close = "Close locker",

	pwl_fail_team = "Only Police Officers can take weapons from locker.",
	pwl_fail_already = "You're already carrying weapon from locker.",
	pwl_fail_taken = "This weapon is taken by another officer.",
	pwl_fail_limit = "Limit of weapons taken from locker hit.",
	pwl_wait = "Wait %d seconds.",
	pwl_success = "Weapon taken.",
	pwl_returned = "Weapon returned.",

	pwl_unit_lightassault = "Assault",
	pwl_unit_heavyassault = "Support",
	pwl_unit_sniper = "Sniper",
	pwl_unit_demolition = "Demolition",

	--
	radar_already = "You already have a radar.",
	c4_defuser = "Defuse Kit",

	unpacker_packed = "Item packed back into box",
	unpacker_toofar = "You're too far from the box",

	radio_instructions1 = "Talk into radio",
	radio_instructions2 = "Selecting radio SWEP won't do anything",
	radio_instructions3 = "as its sole purpose is giving you ability to drop it",

	repair_paid = "Paid for repair: ",

	speedmeter_instructions = "Order car driver to stop vehicle",
	speedmeter_stopnow = "Police Officer orders you to stop",
	speedmeter_ordered_x = "Driver of %s is ordered to stop",
	speedmeter_ordered = "Driver is ordered to stop",

	wepcheck_legal = "Legal: ",
	wepcheck_illegal = "Illegal: ",
	wepcheck_noweps = " doesn't have any weapons.",
	wepcheck_report = "Weapons in possession",
	wepcheck_inbag = "In pocket:",
	money_printers_genitive = "money printers",
	cantpocket_printer = "You can't pocket printers!",

	-- Food
	pumpkin = "Pumpkin",
	burger = "Cheeseburger",
	hotdog = "Hot-Dog",
	watermelon = "Watermelon",
	soda = "Soda",
	milk = "Milk",
	orange = "Orange",
	water_bottle = "Water Bottle",
	difm_station = "Station",
	difm_silence = "- Enjoy The Silence -",
	difm_volume = "Volume",

	--
	car_hint_coplight = "Press Shift+R to turn signal lights on/off",
	car_hint_taxiprice = "You can change cost per kilometer by pressing F and clicking 'Set price for kilometer' on the right",

	-- Taxi
	taxi_nomoney = "You can't afford to continue this ride!",
	taxi_paid = "Paid %s for taxi ride",
	taxi_payment = "Received %s for ride",
	taxi_setprice_fail = "You can't change price while driving!",
	taxi_setprice_ok = "Set cost to %s per kilometer",
	taxi_nocar = "You need to own a taxi car!",
	call_taxi_fail = "Unfortunately, there's no taxi drivers now.",
	call_taxi_alert = "Calling taxi!",

	--
	demote_restriced = "Demote votes can be started only by Premium users or Administrators",
	fishingmod_you = "[Fishing] You ",
	fishingmod_spent = "spent",
	fishingmod_received = "received",

	--
	coolmodel_enabled = "Replace default models",
	coolmodel_skin = "Skin:",
	coolmodel_respawn = "Changes will take effect after respawn.",
	coolmodel_nopremium = "You don't own Premium, customizable\nmodels won't work.",
	coolmodel_none = "None",
	coolmodel_settings = "Customizations",
	coolmodel_color = "Color",
	coolmodel_title = "Model Customizations",

	--
	he_wants_demote = "%s (%s) wants to demote %s (%s):\n%s",
	he_wants_demote_vgui = "wants to demote",
	he_wants_demote_vgui_res = "with reason:",
	wanna_vote_demote = "%s (%s) wants to demote %s (%s):\n%s\nAre you willing to vote?",
	precache_panic = "Due to the limits of Source Engine, which we can do nothing about,\nserver will be restarted in %d seconds or earlier.\nOtherwise the server would crash.\nPurchased items, jobs and positions will be restored automatically.",
	restartstuff_given = "You received %s for items, owned by you by the time of server shutdown.",
	arrest_reason = "Arrest reason",
	arrested_x = "Arrestee ",

	-- Detective
	dna_crush = "crushed by heavy object",
	dna_bullet = "bullet wound",
	dna_fall = "fall from height",
	dna_blast = "explosion",
	dna_club = "hit with hard object",
	dna_drown = "drowning",
	dna_slash = "knife wounds",
	dna_burn = "fire",
	dna_vehicle = "car accident",
	dna_unknown = "unknown",
	dna_title = "Victim",
	dna_name = "Name of victim: ",
	dna_job = "Job of victim: ",
	dna_time = "Time of death: %d seconds ago",
	dna_reason = "Reason of death: ",
	dna_dist = "Distance to killer: ",
	dna_weapon = "Weapon: ",
	dna_nopoint = "Killer is already dead or arrested",
	dna_destroyed = "DNA was destroyed by recent tests",
	dna_start = "Start scanning killer DNA",
	dna_decoy = "DNA sample of the killer has decayed",
	dna_timeout = "Body will disappear in %d seconds.",
	dna_call = "Call the Police",
	dna_call_done = "Police is called",
	dna_cr = "Here's dead %s!",
	dna_scanner = "DNA scanner",
	dna_scan_name = "Victim: ",
	dna_searching = "Searching for killer",
	dna_next = "Time until next scan: ",
	dna_decoy_time = "DNA will decay in ",
	dna_killer = "Killer of %s",
	dna_killer_dead = "Killer is dead",
	dna_arrest = "Arrest was performed by results of DNA scan",
	dna_killer_arrested = "Killer is arrested",
	dna_killer_leave = "Killer has left the city",
	dna_killer_cop = "Killed by Police",
	dna_killer_hitman = "Killed by Mercenary",

	--
	arrest_question = "Arrested %s\nYes - specify arrest reason\nNo - release from jail\nArrestee will be released automatically, if no reason is specified",
	hitletter = "Hit contract on %s from %s.",

	--
	mayor_overthrown = "City Mayor was overthrown!",
	mayor_danger = "City Mayor in danger! If he gets killed within the next %d minutes, he loses his job.",
	mayor_nodanger = "City Mayor is no longer in danger.",

	-- Group
	gang_creation = "Gang Creation",
	gang_name = "Gang title:",
	gang_info = "At least 2 members should join your gang.",
	gang_create = "Create Gang",
	gang_poor_name = "Poor name",
	gang_few_mates = "Too few members chosen",
	gang_tab_bandits = "Members",
	gang_kick = "Kick",
	gang_invite = "Invite to Gang",
	gang_give = "Give money to members",
	gang_give_title = "Give money to members",
	gang_split = "Split",
	gang_each = "Each",
	gang_split_am = "Amount of %s (split):",
	gang_each_am = "Amount of %s (each):",
	gang_request = "Request money from members",
	gang_request_title = "Request money from members",
	gang_request_am = "Amount of %s (each):",
	gang_disband = "Disband",
	gang_disband_title = "Disband",
	gang_disband_confirm = "Confirm gang disband",
	gang_invite_title = "Invite to Gang",
	gang_send_invites = "Send invites",

	-- Gang SV
	gang_disbanded = "Gang %s (boss: %s) was disbanded",
	gang_job_leaderonly = "Only gang leader can change this",
	gang_name_copy = "Gang with same name exists already",
	gang_mates_fail = "Members weren't chosen, left from server or do not exist",
	gang_accepted = " accepted your invite",
	gang_created = "Gang was created",
	gang_he_created = "%s created gang '%s'",
	gang_not_accepted = " didn't accept your invite",
	gang_not_created = "Gang wasn't created",
	gang_invites_sent = "Invites were sent",
	gang_upgrade_bought = "Gang leader bought %s upgrade",
	gang_invite_text = "Would you like to join %s (boss: %s)?",
	gang_invite_msg = " invites you to join ",
	gang_kicked_you = " kicked you from ",
	gang_kicked = " was kicked from gang",
	gang_job_changed_you = " changed your rank ",
	gang_job_changed = "%s's rank was changed to %s",
	gang_given_each = "Given %s to each member",
	gang_gave_you = " gave you ",
	gang_request_sent = "Requests sent",
	gang_request_text = "Gang leaders asks you to give %s",
	gang_he_gave = " gave ",
	gang_he_left = " has left the gang",
	gang_boss = "Leader of",
	gang_money_warning = "Pay attention to the amount requested by gang leader!",

	-- Markers
	marker_no_police = "Unfortunately, there's no police officers now.",
	marker_no_fire = "Unfortunately, there's no fire fighters now.",
	marker_no_medic = "Unfortunately, there's no medics now.",

	-- Permaupgrades
	up_flashlight = "Flashlight",
	up_flashlight_desc = "Press H, to use flashlight.",
	up_door_upgrade = "Enhanced Doors",
	up_door_upgrade_desc = "All doors owned by you receive touch lock/unlock screen.",
	up_parkour = "Parkour",
	up_parkour_desc = "1 level: ability to dodge once from wall.\n2 level: ability to grab ledges.",
	up_level = " (level ",
	up_bought = "Purchased",
	up_already = "You already have this upgrade",
	up_bought_msg = "Purchased ",
	up_nomoney = "Insufficient funds",

	-- Phone/Radio
	phone = "Phone",
	phone_call_out = "Outgoing call",
	phone_call_in = "Incoming call",
	phone_drop = "Drop",
	phone_answer = "Answer",
	phone_dismiss = "Dismiss",
	phone_already = "Call is already active",
	phone_busy = ": busy",
	phone_remote_off = ": the mobile phone is switched off or out of coverage",
	phone_noans = ": no answer",

	radio_title = "Radio: select channel",
	radio_group_chan = "Group Channel",
	radio_group_chan_ok = "Selected group channel",
	radio_chan = "Channel (1-999):",
	radio_chan_ok = "Selected channel ",
	radio_chan_fail = "Channel should be a number within 1-999.",

	--
	sec = " s",
	tradersell_who = "Who's going to own this?",
	ifak_nomoney = "You're not getting money from healing this person, as you've damaged them",
	dice_roll = "%s rolls the dice (%s). The number is %s.",

	rpname_info = "Think of your roleplay name.\n\nYour roleplay name should be realistic (no to Cat Meow, Crab Man),\nit shouldn't contain redundant punctuation\nand should follow general rules of word capitalization.",
	rpname_name = "Name",
	rpname_surname = "Surname",
	rpname_fail_length_min = "Needs to be no shorter than %d",
	rpname_fail_length_max = "Needs to be no longer than %d",
	rpname_fail_blocked = "Bad name",
	rpname_fail_notallowed = "Includes unallowed characters",
	rpname_fail_exclusive = "hm?", -- not needed for this language
	rpname_fail_words = "2 parts (name and surname) minimum",
	rpname_fail_capital = "Capital letters?",
	rpname_cooldown = "You will be able to change your name after %s",
	rpname_you_are_changing_to = "You are changing your name to",
	rpname_cooldown_alt = "Next time you can change your name after %s",

	premium = "Premium",
	connecting = "Joining",
	score_ingame = " players in game",
	score_and = " and ",
	score_connecting = " joining",

	elevator_title = "TURBOLIFT",
	elevator_hall = "Hall",
	elevator_office = "Offices",

	deployable_onlylast = "Only person who last carried this box can unpack item",
	deployable_wait = "Please wait %d seconds",

	--
	warn_cops = "Warn the Police",
	cr_phrase = "Here's %s wanted by police!",

	widget_rules = "Rules",
	widget_news = "News",
	widget_info = "Guide",
	widget_group = "Steam Group",

	-- elections
	elections_timer = "Election with %d candidates in %s",

	quota = "Quota: %d%% of current players",
	no_quota = "No quota",
	quota_one_man = "One person only",
	quota_notice = "Job limits are based on player amount. More players - more job slots.",
	need_to_be_x = "Need to be %s",
	joining_or = " or ",
	job_singleman_occupied = "Job is occupied",
	job_already = "This is your current job",
	job_limit_hit_premium = "Reached maximum amount of players on this job\nYou can surpass the limit, using Premium subscription",
	job_limit_hit_no_premium = "Reached maximum amount of players on this job",

	enemy = "Enemy",
	neutral = "Neutral",
	friend = "Friend",
	turret_default = "Defaults:",
	turret_friends = "Friends:",
	steam_friends = "Steam friends",
	gang_or_police = "gang / police",
	cant_pack_turret = "Can't pack broken turret",
	turret_already_repair = "Turret is already repairing",
	turret_repairing = "Repairing turret...",
	turret_attacked = "Turret is under attack!",
	turret_lockpicker = "Lockpicker!",
	turret_owner = "Owner: %s",
	turret_state = "Health: %d%% (%d)",

	-- Player stats
	stat_stamina_low = "Exhausted",
	stat_stamina_med = "Tired",
	stat_stamina_hi = "Tired",

	stat_break_low = "Small fracture",
	stat_break_med = "Medium fracture",
	stat_break_hi = "Major fracture",

	stat_starve_low = "Hungry",
	stat_starve_med = "Very hungry",
	stat_starve_hi = "Starving",

	stat_drowning = "Low oxygen",

	stat_bleed_low = "Bleeding",
	stat_bleed_med = "Heavy bleeding",
	stat_bleed_hi = "Fatal bleeding",

	stat_bone_left_quadricep = "Left quadricep",
	stat_bone_left_knee = "Left knee",
	stat_bone_left_shin = "Left shin",
	stat_bone_left_ankle = "Left ankle",
	stat_bone_left_foot = "Left foot",
	stat_bone_left_toe = "Left toe",

	stat_bone_right_quadricep = "Right quadricep",
	stat_bone_right_knee = "Right knee",
	stat_bone_right_shin = "Right shin",
	stat_bone_right_ankle = "Right ankle",
	stat_bone_right_foot = "Right foot",
	stat_bone_right_toe = "Right toe",

	stat_wellfed_low = "Well fed",
	stat_wellfed_med = "Full",
	stat_wellfed_hi = "Fat",

	nx_medcenter = "Medkit",
	nx_medcenter_energy = "Medkit Batteries",
	medcenter_mode_heal = "Common Healing",
	medcenter_mode_bones = "X-Ray",
	medcenter_mode_desease = "Common Analyze",
	medcenter_skel_health = "Skeleton health",
	medcenter_skel_scanning = "Scanning",
	medcenter_health = "Health",
	medcenter_ready = "Ready",

	police_is_near = "Police is near",

	thanks_printers = "Take your printers, %s...",
	thanks_goods = "Nice merchandise, %s...",

	heatmap = "Heatmap",
	heatmap_desc = "Displays heat, produced by money printers, microwaves and other electrical devices on map",
	heatmap_already = "You already have a heatmap",

	lockdown_timeleft = "You have %d seconds to get home",
	lockdown_timeout = "Police may arrest you for being outside in lockdown time",
	lockdown_info_timeleft = "Has %d seconds to get home",
	lockdown_info_timeout = "Can be arrested for lockdown violation",

	pd_permit_give = "Give/extend PD entrance permit (%d min)",
	pd_permit_revoke = "Revoke PD entrance permit",
	pd_permit_timeleft = "PD entrance permit: %s",
	pd_permit_issued_actor = "Issued a PD entrance permit for %s",
	pd_permit_issued_target = "Got a PD entrance permit for %d min",
	pd_permit_revoked_actor = "Revoked PD entrance permit for %s",
	pd_permit_revoked_target = "Your PD entrance permit has been revoked; please vacate the premises immediately",

	pd_entrance_warning = "Entrance without a permit is prohibited",

	purchase_placement = "Choose where to place your purchases.\nYou can also put stuff in nearest cars.",
	buy_printer_for = "Buy Money Printer for %s",
	my_pocket = "My pocket",
	restock_in = "Restocking in %s",
	for_you_in_stock = "For you in stock: %d/%d\n%s",
	printerman_gui_title = "PrintService",
	restock_m_s = "%02dm%02ds",
	restock_s = "%02ds",

	sellers_gohere = "Move out to the beacon to contact the seller",
	sellers_here = "Meet seller here",

	printer_new_way = "You can't spawn printer from nowhere anymore.\nYou need to call a special trader now.\nPress F > Call an Emergency or Service > Contact Printer Seller",
	buyprinter_new_way = "You can only buy printers from a special service",

	charger_battery = "Battery with 100 charge",
	weapon_vape = "Vaporizer",
	repair_verb = "Repair",
	door_single = "Door",
	ignore_cops = "Ignore the Police",

	pot = "Flower pot",
	seedbag_weed = "Weed seeds",
	seedbag_orange = "Orange seeds",
	fertilizer = "Fertilizer",
	drug_weed = "Weed",

	stat_weed1 = "High",
	stat_weed2 = "Very high",
	stat_weed3 = "THE HIGHEST ONE",

	itemshop = "Vending machine",
	empty = "EMPTY",
	itemshop_eject = "EJECT",
	itemshop_price = "PRICE",
	itemshop_map_spot = "Public map spot",
	itemshop_wallpaper = "Wallpaper",
	itemshop_eject_money = "Eject money",
	itemshop_settings = "Service",
	itemshop_on_service = "ON SERVICE",
	itemshop_put_shipments = "Put your shipments directly on screen to add them",
	itemshop_restore = "Restore kernel",
	itemshop_rename = "Rename",
	itemshop_setprice_title = "Change price for %s",
	itemshop_setprice_text = "Enter new price",
	itemshop_rename_title = "Change vending machine name",
	itemshop_rename_text = "Enter new name",
	itemshop_buyhint = "Buy %s for %s",
	itemshop_increase_count = "Add more",
	itemshop_decrease_count = "Remove",
	itemshop_tap = "Tap",

	disabled_dead = "Dead are unable",
	disabled_arrested = "Arrested are unable",
	disabled_tased = "Tased are unable",
	disabled_cuffs = "Cuffed are unable",
	disabled_car = "Unable while in car",

	handcuffs = "Handcuffs",
	handcuffs_topocket = "Handcuffs were put to the pocket",
	handcuffs_toinventory = "Handcuffs were returned",
	handcuffs_arrest = "arrest",
	handcuffs_relese = "release",
	handcuffs_makefollow = "make them follow",
	handcuffs_makestop = "stop",
	handcuffs_incuffs = "In handcuffs",
	handcuffs_escape_progress = "Escape:",
	handcuffs_escape = "escape",
	handcuffs_emenynearby = "enemy nearby",
	handcuffs_immediate = "This citizen has just been released and can't be cuffed immediately again",

	-- Entity
	elevator_button_up = "Call elevator up",
	elevator_button_down = "Call elevator down",
	elevator_button_level = "Floor %d",
	elevator_display_level = "Floor:",
	-- TOOL:
	["undone_elevator"] = "Undone elevator",
	["tool.nx_elevator.name"] = "Elevator",
	["tool.nx_elevator.desc"] = "Easy multilevel elevator tool",
	["tool.nx_elevator.material"] = "Chamber material:",
	["tool.nx_elevator.model"] = "Model:",
	["tool.nx_elevator.dupehint"] = "In order to use Duplicator tool with elevator you must create elevator on prop",
	["tool.nx_elevator.1_left"] = "Click anywhere to create new elevator or click on existing one to edit",
	["tool.nx_elevator.2_left"] = "Add floor",
	["tool.nx_elevator.2_right"] = "Remove floor",
	["tool.nx_elevator.2_reload"] = "Apply",
	["sboxlimit_elevator_floors"] = "Maximum floors limit reached",
	["sboxlimit_elevator_near_level"] = "You need to be on desired floor level and stay close to the chamber",
	["sboxlimit_elevator_blocked"] = "Something is blocking elevator chamber",
	["sboxlimit_elevator_cant_see"] = "New elevator floor must be in line of your sight",

	tool_link_name = "Link",
	tool_link_desc = "Links objects into a contraption to be saved into Duplicator",
	tool_link_left = "select one object or contraption",
	tool_link_left_shift = "+ Shift   select all nearby objects",
	tool_link_right = "link / unlink",
	tool_link_reload = "reset selection",
	tool_link_dist = "Search distance",
	tool_link_screen_separate = "Separate:",
	tool_link_screen_contraptions = "Contraptions:",

	loading_net = "Downloading data...",

	weekday_1 = "Monday",
	weekday_2 = "Tuesday",
	weekday_3 = "Wednesday",
	weekday_4 = "Thursday",
	weekday_5 = "Friday",
	weekday_6 = "Saturday",
	weekday_7 = "Sunday",

	-- teamkill
	teamkill_kill = "%s killed a teammate %s.",
	teamkill_kill_warn = "WARNING: You killed a teammate! You will be banned from Police if you kill %d more teammates!",
	teamkill_hurt = "%s attacked a teammate %s.",
	teamkill_hurt_warn = "WARNING: You attacked a teammate %s!",

	-- lives
	lives_died = "You have %d lives left. %d minutes until restoring one.",
	lives_died_warn = "If you have no life left, you will not be able to use weapons.",
	lives_restored = "Restored one life. Lives amount: %d",
	lives_hud1 = "Lives: %d/2",
	lives_hud2 = "Restoring in: %s minutes",
	lives_hud = "Lives: ",

	-- election
	election_start = "Election is starting, accepting candidatures!",
	election_reg_over = "Candidudature registration is over, vote has started!",
	election_thanks_for_voting = "Your vote has been registered",
	election_over = "Election is over. Winner — %s",
	election_second_tour = "No clear winner. Commencing additional vote tour!",
	election_wanna = "Do you want to vote on election?",
	election_results = "Vote results:",
	election_put_promise = "Enter your pre-election promise:",
	election_registered = "Your candidature has been registered",
	election_already = "Your candidature is already registered!",
	election_too_late = "Registration is closed",

	-- car trunk
	trunk_inspect = "Inspect trunk",
	trunk_instructions = "Drop an item with Gravity Gun near car trunk to put it into storage",

	admin_tp = "You need to be more specific if you want to call an administrator.",

	wire_ranger_restricted = "Use of wire ranger is restricted due to unjustified server & client performance strain. Use wire trigger instead. It can be used for the same purpose as ranger.",
	wire_e2say_alert = "You have placed a Wire Expression 2 chip that just wrote a chat message on your behalf.\nIf you want to prevent the chip from sending messages, then click on this button.",

	district_main = "Financial district",
	district_second = "Residential district",
	district_industrial = "Industrial district",
	district_elite = "Elite district",
	district_fishing = "Coastal district",
	district_rcar = "Rockford Ring Road",
	district_mountain = "Mountains",

	can_steal_cars_no = "%s doesn't know how to steal cars. Only %s can do this.",

	prop_hp = "Strength",
	prop_stability = "Stability",

	cop_rdm_watch_warning = "Police officer is not allowed to harm unarmed citizens; you will be banned if you continue",
	cop_rdm_watch_ban_reason = "killing of unarmed citizen",

	bus_popup = "Take a bus ride: %s",
	bus_wait = "Wait %d seconds",
	bus_reward = "%s for completing a stop",
	bus_get_back = "Get back to the point!",

	bus_stops = {
		pier = "Pier",
		village = "Village",
		apartments = "Apartments",
		supermarket = "Supermarket",
		tavern = "Tavern",
		factories = "Industrial Zone",
		club = "Club",
		theater = "Theater",
		pd = "Police Department",
		medcenter = "Medical Center",
		cobsgm = "Car Showroom",
		shell = "Gas Station",
	},

	bus_lanes = {
		perspective = "Perspective",
		distant = "Distant",
		ring = "Ring Road",
		center = "City Center",
	},

	bus_announcer_next = "Next stop is",

	-- Halloween
	zombies_start = "The city gets covered in darkness, screams are heard, bloodthirsty monsters come out to harvest...",
	zombies_end = "The sun rises above city. Monsters retreat.",
}
