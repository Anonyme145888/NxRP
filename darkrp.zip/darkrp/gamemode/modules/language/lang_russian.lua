return "ru", {
	looking_your_shop = "Просматривает ваш магазин",

	-- Admin things
	need_admin = "Вам нужны права админа для %s",
	need_sadmin = "Вам нужны права суперадмина для %s",
	no_privilege = "У вас нет нужных прав для этого действия",
	no_jail_pos = "Позиция тюрьмы не установлена",
	invalid_x = "Ошибка в %s! %s",

	-- F1 menu
	f1ChatCommandTitle = "Чат-команды",
	f1Search = "Поиск...",


    shop_shipment_ak47 = "AK-47",
	shop_shipment_ak74 = "AK-74",
	shop_shipment_g3 = "G3A3",
	shop_shipment_sks = "SKS",
	shop_shipment_ragebull = "Raging Bull",
	shop_shipment_mac11 = "MAC11",
    shop_shipment_deagle = "IMI Desert Eagle",
    shop_shipment_glock20 = "Glock-20",
    shop_shipment_m1911 = "M1911",
    shop_shipment_m24 = "M-24",
    shop_shipment_m3super90 = "M3SUPER90",
    shop_shipment_m4a1 = "M4A1",
    shop_shipment_mp5a5 = "MP5A5",
    shop_shipment_p226 = "P-226",
    shop_shipment_rk95 = "Sako RK-95",
    shop_shipment_sg552 = "SG-552",
    shop_shipment_pp19 = "PP-19",
    shop_shipment_uzi = "IMI Uzi",
    shop_shipment_c4 = "C4",
    shop_shipment_m67 = "Граната M67",
    shop_shipment_dv2 = "Нож DV2",
    shop_shipment_machete = "Мачете",
    shop_shipment_rpg = "RPG",

	-- Money things:
	price = "Цена: %s%d",
	priceTag = "Цена: %s",
	reset_money = "%s сбросил деньги всем игрокам!",
	has_given = "%s дал вам %s",
	you_gave = "Вы дали %s %s",
	npc_killpay = "%s за убийство НИПа!",
	profit = " дохода",
	loss = "убыток",

	-- backwards compatibility
	deducted_x = "Вычтено %s%d",
	need_x = "Нужно %s%d",

	deducted_money = "Вычтено %s",
	need_money = "Нужно %s",

	payday_message = "Зарплата! Вы получили %s!",
	payday_unemployed = "Вы безработный и вы не получаете зарплату!",
	payday_missed = "Получка пропущена! (Вы под арестом)",

	property_tax = "Налог на собственность! %s",
	property_tax_cant_afford = "Вы не смогли уплатить налоги! Ваша собственность отобрана у вас!",
	taxday = "День налогов! Вычтено %s%% из вашей прибыли!",

	found_cheque = "Вы нашли %s%s в чеке, выписанном вам от %s.",
	cheque_details = "Этот чек выписан %s.",
	cheque_torn = "Вы разорвали чек.",
	cheque_pay = "Уплата: %s",
	signed = "Подпись: %s",

	found_cash = "Вы нашли %s%d!", -- backwards compatibility
	found_money = "Вы нашли %s!",

	owner_poor = "Владелец %s слишком беден чтобы субсидировать эту продажу!",

	-- Police
	Wanted_text = "Разыскивается!",
	he_wanted = "Разыскивается полицией!\nПричина: %s",
	youre_unarrested_by = "%s выпустил вас.",
	hes_arrested = "%s был арестован на %d секунд!",
	hes_unarrested = "%s был выпущен из тюрьмы!",
	warrant_request = "%s запрашивает ордер на обыск %s\nПричина: %s",
	warrant_request2 = "Запрос на ордер отправлен мэру %s!",
	warrant_approved = "Запрос на обыск %s был одобрен!\nПричина: %s\nПриказ выдал: %s",
	warrant_approved2 = "Теперь вы можете обыскать его дом.",
	warrant_denied = "Мэр %s отклонил ваш запрос на ордер.",
	warrant_expired = "Ордер на обыск %s истёк!",
	warrant_required = "Вам нужен ордер на обыск чтобы взломать эту дверь.",
	warrant_required_unfreeze = "Вам нужен ордер на обыск чтобы разморозить эту пропу.",
	warrant_required_unweld = "Вам нужен ордер на обыск чтобы отсоединить эту пропу.",
	wanted_by_police = "%s разыскивается полицией!\nПричина: %s\nПриказ выдал: %s",
	wanted_by_police_noactor = "%s разыскивается полицией!\nПричина: %s",
	wanted_expired = "%s больше не разыскивается полицией.",
	wanted_revoked = "%s больше не разыскивается полицией.\nОтменил: %s",
	cant_arrest_other_cp = "Вы не можете арестовывать других копов!",
	must_be_wanted_for_arrest = "Игрок должен быть в розыске чтобы вы могли арестовать его.",
	cant_arrest_no_jail_pos = "Вы не можете арестовывать людей так как нет позиций для тюрьмы!",
	cant_arrest_spawning_players = "Вы не можете арестовывать людей которые спавнятся.",
	escape_from_jail = "побег из тюрьмы",
	need_policeres = "Требуется %d монет полицейского",

	suspect_doesnt_exist = "Подозреваемый отсутствует.",
	actor_doesnt_exist = "Действующее лицо отсутствует.",
	get_a_warrant = "Запросить ордер на обыск",
	give_warrant = "Выдать ордер на обыск гражданина",
	make_someone_wanted = "Объявить в розыск",
	remove_wanted_status = "Снять розыск",
	already_a_warrant = "Ордер на обыск подозреваемого всё ещё в силе.",
	already_wanted = "Подозреваемый уже в розыске.",
	not_wanted = "Подозреваемый не в розыске.",
	need_to_be_cp = "Вы должны быть представителем полиции.",
	suspect_must_be_alive_to_do_x = "Подозреваемый должен быть живым чтобы %s.",
	suspect_already_arrested = "Подозреваемый уже в тюрьме.",

	-- Mayor
	curfew = "Мэр объявил комендантский час: ",

	-- Players
	health = "Здоровье: %s",
	job = "Работа: %s",
	job_s = "Работа",
	salary = "Зарплата: %s%s",
	wallet = "Кошелёк: %s%s",
	weapon = "Оружие: %s",
	kills = "Убийств: %s",
	deaths = "Смертей: %s",
	rpname_changed = "%s сменил ролевое имя на %s",
	disconnected_player = "Отсоединившийся игрок",
	hunger = "Голод: ",
	starving = "ГОЛОДАНИЕ",
	armor = "Броня: ",
	in_jail = "В тюрьме%s. Осталось: %d секунд",
	with_license = "Имеется лицензия",
	radio_disabled = "Рация отключена",
	wanted = "В розыске: ",

	-- Cars
	rented_car_tag = "Аренда",
	path = "Путь: ",
	m = "%d м",
	km = "%.1f км",
	speed = "Скорость: ",
	kmh = "%d км/ч",

	-- Teams
	need_to_be_before = "Вы должны быть %s чтобы стать %s",
	need_to_make_vote = "Вы должны провести голосование чтобы стать %s!",
	team_limit_reached = "Нельзя стать %s, лимит исчерпан",
	wants_to_be = "%s желает стать %s",
	has_not_been_made_team = "%s не стал %s!",
	job_has_become = "%s стал %s!",

	-- Keys, vehicles and doors
	keys_allowed_to_coown = "Вам разрешено быть со-владельцем\n(Нажмите C чтобы стать со-владельцем)\n",
	keys_other_allowed = "Потенциальные со-владельцы:",
	keys_allow_ownership = "(Нажмите C чтобы разрешить владение)",
	keys_disallow_ownership = "(Нажмите C чтобы запретить владение)",
	keys_owned_by = "Владелец:",
	keys_unowned = "Свободно\n(Нажмите C чтобы стать владельцем)",
	keys_everyone = "(Нажмите C чтобы разрешить для всех)",
	door_unown_arrested = "You can not own or unown things while arrested!",
	door_unownable = "This door cannot be owned or unowned!",
	door_sold = "Вы продали это за %s",
	door_already_owned = "Этой дверью уже кто-то владеет!",
	door_cannot_afford = "Недостаточно средств для покупки этой двери!",
	door_hobo_unable = "Вы не можете купить дверь если вы бомж!",
	vehicle_cannot_afford = "Вы не можете позволить себе этот транспорт!",
	door_bought = "Вы купили эту дверь за %s%s",
	vehicle_bought = "Вы купили этот транспорт за %s%s",
	door_need_to_own = "Вам нужно владеть этой дверью чтобы %s",
	door_rem_owners_unownable = "Вы не можете удалять владельцев если дверь неовладима!",
	door_add_owners_unownable = "Вы не можете добавлять владельцев если дверь неовладима!",
	rp_addowner_already_owns_door = "%s уже (со-)владеет этой дверью!",
	add_owner = "Добавить владельца",
	remove_owner = "Удалить владельца",
	coown_x = "Со-владение %s",
	allow_ownership = "Разрешить владение",
	disallow_ownership = "Запретить владение",
	edit_door_group = "Редактировать группу двери",
	door_groups = "Группы дверей",
	door_group_doesnt_exist = "Группа дверей не существует!",
	door_group_set = "Группа двери успешно установлена.",
	sold_x_doors_for_y = "Вы продали %d дверей за %s%d!", -- backwards compatibility
	sold_x_doors = "Вы продали %d дверей за %s!",

	-- Entities
	gmod_camera = "Камера",
	gmod_tool = "Тулган",
	weapon_bugbait = "Комок грязи",
	weapon_physcannon = "Гравипушка",
	weapon_physgun = "Физган",

	drugs = "Наркотики",
	drug_lab = "Лаборатория наркотиков",
	gun_lab = "Лаборатория оружия",
	gun = "Пушка",
	microwave = "Микроволновка",
	food = "Еда",
	money_printer = "Денежный принтер",

	write_letter = "Написать письмо...",
	send = "Отправить",
	sign_this_letter = "Подписать это письмо",
	signed_yours = "С уважением,",

	money_printer_exploded = "Ваш денежный принтер взорвался!",
	money_printer_overheating = "Ваш денежный принтер перегревается!",

	previous_owner_nof = "Прежний: ",
	microwave_steal = "Нажми здесь чтобы украсть",
	microwave_hacking = "Перепрошивание...",
	microwave_alreadyown = "Вы уже владеете этой мирковолновкой!",
	microwave_alert = "Вашу микроволновку крадут!",

	camera_destroyed = "Ваша камера уничтожена!",

	contents = "Содержит: ",
	amount = "Количество: ",

	picking_lock = "Взламываем замок",

	cannot_pocket_x = "Вы не можете положить это в пакет!",
	object_too_heavy = "Этот предмет слишком тяжёлый.",
	pocket_full = "Ваш пакет полон!",
	pocket_no_items = "Ваш пакет пуст.",
	drop_item = "Выбросить предмет",
	drop_ammo = "Выбросить патроны/снаряжение",

	pickup_item = "Подобрать предмет",
	put_item_in_pocket = "Положить предмет в сумку",
	drop_last_item = "Выбросить последний предмет",
	inventory = "Инвентарь",

	bonus_destroying_entity = "уничтожение нелегального предмета.",

	switched_burst = "Переключение на пакетный режим огня.",
	switched_fully_auto = "Переключение на автоматический режим огня.",
	switched_semi_auto = "Переключение на полуавтоматический режим огня.",

	keypad_checker_shoot_keypad = "Shoot a keypad to see what it controls.",
	keypad_checker_shoot_entity = "Shoot an entity to see which keypads are connected to it",
	keypad_checker_click_to_clear = "Right click to clear.",
	keypad_checker_entering_right_pass = "Entering the right password",
	keypad_checker_entering_wrong_pass = "Entering the wrong password",
	keypad_checker_after_right_pass = "after having entered the right password",
	keypad_checker_after_wrong_pass = "after having entered the wrong password",
	keypad_checker_right_pass_entered = "Right password entered",
	keypad_checker_wrong_pass_entered = "Wrong password entered",
	keypad_checker_controls_x_entities = "This keypad controls %d entities",
	keypad_checker_controlled_by_x_keypads = "This entity is controlled by %d keypads",
	keypad_on = "ON",
	keypad_off = "OFF",
	seconds = "seconds",

	persons_weapons = "Нелегальное оружие у %s:",
	returned_persons_weapons = "Вернул вещи конфискованные у %s.",
	no_weapons_confiscated = "%s не имеет конфискованных предметов!",
	no_illegal_weapons = "%s не имеет нелегального оружия.",
	confiscated_these_weapons = "Конфисковал следующее оружие:",
	checking_weapons = "Проверяем оружие",

	shipment_antispam_wait = "Подождите прежде чем спавнить другой ящик.",
	shipment_cannot_split = "Нельзя разделить этот ящик.",

	-- Talking
	hear_noone = "Никто не слышит ваш%s!",
	hear_everyone = "Вас все слышат!",
	hear_certain_persons = "Ваш%s слышат: ",

	whisper = " шёпот",
	yell = " крик",
	advert = "[Объявление]",
	broadcast = "[Передача!]",
	radio = "радио",
	request = "(ЗАПРОС!)",
	group = "(группе)",
	demote = "(УВОЛЬНЕНИЕ)",
	ooc = "Город",
	chat_in_region = "Регион",
	radio_x = "Радио %d",

	talk = " чат",
	speak = " голос",

	speak_in_ooc = " городской чат",
	perform_your_action = "е выполнение действия",
	talk_to_your_group = "е сообщение группе",

	channel_set_to_x = "Канал установлен на %s!",
	channel_not_set = "Канал рации не настроен (F-меню).",

	-- Notifies
	disabled = "%s выключено! %s",
	gm_spawnvehicle = "The spawning of vehicles",
	gm_spawnsent = "The spawning of scripted entities (SENTs)",
	gm_spawnnpc = "The spawning of Non-Player Characters (NPCs)",
	see_settings = "Please see the DarkRP settings.",
	limit = "Вы достигли лимита %s!",
	have_to_wait = "Вам нужно подождать ещё %d секунд прежде чем %s!",
	must_be_looking_at = "Вам нужно смотреть на %s!",
	incorrect_job = "Неправильная работа для %s",
	unavailable = "%s недоступен",
	unable = "Вы не можете %s. %s",
	cant_afford = "Вы не можете позволить себе %s",
	cleaned_up = "Ваши %s были очищены.",
	you_bought_x = "Вы купили %s за %s%d.", -- backwards compatibility
	you_bought = "Вы купили %s за %s.",
	you_received_x = "Вы получили %s за %s.",

	created_first_jailpos = "You have created the first jail position!",
	added_jailpos = "You have added one extra jail position!",
	reset_add_jailpos = "You have removed all jail positions and you have added a new one here.",
	created_spawnpos = "%s's spawn position created.",
	updated_spawnpos = "%s's spawn position updated.",
	do_not_own_ent = "Вы не владеете этим предметом!",
	cannot_drop_weapon = "Нельзя выбросить это оружие!",
	job_switch = "Профессии были успешно обменены!",
	job_switch_question = "Поменяться профессиями с %s?",
	job_switch_requested = "Запрос об обмене профессиями отправлен.",

	cooks_only = "Только поварам.",

	-- Misc
	unknown = "Неизвестное",
	arguments = "аргументы",
	no_one = "никто",
	door = "двери",
	vehicle = "транспорт",
	door_or_vehicle = "дверь/транспорт",
	name = "Название %s",
	lock = "Закрыть",
	locked = "Закрыто",
	unlock = "Открыть",
	unlocked = "Открыто",
	player_doesnt_exist = "Игрок отсутствует.",
	job_doesnt_exist = "Профессия не существует!",
	must_be_alive_to_do_x = "Вы должны быть живы чтобы %s.",
	banned_or_demoted = "Забанен/уволен",
	wait_with_that = "Эй, подожди с этим.",
	could_not_find = "Невозможно найти %s",
	f3tovote = "Нажмите F3 или зажмите TAB чтобы вывести курсор для голосования",
	listen_up = "Внимание:", -- In rp_tell or rp_tellall
	nlr = "Правило новой жизни (NLR): Не убивайте/арестовывайте в отместку.",
	reset_settings = "Все настройки сброшены!",
	must_be_x = "Вы должны быть %s чтобы сделать %s.",
	agenda_updated = "Повестка дня обновлена",
	job_set = "%s сменил свою работу на '%s'",
	demoted = "%s был уволен",
	demoted_not = "%s не был уволен",
	demoted_not_quorum = "%s не был уволен (не набрался кворум)",
	demote_vote_started = "%s запустил голосование об увольнении %s",
	demote_vote_text = "Причина увольнения:\n%s", -- '%s' is the reason here
	cant_demote_self = "Вы не можете уволить себя же.",
	i_want_to_demote_you = "Я желаю уволить тебя с работы. Причина: %s",
	x_wants_to_demote_you_for_x = "желает уволить вас по причине",
	tried_to_avoid_demotion = "Вы попытались избежать увольнения. Хорошая попытка, но вы всё равно были уволены.", -- naughty boy!
	lockdown_started = "Мэр объявил комендантский час, возвращайтесь по домам!",
	lockdown_ended = "Комендатский час отменён",
	gunlicense_requested = "%s запросил лицензию у %s",
	gunlicense_granted = "%s дал %s лицензию",
	gunlicense_denied = "%s отказал %s в лицензии",
	gunlicense_question_text = "Дать %s лицензию?",
	gunlicense_remove_vote_text = "%s начал голосование об отзыве лицензии у %s",
	gunlicense_remove_vote_text2 = "Отозвать лицензию:\n%s", -- Where %s is the reason
	gunlicense_removed = "Лицензия %s не была отозвана!",
	gunlicense_not_removed = "Лицензия %s была отозвана!",
	vote_specify_reason = "Вам нужно указать причину!",
	vote_started = "Голосование создано",
	vote_alone = "Вы выиграли голосование так как вы один на сервере.",
	you_cannot_vote = "Вы не можете голосовать!",
	x_cancelled_vote = "%s cancelled the last vote.",
	cant_cancel_vote = "Could not cancel the last vote as there was no last vote to cancel!",
	jail_punishment = "Наказание за отсоединение! Арестован на: %d секунд.",
	frozen = "Заморожено.",
	yes_demote = "Да, уволить",
	no_demote = "Нет, не увольнять",
	dont_vote = "Не голосовать",
	demote_rule = [[Голосуйте с умом, не нажимайте на "да" или "нет" в голосованиях просто так.]],

	dead_in_jail = "Вы мертвы до тех пор, пока с вас не снимут арест!",

	credits_for = "АВТОРЫ %s\n",
	credits_see_console = "Список авторов DarkRP отправлен в консоль.",

	data_not_loaded_one = "Ваши данные ещё не загрузились. Пожалуйста, подождите.",
	data_not_loaded_two = "Если проблема все ещё остаётся, свяжитесь с админом.",

	cant_spawn_weapons = "Вы не можете спавнить оружие.",
	drive_disabled = "Управление отключено.",
	property_disabled = "Опция отключена.",

	not_allowed_to_purchase = "Вам нельзя купить этот предмет.",

	already_taken = "Уже занято.",

	-- The lottery
	lottery_started = "Проводится лотерея! Участвовать за %s%d?", -- backwards compatibility
	lottery_has_started = "Проводится лотерея! Участвовать за %s?",
	lottery_entered = "Вы участвуете в лотерее за %s",
	lottery_not_entered = "%s не участвует в лотерее",
	lottery_noone_entered = "Никто не участвовал в лотерее",
	lottery_won = "%s выиграл %s в лотерее!",
	lottery_you_won = "Вы победили в лотерее!",
	lottery_msg = "Запущена лотерея на %s",

	-- Animations
	custom_animation = "",
	bow = "Поклон",
	dance = "Танец 'Флекс'",
	follow_me = "За мной",
	laugh = "Хаха",
	lion_pose = "Лев",
	nonverbal_no = "Нет",
	thumbs_up = "Палец вверх",
	wave = "Помахать",
	dance2 = "Танец",
	cheer = "Радость",
	salute = "Отдать честь",
	robot = "Робот",
	animations = "Жесты",

	-- AFK
	afk_mode = "AFK Mode",
	salary_frozen = "Your salary has been frozen.",
	salary_restored = "Welcome back, your salary has now been restored.",
	no_auto_demote = "You will not be auto-demoted.",
	youre_afk_demoted = "You were demoted for being AFK for too long. Next time use /afk.",
	hes_afk_demoted = "%s has been demoted for being AFK for too long.",
	afk_cmd_to_exit = "Type /afk again to exit AFK mode.",
	player_now_afk = "%s is now AFK.",
	player_no_longer_afk = "%s is no longer AFK.",

	-- Hitmenu
	hit = "заказ",
	hitman = "Заказной убийца",
	current_hit = "Заказ: %s",
	cannot_request_hit = "Невозможно сделать заказ! %s",
	hitmenu_request = "Заказать",
	player_not_hitman = "Этот игрок не убийца по заказу!",
	distance_too_big = "Слишком большое расстояние.",
	hitman_no_suicide = "Убийца не может убить себя.",
	hitman_no_self_order = "Убийца не может получить заказ от себя же.",
	hitman_already_has_hit = "Убийца уже имеет заказ.",
	price_too_low = "Цена слишком низкая!",
	hit_target_recently_killed_by_hit = "Цель была ранее убита по заказу,",
	customer_recently_bought_hit = "Заказчик сделал заказ ранее.",
	accept_hit_question = "Принять заказ от %s\nв отношении %s за %s%d?", -- backwards compatibility
	accept_hit_request = "Принять заказ от %s\nв отношении %s for %s?",
	hit_requested = "Заказ сделан!",
	hit_aborted = "Заказ прерван! %s",
	hit_accepted = "Заказ принят!",
	hit_declined = "Убийца отклонил заказ!",
	hitman_left_server = "Убийца покинул сервер!",
	customer_left_server = "Заказчик покинул сервер!",
	target_left_server = "Цель покинула сервер!",
	hit_price_set_to_x = "Цена на заказ установлена в %s%d.", -- backwards compatibility
	hit_price_set = "Цена на заказ установлена в %s.",
	hit_complete = "Заказ у %s выполнен!",
	hitman_died = "Заказной убийца умер!",
	target_died = "Цель умерла!",
	hitman_arrested = "Заказной убийца был арестован!",
	hitman_changed_team = "Заказной убийца сменил команду!",
	x_had_hit_ordered_by_y = "%s имел действующий заказ от %s",

	-- Hits
	hit_errors = {
		no_access = "нет доступа",
		not_found = "заказ не найден",
		same_request = "заказ слишком похож на существующий",
		same_subscribe = "вы уже подписаны",
		cant_subscribe = "нельзя подписаться",
		too_many = "достигнут лимит подписок",
		bad_reward = "вознаграждение не прошло проверку",
		cant_afford = "недостаточно денег",
		no_clients = "клиенты отменили заказ",
		victim_left = "жертва покинула город",
		victim_changed_team = "жертва сменила профессию и минимальная цена заказа повысилась",
		victim_cooldown = "эта цель уже была устранена недавним заказом, подождите %s",
	},

	hits_menu_subscriptions_title = "Заказы наёмникам",
	hits_menu_subscriptions_hint = "Вы можете подписаться максимум на 3 заказа одновременно.\nЕсли у вас есть союзники, то они могут помочь вам выполнить заказ.",
	hits_menu_subscriptions_empty = "Сейчас заказов нет, следите за уведомлениями.",
	hits_menu_subscriptions_subscribe =  "Подписаться",
	hits_menu_subscriptions_unsubscribe =  "Отписаться",

	hits_menu_makehit_title = "Заказать услуги наёмника",
	hits_menu_makehit_target = "Цель",
	hits_menu_makehit_reason = "Причина",
	hits_menu_makehit_reason_hint = "Любой заказ должен иметь адекватную причину. Заказ без причины - такой же RDM, как и убийство без причины.\nВ случае беспричинного заказа ответственность несет заказчик, а не наемник.",
	hits_menu_makehit_reward = "Вознаграждение",
	hits_menu_makehit_reward_minam = "Минимальная сумма: %s. Чем больше награда, тем охотнее работа будет выполнена.",
	hits_menu_makehit_reward_job = " (обусловлена профессией жертвы)",
	hits_menu_makehit_submit = "Заказать!",

	hits_menu_ctrlhit_title = "Мои заказы",
	hits_menu_ctrlhit_empty = "Вы не заказывали услуги наёмника. Возможно, самое время сделать это?",
	hits_menu_ctrlhit_empty_makeone = "Сделать заказ",

	hits_msg_created = "%s создан!",
	hits_msg_new_available = "Доступен %s",
	hits_msg_create_fail = "Не удалось создать заказ, %s",
	hits_msg_removed = "%s удалён!",
	hits_msg_remove_fail = "Не удалось удалить заказ, %s",
	hits_msg_subscribed = "Подписан на %s!",
	hits_msg_subscribed_boss = "Глава группы подписался на %s!",
	hits_msg_subscribe_fail = "Не удалось подписаться, %s",
	hits_msg_unsubbed = "Отписан от %s!",
	hits_msg_unsubbed_boss = "Глава группы отписался от %s!",
	hits_msg_unsub_fail = "Не удалось отписаться, %s",
	hit_msg_completed_client = "%s выполнен!",
	hit_msg_completed_for = "%s выполнен для %s!",
	hit_msg_completed_for_boss = "%s выполнил %s! Вы получили %s",
	hit_msg_completed = "%s выполнен! Вы получили %s",
	hit_msg_aborted = "%s отменён, %s",
	hit_msg_finished_by_other = "%s был выполнен другим наёмником!",
	hits_msg_need_target = "Выберите цель!",
	hits_msg_need_reason = "Укажите причину!",
	hits_msg_cop_fail = "Провал, полиция убила наёмника с уликами",
	hits_msg_cop_success = "Отлично! Полиция арестовала наёмника. Ведётся поиск заказчиков!",
	hits_msg_cop_found = "Заказчики преступления были обнаружены, арестуйте их!",
	hits_msg_you_dead = "Вас убили по заказу у наёмников!",


	hit_selfdesc_kill = "Заказ на убийство %s",
	hit_selfdescobj_kill = "Убить %s",

	hit_letter_title = "Список заказов",

	dealer_title = "Криминальные услуги",
	dealer_buy_printer = "Купить принтер",

	hits_hud_target = "Цели",
	hits_hud_hint = "Подпишитесь на %d заказа из %d доступных",

	hits_wanted_reason = "Заказчик убийства",

	dealer_sellgoods = "Сбыть нелегал",
	sold_x_goods = "Вы сбыли %d товаров за %s!",
	goods_onlygang = "Сбывать нелегал могут только бандиты",

	-- Shops

	shop_hint_res = "У вас недостаточно ресурсов чтобы продавать товары покупателям\nПроследуйте к метке $ чтобы получить ресурсы",
	shop_hint_location = "Разместитесь в подходящем месте и найдите покупателей",
	open_shop_gui = "Открыть магазин",
	finish_purchase = "Завершить покупку",
	set_profit_margin_percent = "Установить наценку",
	trading_merchantry = "Управление магазином",

	finish_purchase_hint = "Снова нажмите на торговца, чтобы завершить заказ",
	purchase_sent = "Запрос отправлен продавцу",
	purchase_ques = "Продать заказ покупателю %s?",
	purchase_ques_fail = "Продавец не смог одобрить заказ",
	deal_fail_space = "Некуда сложить товар!",
	deal_fail_res = "Магазин не может произвести товар!",

	shops_finish_purchase = "Закончить покупку",
	shops_total_stat = "Итого: %s",

	resdealer_but = "Получить %d RES за %s",
	resdealer_msg = "Получено %d RES за %s",
	resdealer_title = "Поставщик ресурсов",
	resdealer_subtitle = "Ресурсы для вашего магазина",

	remove_current_ammo = "Изъять патроны",

	shop_equipment = "Снаряжение",
	shop_foodstuffs = "Продовольствие",

	floor = "Пол",
	ground = "Земля",

	deployable = "С упаковкой",
	stackable = "Складывается",
	canpocket = "Помещается в сумку",

	no_place_excl = "Нет места!",

	-- Vote Restrictions
	hobos_no_rights = "Бездомные не имеют права голоса!",
	gangsters_cant_vote_for_government = "Бандиты не могут голосовать по правительственным делам!",
	government_cant_vote_for_gangsters = "Представители правительства не могут голосовать по делам криминалов!",

	-- VGUI and some more doors/vehicles
	vote = "Голосование",
	time = "Время: %d",
	yes = "Да",
	no = "Нет",
	ok = "Окей",
	cancel = "Отмена",
	add = "Добавить",
	remove = "Удалить",
	none = "Ничего",
	none_alt = "нет",
	confirmed = "Подтверждено",
	v_back = "< Назад",
	esc_back = "[ESC] Назад",

	x_options = "Опции %s",
	sell_x = "Продать %s",
	set_x_title = "Задать название %s",
	set_x_title_long = "Задать название %s на которую вы смотрите.",
	jobs = "Профессии",
	menu = "Меню",
	buy_x = "Купить %s",

	-- F4menu
	no_extra_weapons = "Эта профессия не даёт дополнительного оружия.",
	become_job = "Занять профессию",
	create_vote_for_job = "Создать голосование",
	participate_in_elections = "Участвовать в выборах",
	shipments = "Ящики",
	F4guns = "Оружие",
	F4entities = "Предметы",
	F4ammo = "Патроны",
	F4vehicles = "Транспорт",
	F4premium = "Премиум-предложения",
	F4cars = "Автомобили",
	F4hats = "Одежда",
	F4attachments = "Оптика и снаряжение",

	-- Tab 1
	give_money = "Передать деньги",
	drop_money = "Выбросить пачку денег",
	change_name = "Сменить ролевое имя",
	go_to_sleep = "Уснуть или проснуться",
	drop_weapon = "Выбросить текущее оружие",
	drop_weapon_s = "Выбросить",
	customize_weapon = "Настроить текущее оружие",
	customize_weapon_s = "Настроить",
	buy_health = "Купить излечение за %s",
	request_gunlicense = "Запросить лицензию на оружие",
	demote_player_menu = "Уволить игрока с работы",


	searchwarrantbutton = "Объявить в розыск",
	unwarrantbutton = "Снять розыск",
	noone_available = "Никто не доступен",
	request_warrant = "Запросить ордер на обыск",
	make_wanted = "Объявить кого-либо в розыск",
	make_unwanted = "Снять розыск с кого-либо",
	set_jailpos = "Установить позицию тюрьмы (сброс)",
	add_jailpos = "Добавить позицию тюрьмы",

	set_custom_job = "Установить название профессии",

	set_agenda = "Установить агенду",

	initiate_lockdown = "Установить комендантский час",
	stop_lockdown = "Отменить комендантский час",
	start_lottery = "Запустить лотерею",
	give_license_lookingat = "Дать лицензию",

	laws_of_the_land = "ЗАКОНЫ ГОРОДА",
	law_added = "Закон добавлен.",
	law_removed = "Закон удалён.",
	law_reset = "Законы сброшены.",
	laws_full = "Доска законов переполнена.",
	default_law_change_denied = "Вам не разрешено менять основные законы.",

	-- Second tab
	job_name = "Название: ",
	job_description = "Описание: ",
	job_weapons = "Оружие: ",

	-- Entities tab
	buy_a = "Купить %s: %s",

	-- Licenseweaponstab
	license_tab = [[License weapons

	Tick the weapons people should be able to get WITHOUT a license!
	]],
	license_tab_other_weapons = "Other weapons:",

	-- Car Terminal
	car_terminal = "Автотерминал",

	-- Destroyer
	destroyer_message = "Принесите сюда денежный принтер, наркотики или оружие чтобы получить награду.",
	destroyer_reward = "Награда за уничтожение нелегального предмета: %s!",
	destroyer_bringthis = "Отнесите это в уничтожитель в полицейском участке чтобы получить награду.",

	-- Printer
	printer_disabled = "Принтер отключен. Отнесите его в уничтожитель в полицейском участке чтобы получить награду.",
	printer_fixed = "Полицейская блокировка снята. Принтер снова функционирует.",
	printer_warning = "Внимание!\nВозможно самопроизвольное возгорание!",
	printer_error = "Печать невозможна!\nНет места для выброса денег.",
	printer_speed = "Скорость",
	printer_speed_upgrade = "апгрейд скорости",
	printer_rely = "Надёжность",
	printer_rely_upgrade = "апгрейд надёжности",
	printer_start = "Начать печать",
	printer_stop = "Остановить печать",
	printer_auto = "Автоповтор",
	printer_update = "Обновить за %s",
	printer_collect = "Собрать деньги",
	printer_printed = "Напечатано: %s",
	printer_onlygang_use = "Пользоваться денежным принтером могут только бандиты",
	printer_onlygang_buy = "Покупать денежные принтеры могут только бандиты",
	printer_already_x = "У вас уже есть %d запущенных принтеров!",

	-- Jobs
	citizens = "Граждане",
	law_enforcement = "Правопорядок",
	criminal = "Криминал",
	criminal_business = "Криминальный бизнес",
	city_service = "Городские службы",
	business = "Бизнес",

	citizen = "Гражданин",
	citizen_desc = [[Гражданин — основа городского общества.
	У вас нет предопределенной роли в жизни города.
	Вы можете придумать себе свою собственную профессию и заниматься своими делами.]],

	hobo = "Бездомный",
	hobo_desc = [[Бездомные находятся в самом низу общественного строя. Над ними все смеются.
		У них нет домов.
		Они вынуждены просить еду и деньги.

		Постройте дом из дощечек и мусора, чтобы укрыться от холода.
		Вы можете поставить ведро и написать на нём просьбу дать пожертвование.
		Проявите фантазию, устройте цирковое представление, спойте, станцуйте, постойте на одной ноге.
		Развлекая людей, вы получаете больше денег.]],

	fishman = "Рыбак",
	fishman_desc = [[Используйте свои умения для добычи улова на продажу.
	Покупайте снасти и улучшайте свою удочку чтобы получать больше и больше улова.

	Нажмите B, держа удочку, чтобы открыть меню.]],

	cp = "Офицер Полиции",
	cp_desc = [[Полицейский является защитником каждого, кто живет в городе.
		Вы можете арестовывать людей, нарушающих законы, участвовать в штурмах, либо патрулировать улицы.
		Хотим напомнить, что вы обязательно должны выполнять поручения Начальника Полиции и Главы города.
		Используйте "Демократизатор", чтобы привести в чувство нарушителей порядка.
		Дверной таран способен выломать любую дверь и выгнать всех из транспорта, если у вас есть соответствующее разрешение.
		Таран также может ломать любые постройки.
		В F-меню вы сможете найти дополнительные функции Полиции.

		Соблюдайте законы, подавайте другим гражданам хороший пример.]],
	cp_msg_pos = "Вам нужно быть в Полицейском Участке (ПУ), чтобы стать полицейским!",
	cp_msg_wanted = "Нельзя становиться полицейским в розыске!",

	chief = "Начальник Полиции",
	chief_desc = [[Начальник Полиции является главным среди полицейских.
		Координируйте действия сотрудников Полиции, наводите порядок в городе.

		В F-меню вы сможете найти дополнительные функции Начальника Полиции.

		Соблюдайте законы, подавайте другим Полицейским и гражданам хороший пример.]],

	mayor = "Глава города",
	mayor_desc = [[Глава города создает законы, чтобы улучшить жизнь людей в городе.
	Будучи Главой города, вы можете создавать и принимать ордера на обыск игроков.
	В F-меню вы сможете найти дополнительные функции Главы города.

	Пишите законы так, чтобы они не нарушали правила.

	Срок полномочий: 45 минут]],

	gangster = "Бандит",
	gangster_desc = [[Бандиты — основа криминалитета города.
		Бандит обычно работает на главу банды, который заправляет всеми делами.
		Воруйте, убивайте на заказ и следуйте агенде от босса, или вы, возможно, будете наказаны.]],

	mobboss = "Глава банды",
	mobboss_desc = [[Глава банды является одним из главных преступников в городе.
	Он даёт задания своим подчинённым бандитам и формирует эффективные преступные группировки.
	Он обладает способностью взламывать квартиры и выпускать из тюрем людей.]],
	mobboss_msg = "Станьте бандитом и создайте свою банду (F-меню) чтобы получить эту профессию.",

	merc = "Наёмник",
	merc_desc = [[Наемник выполняет различные заказы за определенную плату.
	Заказы могут быть какими угодно: убийство, кража, разведка и любые другие.
	Покупать услуги наемника могут как бандиты, так и полиция и другие граждане.]],

	medic = "Медик",
	medic_desc = [[Доктор способен исцелить игроков с помощью своих медицинских знаний.
	Используйте медкит, чтобы лечить пациентов и восстанавливать сломанные кости.]],

	gundealer = "Продавец оружия",
	gundealer_desc = [[Продавец оружия является единственным человеком, который может легально продавать оружие другим людям.
		Удостовертесь в том, что вы не продаёте нелегальные виды вооружения в открытую, иначе вас могут арестовать!]],

	trader = "Торговец",
	trader_desc = [[Продавайте различные полезные приспособления (телевизоры, отмычки, раздатчики и др.).
	Перекупайте вещи, оружие. Откройте магазин и начните продажу товаров.]],

	bar = "Бармен",
	bar_desc = [[Бармен продаёт гражданам еду, напитки, алкоголь и другие психоактивные вещества.
	Вам предстоит открыть свой бар и принимать клиентов. Вы также можете продавать продукты, если кто придёт к вам с пустым желудком.
	Также наймите обязательно охрану от буйных посетителей.]],

	carmaster = "Автомеханик",
	carmaster_desc = [[Вы обладаете умениями починки автомобилей.
	Сделайте гараж, где вы будете оказывать услуги владельцам авто.
	Вы также способны заправлять машины и продавать топливо.]],

	security = "Охранник",
	security_desc = [[Нанимайтесь в охрану магазина, банка или телохранителем.
	Вы должны защищать заведение от хулиганов и мелких воров.
	При сложной ситуации вызывайте полицию.
	По умолчанию вам даётся Демократизатор, так что не рискуйте особо, действуйте осторожно.]],

	taxidriver = "Таксист",
	taxidriver_desc = [[Используйте свою или бесплатную машину для частного извоза пассажиров.
	Установите желаемый тариф за километр и отвечайте на вызовы.

	Не тараньте чужие автомобили, иначе вы будете арестованы!]],

	fireman = "Пожарный",
	fireman_desc = [[Ответственная и очень опасная работа. Без вас город может просто сгореть до тла.
	За тушение пожаров вы получаете вознаграждение.

	Не тараньте чужие автомобили, иначе вы будете арестованы!]],

	busdriver = "Водитель автобуса",
	busdriver_desc = [[Вы будете управлять городским автобусом.
	Выберите маршрут из списка предложенных и следуйте по нему.
	Подбирайте людей на остановках.
	Получайте вознаграждение за каждую пройденную остановку.

	Не тараньте чужие автомобили, иначе вы будете арестованы!]],

	extinguish_fire = "%s за тушение огня!",
	extinguish_prop = "%s за тушение пропы!",
	extinguish_player = "%s за тушение человека!",
	extinguish_vehicle = "%s за тушение транспорта!",

	-- Weapons
	wep_nx_c4 = "Бомба C4",
	nx_c4_ammo = "Бомба",
	lockpick = "Отмычка",
	weapon_extinguisher = "Огнетушитель",
	nx_radio = "Рация",
	nx_fuel = "Канистра бензина",
	fuel_ammo = "Бензин",
	fas2_ifak = "Пехотная аптечка",
	stunstick = "\"Демократизатор\"",
	fas2_dv2 = "Боевой нож DV2",
	fas2_machete = "Мачете",
	fas2_ots33 = "ОЦ-33 «Пернач»",
	weapon_rpg = "RPG",
	fas2_m67 = "Граната M67",
	molotov = "Коктейль Молотова",

	-- Ammo
	ammo = "Патроны",
	RPG_Round = "Ракета RPG",
	bandages = "Бинты",
	hemostats = "Зажимы",
	quikclots = "Пластыри",

	-- Categories
	devices = "Оборудование",
	other = "Другое",
	pistols = "Пистолеты",
	smg = "Пистолет-пулемёты",
	rifles = "Винтовки",
	sniper_rifles = "Снайперские винтовки",
	shotguns = "Дробовики",

	-- Attachments
	sights = "Прицел %s",
	tritium_sights = "Тритиевый Прицел",
	foregrip = "Рукоятка",
	bipod = "Бипод",
	silencer = "Глушитель",
	clip = "Магазин %s",

	-- Entities
	soccer_ball = "Футбольный мяч",
	piano = "Рояль",
	drums = "Ударные",
	wepdetector = "Детектор оружия",
	turret = "Турель",
	playxradio = "Радио PlayX",
	playxtv = "Телевизор PlayX",
	playxbillboard = "Биллборд PlayX",
	charger_medkit = "Раздатчик здоровья",
	charger_suit = "Раздатчик брони",
	radar = "Радар",

	-- Drugs
	beer = "Пиво",
	cigarettes = "Сигареты",
	weed = "Марихуана",

	-- SWEPs
	keys = "Ключи",
	pocket = "Сумка",
	arrest_stick = "Арестовывающая дубинка",
	weaponchecker = "Проверка на оружие",
	nx_speedmeter = "Радар-измеритель",
	deployable_tool = "Распаковщик",
	nx_repair = "Починка машины",
	door_ram = "Дверной таран",
	binoculars = "Бинокль",
	weapon_popcorn = "Попкорн",

	-- Hints
	bomb_instructions1 = "Выбросить бомбу",
	bomb_instructions2 = "Прикрепить бомбу к стене или машине",
	bomb_cant = "Нельзя разместить здесь",

	unpacker_instructions1 = "Установить предмет",
	unpacker_instructions2 = "Повернуть предмет",
	unpacker_instructions3 = "Отменить",
	unpacker_instructions4 = "Зажмите %s после распаковки,",
	unpacker_instructions5 = "чтобы упаковать обратно",

	respawn_timer = "До возрождения осталось %d секунд",
	respawn_fee = "Вы заплатили %s за медицинские услуги",
	premium_only = "Доступно только для владельцев Премиум",

	hitman_use = "Сделать заказ",

	rules = "Правила",
	read_rules = "Обязательно ознакомтесь с правилами, нажав ",
	nobind = "[НЕ НАЗНАЧЕНО]",

	-- Cars
	car_on_fire = "Ваша машина горит, эвакуация невозможна",
	car_cant_enter_destroyed = "Машина полностью сломана, невозможно открыть дверь.\nОбратитесь к Автомеханику для починки.",
	car_bought = "Машина куплена",
	car_buymsg = "Вы приобрели %s.\nИспользуйте ближайший терминал чтобы заспавнить машину.",
	car_rentmsg = "Вы арендовали %s.\nИспользуйте ближайший терминал чтобы заспавнить машину.",
	car_nomoney = "У вас недостаточно денег",
	car_modified = "Машина изменена",
	car_sold = "Машина продана",
	car_hobos = "У бездомных нет машин",
	car_coplimit = "Достигнут лимит полицейских машин",
	car_stolen = "Ваша машина украдена",
	car_spawned = "Машина вызвана",
	car_removed = "Машина убрана",
	car_request = "Пустить %s в машину?",
	car_request_sent = "Запрос отправлен",
	car_request_sent_already = "Запрос уже отправлен",
	car_ok_but_distance = "Водитель одобрил запрос, но вы уже слишком далеко от машины",
	car_ok_but_distance_owner = "Пассажир уже слишком далеко от машины",
	car_retrieved = "Владение машиной восстановлено",
	car_alarm = "Сигнализация!",
	car_lockpick_success = "Машина украдена!",
	need_warrant = "Нужен ордер",
	car_rent_broken = "Машина повреждена, почините её у Автомастера",
	car_rent_end = "Аренда машины прекращена",
	car_rent_premium = "Вызов арендованной машины доступен только Премиумам.",
	car_rent_need_premium = "Для аренды машины вам нужен Премиум, который можно найти в разделе Подписки.",
	car_rent_limit = "У вас уже есть арендованная машина!",
	car_rent_start = "Машина арендована",
	car_rent_stop = "Прекратить аренду",
	car_rent_stop_ask = "Сдать машину обратно?",

	my_cars = "Мои машины",
	buy = "Купить",
	car_spawn = "Вызвать",
	car_modify = "Изменить",
	car_sell_for = "Продать: ",
	sell_x_for_x = "Продать %s за %s?",
	modify_x_for_x = "Изменить %s за %s?",
	car_sell = "Продать машину",
	car_modification = "Изменение машины",
	car_apply = "Применить: ",
	car_driver = "Водитель:",
	car_passenger = "Пассажир %d:",
	car = "Машина",
	car_kick = "Выгнать",
	previous_owner = "Прежний владелец: %s",
	taxi_popup = "Такси %s/километр",
	car_retrieval = "Возвращение машины",

	car_destroyed_fine = "Штраф %s за порчу транспорта!",
	car_rent_stopped = "Недостаточно средств для оплаты аренды машины, аренда прекращена",
	car_rent_paid = "Оплата аренды машины: %s",
	car_rent_paid_fine = "Штраф оплачен, вы можете арендовать машину снова",
	car_rent_cant_pay_fine = "Недостаточно средств для оплаты штрафа",
	car_rent_banned = "Вы забанены с аренды на %s",

	cars_unavail = "У вас нет доступных машин",
	cars_unavail_hint = "Авто можно приобрести за деньги или получить от некоторых профессий",

	-- Laws
	laws_title = "Законы города",
	laws_speedlimit = "Ограничение скорости для транспортных средств: ",
	laws_kmh = " км/ч",
	laws_legal = "Легальное",
	laws_license = "Требуется лицензия",
	laws_illegal = "Нелегальное",
	close = "Закрыть",
	close_and_dont_show_for_week = "Закрыть и не показывать неделю",
	apply = "Применить",
	laws_added = "Глава города добавил закон ",
	laws_edited = "Глава города отредактировал закон ",
	laws_removed = "Глава города удалил закон ",
	laws_set = "Установлены законы мэра ",
	laws_clear = "Глава города очистил законы.",
	laws_reset = "Глава города сбросил законы.",
	laws_default = "Установлены стандартные законы.",

	-- City Management
	cc_cityman = "Управление городом",
	cc_copman = "Управление полицией",
	cc_laws = "Законы",
	cc_limits = "Ограничения",
	cc_orders = "Указы",
	cc_upgrades = "Улучшения",
	cc_points = "Очки власти: ",
	cc_save = "<Enter> - сохранить изменения",
	cc_resetlaws = "Сбросить законы на стандартные",
	cc_clearlaws = "Очистить законы",
	cc_addlaw = "Добавить закон",
	cc_lawlimit = "Достигнут лимит законов",
	cc_lawtext = "Текст закона",
	cc_invitecop = "Сделать полицейским",
	cc_kickcop = "Выгнать из полиции",
	cc_assignchief = "Назначить начальника полиции",
	cc_helicopter = "Купить вертолёт",

	-- City Management SV
	cc_limitschanged = "Глава города изменил ограничения.",
	cc_invitetext = "%s приглашает вступить в полицию",
	cc_invited = "Глава города пригласил %s в полицию.",
	cc_invite_fail_ban = "%s не можеть стать полицейским.",
	cc_nopoints = "Недостаточно очков власти",
	cc_kicked = "%s освободил %s от должности.\nОснование: %s",
	cc_chiefassigned = "Глава города назначил %s Начальником Полиции!",
	cc_upgradedalready = "Улучшение уже приобретено",
	cc_upgraded = "Улучшение '%s' приобретено",
	cc_mayor_upgraded = "%s приобрел улучшение '%s'",
	cc_helicopter_spawned = "Вертолёт доставлен на площадку",
	cc_helicopter_obstructed = "Вертолётная площадка занята!",

	lockdown_reason = "Причина: %s",
	door_cp = "Правоохранительные органы",
	agenda_cp = "Повестка дня полиции",

	police_halo = "Радар полиции",
	gang_halo = "Радар банды",
	door_upgrade = "Улучшенные двери",

	charger_medkit_desc = "В здании полиции появляется раздатчик здоровья.",
	charger_suit_desc = "В здании полиции появляется раздатчик брони.",
	door_upgrade_desc = "Государственные двери получают сенсорные панели для удобного открытия/закрытия с отображением статуса замка.",
	police_halo_desc = "Союзников видно через стены зеленым цветом. Если союзник говорит в рацию, цвет сменится на синий. Если союзник получает урон, цвет сменится на красный.",
	microwave_desc = "В здании полиции появляется микроволновка.",
	radio_desc = "Все бандиты в банде автоматически получают рацию.",

	-- CMenu
	actions = "Действия",
	quick_actions = "Быстрые действия",
	issue_cheque = "Выписать чек",
	buy_current_ammo = "Купить патроны на текущее оружие",
	buy_current_ammo_s = "Купить патроны",
	call_to = "Позвонить",
	call_emergency = "Вызвать 911",
	call_service = "Вызвать службу или сервис",
	police = "Полиция",
	police_call = "Вызвать полицию",
	ambulance = "Скорая помощь",
	ambulance_call = "Вызвать скорую помощь",
	fire_service = "Пожарная служба",
	call_fire_service = "Вызвать пожарную службу",
	describe_problem = "Опишите происшествие",
	buy_printer = "Заказать денежный принтер",
	phone_off = "Отключить телефон",
	phone_on = "Включить телефон",
	phone_off_s = "Отключить",
	phone_on_s = "Включить",
	phone_is_off = "Телефон отключен",
	phone_is_on = "Телефон включен",
	option_gang = "- Банда -",
	call_taxi = "Вызвать такси",
	write_letter = "Написать письмо",
	show_laws = "Свод законов",
	upgrades = "Улучшения",
	roll_the_dice = "Бросить кубик",
	roll_sides = "Количество сторон",
	demote_warn = "Используйте увольнение только когда вы стопроцентно уверенны в своей правоте.\n\nПричиной для голосования за увольнение может быть только нарушение правил сервера.\nЗапускать увольнение по любой другой причине, либо с ложной причиной, запрещено.\nПричина не может содержать оскорбления.\n\nНекорректное использование увольнений грозит баном.",
	demote_enter_reason = "Введите причину:",
	demote_prem = "Доступно только для владельцев Roleplay Premium\n\nХотите ли вы узнать больше о Премиум подписке?",
	sell_all_doors = "Продать все двери",
	enter_new_title = "Введите новое название",
	edit_model = "Настроить модель",
	remove_car = "Убрать машину",
	turret_control = "Управление турелями",
	set_shop_pos = "Установить позицию магазина",
	shop_pos_set = "Позиция для обнаружения торговцев установлена",
	microwave_setprice = "Установить цену на микроволновку",
	taxi_setprice = "Установить цену за километр",
	hitman_setprice = "Установить цену за заказ",
	enter_price = "Введите цену",
	enter_reason = "Введите причину",
	enter_reason_suspect = "Подозреваемый: %s\n\nВведите причину",
	stop_dna_scan = "Остановить сканирование ДНК",
	enter_entry_cost = "Введите стоимость участия",
	select_radio_channel = "Сменить канал рации",
	radio_off = "Отключить рацию",
	radio_on = "Включить рацию",
	ballot_reopen = "Вернуться к голосованию на выборах",
	phone_printer_hint = "Нужны деньги? Денежный принтер — лёгкий, но преступный способ получения денег.",
	phone_printer_hint_new = "Нужны деньги? Денежный принтер — лёгкий, но преступный способ получения денег.\nВам нужно быть бандитом чтобы приобрести и использовать принтеры.",
	phone_business_hint = "Воспользуйте услугами бизнесменов. Легальных и не очень.",
	phone_cityserv_hint = "Вызов городских служб",
	no_actions = "Нет действий",
	drop_item_hint = "Нажмите на предмет чтобы выбросить",
	x_interactions = "%d взаимодействий",

	create_group = "Создать банду",
	manage_group = "Управление бандой",
	leave_group = "Покинуть банду",
	enter_summ = "Введите сумму",
	unarrest_player = "Освободить из заключения",
	split_shipment = "Разделить ящик поровну",
	make_shipment = "Сделать ящик из оружия",
	pack = "Упаковать",

	cmenu_hint = "Нажмите кнопку, чтобы открыть игровое меню",
	hint = "Подсказка",

	-- bomb
	bomb_code = "Код:",
	timer_until = "До взрыва (секунд):",
	start_timer = "Запустить отсчет",
	take_bomb = "Забрать бомбу",
	stop_timer = "Остановить отсчет",
	wrong_code = "Неверный код",
	letter_code = "Код бомбы: ",
	disarm = "Разминировать",

	-- weplocker
	pwl_title = "Оружейный шкаф полиции",
	pwl_count = "Взято полицейских оружий: ",
	pwl_warn = "Вы не сможете брать оружия, если нанесете урон другому полицейскому.",
	pwl_wep = "Оружие",
	pwl_avail_c = "Доступность",
	pwl_taken = "занято",
	pwl_avail = "доступно",
	pwl_unavail = "не доступно",
	pwl_giveme = "Получить выбранное оружие",
	pwl_timer = "До следующей выдачи: ",
	pwl_return = "Сдать полученное оружие",
	pwl_close = "Закрыть шкаф",

	pwl_fail_team = "Брать оружие из оружейного шкафа может только полиция.",
	pwl_fail_already = "У вас уже есть оружие из шкафа.",
	pwl_fail_taken = "Это оружие уже взято другим полицейским.",
	pwl_fail_limit = "Достигнут лимит оружий из шкафа.",
	pwl_wait = "Подождите %d секунд.",
	pwl_success = "Оружие выдано.",
	pwl_returned = "Оружие возвращено.",

	pwl_unit_lightassault = "Штурмовик",
	pwl_unit_heavyassault = "Поддержка",
	pwl_unit_sniper = "Снайпер",
	pwl_unit_demolition = "Подрывник",

	--
	radar_already = "У вас уже есть радар.",
	c4_defuser = "Набор для обезвреживания",

	unpacker_packed = "Предмет возвращён в коробку",
	unpacker_toofar = "Слишком далеко от коробки",

	radio_instructions1 = "Говорить в рацию",
	radio_instructions2 = "Само по себе доставание рации ничего не делает",
	radio_instructions3 = "и нужно только для возможности выбросить рацию",

	repair_paid = "Цена ремонта: ",

	speedmeter_instructions = "Приказать водителю остановиться",
	speedmeter_stopnow = "Сотрудник ДПС приказывает остановиться",
	speedmeter_ordered_x = "Водителю %s приказано остановиться",
	speedmeter_ordered = "Водителю приказано остановиться",

	wepcheck_legal = "Легальное: ",
	wepcheck_illegal = "Нелегальное: ",
	wepcheck_noweps = " не имеет оружия.",
	wepcheck_report = "Оружие у",
	wepcheck_inbag = "В сумке:",
	money_printers_genitive = "денежных принтеров",
	cantpocket_printer = "Нельзя положить принтер в сумку!",

	-- Food
	pumpkin = "Тыква",
	burger = "Чизбургер",
	hotdog = "Хот-дог",
	watermelon = "Арбуз",
	soda = "Содовая",
	milk = "Молоко",
	orange = "Апельсин",
	water_bottle = "Бутылка воды",
	difm_station = "Станция",
	difm_silence = "- Тишина 24/7 -",
	difm_volume = "Громкость",

	--
	car_hint_coplight = "Нажмите Shift+R чтобы включить или выключить мигалки",
	car_hint_taxiprice = "Вы можете изменить цену поездки за километр, нажав F и нажав на 'Установить цену за километр' справа",

	-- Taxi
	taxi_nomoney = "У вас больше нет денег на оплату дальнейшего пути!",
	taxi_paid = "Уплачено %s за поездку на такси",
	taxi_payment = "Получено %s за поездку",
	taxi_setprice_fail = "Нельзя менять цену во время поездки!",
	taxi_setprice_ok = "Цена %s за километр установлена",
	taxi_nocar = "Вам нужно обладать машиной такси!",
	call_taxi_fail = "К сожалению, сейчас нет ни одного таксиста.",
	call_taxi_alert = "Вызов такси!",

	--
	demote_restriced = "Голосование на увольнение могут запустить только премиумы и администраторы",
	fishingmod_you = "[Рыбалка] Вы ",
	fishingmod_spent = "потратили",
	fishingmod_received = "получили",

	--
	coolmodel_enabled = "Заменять стандартные модели",
	coolmodel_skin = "Скин:",
	coolmodel_respawn = "Изменения вступят в силу после респавна.",
	coolmodel_nopremium = "У вас нет Премиума, настраиваемые\nмодели не будут работать.",
	coolmodel_none = "Отсутствует",
	coolmodel_settings = "Настройка",
	coolmodel_color = "Цвет",
	coolmodel_title = "Настройка модели",

	--
	he_wants_demote = "%s (%s) желает уволить %s (%s):\n%s",
	he_wants_demote_vgui = "желает уволить",
	he_wants_demote_vgui_res = "с причиной:",
	wanna_vote_demote = "%s (%s) желает уволить %s (%s):\n%s\nЖелаете голосовать?",
	precache_panic = "Из-за ограничений Source Engine, на которые мы не можем повлиять,\nсервер будет перезагружен через %d секунд или ранее.\nВ противном случае сервер бы просто упал.\nКупленные вещи, профессия и местоположение будут возвращены автоматически.",
	restartstuff_given = "Вам возвращено %s за вещи, которые были у вас в момент отключения сервера.",
	arrest_reason = "Причина ареста",
	arrested_x = "Арестованный ",

	-- Detective
	dna_crush = "удар тяжелым предметом",
	dna_bullet = "пулевое ранение",
	dna_fall = "падение с высоты",
	dna_blast = "взрыв",
	dna_club = "удар твердым предметом",
	dna_drown = "утопание",
	dna_slash = "ранение холодным оружием",
	dna_burn = "огонь",
	dna_vehicle = "ДТП",
	dna_unknown = "неизвестно",
	dna_title = "Убитый",
	dna_name = "Имя убитого: ",
	dna_job = "Профессия убитого: ",
	dna_time = "Время смерти: %d секунд назад",
	dna_reason = "Причина смерти: ",
	dna_dist = "Расстояние до убийцы: ",
	dna_weapon = "Орудие убийства: ",
	dna_nopoint = "Убийца уже был убит или арестован",
	dna_destroyed = "ДНК уничтожено предыдущими пробами",
	dna_start = "Начать сканирование ДНК убийцы",
	dna_decoy = "Образец ДНК распался",
	dna_timeout = "Тело исчезнет через %d секунд.",
	dna_call = "Вызвать полицию",
	dna_call_done = "Полиция вызвана",
	dna_cr = "Здесь убитый %s!",
	dna_scanner = "Сканер ДНК",
	dna_scan_name = "Убитый: ",
	dna_searching = "Ищем убийцу",
	dna_next = "До следующего сканирования: ",
	dna_decoy_time = "ДНК распадется через ",
	dna_killer = "Убивший %s",
	dna_killer_dead = "Убийца мертв",
	dna_arrest = "Арест совершен по результату экспертизы ДНК",
	dna_killer_arrested = "Убийца арестован",
	dna_killer_leave = "Убийца покинул город",
	dna_killer_cop = "Убит сотрудником Полиции",
	dna_killer_hitman = "Убит наёмником",

	--
	arrest_question = "Арестован %s\nДа - указать причину ареста\nНет - отпустить из тюрьмы\nАрестованный будет отпущен автоматически, если причина не будет указана",
	hitletter = "Заказ на убийство %s от %s.",

	--
	mayor_overthrown = "Глава города был свержен!",
	mayor_danger = "Глава города в опасности! Если его убьют в течение %d минут, он потеряет должность.",
	mayor_nodanger = "Глава города больше не в опасности.",

	-- Group
	gang_creation = "Создание банды",
	gang_name = "Название банды:",
	gang_info = "В банде должно быть хотя бы 2 бандита.",
	gang_create = "Создать банду",
	gang_poor_name = "Бездарное название",
	gang_few_mates = "Выбрано слишком мало бандитов",
	gang_tab_bandits = "Бандиты",
	gang_kick = "Изгнать",
	gang_invite = "Пригласить в банду",
	gang_give = "Выдать деньги банде",
	gang_give_title = "Выдача денег банде",
	gang_split = "Разделить на всех",
	gang_each = "Каждому",
	gang_split_am = "Количество %s (разделить на всех):",
	gang_each_am = "Количество %s (каждому):",
	gang_request = "Запросить деньги у банды",
	gang_request_title = "Запрос денег у банды",
	gang_request_am = "Количество %s (с каждого):",
	gang_disband = "Распустить группу",
	gang_disband_title = "Роспуск группы",
	gang_disband_confirm = "Подтвердите роспуск группы",
	gang_invite_title = "Приглашение в банду",
	gang_send_invites = "Разослать приглашения",

	-- Gang SV
	gang_disbanded = "Банда %s (босс: %s) распущена",
	gang_job_leaderonly = "Менять это может только лидер банды",
	gang_name_copy = "Банда с таким именем уже существует",
	gang_mates_fail = "Бандиты не выбраны, вышли с сервера или не соответствуют",
	gang_accepted = " принял приглашение в банду",
	gang_created = "Банда создана",
	gang_he_created = "%s создал банду %s",
	gang_not_accepted = " не принял приглашение в банду",
	gang_not_created = "Банда не создана",
	gang_invites_sent = "Приглашения разосланы",
	gang_upgrade_bought = "Глава банды приобрел улучшение %s",
	gang_invite_text = "Вы хотите вступить в %s (глава: %s)?",
	gang_invite_msg = " приглашает вас в банду ",
	gang_kicked_you = " выгнал вас из банды ",
	gang_kicked = " изгнан из банды",
	gang_job_changed_you = " сменил ваш ранг на ",
	gang_job_changed = "Ранг %s изменен на %s",
	gang_given_each = "Выдано %s каждому",
	gang_gave_you = " выдал вам ",
	gang_request_sent = "Запросы разосланы",
	gang_request_text = "Глава группы запрашивает %s",
	gang_he_gave = " передал ",
	gang_he_left = " покинул банду",
	gang_boss = "Глава",
	gang_money_warning = "Внимательно прочитайте запрашиваемую главой банды сумму!",

	-- Markers
	marker_no_police = "К сожалению, сейчас нет ни одного полицейского",
	marker_no_fire = "К сожалению, сейчас нет ни одного пожарного",
	marker_no_medic = "К сожалению, сейчас нет ни одного медика",

	-- Permaupgrades
	up_flashlight = "Фонарь",
	up_flashlight_desc = "Нажмите H, чтобы включить фонарь.",
	up_door_upgrade = "Улучшенные Двери",
	up_door_upgrade_desc = "Все купленные вами двери получают сенсорную панель для удобного открытия/закрытия.",
	up_parkour = "Паркур",
	up_parkour_desc = "1 уровень: возможность один раз прыгнуть от стены.\n2 уровень: возможность хвататься за уступы.",
	up_level = " (уровень ",
	up_bought = "Куплено",
	up_already = "Это улучшение у вас уже есть",
	up_bought_msg = "Приобретено улучшение ",
	up_nomoney = "Недостаточно денег",

	-- Phone/Radio
	phone = "Телефон",
	phone_call_out = "Исходящий вызов",
	phone_call_in = "Входящий вызов",
	phone_drop = "Сброс",
	phone_answer = "Принять",
	phone_dismiss = "Отклонить",
	phone_already = "Звонок уже активен",
	phone_busy = ": занято",
	phone_remote_off = ": аппарат абонента отключен или находится вне зоны действия сети",
	phone_noans = ": нет ответа",

	radio_title = "Рация: выбор канала",
	radio_group_chan = "Канал группы",
	radio_group_chan_ok = "Выбран групповой канал рации",
	radio_chan = "Канал (1-999):",
	radio_chan_ok = "Выбран канал рации ",
	radio_chan_fail = "Канал должен быть числом 1-999.",

	--
	sec = " с",
	tradersell_who = "Кто станет владельцем?",
	ifak_nomoney = "Вы не получите денег за лечение игрока, которому вы наносили урон",
	dice_roll = "%s кидает кубик (%s). Выпало число %s.",

	rpname_info = "Выберите себе ролевое имя.\n\nВаше ролевое имя должно быть реалистичным (никаких Котов Барсиков),\nне содержать лишних знаков пунктуации\nи соблюдать правильность использования регистра букв.",
	rpname_name = "Имя",
	rpname_surname = "Фамилия",
	rpname_fail_length_min = "Не меньше %d символов",
	rpname_fail_length_max = "Не больше %d символов",
	rpname_fail_blocked = "Неподходящее имя",
	rpname_fail_notallowed = "Присутствуют неразрешённые символы",
	rpname_fail_exclusive = "В одном слове нельзя сочетать символы из разных алфавитов",
	rpname_fail_words = "Должно состоять из хотя бы имени и фамилии",
	rpname_fail_capital = "Заглавные буквы?",
	rpname_cooldown = "Вы сможете поменять имя через %s",
	rpname_you_are_changing_to = "Вы меняете имя на",
	rpname_cooldown_alt = "Снова изменить имя можно будет через %s",

	premium = "Премиум",
	connecting = "Подключается",
	score_ingame = " человек в игре",
	score_and = " и ",
	score_connecting = " подключаются",

	elevator_title = "ЛИФТ",
	elevator_hall = "Зал",
	elevator_office = "Офисы",

	deployable_onlylast = "Распаковать ящик может только последний державший",
	deployable_wait = "Подождите %d секунд",

	--
	warn_cops = "Сообщить в полицию",
	cr_phrase = "Здесь разыскиваемый %s!",

	widget_rules = "Правила",
	widget_news = "Новости",
	widget_info = "Помощь",
	widget_group = "Группа Steam",

	-- elections
	elections_timer = "Выборы с %d кандидатами через %s",

	quota = "Квота: %d%% от текущих игроков",
	no_quota = "Нет квоты",
	quota_one_man = "Должность для одного человека",
	quota_notice = "Лимиты на профессиях зависят от количества игроков\nИгроки с Премиум подпиской могут занимать профессии в обход лимитов",
	need_to_be_x = "Требуется быть %s",
	joining_or = " или ",
	job_singleman_occupied = "Профессия занята",
	job_already = "Это ваша текущая профессия",
	job_limit_hit_premium = "Достигнут лимит игроков на данной профессии\nВы можете обойти лимит, используя Премиум подписку",
	job_limit_hit_no_premium = "Достигнут лимит игроков на данной профессии",


	enemy = "Враг",
	neutral = "Нейтрал",
	friend = "Друг",
	turret_default = "По умолчанию:",
	turret_friends = "Друзья:",
	steam_friends = "Друзья Steam",
	gang_or_police = "банда / полиция",
	cant_pack_turret = "Нельзя упаковать сломанную турель",
	turret_already_repair = "Турель уже чинится",
	turret_repairing = "Ремонт начался",
	turret_attacked = "Турель атакована!",
	turret_lockpicker = "Взломщик!",
	turret_owner = "Владелец: %s",
	turret_state = "Состояние: %d%% (%d)",

	-- Player stats
	stat_stamina_low = "Изнеможден",
	stat_stamina_med = "Устал",
	stat_stamina_hi = "Утомился",

	stat_break_low = "Ушиб",
	stat_break_med = "Вывих",
	stat_break_hi = "Перелом",

	stat_starve_low = "Проголодался",
	stat_starve_med = "Голоден",
	stat_starve_hi = "Смертельно голоден",

	stat_drowning = "Недостаточно кислорода",

	stat_bleed_low = "Кровотечение",
	stat_bleed_med = "Сильное кровотечение",
	stat_bleed_hi = "Смертельная потеря крови",

	stat_bone_left_quadricep = "Левая бедренная кость",
	stat_bone_left_knee = "Левая коленная чашечка",
	stat_bone_left_shin = "Левая малоберцовая кость",
	stat_bone_left_ankle = "Левая таранная кость",
	stat_bone_left_foot = "Левая ступня",
	stat_bone_left_toe = "Левая лодыжка",

	stat_bone_right_quadricep = "Правая бедренная кость",
	stat_bone_right_knee = "Правая коленная чашечка",
	stat_bone_right_shin = "Правая малоберцовая кость",
	stat_bone_right_ankle = "Правая таранная кость",
	stat_bone_right_foot = "Правая ступня",
	stat_bone_right_toe = "Правая лодыжка",

	stat_wellfed_low = "Сытость",
	stat_wellfed_med = "Полный",
	stat_wellfed_hi = "Жиробас",

	nx_medcenter = "Медкит",
	nx_medcenter_energy = "Батарея медкита",
	medcenter_mode_heal = "Общее лечение",
	medcenter_mode_bones = "Рентген",
	medcenter_mode_desease = "Общий анализ",
	medcenter_skel_health = "Целостность скелета",
	medcenter_skel_scanning = "Сканирование",
	medcenter_health = "Здоровье",
	medcenter_ready = "Готов",

	police_is_near = "Полиция рядом",

	thanks_printers = "Вот твои принтеры, %s...",
	thanks_goods = "Хороший товар, %s...",

	heatmap = "Теплокарта",
	heatmap_desc = "Отображает выделяемое принтерами, микроволновками и прочими электроприборами тепло на карте",
	heatmap_already = "У вас уже есть теплокарта",

	lockdown_timeleft = "У вас есть %d секунд чтобы добраться домой",
	lockdown_timeout = "Полиция может арестовать вас при нарушении ком. часа",
	lockdown_info_timeleft = "Есть %d секунд чтобы добраться домой",
	lockdown_info_timeout = "Можно арестовать при нарушении ком. часа",

	pd_permit_give = "Выдать/продлить пропуск в ПУ (%d мин)",
	pd_permit_revoke = "Отозвать пропуск в ПУ",
	pd_permit_timeleft = "Пропуск в ПУ: %s",
	pd_permit_issued_actor = "Выдан пропуск в ПУ для %s",
	pd_permit_issued_target = "Получен пропуск в ПУ на %d мин",
	pd_permit_revoked_actor = "Пропуск в ПУ для %s отозван",
	pd_permit_revoked_target = "Ваш пропуск в ПУ отозван; срочно покиньте ПУ",

	pd_entrance_warning = "Вход без пропуска воспрещён",

	purchase_placement = "Выберите куда сложить ящики с товаром.\nВы также можете сложить покупки в ближайшую машину.",
	buy_printer_for = "Купить принтер за %s",
	my_pocket = "Моя сумка",
	restock_in = "Пополнение через %s",
	for_you_in_stock = "Для вас в наличии: %d/%d\n%s",
	printerman_gui_title = "Принт-сервис",
	restock_m_s = "%02dм%02dс",
	restock_s = "%02dс",

	sellers_gohere = "Выдвигайтесь к метке для встречи с продавцом",
	sellers_here = "Встреча здесь",

	printer_new_way = "Принтеры нельзя купить из воздуха.\nТеперь нужно вызвать специального торговца.\nC > Вызвать службу или сервис > Заказать денежный принтер",
	buyprinter_new_way = "Заказать принтеры можно только через сервис",

	charger_battery = "Батарея на 100 заряда",
	weapon_vape = "Вапорайзер",
	repair_verb = "Починить",
	door_single = "Дверь",
	ignore_cops = "Игнорировать полицейских",

	pot = "Садовый горшок",
	seedbag_weed = "Семена марихуаны",
	seedbag_orange = "Семена апельсина",
	fertilizer = "Грунт",
	drug_weed = "Марихуана",

	stat_weed1 = "Высокий",
	stat_weed2 = "Очень высокий",
	stat_weed3 = "НАИВЫСОЧАЙШИЙ",

	itemshop = "Торговый автомат",
	empty = "ПУСТО",
	itemshop_eject = "ИЗЪЯТЬ",
	itemshop_price = "ЦЕНА",
	itemshop_map_spot = "Публичная метка",
	itemshop_wallpaper = "Обои",
	itemshop_eject_money = "Изъять деньги",
	itemshop_settings = "Обслуживание",
	itemshop_on_service = "В ОБСЛУЖИВАНИИ",
	itemshop_put_shipments = "Для добавления товара поднесите его к экрану",
	itemshop_restore = "Восстановить ядро",
	itemshop_rename = "Переименновать",
	itemshop_setprice_title = "Установить цену на %s",
	itemshop_setprice_text = "Введите новую цену",
	itemshop_rename_title = "Задать имя торговому автомату",
	itemshop_rename_text = "Введите новое имя",
	itemshop_buyhint = "Купить %s за %s",
	itemshop_increase_count = "Добавить",
	itemshop_decrease_count = "Убрать",
	itemshop_tap = "Нажать",

	disabled_dead = "Мертвые не могут",
	disabled_arrested = "Арестованные не могут",
	disabled_tased = "Шокированные не могут",
	disabled_cuffs = "Закованные не могут",
	disabled_car = "В машине нельзя",

	handcuffs = "Наручники",
	handcuffs_topocket = "Наручники положены в сумку",
	handcuffs_toinventory = "Наручники возвращены",
	handcuffs_arrest = "арестовать",
	handcuffs_relese = "освободить",
	handcuffs_makefollow = "вести за собой",
	handcuffs_makestop = "остановить",
	handcuffs_incuffs = "В наручниках",
	handcuffs_escape_progress = "Освобождение:",
	handcuffs_escape = "освободиться",
	handcuffs_emenynearby = "враг рядом",
	handcuffs_immediate = "Этот гражданин только что был освобожён и не может быть тут же закован заново",

	-- Entity
	elevator_button_up = "Вызвать лифт вверх",
	elevator_button_down = "Вызвать лифт вниз",
	elevator_button_level = "Этаж %d",
	elevator_display_level = "Этаж:",
	-- TOOL:
	["undone_elevator"] = "Отмена: лифт",
	["tool.nx_elevator.name"] = "Лифт",
	["tool.nx_elevator.desc"] = "Инструмент для создания многоэтажных лифтов",
	["tool.nx_elevator.material"] = "Материал шахты:",
	["tool.nx_elevator.model"] = "Модель лифта:",
	["tool.nx_elevator.dupehint"] = "Чтобы использовать Дубликатор на лифте, вы должны разместить лифт на пропе",
	["tool.nx_elevator.1_left"] = "Нажмите где угодно для создания лифта или нажмите на существующий для редактирования",
	["tool.nx_elevator.2_left"] = "Добавить этаж",
	["tool.nx_elevator.2_right"] = "Убрать этаж",
	["tool.nx_elevator.2_reload"] = "Применить изменения",
	["sboxlimit_elevator_floors"] = "Достигнут лимит этажей",
	["sboxlimit_elevator_near_level"] = "Вам нужно быть на желаемом этаже и быть близко к камере",
	["sboxlimit_elevator_blocked"] = "Что-то блокирует камеру лифта",
	["sboxlimit_elevator_cant_see"] = "Новая камера лифта должна быть в зоне видимости",

	tool_link_name = "Соединение",
	tool_link_desc = "Соединяет объекты в постройку для сохранения в Duplicator",
	tool_link_left = "выбрать один объект или постройку",
	tool_link_left_shift = "+ Shift   выбрать все объекты рядом",
	tool_link_right = "соединить / разъединить",
	tool_link_reload = "сбросить выбор",
	tool_link_dist = "Дальность поиска",
	tool_link_screen_separate = "Отдельных:",
	tool_link_screen_contraptions = "Построек:",

	loading_net = "Загрузка данных...",

	weekday_1 = "Понедельник",
	weekday_2 = "Вторник",
	weekday_3 = "Среда",
	weekday_4 = "Четверг",
	weekday_5 = "Пятница",
	weekday_6 = "Суббота",
	weekday_7 = "Воскресенье",

	-- teamkill
	teamkill_kill = "%s убил союзника %s.",
	teamkill_kill_warn = "ВНИМАНИЕ: Вы убили союзника! Вы будете забанены с полиции если вы убьёте еще %d союзников!",
	teamkill_hurt = "%s атаковал союзника %s.",
	teamkill_hurt_warn = "ВНИМАНИЕ: Вы атаковали союзника %s!",

	-- lives
	lives_died = "У вас осталось %d жизней. %d минут до восполнения одной.",
	lives_died_warn = "При отсутствующих жизнях вы не сможете использовать оружие.",
	lives_restored = "Восстановлена одна жизнь. Количество жизней: %d",
	lives_hud1 = "Жизней: %d/2",
	lives_hud2 = "До восполнения: %s минут",
	lives_hud = "Жизней: ",

	-- election
	election_start = "Выборы начинаются, идёт регистрация кандидатов!",
	election_reg_over = "Закончилась регистрация кандидатов, начинается голосование!",
	election_thanks_for_voting = "Ваш голос зарегистрирован",
	election_over = "Выборы закончились. Победитель — %s",
	election_second_tour = "Нет однозначного победителя. Объявляется дополнительный тур голосования!",
	election_wanna = "Желаете проголосовать на выборах?",
	election_results = "Результаты голосования:",
	election_put_promise = "Укажите ваше предвыборное обещание:",
	election_registered = "Ваша кандидатура зарегистрирована",
	election_already = "Ваша кандидатура уже зарегистрирована!",
	election_too_late = "Регистрация в кандидаты закончена",

	-- car trunk
	trunk_inspect = "Осмотреть багажник",
	trunk_instructions = "Чтобы поместить предмет в багажник отпустите его Гравипушкой сзади машины",

	admin_tp = "При вызове администратора обязательно указывайте причину.",

	wire_ranger_restricted = "Использование wire ranger ограничено из-за неоправданной нагрузки на сервер и клиенты. Используйте wire trigger. Его можно использовать для тех же целей, что и ranger.",
	wire_e2say_alert = "Вы разместили чип Wire Expression 2 который только что написал сообщение от вашего лица в чат.\nЕсли вы хотите заблокировать отправление сообщений, то нажмите на эту кнопку.",

	district_main = "Деловой район",
	district_second = "Жилой район",
	district_industrial = "Индустриальный район",
	district_elite = "Элитный район",
	district_fishing = "Прибрежный район",
	district_rcar = "РКАД",
	district_mountain = "Горы",

	can_steal_cars_no = "%s не умеет взламывать автомобили. Такое могут только %s.",

	prop_hp = "Прочность",
	prop_stability = "Стабильность",

	cop_rdm_watch_warning = "Полицейскому запрещено убивать невооруженных граждан; при повторных нарушениях будет выдан бан",
	cop_rdm_watch_ban_reason = "убийство невооружённого гражданина",

	bus_popup = "Проезд на автобусе: %s",
	bus_wait = "Ожидайте %d секунд",
	bus_reward = "%s за выполнение остановки",
	bus_get_back = "Вернитесь на точку!",

	bus_stops = {
		pier = "Причал",
		village = "Деревня",
		apartments = "Апартаменты",
		supermarket = "Супермаркет",
		tavern = "Таверна",
		factories = "Промзона",
		club = "Клуб",
		theater = "Театр",
		pd = "Полицейский Участок",
		medcenter = "Медцентр",
		cobsgm = "Автосалон",
		shell = "АЗС",
	},

	bus_lanes = {
		perspective = "Перспективная",
		distant = "Дальняя",
		ring = "РКАД",
		center = "Центр",
	},

	bus_announcer_next = "Следующая остановка",

	fishtutor_bait = "Нажмите B чтобы открыть меню наживок",
	fishtutor_bait = "Зажмите ЛКМ чтобы погрузить крючок в воду\nЗажав SHIFT, вы ускорите размотку\n\nВы можете снять наживку, зажав R",
	fishtutor_ = "Ждите улова...",
	fishtutor_ = "Вы поймали %s!",
	fishtutor_ = "Зажмите ПКМ чтобы намотать леску\nЗажав SHIFT, вы ускорите намотку",
	fishtutor_ = "Снимите добычу зажав R над землёй",
	fishtutor_ = "Вы можете продать предмет нажав R",
	fishtutor_ = "Вы можете открыть подарок нажав E",
	fishtutor_ = "Мусор",
	fishtutor_ = "Плита",
	fishtutor_ = "Сферы разума",
	fishtutor_ = "",

	-- Halloween
	zombies_start = "Город покрывается тьмой, слышутся вопли и крики, кровожадные монстры выходят собирать жатву...",
	zombies_end = "Солнце восходит над городом. Монстры отступают.",

	----- OLDER
	russiandrp1 = "Русский DarkRP #1",
	onlineplayers = " онлайн игроков",
	wscreenstatus = "Синхронизируем ваши данные",
	wscreenwelcome = "Добро пожаловать. Снова.",
	secs = " секунд",
	r_u_sure = "Вы уверены?",

	finefortk = "Вы заплатили штраф за убийство союзника в размере %s",
	finecantafford = "Вы не смогли оплатить штраф за убийство союзника и были уволены!",

	heyitsnlrbaby = "Вам запрещено возвращаться на место насильственной смерти в течение: ",

	antiafk = "Внимание!\nЕсли вы продолжите бездействовать, вы можете быть кикнуты!",

	should_be_handcuffed = "Игрок должен находиться в наручниках!",

	picture_invalidurl = "Неверный URL адрес!",

	ent_storage_locked = "Хранилище закрыто\nНажмите SHIFT + E для открытия",

	antipropspam = "Вы не можете так часто спавнить пропы",

	initialjob_radioman = "Радиоведущий",
	initialjob_engeneer = "Инженер",
	initialjob_constructor = "Конструктор",
	initialjob_plumber = "Сантехник",
	initialjob_teacher = "Преподаватель",
	initialjob_archaeologist = "Археолог",
	initialjob_astronomer = "Астроном",
	initialjob_philosopher = "Философ",
	initialjob_speaker = "Диктор",
	initialjob_programmer = "Программист",
	initialjob_journalist = "Журналист",
	initialjob_trainer = "Тренер",
	initialjob_librarian = "Библиотекарь",
	initialjob_receptionist = "Портье",
	initialjob_janitor = "Садовник",
	initialjob_postman = "Почтальон",
	initialjob_agronomist = "Агроном",
	initialjob_translator = "Переводчик",
	initialjob_taster = "Дегустатор",
	initialjob_lawyer = "Юрист",
	initialjob_accountant = "Бухгалтер",
	initialjob_realtor = "Риелтор",
	initialjob_carpenter = "Плотник",
	initialjob_joiner = "Столяр",
	initialjob_actor = "Актёр",
	initialjob_animator = "Аниматор",
	initialjob_photographer = "Фотограф",
	initialjob_tattooartist = "Татуировщик",
	initialjob_artist = "Художник",
	initialjob_producer = "Режиссёр",
	initialjob_model = "Фотомодель",
	initialjob_dj = "Диджей",
	initialjob_hairdresser = "Парикмахер",
	initialjob_florist = "Флорист",
	initialjob_croupier = "Крупье",
	initialjob_toastmaster = "Тамада",
	initialjob_peacemaker = "Миротворец",
	initialjob_inquirer = "Дознаватель",
	initialjob_furcol = "Сборщик мебели",
	initialjob_fitinst = "Фитнес инструктор",
	initialjob_visagiste = "Визажист",
	initialjob_designer = "Дизайнер",
	initialjob_modeler = "Модельер",
	initialjob_stylist = "Стилист",
	initialjob_architect = "Архитектор",
	initialjob_builder = "Строитель",
	initialjob_blogger = "Блогер",
	initialjob_therapist = "Логопед",
	initialjob_farmer = "Фермер",

	state_bleeding = "Кровотечение",
	state_dehydration = "Обезвоживание",
	state_drowning = "Недостаток кислорода",
	state_pain = "Боль",
	state_hunger = "Голод",
	state_rage = "Ярость",
	state_satiety = "Удовлетворенность",
	state_surfeit = "Переедание",

	gift_ishere = "Подарок находится здесь!",
	gift_dontwait = "Успейте забрать!",
	gift_spawned = "На сервере появился подарок!\nУ вас есть 5 минут чтобы забрать его!",
	gift_alreadyused = " активировал подарок!",

	hints_click = "Кликните чтобы продолжить",
	hints_use = "Использовать",
	hints_handsup = "Поднять/опустить кулаки",
	hints_menu = "Меню",
	hints_animations = "Меню жестов",
	hints_take = "Поднять",
	hints_throw = "Выбросить",
	hints_open = "Открыть",
	hints_close = "Закрыть",
	hints_cuff = "Заковать",
	hints_uncuff = "Освободить",
	hints_dead = "Нажмите SPACE, чтобы возродиться",
	hints_giveweaponsback = "Вернуть конфискованное оружие",
	hints_takeweapons = "Конфисковать нелегальное оружие",
	hints_checkweapons = "Проверить наличие нелегального оружия",

	events_noeventsnow = "Срок регистрации на событие закончился",
	events_noticeaboutleave = "Вы можете покинуть событие выбрав пункт в контекстном меню",
	events_dm = "Событие Deathmatch",
	events_dm_enabled = "Сейчас проходит событие Deathmatch!",
	events_dm_aboutjoin = "Вы можете присоединиться к Deathmatch, выбрав пункт в контекстном меню",
	events_dm_over = "Событие Deahtmatch закончено!",
	events_dm_notify = "Через 2 минуты начнётся событие Deahtmatch!",

	rpname_title = "Регистрация",
	rpname_name = "Имя",
	rpname_surname = "Фамилия",
	rpname_ready = "Готово",
	rpname_incorrectname = "Введите корректное имя!",
	rpname_incorrectsurname = "Введите корректную фамилию!",
	rpname_help = "Не могу зарегистрироваться",
	rpname_helptitle = "Решение проблем",
	rpname_helptext = "Помните!\nВы должны писать своё имя на Английском языке и с большой буквы, иначе вы не сможете зарегистрироваться!\n\nЕсли вам до сих пор не понятно как это должно выглядеть, то придерживайтесь следующему:\nName Surname",

	scoreboard_openprofile = "Открыть профиль",
	scoreboard_copysteamid = "Скопировать SteamID",
	scoreboard_copysteamid64 = "Скопировать SteamID64",
	scoreboard_goto = "Телепортироваться",
	scoreboard_teleport = "Телепортировать",
	scoreboard_return = "Вернуть",
	scoreboard_spectate = "Следить",
	scoreboard_premium = "Премиум",

	esc_copyright = "© SkynetProject 2015-2018",
	esc_content = "Контент",
	esc_settings = "Настройки",
	esc_leave = "Отключиться",
	esc_playertable = "Таблица игроков",
	esc_spraytable = "Таблица спреев",
	esc_vk = "Группа ВКонтакте",
	esc_steam = "Группа Steam",
	esc_website = "Веб-сайт",
	esc_badskin = "Неподходящаяя профессия",
	esc_badskin_info = "К сожалению, модель вашей профессии не подходит для использования магазина",
	esc_warning = "При отключении с сервера вы потеряете всё своё имущество и содержимое сумки. Вы уверены?",
	esc_gamesettings = "Настройки игры",
	esc_hudsettings = "Настройки интерфейса",

	settings_hud = "Настройки интерфейса",
	settings_global = "Глобальные настройки",
	settings_minimap = "Миникарта",
	settings_hud_outline = "Отображать обводку интерфейса",
	settings_hud_alt = "Отображать альтернативный интерфейс",
	settings_hud_viewbob = "Отображать трясение экрана",
	settings_minimap_draw = "Отображать миникарту",
	settings_minimap_bg = "Отображать дополнительный фон миникарты",
	settings_minimap_friends = "Отображать друзей",
	settings_minimap_teammates = "Отображать товарищей",
	settings_minimap_shops = "Отображать магазины и терминалы",

	warning = "Предупреждение",

	names_health = "Здоровье: ",
	names_speaking = "Говорит",
	names_chatting = "Печатает",
	names_license = "Лицензия имеется",
	names_wanted = "В розыске!",

	hud_mainindicators = "Основные индикаторы",
	hud_health = "Здоровье",
	hud_armor = "Броня",
	hud_energy = "Энергия",
	hud_hunger = "Голод",
	hud_thirst = "Жажда",
	hud_microoff = "Микрофон рации выключен (T)",
	hud_microon = "Микрофон рации включён (T)",
	hud_speakeroff = "Динамик рации выключен (H)",
	hud_speakeron = "Динамик рации включён (H)",
	hud_lockdown = "Сейчас проводится комендантский час!",
	hud_talk = "Говорите",
	hud_license = "с лицензией",

	cmenu_turnoffphone = "Выключить телефон",
	cmenu_turnonphone = "Включить телефон",
	cmenu_chooseringtone = "Выбрать мелодию звонка",
	cmenu_givemoney = "Дать денег",
	cmenu_dropmoney = "Выкинуть деньги",
	cmenu_dropweapon = "Выкинуть текущее оружие",
	cmenu_buyammo = "Купить патроны на текущее оружие",
	cmenu_sellalldoors = "Продать все двери",
	cmenu_sendpos = "Отправить местоположение",
	cmenu_changejob = "Сменить название профессии",
	cmenu_demote = "Уволить игрока",
	cmenu_enteramount = "Введите число",
	cmenu_enterlaw = "Введите закон",
	cmenu_enterreason = "Введите причину",
	cmenu_entername = "Введите новое название",
	cmenu_phone = "Телефон",
	cmenu_dropcube = "Бросить кубик",
	cmenu_laws = "Законы города",
	cmenu_askforlicense = "Запросить лицензию",
	cmenu_startlockdown = "Начать комендантский час",
	cmenu_stoplockdown = "Закончить комендантский час",
	cmenu_givelicense = "Выдать лицензию",
	cmenu_addlaw = "Добавить закон",
	cmenu_removelaw = "Удалить закон",
	cmenu_addwanted = "Объявить в розыск",
	cmenu_removewanted = "Снять розыск",
	cmenu_addwarrant = "Выдать ордер на обыск",
	cmenu_rules = "Правила сервера",
	cmenu_groups = "Меню группировки",
	cmenu_logs = "Открыть логи",
	cmenu_left = "Игрок отключился",
	cmenu_callpolice = "Вызвать полицию",
	cmenu_callingpolice = "Вызов полиции",
	cmenu_entersituation = "Опишите ситуацию",
	cmenu_leaveevent = "Покинуть событие",
	cmenu_joinevent = "Участвовать в событии",
	cmenu_hitprice = "Установить цену на заказ",
	cmenu_reports = "Меню жалоб",
	cmenu_report_quest = "Вопрос",
	cmenu_report_rp = "Жалоба",
	cmenu_admcom = "Связь с администрацией",

	reports_adminsgotrequest = "Администрация получила ваш запрос и ответит в ближайшее время",

	phone_chooseringtone = "Выбрать рингтон",
	phone_save = "Сохранить",
	phone_title = "Телефон",
	phone_accept = "Принять",
	phone_deny = "Отклонить",
	phone_disabled = "Ваш телефон выключен",
	phone_ringtonechanged = "Рингтон звонка изменён",
	phone_unknown = "Такого рингтона не существует",
	phone_nocall = "Нет активных вызовов",
	phone_on = "Телефон включен",
	phone_off = "Телефон выключен",

	hitman_title = "Наёмный убийца",
	hitman_before = "Нажмите Е чтобы заказать убийство",
	hitman_after = "Заказ\nпринят",

	job_citizen_title = "Гражданин",
	job_citizen_desc = [[Вы основное звено мирного населения города.
Если вы не нашли подходящую оплачиваемую профессию, вы всегда можете подрабатывать в своё удовольствие. Станьте комиком и устраивайте спектакли, музыкантом, курьером или же подмастерьем у Торговца оружием.
На крайний случай вы можете сблизиться с криминальным миром и помогать в различных событиях связанных с ограблением или рейдом жилых помещений для получения прибыли. Всё в ваших руках.]],

	job_hobo_title = "Бездомный",
	job_hobo_desc = [[Вы лицо без определенного места жительства, к сожалению жизнь обошлась с вами не слишком хорошо, и теперь вы вынуждены осматривать каждое мусорное хранилище, чтобы прожить эту замечательную и в тоже время безжалостную жизнь.]],

	job_gang_title = "Бандит",
	job_gang_desc = [[Вы основное звено криминального мира. Объединяйтесь в банды и занимайтесь нелегальной перепродажей, заработком или ограблениями.
В случае одиночества, вы всегда можете присоединиться к Главе криминала или же остаться одиночкой.]],

    job_hitman_title = "Наёмный убийца",
    job_hitman_desc = [[Вы также являетесь торговцем, как и многие другие, но услуги у вас немного своеобразные.
Ищите клиентов на улицах города и расправляйтесь над неудачниками, которым повезло оказаться в уголке вашего контракта.]],

    job_mob_title = "Глава криминала",
    job_mob_desc = [[Глава криминала является самым главным преступником в городе.
В вашей власти устраивать самые серьёзные перевероты и революции, но не стоит забывать, что бандиты могут объединяться между собой и в случае чего вы не будете их авторитетом.]],

    job_trader_title = "Торговец",
    job_trader_desc = [[Вы один из самых требуемых торговцев города. В вашем арсенале различные потребительские товары.
Получите должную лицензию, обустройте ваш магазин всякой всячины и торгуйте в своё удовольствие.]],

    job_mechanic_title = "Автомеханик",
    job_mechanic_desc = [[Вы специалист в сфере автомобилей. Обустройте свою автомастерскую и проводите работы и диагностику автомобилей.]],

    job_guard_title = "Охранник",
    job_guard_desc = [[Вы обычный охранник на предприятиях. Устройтесь в один из магазинов и следите за соблюдением порядка на вашей территории.
В случае угроз жизни посетителей или торговцев, выводите их на улицы и дожидайтесь прибытия полиции.]],

    job_gun_title = "Торговец оружием",
    job_gun_desc = [[Товар торговца оружием является одним из самых дорогих и полезным.
Обустройте свой магазин и продавайте орудия мести и справедливости различным гражданам.
Также, вам стоит получить лицензию на торговлю у Главы города или полиции, в случае отсутствия предыдущего.]],

    job_medic_title = "Врач",
    job_medic_desc = [[В ваших руках здоровье и жизнь граждан города. Встаньте на службу у полиции и помогайте им в крайних ситуациях или же обустройте свою клинику и лечите мирных граждан и консультируйте их по различным вопросам болезни.]],

    job_cook_title = "Повар",
    job_cook_desc = [[Казалось бы, обычный повар, что здесь такого? Но на самом деле в ваших руках жизни многих граждан.
В еде и питье нуждается множество людей по всему городу.
Откройте свой ресторан в одном из зданий города и повышайте статистику сытого населения.]],

    job_police_title = "Рядовой полиции",
    job_police_desc = [[Вы являетесь самим низшим звеном полиции. В ваших руках слабое вооружение и подготовка.
В случае серьезных угроз лучше вызывать подкрепление.

Разбирайтесь в мелких скандалах и угрозах на улицах города и следите за соблюдением порядка.]],

	job_chief_title = "Офицер полиции",
	job_chief_desc = [[Офицеры это основное звено всей полиции. Слушайте указания начальства и выполняйте их.
Также, не забывайте патрулировать город и избавлять его от нелегальной деятельности.
Ваш долг это защита каждого добропорядочного гражданина города.]],

	job_chiefda_title = "Глава полиции",
	job_chiefda_desc = [[Глава полиции является главным среди полицейских.
Координируйте действия сотрудников полиции, наводя порядок в районах города.
Слушайте указания Главы города и передавайте их своим подчинённым.]],

	job_swat_title = "SWAT",
	job_swat_desc = [[SWAT является самым подготовленным сотрудником полиции.
Слушайте указания Главы полиции и выполняйте их подлежащим образом.

У вас есть специальные силы для штурма квартир и домов. Используйте их по уму.]],

	job_mayor_title = "Глава города",
	job_mayor_desc = [[В ваших руках экономика, процветание и развитие города.
Под вашим руководством имеется вся полиция города.
Прославьтесь самым добрым мэром города за всю историю, или же наоборот безжалостным фюрером. Всё в ваших руках.]],
	job_mayor_die = "Глава города был убит!\nГороду требуется новый законный лидер!",

	door_police = "Правоохранительные органы",
	door_medic = "Здравоохранительные органы",

	demotegroup_police = "Полиция",
	demotegroup_gangs = "Бандиты",

	category_civil = "Граждане",
	category_police = "Правоохранительные органы",
	category_criminal = "Криминал",
	category_trade = "Торговля",

	rules_title = "Правила сервера",

	table_players_title = "Таблица игроков",
	table_players_name = "Игровое имя",
	table_players_job = "Профессия",
	table_players_rank = "Ранг",
	table_players_group = "Группировка",
	table_players_time = "Наигранное время",
	table_players_none = "Отсутствует",

	groups_creating_title = "Создание группировок",
	groups_creating_text = "Обязательно наличие заглавных английских букв!\n          Создание обойдётся вам в ",
	groups_creating_enter = "Введите название группировки..",
	groups_notify_incorrectname = "Данное название не соответствует требованиям!",
	groups_notify_cantafford = "Вы не можете позволить себе группировку!",
	groups_greetings_title = "Поздравляем с созданием группировки!",
	groups_greetings_text_1 = 'Поздравляем с созданием группировки!\n\nГруппировка: "',
	groups_greetings_text_2 = '"\nВаш текущий ранг: owner\n\nДанная система находится в стадии тестирования, о любых ошибках сообщайте на форуме.\n\n© SkynetProject',
	groups_menu_title = 'Меню группировки "',
	groups_menu_leave = "Покинуть группировку",
	groups_menu_leave_title = "Вы точно хотите покинуть группировку?",
	groups_menu_invite_title = "Приглашение игроков",
	groups_menu_kick_title = "Исключение игроков",
	groups_menu_info_title = "Информация о группировке",
	groups_menu_info_text_1 = "Группировка:\n",
	groups_menu_info_text_2 = "\n\nДополнения:\n1) Прибавка к зарплате: ",
	groups_menu_info_text_3 = "\n2) Прибавка к силе прыжка: 5p.\n3) Прибавка к скорости бега: 5p.\n4) Прибавка к скорости ходьбы: 10p.",
	groups_invitebox_title = "Приглашение в группировку",
	groups_invitebox_text = "Вы были приглашены в группировку!\n    Желаете принять приглашение?",
	groups_menu_enterthename = "Введите имя..",
	groups_yes = "Да",
	groups_no = "Нет",
	groups_ready = "Готово",

	noowner = "Нет владельца",

	moneyprinter_copyright = "© SkynetBank",
	moneyprinter_owner = "Владелец:",
	moneyprinter_premium = "Премиум",
	moneyprinter_usual = "Стандарт",
	moneyprinter_exploded = "Ваш принтер взорвался!",
	moneyprinter_youtakemoney = "Вы собрали деньги с принтера",

	moneyminer_title = "Майнинг",
	moneyminer_youtakemoney = "Вы собрали деньги с майнера",
	moneyminer_exploded = "Ваш майнер взорвался!",

	police_copyright = "© Skynet Police Department",
	police_copyright_years = "(2015-2018)",

	police_ac_title = "Центр выдачи боеприпасов",
	police_hc_title = "Станция здоровья и брони",

	police_wc_title = "Центр выдачи оружия",
	police_wc_getak47 = "Получить AK47",
	police_wc_getm4a4 = "Получить M4A4",
	police_wc_getm4a1 = "Получить M4A1",
	police_wc_getump45 = "Получить UMP45",
	police_wc_getmp5 = "Получить MP5",
	police_wc_getxm1014 = "Получить XM1014",
	police_wc_getglock18 = "Получить Glock-18",
	police_wc_getgranades = "Получить набор гранат",
	police_wc_notify_ak47 = "Вы экипировали AK47",
	police_wc_notify_m4a4 = "Вы экипировали M4A4",
	police_wc_notify_m4a1 = "Вы экипировали M4A1",
	police_wc_notify_ump45 = "Вы экипировали UMP45",
	police_wc_notify_mp5 = "Вы экипировали MP5",
	police_wc_notify_xm1014 = "Вы экипировали XM1014",
	police_wc_notify_glock18 = "Вы экипировали Glock-18",
	police_wc_notify_granades = "Вы экипировали набор гранат",
	police_wc_notify_distance = "Вы слишком далеко от центра!",
	police_wc_notify_distanceabuse = "Вы слишком далеко от центра и поэтому данное оружие было изъято!",
	police_wc_notify_job = "Вы не являетесь сотрудником полиции!",
	police_wc_notify_rank = "Вы должны быть выше рангом!",

	rockfordcustoms_notify_notforselling = "Данный автомобиль не для продажи!",
	rockfordcustoms_notify_notforyoubaby = "Данный автомобиль вам не доступен!",
	rockfordcustoms_notify_cantafford = "Вы не можете себе позволить данный автомобиль!",
	rockfordcustoms_notify_itcantbesold = "Данный автомобиль не может быть продан!",
	rockfordcustoms_notify_notinyourgarage = "Данный автомобиль не в вашем гараже!",
	rockfordcustoms_notify_youbought = "Вы купили ",
	rockfordcustoms_notify_yousold = "Вы продали ",
	rockfordcustoms_notify_cantbeactivated = "Данный автомобиль не может быть вывезен!",
	rockfordcustoms_notify_noterminal = "Терминал не найден!",
	rockfordcustoms_notify_youtoofar = "Вы слишком далеко от терминала!",
	rockfordcustoms_notify_cardeactivate = "Ваш автомобиль был завезён в гараж!",
	rockfordcustoms_notify_caristoofar = "Ваш автомобиль слишком далеко от терминала!",
	rockfordcustoms_notify_youcantaffordit = "Вы не можете позволить себе эвакуацию",
	rockfordcustoms_notify_youboughtreturning = "Вы заказали эвакуацию для своего автомобиля",
	rockfordcustoms_activecar = "Активный автомобиль:",
	rockfordcustoms_areyousureforbuying = "Вы действительно хотите купить данный автомобиль за ",
	rockfordcustoms_areyousureforselling = "Вы действительно хотите продать данный автомобиль?",
	rockfordcustoms_button_changecolor = "Изменить цвет",

	markers_yourcar = "Местоположение автомобиля",
	markers_yourboyfriend = "Местоположение  игрока",
	markers_noplayer = "Игрок с таким ID не найден",
	markers_youhavealreadysend = "Вы уже отправили местоположение этому игроку. До следующего: ",
	markers_wassend = "Местоположение отправлено игроку",

	shop_ammo_rifle = "Патроны для автоматических винтовок",
	shop_ammo_sniper = "Патроны для снайперских винтовок",
	shop_ammo_smg = "Патроны для пистолетов-пулемётов",
	shop_ammo_pistol = "Патроны для пистолетов",
	shop_ammo_357 = "Патроны для тяжёлых пистолетов",
	shop_ammo_shotgun = "Патроны для дробовиков",
	shop_ammo = "Патроны",

	shop_onlyforpremium = "Данная вещь доступна только с Премиум статусом!",
	shop_category_trading = "Торговля",
	shop_category_donate = "Платный доступ",
	shop_category_granades = "Гранаты",
	shop_category_machineguns = "Пулемёты",
	shop_category_rifles = "Автоматические винтовки",
	shop_category_shotguns = "Дробовики",
	shop_category_sniper = "Снайперские винтовки",
	shop_category_smg = "Пистолеты-пулемёты",
	shop_category_pistols = "Пистолеты",
	shop_category_earning = "Заработок",
	shop_category_fun = "Развлечение",

	shop_item_moneybasket = "Корзинка для сбора денег",
	shop_item_moneyminer = "Денежный майнер",
	shop_item_drum = "Барабанная установка",
	shop_item_ball = "Футбольный мяч",
	shop_item_piano = "Фортепиано",
	shop_item_tv = "Телевизор",
	shop_item_bodypillow = "Дакимакура",
	shop_item_signcook = "Знак Повара",
	shop_item_signtrader = "Знак Торговца",
	shop_item_signgun = "Знак Торговца оружием",
	shop_item_signmedic = "Знак Врача",
	shop_item_signbank = "Знак Банкира",
	shop_item_signmechanic = "Знак Автомеханика",
	shop_item_microwave = "Микроволновка",
	shop_item_drinkmachine = "Автомат разлива",
	shop_item_armor = "Бронежилет",
	shop_item_c4 = "Бомба",
	shop_item_armorstation = "Станция брони",
	shop_item_premiummoneyprinter = "Премиум денежный принтер",
	shop_item_moneyprinter = "Денежный принтер",
	shop_item_healthstation = "Станция здоровья",
	shop_item_lockpick = "Отмычка",
	shop_item_lockpickd = "Отмычка ",
	shop_item_medkit = "Аптечка",
	shop_item_yaguar = "Ягуар",
	shop_item_vape = "Вейп",
	shop_item_spinner = "Спиннер",
	shop_item_stungun = "Электрошокер",
	shop_item_rope = "Верёвка",
	shop_item_fragg = "Осколочная граната",
	shop_item_flashg = "Светошумовая граната",
	shop_item_smokeg = "Дымовая граната",
	shop_item_inceng = "Зажигательная граната",
	shop_item_trampoline = "Батут",
	shop_item_storage = "Хранилище",

	need_admin = "Вам нужны права админа для %s",
	need_sadmin = "Вам нужны права суперадмина для %s",
	no_privilege = "У вас нет нужных прав для этого действия",
	no_jail_pos = "Позиция тюрьмы не установлена",
	invalid_x = "Ошибка в %s! %s",

	f1ChatCommandTitle = "Чат-команды",
	f1Search = "Поиск...",

	price = "Цена: %s%d",
	priceTag = "Цена: %s",
	reset_money = "%s сбросил деньги всем игрокам!",
	has_given = "%s дал вам %s",
	you_gave = "Вы дали %s %s",
	npc_killpay = "%s за убийство НИПа!",
	profit = " дохода",
	loss = "убыток",

	deducted_x = "Вычтено %s%d",
	need_x = "Нужно %s%d",

	deducted_money = "Вычтено %s",
	need_money = "Нужно %s",

	payday_message = "Зарплата! Вы получили %s!",
	payday_message_group = "Зарплата! Вы получили %s с надбавкой за наличие группировки!",
	payday_unemployed = "Вы безработный и вы не получаете зарплату!",
	payday_missed = "Получка пропущена! (Вы под арестом)",

	property_tax = "Вы заплатили налог за собственность в размере %s",
	property_tax_cant_afford = "Вы не смогли уплатить налоги! Ваша собственность отобрана у вас!",
	taxday = "День налогов! Вычтено %s%% из вашей прибыли!",

	services_med = "Вы заплатили за медицинские услуги плату в размере %s",

	found_cheque = "Вы подобрали %s%s из чека, выписанного вам от %s.",
	cheque_details = "Этот чек выписан %s.",
	cheque_torn = "Вы разорвали чек.",
	cheque_pay = "Уплата: %s",
	signed = "Подпись: %s",
	sec = " сек",

	fora = " за ",

	youboughtammo = "Вы купили патроны для ",
	thispurchase = "данную покупку",
	youcantbuyammoforthisweapon = "Вы не можете купить патроны для данного оружия",

	found_cash = "Вы подобрали %s%d!",
	found_money = "Вы подобрали %s!",

	owner_poor = "Владелец %s слишком беден чтобы субсидировать эту продажу!",

	Wanted_text = "Разыскивается!",
	he_wanted = "Разыскивается полицией!\nПричина: %s",
	youre_arrested = "Вы арестованы. Осталось: %d секунд!",
	youre_arrested_by = "%s арестовал вас.",
	youre_unarrested_by = "%s выпустил вас.",
	hes_arrested = "%s был арестован на %d секунд!",
	hes_unarrested = "%s был выпущен из тюрьмы!",
	warrant_ordered = "%s приказывает обыскать %s. Причина: %s",
	warrant_request = "%s запрашивает ордер на обыск %s\nПричина: %s",
	warrant_request2 = "Запрос на ордер отправлен мэру %s!",
	warrant_approved = "Запрос на обыск %s был одобрен!\nПричина: %s\nПриказ выдал: %s",
	warrant_approved2 = "Теперь вы можете обыскать его дом.",
	warrant_denied = "Мэр %s отклонил ваш запрос на ордер.",
	warrant_expired = "Ордер на обыск %s истёк!",
	warrant_required = "Вам нужен ордер на обыск чтобы взломать эту дверь.",
	warrant_required_unfreeze = "Вам нужен ордер на обыск чтобы разморозить эту пропу.",
	warrant_required_unweld = "Вам нужен ордер на обыск чтобы отсоединить эту пропу.",
	wanted_by_police = "%s разыскивается полицией!\nПричина: %s\nПриказ выдал: %s",
	wanted_by_police_print = "%s объявил %s в розыск, причина: %s",
	wanted_expired = "%s больше не разыскивается полицией.",
	wanted_revoked = "%s больше не разыскивается полицией.\nОтменил: %s",
	cant_arrest_other_cp = "Вы не можете арестовывать других полицейских!",
	must_be_wanted_for_arrest = "Игрок должен быть в розыске чтобы вы могли арестовать его.",
	cant_arrest_no_jail_pos = "Вы не можете арестовывать людей так как нет позиций для тюрьмы!",
	cant_arrest_spawning_players = "Вы не можете арестовывать людей которые спавнятся.",
	escape_from_jail = "побег из тюрьмы",

	suspect_doesnt_exist = "Подозреваемый отсутствует.",
	actor_doesnt_exist = "Действующее лицо отсутствует.",
	get_a_warrant = "Запросить ордер на обыск",
	give_warrant = "Выдать ордер на обыск гражданина",
	make_someone_wanted = "Объявить в розыск",
	remove_wanted_status = "Снять розыск",
	already_a_warrant = "Ордер на обыск подозреваемого всё ещё в силе.",
	already_wanted = "Подозреваемый уже в розыске.",
	not_wanted = "Подозреваемый не в розыске.",
	need_to_be_cp = "Вы должны быть представителем полиции.",
	suspect_must_be_alive_to_do_x = "Подозреваемый должен быть живым чтобы %s.",
	suspect_already_arrested = "Подозреваемый уже в тюрьме.",

	curfew = "Мэр объявил комендантский час: ",

	rpname_changed = "%s сменил ролевое имя на %s",

	need_to_be_before = "Вы должны быть %s чтобы стать %s",
	need_to_make_vote = "Вы должны провести голосование чтобы стать %s!",
	team_limit_reached = "Нельзя стать %s, лимит исчерпан",
	wants_to_be = "%s желает стать %s",
	has_not_been_made_team = "%s не стал %s!",
	job_has_become = "%s стал %s!",

	yesf1 = "F1",
	yes = "Да",
	yesf7 = "F7",
	nof2 = "F2",
	no = "Нет",
	nof8 = "F8",

	keys_allowed_to_coown = "Вам разрешено быть со-владельцем\n(Нажмите C чтобы стать со-владельцем)\n",
	keys_other_allowed = "Потенциальные со-владельцы:",
	keys_allow_ownership = "(Нажмите C чтобы разрешить владение)",
	keys_disallow_ownership = "(Нажмите C чтобы запретить владение)",
	keys_owned_by = "Владелец:",
	keys_unowned = "Свободно\n(Нажмите C чтобы стать владельцем)",
	keys_everyone = "(Нажмите C чтобы разрешить для всех)",
	door_unown_arrested = "You can not own or unown things while arrested!",
	door_unownable = "This door cannot be owned or unowned!",
	door_sold = "Вы продали это за %s",
	door_already_owned = "Этой дверью уже кто-то владеет!",
	quota = "",
	no_quota = "",
	door_cannot_afford = "Недостаточно средств для покупки этой двери!",
	door_hobo_unable = "Вы не можете купить дверь если вы бомж!",
	vehicle_cannot_afford = "Вы не можете позволить себе этот транспорт!",
	door_bought = "Вы купили эту дверь за %s%s",
	vehicle_bought = "Вы купили этот транспорт за %s%s",
	door_need_to_own = "Вам нужно владеть этой дверью чтобы %s",
	door_rem_owners_unownable = "Вы не можете удалять владельцев если дверь неовладима!",
	door_add_owners_unownable = "Вы не можете добавлять владельцев если дверь неовладима!",
	rp_addowner_already_owns_door = "%s уже (со-)владеет этой дверью!",
	add_owner = "Добавить владельца",
	remove_owner = "Удалить владельца",
	coown_x = "Со-владение %s",
	allow_ownership = "Разрешить владение",
	disallow_ownership = "Запретить владение",
	edit_door_group = "Редактировать группу двери",
	door_groups = "Группы дверей",
	door_group_doesnt_exist = "Группа дверей не существует!",
	door_group_set = "Группа двери успешно установлена.",
	sold_x_doors_for_y = "Вы продали %d дверей за %s%d!",
	sold_x_doors = "Вы продали %d дверей за %s!",

	gmod_camera = "Камера",
	gmod_tool = "Тулган",
	weapon_bugbait = "Комок грязи",
	weapon_physcannon = "Гравипушка",
	weapon_physgun = "Физган",
	vc_wrench = "Гаечный ключ",

	drugs = "Наркотики",
	drug_lab = "Лаборатория наркотиков",
	gun_lab = "Лаборатория оружия",
	gun = "Пушка",
	microwave = "Микроволновка",
	food = "Еда",

	write_letter = "Написать письмо...",
	send = "Отправить",
	sign_this_letter = "Подписать это письмо",
	signed_yours = "С уважением,",

	previous_owner_nof = "Прежний: ",
	microwave_steal = "Нажми здесь чтобы украсть",
	microwave_hacking = "Перепрошивание...",
	microwave_alreadyown = "Вы уже владеете этой мирковолновкой!",
	microwave_alert = "Вашу микроволновку крадут!",

	camera_destroyed = "Ваша камера уничтожена!",

	contents = "Содержит: ",
	amount = "Количество: ",

	picking_lock = "",

	cannot_pocket_x = "Вы не можете положить это в сумку!",
	object_too_heavy = "Этот предмет слишком тяжёлый.",
	pocket_full = "Ваша сумка полная!",
	pocket_no_items = "Ваша сумка пуста.",
	drop_item = "Выбросить предмет",

	bonus_destroying_entity = "уничтожение нелегального предмета.",

	keypad_checker_shoot_keypad = "Shoot a keypad to see what it controls.",
	keypad_checker_shoot_entity = "Shoot an entity to see which keypads are connected to it",
	keypad_checker_click_to_clear = "Right click to clear.",
	keypad_checker_entering_right_pass = "Entering the right password",
	keypad_checker_entering_wrong_pass = "Entering the wrong password",
	keypad_checker_after_right_pass = "after having entered the right password",
	keypad_checker_after_wrong_pass = "after having entered the wrong password",
	keypad_checker_right_pass_entered = "Right password entered",
	keypad_checker_wrong_pass_entered = "Wrong password entered",
	keypad_checker_controls_x_entities = "This keypad controls %d entities",
	keypad_checker_controlled_by_x_keypads = "This entity is controlled by %d keypads",
	keypad_on = "ON",
	keypad_off = "OFF",
	seconds = "seconds",

	persons_weapons = "Нелегальное оружие у %s:",
	returned_persons_weapons = "Вернул вещи конфискованные у %s.",
	no_weapons_confiscated = "%s не имеет конфискованных предметов!",
	no_illegal_weapons = "%s не имеет нелегального оружия.",
	confiscated_these_weapons = "Конфисковал следующее оружие:",
	checking_weapons = "Проверяем оружие",

	shipment_antispam_wait = "Подождите прежде чем спавнить другой ящик.",
	shipment_cannot_split = "Нельзя разделить этот ящик.",

	hear_noone = "Никто не слышит ваш%s!",
	hear_everyone = "Вас все слышат!",
	hear_certain_persons = "Ваш%s слышат: ",

	whisper = "Шёпот",
	yell = "Крик",
	whisper_c = " шёпот ",
	yell_c = " крик ",
	advert = "[Объявление]",
	broadcast = "[Передача]",
	radio = "[Радио]",
	request = "[ЗАПРОС] ",
	group = "[Группа]",
	demote = "[УВОЛЬНЕНИЕ]",
	ooc = "Город",
	anon = "[Анонимное сообщение]",
	cube = "[Кубик]",
	cube_text = "%s кидает кубик с числом (%d). Выпало число %d.",

	talk = " чат ",
	speak = " голос ",

	speak_in_ooc = " чат в OOC ",
	perform_your_action = "е выполнение действия",
	talk_to_your_group = "е сообщение группе",

	disabled = "%s выключено! %s",
	gm_spawnvehicle = "The spawning of vehicles",
	gm_spawnsent = "The spawning of scripted entities (SENTs)",
	gm_spawnnpc = "The spawning of Non-Player Characters (NPCs)",
	see_settings = "Please see the DarkRP settings.",
	limit = "Вы достигли лимита %s!",
	have_to_wait = "Вам нужно подождать ещё %d секунд прежде чем %s!",
	must_be_looking_at = "Вам нужно смотреть на %s!",
	incorrect_job = "Неправильная профессия для %s",
	unavailable = "%s недоступен",
	unable = "Вы не можете %s. %s",
	cant_afford = "Вы не можете позволить себе %s",
	created_x = "%s создал %s",
	cleaned_up = "Ваши %s были очищены.",
	you_bought_x = "Вы купили %s за %s%d.",
	you_bought = "Вы купили %s за %s.",
	you_received_x = "Вы получили %s за %s.",

	created_first_jailpos = "You have created the first jail position!",
	added_jailpos = "You have added one extra jail position!",
	reset_add_jailpos = "You have removed all jail positions and you have added a new one here.",
	created_spawnpos = "%s's spawn position created.",
	updated_spawnpos = "%s's spawn position updated.",
	do_not_own_ent = "Вы не владеете этим предметом!",
	cannot_drop_weapon = "Нельзя выбросить это оружие!",
	job_switch = "Профессии были успешно обменены!",
	job_switch_question = "Поменяться профессиями с %s?",
	job_switch_requested = "Запрос об обмене профессиями отправлен.",

	cooks_only = "Только поварам.",

	unknown = "Неизвестное",
	arguments = "аргументы",
	no_one = "никто",
	door = "двери",
	vehicle = "транспорт",
	door_or_vehicle = "дверь/транспорт",
	driver = "Водитель: %s",
	name = "Название %s",
	lock = "Закрыть",
	locked = "Закрыто",
	unlock = "Открыть",
	unlocked = "Открыто",
	player_doesnt_exist = "Игрок отсутствует.",
	job_doesnt_exist = "Профессия не существует!",
	must_be_alive_to_do_x = "Вы должны быть живы чтобы %s.",
	banned_or_demoted = "Забанен/уволен",
	wait_with_that = "Эй, подожди с этим.",
	could_not_find = "Невозможно найти %s",
	f3tovote = "Нажмите F3 или зажмите TAB чтобы вывести курсор для голосования",
	listen_up = "Внимание:",
	nlr = "Правило новой жизни (NLR): Не убивайте/арестовывайте в отместку.",
	reset_settings = "Все настройки сброшены!",
	must_be_x = "Вы должны быть %s чтобы сделать %s.",
	agenda_updated = "Повестка дня обновлена",
	job_set = "%s сменил свою работу на '%s'",
	demoted = "%s был уволен",
	demoted_not = "%s не был уволен",
	demoted_not_quorum = "%s не был уволен (не набрался кворум)",
	demote_vote_started = "%s запустил голосование об увольнении %s",
	demote_vote_text = "Причина увольнения:%s",
	cant_demote_self = "Вы не можете уволить самого себя.",
	i_want_to_demote_you = "Я желаю уволить тебя с работы. Причина: %s",
	tried_to_avoid_demotion = "Вы попытались избежать увольнения. Хорошая попытка, но вы всё равно были уволены.",
	lockdown_started = "Мэр объявил комендантский час!",
	lockdown_ended = "Комендатский час отменён",
	gunlicense_requested = "%s запросил лицензию у %s",
	gunlicense_granted = "%s дал %s лицензию",
	gunlicense_denied = "%s отказал %s в лицензии",
	gunlicense_question_text = "Дать %s лицензию?",
	gunlicense_remove_vote_text = "%s начал голосование об отзыве лицензии у %s",
	gunlicense_remove_vote_text2 = "Отозвать лицензию:\n%s",
	gunlicense_removed = "Лицензия %s не была отозвана!",
	gunlicense_not_removed = "Лицензия %s была отозвана!",
	vote_specify_reason = "Вам нужно указать причину!",
	vote_started = "Голосование создано",
	vote_alone = "Вы выиграли голосование так как вы один на сервере.",
	you_cannot_vote = "Вы не можете голосовать!",
	x_cancelled_vote = "%s cancelled the last vote.",
	cant_cancel_vote = "Could not cancel the last vote as there was no last vote to cancel!",
	jail_punishment = "Наказание за отсоединение! Арестован на: %d секунд.",
	admin_only = "Админам только!",
	chief_or = "Шефам или ",
	frozen = "Заморожено.",
	yes_demote = "Да, уволить",
	no_demote = "Нет, не увольнять",
	dont_vote = "Не голосовать",

	dead_in_jail = "Вы мертвы до тех пор, пока с вас не снимут арест!",
	died_in_jail = "%s умер в тюрьме!",

	credits_for = "АВТОРЫ %s\n",
	credits_see_console = "Список авторов DarkRP отправлен в консоль.",

	data_not_loaded_one = "Ваши данные ещё не загрузились. Пожалуйста, подождите.",
	data_not_loaded_two = "Если проблема все ещё остаётся, свяжитесь с админом.",
	data_pleasewait = "Пожалуйста, подождите",

	cant_spawn_weapons = "Вы не можете спавнить оружие.",
	drive_disabled = "Управление отключено.",
	property_disabled = "Опция отключена.",

	not_allowed_to_purchase = "Вам нельзя купить этот предмет.",

	rp_teamban_hint = "rp_teamban [player name/ID] [team name/id]. Use this to ban a player from a certain team.",
	rp_teamunban_hint = "rp_teamunban [player name/ID] [team name/id]. Use this to unban a player from a certain team.",
	x_teambanned_y = "%s забанил %s с профессии %s.",
	x_teamunbanned_y = "%s разбанил %s с профессии %s.",

	you_set_x_salary_to_y = "Вы установили зарплату %s в %s%d.",
	x_set_your_salary_to_y = "%s установил вам зарплату в %s%d.",
	you_set_x_money_to_y = "Вы установили количество денег %s в %s%d.",
	x_set_your_money_to_y = "%s установил вам количество денег в %s%d.",

	you_set_x_salary = "Вы установили зарплату %s в %s.",
	x_set_your_salary = "%s установил вам зарплату в %s.",
	you_set_x_money = "Вы установили количество денег %s в %s.",
	x_set_your_money = "%s установил вам количество денег в %s.",
	you_set_x_name = "Вы установили %s имя %s",
	x_set_your_name = "%s установил вам имя %s",

	someone_stole_steam_name = "Someone is already using your Steam name as their RP name so we gave you a '1' after your name.", -- Uh oh
	already_taken = "Уже занято.",

	job_doesnt_require_vote_currently = "Эта профессия не требует голосования на данный момент!",

	x_made_you_a_y = "%s сделал вас %s!",

	cmd_cant_be_run_server_console = "This command cannot be run from the server console.",

	lottery_started = "Проводится лотерея! Участвовать за %s%d?", -- backwards compatibility
	lottery_has_started = "Проводится лотерея! Участвовать за %s?",
	lottery_entered = "Вы участвуете в лотерее за %s",
	lottery_not_entered = "%s не участвует в лотерее",
	lottery_noone_entered = "Никто не участвовал в лотерее",
	lottery_won = "%s выиграл %s в лотерее!",

	custom_animation = "",
	bow = "Поклон",
	dance = "Танец 1",
	follow_me = "За мной",
	laugh = "Хаха",
	lion_pose = "Лев",
	nonverbal_no = "Нет",
	thumbs_up = "Палец вверх",
	wave = "Помахать",
	dance2 = "Танец 2",
	cheer = "Радость",
	salute = "Отдать честь",
	robot = "Робот",

	carradio_title = "Радио",
	carradio_station = "Станция",
	carradio_silence = "- Тишина 24/7 -",
	carradio_volume = "Громкость",

	hit = "заказ",
	hitman = "Наёмный убийца",
	current_hit = "Заказ: %s",
	cannot_request_hit = "Невозможно сделать заказ! %s",
	hitmenu_request = "Заказать",
	player_not_hitman = "Этот игрок не убийца по заказу!",
	distance_too_big = "Слишком большое расстояние.",
	hitman_no_suicide = "Убийца не может убить себя.",
	hitman_no_self_order = "Убийца не может получить заказ от себя же.",
	hitman_already_has_hit = "Убийца уже имеет заказ.",
	price_too_low = "Цена слишком низкая!",
	hit_target_recently_killed_by_hit = "Цель была ранее убита по заказу,",
	customer_recently_bought_hit = "Заказчик сделал заказ ранее.",
	accept_hit_question = "Принять заказ от %s\nв отношении %s за %s%d?", -- backwards compatibility
	accept_hit_request = "Принять заказ от %s\nв отношении %s for %s?",
	hit_requested = "Заказ сделан!",
	hit_aborted = "Заказ прерван! %s",
	hit_accepted = "Заказ принят!",
	hit_declined = "Убийца отклонил заказ!",
	hitman_left_server = "Убийца покинул сервер!",
	customer_left_server = "Заказчик покинул сервер!",
	target_left_server = "Цель покинула сервер!",
	hit_price_set_to_x = "Цена на заказ установлена в %s%d.", -- backwards compatibility
	hit_price_set = "Цена на заказ установлена в %s.",
	hit_complete = "Заказ у %s выполнен!",
	hitman_died = "Заказной убийца умер!",
	target_died = "Цель умерла!",
	hitman_arrested = "Наёмный убийца был арестован!",
	hitman_changed_team = "Наёмный убийца сменил команду!",
	x_had_hit_ordered_by_y = "%s имел действующий заказ от %s",

	vote = "Голосование",
	time = "Время: %d",
	ok = "Окей",
	cancel = "Отмена",
	add = "Добавить",
	remove = "Удалить",
	none = "Ничего",
	none_alt = "нет",
	confirmed = "Подтверждено",

	x_options = "Опции %s",
	sell_x = "Продать %s",
	set_x_title = "Задать название %s",
	set_x_title_long = "Задать название %s на которую вы смотрите.",
	jobs = "Профессии",
	buy_x = "Купить %s",

	no_extra_weapons = "Эта должность не даёт дополнительного оружия.",
	become_job = "Занять профессию",
	create_vote_for_job = "Создать голосование",
	shipments = "Ящики",
	F4guns = "Оружие",
	F4entities = "Предметы",
	F4ammo = "Патроны",
	F4vehicles = "Транспорт",
	F4donate = "Игровой магазин",
	F4attachments = "Оптика и снаряжение",
	F4equipment = "Снаряжение:",
	F4notice = "Рекомендуем изучить правила прежде чем выбирать профессию.\n              При нарушении правил вы получите наказание.",

	searchwarrantbutton = "Объявить в розыск",
	unwarrantbutton = "Снять розыск",
	noone_available = "Никто не доступен",
	request_warrant = "Запросить ордер на обыск",
	make_wanted = "Объявить кого-либо в розыск",
	make_unwanted = "Снять розыск с кого-либо",
	set_jailpos = "Установить позицию тюрьмы (сброс)",
	add_jailpos = "Добавить позицию тюрьмы",

	set_custom_job = "Установить название профессии",

	set_agenda = "Установить агенду",

	initiate_lockdown = "Установить комендантский час",
	stop_lockdown = "Отменить комендантский час",
	start_lottery = "Запустить лотерею",
	give_license_lookingat = "Дать лицензию",

	laws_of_the_land = "ЗАКОНЫ ГОРОДА",
	law_added = "Закон добавлен.",
	law_removed = "Закон удалён.",
	law_reset = "Законы сброшены.",
	law_too_short = "Текст закона слишком короткий.",
	laws_full = "Доска законов переполнена.",
	default_law_change_denied = "Вам не разрешено менять основные законы.",

	job_name = "Название: ",
	job_description = "Описание: ",
	job_weapons = "Оружие: ",

	buy_a = "Купить %s: %s",

	license_tab = [[License weapons

	Tick the weapons people should be able to get WITHOUT a license!
	]],
	license_tab_other_weapons = "Other weapons:",

	read_rules = "Обязательно ознакомтесь с правилами, нажав ",
	nobind = "[НЕ НАЗНАЧЕНО]",

	job_title_citizen = ([[
Адвокат
Генеральный секретарь
Делопроизводитель
Детектив
Дипломат
Конвоир
Министр
Нотариус
Правовед
Прокурор
Следователь
Судебный пристав
Судья
Телохранитель
Тюремный надзиратель
Юрист
Верстальщик
Выпускающий редактор
Издатель
Корректор
Переплетчик
Печатник
Редактор
Типограф
Фальцовщик
HTML-верстальщик
Web-интегратор
Web-дизайнер
Web-программист
Администратор базы данных
Администратор сайта
Блогер
Диктор
Кодер
Контент-менеджер
Копирайтер
Машинистка
Оператор ПК
Программист
Радиоведущий
Радист
Системный администратор
Телеграфист
Тележурналист
Тестировщик
Археолог
Архивариус
Астроном
Библиограф
Биоинженер
Биолог
Биофизик
Биохимик
Ботаник
Востоковед
Генетик
Генный инженер
Гидролог
Египтолог
Зоолог
Изобретатель
Искусствовед
Историк
Ихтиолог
Конструктор
Культуролог
Математик
Метеоролог
Микробиолог
Нанотехнолог
Орнитолог
Палеонтолог
Политолог
Почвовед
Религиовед
Социолог
Теолог
Физик
Философ
Химик
Эколог
Этнограф
Воспитатель
Дефектолог
Логопед
Педагог
Преподаватель
Проректор
Психолог
Ректор
Сурдопедагог
Тифлопедагог
Учитель
Булочник
Винодел
Кондитер
Месильщик
Мясник
Пекарь
Повар
Вышивальщица
Гид-переводчик
Дегустатор
Кинолог
Лингвист
Переводчик
Промышленный альпинист
Реставратор
Референт
Священнослужитель
Секретарь-референт
Секретарь-стенографистка
Дорожный инспектор
Агроном
Ветеринар
Доярка
Животновод
Комбайнер
Оператор машинного доения
Охотник
Пастух
Пчеловод
Скотник
Специалист по стрижке овец
Тракторист
Фермер
Агент по туризму
Страховой агент
Администратор гостиницы
Администратор ресторана
Администратор салона красоты
Бармен
Библиотекарь
Визажист
Грузчик
Дворник
Кладовщик
Консультант по туризму
Консультант телефона доверия
Маникюрша
Мусоропроводчик
Мусорщик
Настройщик музыкальных инструментов
Оператор call-центра
Официант
Парикмахер
Портье
Почтальон
Садовник
Сапожник
Уборщица
Упаковщик
Флорист
Цветочница
Шеф-повар
Инструктор по видам спорта
Спортивный тренер
Спортсмен
Актер
Аниматор
Артист цирка
Архитектор
Балетмейстер
Диджей
Дизайнер
Дизайнер рекламы
Дизайнер-модельер
Дирижер
Журналист
Закройщик
Звукооператор
Звукорежиссер
Иллюстратор
Имиджмейкер
Каскадер
Кинодраматург
Киномеханик
Кинооператор
Кинорежиссер
Композитор
Критик
Ландшафтный дизайнер
Манекенщица
Модель
Музыкант
Мультипликатор
Оператор кино и телевидения
Писатель
Портной
Продюсер
Режиссер
Скульптор
Спичрайтер
Стилист
Сценарист
Танцор балета
Татуировщик
Технический писатель
Фотограф
Фотомодель
Хореограф
Художник
Художник по костюму
Ювелир
Постановщик трюков
Автогонщик
Аппаратчик-оператор
Архитектор-проектировщик
Бондарь
Бульдозерист
Вальцовщик стана горячей прокатки
Водолаз
Геодезист
Геолог
Геоэколог
Главный инженер
Главный конструктор
Главный технолог
Горняк
Драпировщик
Инженер
Инженер-конструктор
Инженер-технолог
Инженер-химик
Испытатель
Каменщик
Картограф
Крановщик
Краснодеревщик
Кровельщик
Литейщик
Маляр
Маркшейдер
Мастер
Машинист
Металлург
Монтажник
Моторист
Наладчик
Облицовщик
Отделочник
Плотник
Производственный мастер
Прораб
Проходчик
Радиомеханик
Ремонтник
Рихтовщик
Сантехник
Сварщик
Слесарь
Сталевар
Станочник широкого профиля
Столяр
Строитель
Техник по эксплуатации
Технолог
Токарь
Фрезеровщик
Химик-технолог
Холодильщик
Часовщик
Шахтер
Швея
Шлифовщик
Штукатур
Электрик
Электромонтажник
Энергетик
Авиадиспетчер
Бортинженер
Бортмеханик
Бортпроводник
Бригадир железнодорожного пути
Водитель
Воздухоплаватель
Диспетчер
Капитан судна
Космонавт
Курьер
Летчик
Лоцман
Матрос
Моряк
Проводник
Слесарь-механик
Стрелочник
Стюардесса
Штурман
Экспедитор
Продакт-менеджер
Смотритель стойл
Администратор предприятия торговли
Ассистент менеджера по продажам
Аудитор
Банкир
Банковский кассир-операционист
Бизнес-аналитик
Бизнес-консультант
Бизнес-тренер
Билетный кассир
Бренд-дизайнер
Бренд-менеджер
Брокер
Бухгалтер
Дистрибутор
Заведующий складом
Инкассатор
Кассир
Кризис-менеджер
Лоббист
Логист
Маклер
Маркетолог
Медиа-байер
Менеджер
Менеджер по PR
Менеджер по закупкам
Менеджер по логистике
Менеджер по персоналу
Менеджер по продажам
Менеджер по работе с клиентами
Менеджер по рекламе
Менеджер по туризму
Менеджер торгового зала
Мерчендайзер
Налоговый инспектор
Офис-менеджер
Оценщик
Продавец
Продавец-консультант
Промоутер
Риелтор
Сметчик
Снабженец
Специалист по ВЭД
Статистик
Страховой агент
Супервайзер
Товаровед
Торговый представитель
Трейдер
Финансист
Финансовый аналитик
Экономист
Военнослужащий
Разведчик]]):Split("\n"),

job_title_medic = ([[
Акушер
Анестезиолог
Венеролог
Вирусолог
Врач скорой помощи
Врач-диетолог
Дерматовенеролог
Дерматолог
Диетолог
Зубной техник
Иммунолог
Инфекционист
Кардиолог
Кардиохирург
Косметолог
Лаборант
Логопед
Мануалист
Массажист
Медицинская сестра
Невролог
Невропатолог
Нейрохирург
Нефролог
Окулист
Онколог
Ортопед
Оториноларинголог
Офтальмолог
Педиатр
Психиатр
Психотерапевт
Реабилитолог
Реаниматолог
Спортивный врач
Стоматолог
Терапевт
Токсиколог
Травматолог
Фармацевт
Фельдшер
Хирург
Эндокринолог]]):Split("\n"),
}