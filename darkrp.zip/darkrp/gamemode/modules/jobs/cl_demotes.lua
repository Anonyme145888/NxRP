local PANEL = {}

function PANEL:Init()
	--[[
	self:SetDraggable(false)
	self:SetSkin("DarkRP")
	self:SetBackgroundBlur(true)
	self:MakePopup()
	self:SetSize(640, 480)
	self:Center()
	]]
	self.title = self:AddTitle("")
	self:SetKeyboardInputEnabled(false)
end

function PANEL:SetData(data)
	--self:ShowCloseButton(false)
	self.data = data

	local wtall = 0
	local wwide = 0
	for k, v in pairs {("%s (%s)"):format(data.from, data.fromjob), DarkRP.getPhrase("he_wants_demote_vgui"), ("%s (%s)"):format(data.to, data.tojob), DarkRP.getPhrase("he_wants_demote_vgui_res"), data.reason} do
		local lbl = self:Add("DLabel")
		lbl:Dock(TOP)
		lbl:SetFont("DermaNotLarge")
		lbl:SetText(DarkRP.textWrap(v, "DermaNotLarge", 640))
		lbl:SizeToContents()
		lbl:SetContentAlignment(5)
		wwide = math.max(wwide, lbl:GetWide())
		wtall = wtall + lbl:GetTall()
	end

	local lbl = self:Add("DLabel")
	lbl:Dock(TOP)
	lbl:SetFont("DermaNotDefault")
	lbl:SetText(DarkRP.textWrap(DarkRP.getPhrase("demote_rule"), "DermaNotDefault", 640))
	lbl:SizeToContents()
	lbl:SetContentAlignment(5)
	lbl:DockMargin(0, LargeMargin, 0, LargeMargin)

	local ye = self:Add("NxButton")
	ye:SetTall(yscale(42))
	ye:SetFont("DermaNotLarge")
	ye:Dock(TOP)
	ye:SetText(DarkRP.getPhrase("yes_demote"))
	ye:DockMargin(0, SmallMargin, 0, SmallMargin)
	ye:SetDisabled(true)

	ye.DoClick = function()
		self:Remove()
		net.Start("Demote")
			net.WriteUInt(data.id, 32)
			net.WriteBool(true)
		net.SendToServer()
	end

	local no = self:Add("NxButton")
	no:SetTall(yscale(42))
	no:SetFont("DermaNotLarge")
	no:Dock(TOP)
	no:SetText(DarkRP.getPhrase("no_demote"))
	no:DockMargin(0, 0, 0, SmallMargin)
	no:SetDisabled(true)

	no.DoClick = function()
		self:Remove()
		net.Start("Demote")
			net.WriteUInt(data.id, 32)
			net.WriteBool(false)
		net.SendToServer()
	end

	local dv = self:Add("NxButton")
	dv:SetTall(yscale(42))
	dv:SetFont("DermaNotLarge")
	dv:Dock(TOP)
	dv:SetText(DarkRP.getPhrase("dont_vote"))
	dv:SetDisabled(true)

	dv.DoClick = function()
		self:Remove()
	end

	local left = data.ends - CurTime()

	--timer.Simple(left < 5 and 0 or 3, function()
		ye:SetDisabled(false)
		no:SetDisabled(false)
		dv:SetDisabled(false)
	--end)

	--self:SetTall(select(2, dv:GetPos()) + dv:GetTall() + 5)

	self:SetTall(LargeMargin + self.title:GetTall() + MediumMargin + wtall + LargeMargin + lbl:GetTall() + LargeMargin + SmallMargin + ye:GetTall() + SmallMargin + no:GetTall() + SmallMargin + dv:GetTall() + MediumMargin + yscale(32) + LargeMargin)
	self:SetWide(LargeMargin + math.max(lbl:GetWide(), wwide) + LargeMargin)
	self:Center()
	
	self:InvalidateLayout(true)

	timer.Simple(left, function()
		if self:IsValid() then
			self:Remove()
		end
	end)
end

function PANEL:Think()
	if self.data then
		self.title:SetText(string.FormattedTime(self.data.ends - CurTime(), "%02i:%02i"))
	end
end

derma.DefineControl("NxDemote", "", PANEL, "NxGenericFrame")

local lastFrame
net.Receive("Demote", function(len, pl)
	local id, starting = net.ReadUInt(32), net.ReadBool()

	if IsValid(lastFrame) then
		lastFrame:Remove()
	end

	if starting then
		lastFrame = vgui.Create("NxDemote")
		lastFrame:SetData {
			from = net.ReadString(),
			fromjob = RPExtraTeams[net.ReadUInt(8)].name,
			to = net.ReadString(),
			tojob = RPExtraTeams[net.ReadUInt(8)].name,
			reason = net.ReadString(),
			ends = net.ReadFloat(),
			id = id,
		}
	end
end)