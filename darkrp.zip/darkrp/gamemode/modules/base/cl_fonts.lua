--[[---------------------------------------------------------------------------
The fonts that DarkRP uses
---------------------------------------------------------------------------]]
local function loadFonts()
    local tahoma = system.IsLinux() and "DejaVu Sans" or "Tahoma"
    local tahomaSize = system.IsLinux() and fp{fn.Flip(fn.Add), 1} or fn.Id

    surface.CreateFont("Roboto Light", { -- font is not found otherwise
        size = 22,
        weight = 400,
        antialias = true,
        shadow = true,
        extended = true,
        font = "Roboto Condensed"})

    surface.CreateFont("F4MenuFont01", {
        size = 22,
        weight = 400,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Roboto Condensed"})

    surface.CreateFont("F4MenuFont02", {
        size = 30,
        weight = 800,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Roboto Condensed"})
    
    surface.CreateFont("DarkRPHUD1", {
        size = tahomaSize(16),
        weight = 200,
        antialias = true,
        shadow = true,
        extended = true,
        font = tahoma})

    surface.CreateFont("DarkRPHUD2", {
        size = 22,
        weight = 350,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Roboto Condensed"})

    surface.CreateFont("Trebuchet18", {
        size = 18,
        weight = 500,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Trebuchet MS"})

    surface.CreateFont("Trebuchet20", {
        size = 20,
        weight = 500,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Trebuchet MS"})

    surface.CreateFont("Trebuchet24", {
        size = 24,
        weight = 500,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Trebuchet MS"})

    surface.CreateFont("TabLarge", {
        size = tahomaSize(15),
        weight = 700,
        antialias = true,
        shadow = false,
        extended = true,
        font = tahoma})

    surface.CreateFont("UiBold", {
        size = 16,
        weight = 800,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Default"})

    surface.CreateFont("HUDNumber5", {
        size = 30,
        weight = 800,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Roboto Condensed"})

    surface.CreateFont("ScoreboardHeader", {
        size = 32,
        weight = 500,
        antialias = true,
        shadow = false,
        extended = true,
        font = "Roboto Condensed"})

    -- our overrides

    surface.CreateFont("Roboto Light", { -- font is not found otherwise
            size = 22,
            weight = 400,
            antialias = true,
            shadow = true,
            extended = true,
            font = "Roboto Condensed"})

    surface.CreateFont("F4MenuFont01", {
            size = 22,
            weight = 400,
            antialias = true,
            shadow = false,
            extended = true,
            font = "Roboto Condensed"})

    surface.CreateFont("F4MenuFont02", {
            size = 30,
            weight = 800,
            antialias = true,
            shadow = false,
            extended = true,
            font = "Roboto Condensed"})

    surface.CreateFont( "GModNotify", {
        size = 22,
        weight = 350,
        antialias = true,
        extended = true,
        font = "Roboto"
    })
    surface.CreateFont( 'DMInfo', {
	    font = 'Trebuchet MS',
	    size = 27,
	    weight = 200,
	    shadow = true
    })
    surface.CreateFont("TargetID", { -- override because cyrillic characters are shitty
        font = "Roboto Condensed",
        size = 22,
        weight = 350,
        antialias = true,
        extended = true,
    })

    surface.CreateFont("BailNPCFont", { -- override because cyrillic characters are shitty
        font = "Roboto Condensed",
        size = 26,
        weight = 350,
        antialias = true,
        extended = true,
    })

    surface.CreateFont("BailNPCDescFont", { -- override because cyrillic characters are shitty
        font = "Roboto Condensed",
        size = 22,
        weight = 350,
        antialias = true,
        extended = true,
    })
    
    surface.CreateFont("nx_hud_compat", {
        size = 22,
        weight = 350,
        antialias = true,
        extended = true,
        font = "Roboto"})

    surface.CreateFont("nx_hud_compat_shadow", {
        size = 22,
        weight = 350,
        antialias = true,
        blursize = 3,
        extended = true,
        font = "Roboto"})

    surface.CreateFont("nx_hud_compat_s", {
        size = 22,
        weight = 350,
        antialias = true,
        extended = true,
        font = "Roboto"})

    surface.CreateFont("nx_hud_compat_s_shadow", {
        size = 22,
        weight = 350,
        antialias = true,
        blursize = 3,
        extended = true,
        font = "Roboto"})

    if ( system.IsLinux() ) then

        surface.CreateFont( "DermaDefault", {
            font        = "DejaVu Sans",
            size        = 14,
            weight      = 500,
            antialias = true,
            extended = true,
        } )

        surface.CreateFont( "DermaDefaultBold", {
            font        = "DejaVu Sans",
            size        = 14,
            weight      = 800,
            antialias = true,
            extended = true,
        } )

    else

        surface.CreateFont( "DermaDefault", {
            font        = "Tahoma",
            size        = 13,
            weight      = 500,
            antialias = true,
            extended = true,
        } )

        surface.CreateFont( "DermaDefaultBold", {
            font        = "Tahoma",
            size        = 13,
            weight      = 800,
            antialias = true,
            extended = true,
        } )

    end

    surface.CreateFont( "DermaLarge", {
        font        = "Roboto",
        size        = 32,
        weight      = 500,
        antialias = true,
        extended = true,
    } )
end
loadFonts()
-- Load twice because apparently once is not enough
hook.Add("InitPostEntity", "DarkRP_LoadFonts", loadFonts)
