--[[
gamemodes/darkrp/gamemode/modules/base/cl_cooldown.lua
--]]
local stocks = {}

local IsEmpty = function(self)
	return self.stock <= 0
end

DarkRP.StockSettings = {} 
DarkRP.StockSettings.money_printer_package = {
    maxstock = 2,
    restock = 30 * 60,
}
DarkRP.StockSettings.life = {
    maxstock = 2,
    restock = 10 * 60,
    networked = true,
}

local stock_meta = {
	__index = function(self, k)
		if k == "stock" then
			return LocalPlayer():GetNWInt(self.class .. "_stock", DarkRP.StockSettings[self.class].maxstock)
		elseif k == "nextRestock" then
			return LocalPlayer():GetNWFloat(self.class .. "_nextRestock_t")
		elseif k == "maxstock" then
			return DarkRP.StockSettings[self.class].maxstock
		elseif k == "IsEmpty" then
			return IsEmpty
		end
	end
}

function DarkRP.Stock(class)
	if not stocks[class] then
		stocks[class] = setmetatable({class = class}, stock_meta)
	end
	return stocks[class]
end

function ray.meta.Player:Stock(class)
	if self ~= LocalPlayer() then
		return
	end

	return DarkRP.Stock(class)
end

