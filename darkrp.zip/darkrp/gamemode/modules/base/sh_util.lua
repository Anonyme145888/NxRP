--[[-------------------------------------------------------------------------
Utility functions
---------------------------------------------------------------------------]]

local vector = FindMetaTable("Vector")
local meta = FindMetaTable("Player")

function string.BadLen(str, min, max) -- if `max` is not provided then `min` is `max`
    local result, len = str:InputCheck(min, max)

    if result == string.InputCheckInvalid then
        return "??", len
    elseif result == string.InputCheckShort then
        return DarkRP.getPhrase("rpname_fail_length_min", min), len
    elseif result == string.InputCheckLong then
        return DarkRP.getPhrase("rpname_fail_length_max", max or min), len
    else
        return nil, len
    end
end

local banned = {
    [0x000C] = true, -- <Form Feed> (FF)
    --[0x0020] = true, -- Space (SP)
    [0x1680] = true, -- Ogham Space Mark
    [0x2000] = true, -- En Quad
    [0x2001] = true, -- Em Quad
    [0x2002] = true, -- En Space
    [0x2003] = true, -- Em Space
    [0x2004] = true, -- Three-Per-Em Space
    [0x2005] = true, -- Four-Per-Em Space
    [0x2006] = true, -- Six-Per-Em Space
    [0x2007] = true, -- Figure Space
    [0x2008] = true, -- Punctuation Space
    [0x2009] = true, -- Thin Space
    [0x200A] = true, -- Hair Space
    [0x200B] = true, -- Zero Width Space
    [0x2028] = true, -- Line Separator
    [0x202F] = true, -- Narrow No-Break Space
    [0x205F] = true, -- Medium Mathematical Space (MMSP)
    [0x2063] = true, -- Invisible Separator
    [0x2064] = true, -- Invisible Plus
    [0x2800] = true, -- Braille Pattern Blank
    [0x3000] = true, -- Ideographic Space
    [0x00A0] = true, -- No-Break Space

    [0x0009] = true, -- <Character Tabulation> (HT, TAB)
    [0x000B] = true, -- <Line Tabulation> (VT)
    [0x001F] = true, -- <Information Separator One> (US)

    [0x1160] = true, -- Hangul Jungseong Filler
    [0x3164] = true, -- Hangul Filler
    [0xFFA0] = true, -- Halfwidth Hangul Filler
}

function string.ContainsBadSpaces(str)
    for p, c in utf8.codes(str) do
        if banned[c] then
            return true
        end
    end

    return false
end

--[[-------------------------------------------------------------------------
Decides whether the player could touch the entity
---------------------------------------------------------------------------]]
function meta:canTouch(ent)
    local shootpos = self:GetShootPos()
    local entpos = ent:NearestPoint(shootpos)
    return entpos:Distance(shootpos) <= 130 and entpos:isInSight({ent}, self)
end

--[[-------------------------------------------------------------------------
Decides whether the vector could be seen by the player if they were to look at it
---------------------------------------------------------------------------]]
function vector:isInSight(filter, ply)
    ply = ply or LocalPlayer()
    filter = filter or {}
    table.insert(filter, ply)
    local trace = {}
    trace.start = ply:GetShootPos()
    trace.endpos = self
    trace.filter = filter
    trace = util.TraceLine(trace)
    return not trace.Hit, trace.HitPos
end

--[[-------------------------------------------------------------------------
Turn a money amount into a pretty string
---------------------------------------------------------------------------]]
local function attachCurrency(str)
    local config = GAMEMODE.Config
    return config.currencyLeft and config.currency .. str or str .. config.currency
end
function DarkRP.formatMoney(n)
    if not n then return attachCurrency("0") end

    if n >= 1e14 then return attachCurrency(tostring(n)) end
    if n <= -1e14 then return "-" .. attachCurrency(tostring(math.abs(n))) end

    local negative = n < 0

    n = tostring(math.abs(n))
    local sep = ","
    local dp = string.find(n, "%.") or #n + 1

    for i = dp - 4, 1, -3 do
        n = n:sub(1, i) .. sep .. n:sub(i + 1)
    end

    return (negative and "-" or "") .. attachCurrency(n)
end

--[[-------------------------------------------------------------------------
Find a player based on given information
---------------------------------------------------------------------------]]
function DarkRP.findPlayer(info)
    if not info or info == "" then return nil end
    local pls = player.GetAll()

    for k = 1, #pls do -- Proven to be faster than pairs loop.
        local v = pls[k]
        if tonumber(info) == v:UserID() then
            return v
        end

        if info == v:SteamID() then
            return v
        end

        if string.find(string.lower(v:Name()), string.lower(tostring(info)), 1, true) ~= nil then
            return v
        end

        if string.find(string.lower(v:SteamName()), string.lower(tostring(info)), 1, true) ~= nil then
            return v
        end
    end
    return nil
end

--[[-------------------------------------------------------------------------
Find multiple players based on a string criterium
Taken from FAdmin
---------------------------------------------------------------------------]]
function DarkRP.findPlayers(info)
    if not info then return nil end
    local pls = player.GetAll()
    local found = {}
    local players

    if string.lower(info) == "*" or string.lower(info) == "<all>" then return pls end

    local InfoPlayers = {}
    for A in string.gmatch(info .. ";", "([a-zA-Z0-9:_.]*)[;(,%s)%c]") do
        if A ~= "" then
            table.insert(InfoPlayers, A)
        end
    end

    for _, PlayerInfo in pairs(InfoPlayers) do
        -- Playerinfo is always to be treated as UserID when it's a number
        -- otherwise people with numbers in their names could get confused with UserID's of other players
        if tonumber(PlayerInfo) then
            if IsValid(Player(PlayerInfo)) and not found[Player(PlayerInfo)] then
                found[Player(PlayerInfo)] = true
                players = players or {}
                table.insert(players, Player(PlayerInfo))
            end
            continue
        end

        for k, v in pairs(pls) do
            -- Prevend duplicates
            if found[v] then continue end

            -- Find by Steam ID
            if (PlayerInfo == v:SteamID() or v:SteamID() == "UNKNOWN") or
            -- Find by Partial Nick
            string.find(string.lower(v:Name()), string.lower(tostring(PlayerInfo)), 1, true) ~= nil or
            -- Find by steam name
            (v.SteamName and string.find(string.lower(v:SteamName()), string.lower(tostring(PlayerInfo)), 1, true) ~= nil) then
                found[v] = true
                players = players or {}
                table.insert(players, v)
            end
        end
    end

    return players
end

-- todo: change those ungodly names
function DarkRP.getEyeSightHitEntityPlayerFilter(ent)
    return ent:Alive() and not (ent:GetVehicle():IsValid() and ent:GetVehicle():IsCar())
end
function DarkRP.getEyeSightHitEntityDefaultFilter(ent)
    return ent:IsPlayer() and DarkRP.getEyeSightHitEntityPlayerFilter(ent)
end
function meta:getEyeSightHitEntity(searchDistance, hitDistance, filter)
    searchDistance = searchDistance or 60
    hitDistance = hitDistance or 15
    filter = filter or DarkRP.getEyeSightHitEntityDefaultFilter

    self:LagCompensation(true)

    local shootPos = self:GetShootPos()
    local entities = ents.FindInSphere(shootPos, searchDistance)
    local aimvec = self:GetAimVector()

    local smallestDistance = math.huge
    local foundEnt

    for k, ent in pairs(entities) do
        if ent == self or ent:GetNoDraw() or filter(ent) == false then continue end

        -- project the center vector on the aim vector
        local projected = shootPos + (ent:GetPos() - shootPos):Dot(aimvec) * aimvec

        if aimvec:Dot((projected - shootPos):GetNormalized()) < 0 then continue end

        -- the point on the model that has the smallest distance to your line of sight
        local nearestPoint = ent:NearestPoint(projected)
        local distance = nearestPoint:DistToSqr(projected)

        if distance < smallestDistance then
            local trace = {
                start = self:GetShootPos(),
                endpos = nearestPoint,
                filter = {self, ent}
            }
            local traceLine = util.TraceLine(trace)
            if traceLine.Hit then continue end

            smallestDistance = distance
            foundEnt = ent
        end
    end

    self:LagCompensation(false)

    if smallestDistance < hitDistance ^ 2 then
        return foundEnt
    end
end

--[[-------------------------------------------------------------------------
Whether a player has a DarkRP privilege
---------------------------------------------------------------------------]]
function meta:hasDarkRPPrivilege(priv)
    return self:IsSuperAdmin()
end

--[[-------------------------------------------------------------------------
Convenience function to return the players sorted by name
---------------------------------------------------------------------------]]
function DarkRP.nickSortedPlayers()
    local plys = player.GetAll()
    table.sort(plys, function(a, b) return a:Name():uforce():ucasefold() < b:Name():uforce():ucasefold() end)
    return plys
end

function meta:IsAlly(ply)
	return
		self == ply
		or
		self:isCP() and ply:isCP()
		or
		getgroup and getgroup(self) and getgroup(ply) == getgroup(self)
end

function meta:GetAllies(excludeSelf)
	local t = {}

	if not excludeSelf then
		table.insert(t, self)
	end

	for k, v in ipairs(player.GetAll()) do
		if v ~= self and self:IsAlly(v) then
			table.insert(t, v)
		end
	end

	return t
end

function meta:HasAllies()
    return self:isCP() or (getgroup and getgroup(self))
end

function meta:isHitman()
    return self:Team() == TEAM_MOB or self:Team() == TEAM_MERC
end

function meta:isTradingJob()
    return self:Team() == TEAM_GUN or self:Team() == TEAM_TRADE or self:Team() == TEAM_COOK or self:Team() == TEAM_CAR --[[or self:Team() == TEAM_MEDIC]]
end

function meta:isCook()
    return self:Job().cook
end

-- 1: arrested
-- 2: in handcuffs
-- 3: tased/dead
function meta:IsDisabled(level)
    local cant = hook.Run("IsDisabled", level, self)
    if cant then
        return DarkRP.getPhrase(cant) or cant
    end
end
function GM:IsDisabled(level, ply)
    if level <= 3 and not ply:Alive() then
        return "disabled_dead"
    end
end

function meta:IsDriving()
    local cant = hook.Run("IsDriving", self)
    if cant then
        return DarkRP.getPhrase(cant) or cant
    end
end
function GM:IsDriving(ply)
    if ply:InVehicle() then
        return "disabled_car"
    end
end

function DarkRP.playersByJob(...)
    local hash = {}
    for _, v in ipairs({...}) do
        if istable(v) then
            for i, j in pairs(v) do
                hash[j] = true
            end
        else
            hash[v] = true
        end
    end
    return table.filter(player.GetAll(), function(x) return hash[x:Team()] end)
end

function DarkRP.playersByFilter(func)
    return table.filter(player.GetAll(), func)
end

function DarkRP.playersInRange(entOrVec, size)
    local vec = isvector(entOrVec) and entOrVec or entOrVec:EyePos()
    local size = size^2
    return table.filter(player.GetAll(), function(x) return x:GetPos():DistToSqr(vec) <= size end)
end

function DarkRP.costToManufacture(item)
    local price = istable(item) and (item.pricesep or item.price) or item
    return math.max(1, math.Round((price / 50)^0.689)) --math.ceil( price / 100 )
end
--[[---------------------------------------------------------------------------
Like tonumber, but makes sure it's an integer
---------------------------------------------------------------------------]]
function DarkRP.toInt(value)
    value = tonumber(value)
    return value and math.floor(value)
end
