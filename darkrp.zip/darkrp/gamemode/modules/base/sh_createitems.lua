local plyMeta = FindMetaTable("Player")

-----------------------------------------------------------
-- Commandes des équipes --
-----------------------------------------------------------
local function addTeamCommands(CTeam)
    if CLIENT then return end

    local teamIndex = 0
    for num, v in pairs(RPExtraTeams) do
        if v.command == CTeam.command then
            teamIndex = num
            break
        end
    end

    if CTeam.vote or CTeam.RequiresVote then
        -- Commande de vote
        DarkRP.defineChatCommand("vote" .. CTeam.command, function(ply, args)
            if CTeam.RequiresVote and not CTeam.RequiresVote(ply, teamIndex) then
                DarkRP.notify(ply, 1, 4, "Cette équipe ne nécessite pas de vote actuellement.")
                return ""
            end

            if CTeam.canStartVote and not CTeam.canStartVote(ply) then
                local reason = isfunction(CTeam.canStartVoteReason) and CTeam.canStartVoteReason(ply, CTeam) or CTeam.canStartVoteReason or ""
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("unable", "/vote" .. CTeam.command, reason))
                return ""
            end

            if CTeam.admin == 1 and not ply:IsAdmin() then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("need_admin", "/" .. "vote" .. CTeam.command))
                return ""
            elseif CTeam.admin > 1 and not ply:IsSuperAdmin() then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("need_sadmin", "/" .. "vote" .. CTeam.command))
                return ""
            end

            if CTeam.customCheck and not CTeam.customCheck(ply) then
                local message = isfunction(CTeam.CustomCheckFailMsg) and CTeam.CustomCheckFailMsg(ply, CTeam) or CTeam.CustomCheckFailMsg or DarkRP.getPhrase("not_allowed_to_vote")
                DarkRP.notify(ply, 1, 4, message)
                return ""
            end

            if ply:Team() == teamIndex then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("unable", CTeam.command, ""))
                return ""
            end

            local numPlayers = team.NumPlayers(teamIndex)
            local max = CTeam.max

            if max ~= 0 and ((max % 1 == 0 and numPlayers >= max) or (max % 1 ~= 0 and (numPlayers + 1) / #player.GetAll() > max)) then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("team_limit_reached", CTeam.name))
                return ""
            end

            -- Vérification si DarkRP.electionAddParticipant est disponible
            if DarkRP.electionAddParticipant then
                local ok, why = DarkRP.electionAddParticipant(ply, teamIndex, args)
                if why then
                    DarkRP.notify(ply, ok and 0 or 1, 4, why)
                end
            else
                -- Utilisation d'un vote personnalisé comme alternative
                print("[DarkRP] Système d'élection indisponible. Utilisation d'un vote personnalisé.")
                DarkRP.createVote(DarkRP.getPhrase("wants_to_be", ply:Nick(), CTeam.name), "job", ply, 20, function(vote, choice)
                    if not IsValid(vote.target) then return end
                    if choice >= 0 then
                        vote.target:changeTeam(teamIndex)
                    else
                        DarkRP.notifyAll(1, 4, DarkRP.getPhrase("has_not_been_made_team", vote.target:Nick(), CTeam.name))
                    end
                end, nil, nil, {targetTeam = teamIndex})
            end

            return ""
        end)
    else
        -- Commande sans vote
        DarkRP.defineChatCommand(CTeam.command, function(ply)
            if CTeam.admin == 1 and not ply:IsAdmin() then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("need_admin", "/" .. CTeam.command))
                return ""
            end

            if CTeam.admin > 1 and not ply:IsSuperAdmin() then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("need_sadmin", "/" .. CTeam.command))
                return ""
            end

            if CTeam.customCheck and not CTeam.customCheck(ply) then
                local message = isfunction(CTeam.CustomCheckFailMsg) and CTeam.CustomCheckFailMsg(ply, CTeam) or CTeam.CustomCheckFailMsg or DarkRP.getPhrase("not_allowed_to_vote")
                DarkRP.notify(ply, 1, 4, message)
                return ""
            end

            ply:changeTeam(teamIndex)
            return ""
        end)
    end
end

-----------------------------------------------------------
-- Commandes des entités --
-----------------------------------------------------------
local function addEntityCommands(tblEnt)
    -- Définir la commande pour l'achat d'une entité
    DarkRP.declareChatCommand{
        command = tblEnt.cmd,
        description = "Acheter un(e) " .. tblEnt.name,
        delay = tblEnt.delay or 2,
        condition = function(ply)
            if ply:isArrested() then return false end
            if istable(tblEnt.allowed) and not table.HasValue(tblEnt.allowed, ply:Team()) then return false end
            if not ply:canAfford(tblEnt.price) then return false end
            if tblEnt.customCheck and not tblEnt.customCheck(ply) then return false end
            return true
        end
    }

    if CLIENT then return end

    local function buyEntity(ply)
        if ply:isArrested() then return "" end

        if type(tblEnt.allowed) == "table" and not table.HasValue(tblEnt.allowed, ply:Team()) then
            DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("incorrect_job", tblEnt.name))
            return ""
        end

        if tblEnt.customCheck and not tblEnt.customCheck(ply) then
            local message = isfunction(tblEnt.CustomCheckFailMsg) and tblEnt.CustomCheckFailMsg(ply, tblEnt) or tblEnt.CustomCheckFailMsg or DarkRP.getPhrase("not_allowed_to_purchase")
            DarkRP.notify(ply, 1, 4, message)
            return ""
        end

        if not ply:canAfford(tblEnt.price) then
            DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("cant_afford", tblEnt.name))
            return ""
        end

        ply:addMoney(-tblEnt.price)
        DarkRP.notify(ply, 0, 4, "Vous avez acheté " .. tblEnt.name .. " pour " .. DarkRP.formatMoney(tblEnt.price))

        local trace = {}
        trace.start = ply:EyePos()
        trace.endpos = trace.start + ply:GetAimVector() * 85
        trace.filter = ply

        local tr = util.TraceLine(trace)
        local ent = ents.Create(tblEnt.ent)
        ent:SetPos(tr.HitPos)
        ent:Setowning_ent(ply)
        ent:Spawn()
        return ""
    end

    DarkRP.defineChatCommand(tblEnt.cmd, buyEntity)
end

RPExtraTeams = {}

local jobByCmd = {}
DarkRP.getJobByCommand = function(cmd)
	if not jobByCmd[cmd] then return nil, nil end
	return RPExtraTeams[jobByCmd[cmd]], jobByCmd[cmd]
end

function plyMeta:getJobTable()
	return RPExtraTeams[self:Team()] or RPExtraTeams[GAMEMODE.DefaultTeam]
end
plyMeta.Job = plyMeta.getJobTable

local job_mt = {
	__index = {
		Count = function(self)
			local count = 0
			for k, v in ipairs(player.GetAll()) do
				if v:Team() == self.team then
					count = count + 1
				end
			end
			return count
		end
	}
}

function DarkRP.createJob(Name, CustomTeam)
	CustomTeam.name = Name

	local valid, err, hints = true
	if not valid then error(string.format("Corrupt team: %s!\n%s", CustomTeam.name or "", err)) end

	local index = table.insert(RPExtraTeams, CustomTeam)

	CustomTeam.team = index

	CustomTeam.salary = math.floor(CustomTeam.salary)

	jobByCmd[CustomTeam.command] = index

	DarkRP.addToCategory(CustomTeam, "jobs", CustomTeam.category)

	setmetatable(CustomTeam, job_mt)

	team.SetUp(#RPExtraTeams, Name, CustomTeam.color)

	timer.Simple(0, function()
		addTeamCommands(CustomTeam)
	end)

	-- Precache model here. Not right before the job change is done
	if type(CustomTeam.model) == "table" then
		for k,v in pairs(CustomTeam.model) do util.PrecacheModel(v) end
	else
		util.PrecacheModel(CustomTeam.model)
	end

	return index
end

function DarkRP.removeJob(i)
	local job = RPExtraTeams[i]
	RPExtraTeams[i] = nil
	jobByCmd[job.command] = nil
	DarkRP.removeFromCategory(job, "jobs")
	hook.Run("onJobRemoved", i, job)
end

--[[
		Doors
]]

RPExtraTeamDoors = {}
RPExtraTeamDoorIDs = {}
local maxTeamDoorID = 0
function DarkRP.createEntityGroup(name, ...)
	RPExtraTeamDoors[name] = {...}
	RPExtraTeamDoors[name].name = name

	maxTeamDoorID = maxTeamDoorID + 1
	RPExtraTeamDoorIDs[name] = maxTeamDoorID
end
AddDoorGroup = DarkRP.createEntityGroup

--[[
		Agendas
]]

-- here for backwards compatibility
DarkRPAgendas = {}

local agendas = {}
-- Returns the agenda managed by the player
plyMeta.getAgenda = fn.Compose{fn.Curry(fn.Flip(fn.GetValue), 2)(DarkRPAgendas), plyMeta.Team}

-- Returns the agenda this player is member of
function plyMeta:getAgendaTable()
	return agendas[self:Team()]
end

DarkRP.getAgendas = fp{fn.Id, agendas}

function DarkRP.createAgenda(Title, Manager, Listeners)
	local agenda = {Manager = Manager, Title = Title, Listeners = Listeners, ManagersByKey = {}}

	local valid, err, hints = true
	if not valid then error(string.format("Corrupt agenda: %s!\n%s", agenda.Title or "", err)) end

	for k,v in pairs(Listeners) do
		agendas[v] = agenda
	end

	for k,v in pairs(istable(Manager) and Manager or {Manager}) do
		agendas[v] = agenda
		DarkRPAgendas[v] = agenda -- backwards compat
		agenda.ManagersByKey[v] = true
	end

	if SERVER then
		timer.Simple(0, function()
			-- Run after scripts have loaded
			agenda.text = hook.Run("agendaUpdated", nil, agenda, "")
		end)
	end
end

--[[
		Chat Groups
]]

GM.DarkRPGroupChats = {}
function DarkRP.createGroupChat(funcOrTeam, ...)
	local gm = GM or GAMEMODE
	gm.DarkRPGroupChats = gm.DarkRPGroupChats or {}
	-- People can enter either functions or a list of teams as parameter(s)
	if type(funcOrTeam) == "function" then
		table.insert(gm.DarkRPGroupChats, funcOrTeam)
	else
		local teams = {funcOrTeam, ...}
		table.insert(gm.DarkRPGroupChats, function(ply) return table.HasValue(teams, ply:Team()) end)
	end
end
GM.AddGroupChat = function(GM, ...) DarkRP.createGroupChat(...) end


--[[
		Demote Groups
]]

local demoteGroups = {}
function DarkRP.createDemoteGroup(name, tbl)
	if not tbl or not tbl[1] then error("No members in the demote group!") end

	local set = demoteGroups[tbl[1]] or disjoint.MakeSet(tbl[1])
	set.name = name
	for i = 2, #tbl do
		set = (demoteGroups[tbl[i]] or disjoint.MakeSet(tbl[i])) + set
		set.name = name
	end

	for _, teamNr in pairs(tbl) do
		if demoteGroups[teamNr] then
			-- Unify the sets if there was already one there
			demoteGroups[teamNr] = demoteGroups[teamNr] + set
		else
			demoteGroups[teamNr] = set
		end
	end
end

function DarkRP.getDemoteGroup(teamNr)
	demoteGroups[teamNr] = demoteGroups[teamNr] or disjoint.MakeSet(teamNr)
	return disjoint.FindSet(demoteGroups[teamNr])
end

DarkRP.getDemoteGroups = fp{fn.Id, demoteGroups}

--[[
		Categories
]]

local categories = {
	jobs = {},
	entities = {},
	shipments = {},
	weapons = {},
	vehicles = {},
	ammo = {},
}
local categoriesMerged = false -- whether categories and custom items are merged.

DarkRP.getCategories = fp{fn.Id, categories}

local categoryOrder = function(a, b)
	local aso = a.sortOrder or 100
	local bso = b.sortOrder or 100
	return aso < bso or aso == bso and a.name < b.name
end

local function insertCategory(destination, tbl)
	table.insert(destination, tbl)
	local i = #destination

	while i > 1 do
		if categoryOrder(destination[i - 1], tbl) then break end
		destination[i - 1], destination[i] = destination[i], destination[i - 1]
		i = i - 1
	end
end

function DarkRP.createCategory(tbl)
	local valid, err, hints = true
	if not valid then error(string.format("Corrupt category: %s!\n%s", tbl.name or "", err)) end
	tbl.members = {}

	local destination = categories[tbl.categorises]
	insertCategory(destination, tbl)

	-- Too many people made the mistake of not creating a category for weapons as well as shipments
	-- when having shipments that can also be sold separately.
	if tbl.categorises == "shipments" then
		insertCategory(categories.weapons, table.Copy(tbl))
	end
end

function DarkRP.addToCategory(item, kind, cat)
	cat = cat or "Other"
	item.category = cat

	-- The merge process will take care of the category:
	if not categoriesMerged then return end

	-- Post-merge: manual insertion into category
	local cats = categories[kind]
	for _, c in ipairs(cats) do
		if c.name ~= cat then continue end

		insertCategory(c.members, item)
		return
	end

	--error(string.format([[The category of "%s" ("%s") does not exist!]], item.name, cat))
end

function DarkRP.removeFromCategory(item, kind)
	local cats = categories[kind]
	if not cats then DarkRP.error(string.format("Invalid category kind '%s'.", kind), 2) end
	local cat = item.category
	if not cat then return end
	for _, v in pairs(cats) do
		if v.name ~= item.category then continue end
		for k, mem in pairs(v.members) do
			if mem ~= item then continue end
			table.remove(v.members, k)
			break
		end
		break
	end
end

-- Assign custom stuff to their categories
local function mergeCategories(customs, catKind, path)
	local categories = categories[catKind]
	local catByName = {}
	for k,v in pairs(categories) do catByName[v.name] = v end
	for k,v in pairs(customs) do
		-- Override default thing categories:
		local catName = v.category or "Other"
		local cat = catByName[catName]
		if not cat then
			--error(string.format([[The category of "%s" ("%s") does not exist!]], v.name, catName))
			return
		end

		cat.members = cat.members or {}
		table.insert(cat.members, v)
	end

	-- Sort category members
	--for k,v in pairs(categories) do table.sort(v.members, categoryOrder) end
end

hook.Add("loadCustomDarkRPItems", "mergeCategories", function()
	local shipments = fn.Filter(fc{fn.Not, fp{fn.GetValue, "noship"}}, CustomShipments)
	local guns = fn.Filter(fp{fn.GetValue, "separate"}, CustomShipments)

	mergeCategories(RPExtraTeams, "jobs", "your jobs")
	mergeCategories(DarkRPEntities, "entities", "your custom entities")
	mergeCategories(shipments, "shipments", "your custom shipments")
	mergeCategories(guns, "weapons", "your custom weapons")
	mergeCategories(GAMEMODE.AmmoTypes, "ammo", "your custom ammo")

	categoriesMerged = true
end)
