DarkRPEntities = {}

function DarkRP.createEntity(name, tblEnt)
	tblEnt.name = name

	if type(tblEnt.allowed) == "number" then
		tblEnt.allowed = {tblEnt.allowed}
	end

	local id = table.insert(DarkRPEntities, tblEnt)
	tblEnt.cmd = id
	--DarkRP.addToCategory(tblEnt, "entities", tblEnt.category)
end

--[[
		Shipments
]]

CustomShipments = {}

local shipByName = {}
DarkRP.getShipmentByName = function(name)
	name = string.lower(name or "")

	if not shipByName[name] then return nil, nil end
	return CustomShipments[shipByName[name]], shipByName[name]
end

function DarkRP.createShipment(name, customShipment)
	local AllowedClasses = classes or {}
	if not classes then
		for k,v in pairs(team.GetAllTeams()) do
			table.insert(AllowedClasses, k)
		end
	end

	local price = tonumber(price)

	if customShipment.separate ~= nil then
		customShipment.separate = customShipment.separate
	end
	customShipment.name = name
	customShipment.allowed = customShipment.allowed or {}

	if not customShipment.price then
		customShipment.noship = true
		customShipment.price = customShipment.pricesep * customShipment.amount
	end

	customShipment.allowed = isnumber(customShipment.allowed) and {customShipment.allowed} or customShipment.allowed

	if not customShipment.noship then --[[DarkRP.addToCategory(customShipment, "shipments", customShipment.category)]] end
	if customShipment.separate then --[[DarkRP.addToCategory(customShipment, "weapons", customShipment.category)]] end

	shipByName[string.lower(name or "")] = table.insert(CustomShipments, customShipment)
	util.PrecacheModel(customShipment.model)
end

--[[
		Food
]]

FoodItems = {}

function DarkRP.createFood(name, mdl, energy, price)
	local foodItem = istable(mdl) and mdl or {model = mdl, energy = energy, price = price}
	foodItem.name = name

	table.insert(FoodItems, foodItem)
end
AddFoodItem = DarkRP.createFood

--[[
		Ammo
]]

GM.AmmoTypes = {}

function DarkRP.createAmmoType(ammoType, name, model, price, amountGiven, customCheck)
	local gm = GM or GAMEMODE
	gm.AmmoTypes = gm.AmmoTypes or {}
	local ammo = istable(name) and name or {
		name = name,
		model = model,
		price = price,
		amountGiven = amountGiven,
		customCheck = customCheck
	}
	ammo.ammoType = ammoType

	ammo.id = table.insert(gm.AmmoTypes, ammo)

	--DarkRP.addToCategory(ammo, "ammo", ammo.category)
end
GM.AddAmmoType = function(GM, ...) DarkRP.createAmmoType(...) end
