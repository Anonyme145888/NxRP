local meta = FindMetaTable( "Entity" )

function meta:GetPropOwner()
	return self:GetDTInt(31)
end

function meta:GetDeployableOwnerID()
	return self:GetDTInt(30)
end


function meta:GetPropCracks()
	return self:GetDTBool(31)
end

function meta:IsPropdInitialized()
	return self:GetDTBool(30)
end

function meta:IsDarkRPCar()
	return self:GetDTBool(29)
end

function meta:GetHandcuffsLock()
	return self:GetDTBool(28)
end


function meta:GetDTime()
	return self:GetDTFloat(31)
end

function meta:GetStability()
	return self:GetDTFloat(30)
end

function meta:GetFuel()
	return self:GetDTFloat(29)
end

function meta:GetIntegrity()
	return self:GetDTFloat(28)
end

function meta:GetTaxiPath()
	return self:GetDTFloat(27)
end

function meta:GetPropHealth()
	return self:GetDTFloat(26)
end
