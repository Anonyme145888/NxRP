local generated_textures = {}

procedural_textures = {}
procedural_textures.list = generated_textures

local function DrawError( text, echo )
	render.Clear(128,0,128,255)
	render.ClearDepth()
	cam.Start2D()
	surface.SetTextColor( color_white )
	surface.SetFont("DermaLarge")
	surface.SetTextPos(8,8)
	surface.DrawText( text )
	cam.End2D()
	if echo then
		print( text )
	end
	return true
end

-- This all checks needed to no crash or catch rendering problems
local function DrawProceduralTexture( tex )
	local ent = tex.ent
	if not ent then
		return DrawError("Entity is not set, ent = "..tostring(ent))
	end
	if not ent:IsValid() then
		-- It is possible that entity only existed for one frame so it needs to be generated once we see it again
		DrawError("Entity is not valid, ent = "..tostring(ent), true)
		return false
	end
	if not ent.GenerateTexture then
		return DrawError("Entity has no GenerateTexture function, ent = "..tostring(ent))
	end
	local res = ent:GenerateTexture( tex )
	if res then print( "Generated texture "..res.id ) end
	return res == nil or res
end

function procedural_textures.Flush()
	generated_textures = {}
end

concommand.Add("mat_flush_procedural",function( ply, cmd, args )
	procedural_textures.Flush()
end)

hook.Add("PreRender","RefreshProceduralTextures", function()
	for k,v in pairs( generated_textures ) do
		local rt = v.rt:GetTexture()
		if (not v.ready or v.needupdate) and rt and not v.failedrt then
			render.PushRenderTarget( rt )
			local succ, res = pcall( DrawProceduralTexture, v )
			render.PopRenderTarget()
			v.ready = true
			if succ then
				v.needupdate = false
				v.lastupdate = RealTime()
				--print("updated texture ["..k.."]")
			else
				ErrorNoHalt("Error occured while generating texture for "..tostring(v.ent)..":", res )
			end
		end
	end
end)

local function GetProceduralTexture( ent )
	local id = ent.GetProceduralTextureID and ent:GetProceduralTextureID()
	if not id then return end
	local tex = generated_textures[ id ]
	if tex then
		-- request texture update every minute since source engine can suddenly unload our texture
		if tex.lastupdate and (RealTime() - tex.lastupdate > 60) then
			tex.needupdate = true
			tex.ent = ent
		end
		return tex.ready and tex.rt:GetTexture()
	end

	tex = {}
	tex.ent = ent -- referencial instance
	tex.id = id
	local params = ent.GeneratedTextureParams
	if params then
		tex.rt = rendertarget.Get(
			params.w or 512,
			params.h or 512,
			params.sizemode,
			params.depthmode,
			params.texflags,
			params.rtflags
		)
	else
		tex.rt = rendertarget.Get( 512, 512 )
	end

	generated_textures[ id ] = tex

	-- the texture is not ready yet anyway so returning nothing
end

matproxy.Add({
	name = "ProceduralTexture",
	init = function( self, mat, values )
		self.tex_resultvar = values["resultvar"]
		-- we're getting black texture until source collected it as garbage
		self.tex_black = Material"tools/toolsblack":GetTexture"$basetexture"
	end,
	bind = function( self, mat, ent )
		if self.tex_resultvar and IsValid( ent ) then
			local tex = GetProceduralTexture( ent )
			if tex then
				mat:SetTexture( self.tex_resultvar, tex )
				return
			end
		end
		mat:SetTexture( self.tex_resultvar, self.tex_black )
	end
})
