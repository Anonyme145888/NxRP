-- lua object module

AddCSLuaFile()

object = {}

local function saferequire( name )
	local err,ret = pcall(require, name)
	return err and ret
end

local NS = {}
local NSMeta = { __index=NS }

-- this function will be added to all metatables of target classes to make them able to be printer as objects
local function object_tostring( obj )
	return type(obj._tostring)=="function" and obj:_tostring() or obj._tostring or obj.Name or "object"
end

-- Create new namespace which can be used to register classes and create theirs instances
function object.CreateNamespace()
	local namespace = {}

	setmetatable( namespace, NSMeta )

	--namespace.baseclassname = "base"
	namespace.classes = {}

	-- NS:RegisterFromFile settings:
	-- name of file which should be loaded from found directories when
	namespace.initfilename = "init.lua"
	-- masks for directories and files
	namespace.filemask = "^[^.].*%.lua$"
	namespace.dirmask = "^[^.].*$"

	return namespace
end

-- Allow debug information to be printed
-- state: boolean    Debug state, true=on
function NS:SetVerbose( state )
	self._b_verbose = state
end

-- Set default base class name
-- classname : string   Default base class name
function NS:SetBaseClassName( classname )
	self.baseclassname = classname
end

-- Update class table's derivery
-- ct : Table   class table
-- force : Bool update even if no _needbaseupdate
function NS:UpdateDerivery( ct, force, recursive )
	local base = ct.Base or self.baseclassname
	self:_debug("updating derivery for" .. (ct.Name or tostring(ct)) .. " : " .. (base or "") )
	if ct.Name == base then -- We should not try to resolve baseclass derivery since its base
		ct._needbaseupdate = false
	elseif ( ct._needbaseupdate or force ) and base then

		local basect = self:FindClassTable( base ) -- resolving base class
		if basect then
			if recursive then
				self:UpdateDerivery( basect, force, true )
			end

			setmetatable( ct, { __index = basect } )
			ct._needbaseupdate = false
		else
			print("Failed base class lookup for '"..classname.."'")
			-- I hope next time we'll be succeded
		end
	end
	self:_debug"done"
	return
end

-- Update derivery of all classes
-- force : Bool    same as above
function NS:UpdateAllClassesDerivery( force, recursive )
	for k,v in pairs(self.classes) do
		self:UpdateDerivery( v, force, recursive )
	end
end

-- Look up class table
-- classname : String     Class name to search for
-- noprepare : Boolean    Do not update derivery ( optional )
-- returns Table if any found
function NS:FindClassTable( classname, noprepare )
	local ct = self.classes[ classname ]

	if not ct then error("Unknown class name '"..tostring(classname).."'") end

	if not noprepare then	self:UpdateDerivery( ct ) end

	return ct
end

-- Register new class in namespace from table
-- tbl : Table            Class table to register
-- nooverride : Boolean   Do not override already registered classes ( optional )
function NS:Register( tbl, nooverride )
	if type(tbl)~="table" then error("First argument 'table' is "..type(tbl)) end

	local classname = tbl.Name
	if not classname then error"No calassname specified" end

	if not nooverride and self.classes[ classname ] then return end

	tbl._mt = { __index = tbl, __tostring = object_tostring }
	tbl._needbaseupdate = true
	tbl.Base = tbl.Base or self.baseclassname

	self.classes[ classname ] = tbl
end

local function init_call( ... )
	local oldc = C
	local newc = {}
	C = newc
	succ, err = pcall( ... )
	C = oldc
	return succ, ( succ and newc or err )
end

-- Register new class in namespace from chunk
-- chunk : Lua chunk      Chunk to register from
-- nooverride : Boolean   Do not override already registered classes ( optional )
-- filename : string      Optional filename for error messages
function NS:RegisterFromChunk( chunk, nooverride, filename )
	local tb = {}

	local succ, newtb = init_call( chunk, tb )
	if succ then
		tb = newtb or tb
		return self:Register( tb, nooverride )
	else
		error(" Failed class loading" ..
			(filename and (" from file '"..filename.."'") or "") .. ":\n" ..
			newtb)
	end
end

-- Register new class in namespace from file
-- fname : string         Filename of file to register from
-- base : string          Path base like LUA or GAME (GMOD only)
-- nooverride : Boolean   Do not override already registered classes ( optional )
function NS:RegisterFromFile( fname, base, nooverride )
	local chunk, er
	if luatools then -- gmod way
		self:_debug"loaded in luatools way"
		local code = luatools.FindAndLoadFile( fname, base and {base} )

		local fine, tab = luatools.RunCode( code..";return C", fname, nil, {C={}} )

		if fine then
			return self:Register( tab , nooverride )
		else
			error("Errors while loading '"..fname.."':"..tab)
		end

	elseif include then -- gmod way
		self:_debug"loaded include way"
		-- I know, setting globals is not a good way
		-- but I can't do it in other way
		succ, result = init_call( include, fname )

		if not succ then error( result ) end

		return self:Register( result, nooverride )
	elseif loadfile then
		chunk, er = loadfile( fname )
	else
		error"Unable to load from file: No any suitable way found"
	end

	if not chunk then error("Failed class loading:" .. er ) end

	return self:RegisterFromChunk( chunk, nooverride, fname )
end

-- Register new classes in namespace from all lua files in directory
-- dir : string           Directory path to load from
-- base : string          Path base like LUA or GAME (GMOD only)
function NS:RegisterFromDirectory( dir, base )
	local dirs = {}
	local files = {}
	base = base or "LUA"

	self:_debug("Loading everything from "..dir)

	if file and file.Find then -- this is gmod
		files, dirs = file.Find( dir.. "/*" , base )
		self:_debug("found: "..#files.." files")
	elseif saferequire"lfs" then
	-- looking for another method of retriving list of files
		for f in lfs.dir( dir ) do
			local attr = lfs.attributes( dir.."/"..f )
			table.insert(
				(attr.mode == "directory") and dirs or files,
				f)
		end
	else
		error"Unable to read directory: No any suitable module found."
	end

	-- now load all the files
	for k,v in pairs( dirs ) do
		if string.match( v, self.dirmask ) then
			self:RegisterFromFile( dir.."/"..v.."/"..self.initfilename )
			self:_debug(" loaded dir "..v )
		end
	end
	self:_debug"Done loading directories"
	for k,v in pairs( files ) do
		if string.match( v, self.filemask ) then
			self:RegisterFromFile( dir.."/"..v )
			self:_debug(" loaded "..v )
		end
	end
	self:_debug"done loading files"

	-- force update all classes derivery because we just loaded bunch of some
	self:UpdateAllClassesDerivery( true )
	self:_debug"done updating classes"
end

local function call_recursive( obj, name, idx, ... )
	idx = idx or obj
	-- idx = idx or obj._mt and obj._mt.__index
	local nextmt = getmetatable(idx)
	local nextidx = nextmt and nextmt.__index
	-- local nextidx = idx._mt and idx._mt.__index
	if nextidx then
		call_recursive( obj, name, nextidx, ... )
	end
	local fun = rawget( idx, name )
	if fun then
		--self:_debug("+ ".. (obj.Name or "unknown") .." is calling init for "..( idx.Name or "unknown" ) )
		fun( obj, ... )
	else
		--self:_debug("- ".. (rawget(obj,Name) or "unknown") .." is not calling init for "..( rawget(idx,Name) or "unknown" ) )
	end
end

-- Create object instance by its classname
-- classname : String     Name of class to create
-- returns created object ( Table )
function NS:Create( classname, ... )
	local ct = self:FindClassTable( classname )

	local obj = {}
	setmetatable( obj, ct._mt )

	if not obj.b_no_recurse_init then
		call_recursive( obj, "Initialize", nil, ... )
	else
		if obj.Initialize then obj:Initialize( ... ) end
	end
	return obj
end

-- Get classes tree table (for debug purposes)
-- classname : String   Name of the class to start from ( optional )
-- returns classes tree ( Table )
function NS:GetClassesTree( classname )
	local tree = {}
	classname = classname or self.baseclassname

	-- TODO: make it go from multiple bases

	for k,v in pairs( self.classes ) do
		if v.Base == classname then
			tree[k] = self:GetClassesTree( k )
		end
	end
	return tree
end

-- returns classes table
function NS:GetClassesTable()
	return self.classes
end

-- Prints if verbose mode is on, you dont need it
function NS:_debug(...)
	if self._b_verbose then print(...) end
end


return object