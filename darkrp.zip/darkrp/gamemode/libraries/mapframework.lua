mapfw = mapfw or {}

function mapfw.GetTable()
	if mapfw.failed then return end
	if not mapfw.table then
		mapfw.failed = true

		-- shared stuff will be merged into serverside version of json so we don't need clientside one
		local fname = "maps/" .. game.GetMap() .. (SERVER and "_server.json" or ".json")

		str = file.Read(fname, "GAME")

		if not str then print("No map data file "..fname.."\n") return end

		local tbl = util.JSONToTable( str )
		if not tbl then ErrorNoHalt("Failed parsing map data "..fname.."\n") return end

		print("Loaded map data from "..fname)

		mapfw.table = tbl

		mapfw.failed = false

		if SERVER then
			local fname = "maps/" .. game.GetMap() .. ".json"

			str = file.Read(fname, "GAME")

			if not str then print("No map data (client data on server) file "..fname.."\n") return end

			tbl = util.JSONToTable( str )
			if not tbl then ErrorNoHalt("Failed parsing map data (client data on server) "..fname.."\n") return end

			print("Loaded map data (client data on server) from "..fname)

			mapfw.table.client = tbl
		end
	end
	return mapfw.table
end

function mapfw.GetFileList()
	if mapfw.lsfailed then return end
	if mapfw.filelist then return mapfw.filelist end
	mapfw.lsfailed = true

	local fname = "mapls_"..game.GetMap()..".txt"

	local str = file.Read(fname,"GAME")
	if not str then
		print("MapFW: no map file list "..fname.."\n")
		return
	end
	mapfw.filelist = string.Split( str, "\n" )
	mapfw.lsfailed = false
	return mapfw.filelist
end
