local GAMEMODE = GAMEMODE or GM

--[[-------------------------------------------------------------------------
Citizens
---------------------------------------------------------------------------]]

TEAM_CITIZEN = DarkRP.createJob(DarkRP.getPhrase("citizen"), {
    color = Color(0x4c, 0xaf, 0x50),
    model = {
        "models/player/group01/female_01.mdl",
        "models/player/group01/female_02.mdl",
        "models/player/group01/female_03.mdl",
        "models/player/group01/female_04.mdl",
        "models/player/group01/female_06.mdl",
        "models/player/group01/male_01.mdl",
        "models/player/group01/male_02.mdl",
        "models/player/group01/male_03.mdl",
        "models/player/group01/male_04.mdl",
        "models/player/group01/male_05.mdl",
        "models/player/group01/male_06.mdl",
        "models/player/group01/male_07.mdl",
        "models/player/group01/male_08.mdl",
        "models/player/group01/male_09.mdl",
    },
    jobTitles = DarkRP.lKey("job_title_citizen"),
    description = DarkRP.getPhrase("citizen_desc"),
    weapons = {},
    command = "citizen",
    max = 0,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = DarkRP.getPhrase("citizens"),
    icon = "J",
})

TEAM_HOBO = DarkRP.createJob(DarkRP.getPhrase("hobo"), {
    color = Color(0x8d, 0x6e, 0x63),
    model = "models/player/corpse1.mdl",
    description = DarkRP.getPhrase("hobo_desc"),
    weapons = {"weapon_bugbait"},
    command = "hobo",
    max = 0,
    salary = 0,
    admin = 0,
    vote = false,
    candemote = false,
    hobo = true,
    category = DarkRP.getPhrase("citizens"),
    icon = "N",
    CanStealCars = true,
})

TEAM_FISH = DarkRP.createJob(DarkRP.getPhrase("fishman"), {
    color = Color(0xff, 0x8a, 0x80),
    model = {
        "models/player/eli.mdl",
        "models/player/p2_chell.mdl"
    },
    description = DarkRP.getPhrase("fishman_desc"),
    weapons = {"weapon_fishing_rod"},
    command = "fishman",
    max = 3,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    candemote = false,
    category = DarkRP.getPhrase("citizens"),
    icon = "F",
})

--[=[TEAM_NEWS = DarkRP.createJob("Репортёр", {
    color = Color(77, 113, 152),
    model = {
        "models/player/hostage/hostage_02.mdl",
        "models/player/hostage/hostage_03.mdl",
    },
    description = [[Освещайте различные события в городе, держите всех в курсе событий.]],
    weapons = {"tv_camera"},
    command = "reporteur",
    max = 4,
    salary = GAMEMODE.Config.normalsalary * 1.11,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("citizens")
})]=]

TEAM_POLICE = DarkRP.createJob(DarkRP.getPhrase("cp"), {
    color = Color(0x39, 0x49, 0xab),
    --model = {"models/player/police.mdl", "models/player/police_fem.mdl"},
    model = {
        "models/ccz/cop7.mdl",
        "models/ccz/cop9.mdl",
        "models/ccz/cop4.mdl",
        "models/ccz/femalecop1.mdl",
        "models/ccz/femalecop2.mdl",
        "models/ccz/cop2.mdl",
        "models/ccz/cop1.mdl",
        "models/ccz/cop3.mdl",
    },
    description = DarkRP.getPhrase("cp_desc"),
    weapons = {"xp_handcuffs", "taser", "fas2_g3", "stunstick", "door_ram", "weaponchecker", "gx_radio", "gx_speedmeter"},
    command = "cp",
    max = 7,
    salary = GAMEMODE.Config.normalsalary * 1.45,
    admin = 0,
    vote = false,
    customCheck = function(pl)
        return not pl:isWanted() and (not (SERVER and nxpositions and nxpositions.policejob) or pl:GetPos():WithinAABox(nxpositions.policejob[1], nxpositions.policejob[2]))
    end,
    CustomCheckFailMsg = function(pl)
        return pl:isWanted() and DarkRP.getPhrase("cp_msg_wanted") or DarkRP.getPhrase("cp_msg_pos")
    end,
    hasLicense = true,
    category = DarkRP.getPhrase("law_enforcement"),
    police = true,
    cityservice = true,
    icon = "X",
    nocollide = 1,
})

TEAM_CHIEF = DarkRP.createJob(DarkRP.getPhrase("chief"), {
    color = Color(0x00, 0x49, 0xf0),
    --model = "models/player/combine_super_soldier.mdl",
    model = {
        "models/ccz/cop7.mdl",
        "models/ccz/cop9.mdl",
        "models/ccz/cop4.mdl",
        "models/ccz/femalecop1.mdl",
        "models/ccz/femalecop2.mdl",
        "models/ccz/cop2.mdl",
        "models/ccz/cop1.mdl",
        "models/ccz/cop3.mdl",
    },
    description = DarkRP.getPhrase("chief_desc"),
    weapons = {"xp_handcuffs", "taser", "nxw_glock", "m9k_m3", "stunstick", "door_ram", "weaponchecker", "gx_radio", "gx_speedmeter"},
    command = "chief",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 1.67,
    admin = 0,
    vote = false,
    hasLicense = true,
    chief = true,
    NeedToChangeFrom = {TEAM_POLICE},
    category = DarkRP.getPhrase("law_enforcement"),
    police = true,
    cityservice = true,
    icon = "Y",
    nocollide = 1,
})

TEAM_MAYOR = DarkRP.createJob(DarkRP.getPhrase("mayor"), {
    color = Color(0xc6, 0x28, 0x28),
    model = {"models/player/female_02_suit_fix.mdl", "models/player/breen.mdl"},
    description = DarkRP.getPhrase("mayor_desc"),
    weapons = {"gx_radio"},
    command = "mayor",
    max = 1,
    salary = GAMEMODE.Config.normalsalary * 1.89,
    admin = 0,
    vote = true,
    election = true,
    DoClick = function()
        local frame = DarkRP.StringRequest("", DarkRP.getPhrase("election_put_promise"), function(s)
            ConCommand("votemayor", s)
        end)
    end,
    RequiresVote = function(pl)
        return true
    end,
    hasLicense = true,
    mayor = true,
    category = DarkRP.getPhrase("law_enforcement"),
    police = true,
    cityservice = true,
    icon = "Z",
    nocollide = 1,
})

table.insert(RPExtraTeams[TEAM_CHIEF].NeedToChangeFrom, TEAM_MAYOR)

TEAM_GANG = DarkRP.createJob(DarkRP.getPhrase("gangster"), {
    color = Color(0x60, 0x7d, 0x8b),
    model = {
                "models/player/group01/female_01.mdl",
                "models/player/group01/female_02.mdl",
                "models/player/group01/female_03.mdl",
                "models/player/group01/female_04.mdl",
                "models/player/group01/female_06.mdl",
                "models/player/group01/male_01.mdl",
                "models/player/group01/male_02.mdl",
                "models/player/group01/male_03.mdl",
                "models/player/group01/male_04.mdl",
                "models/player/group01/male_05.mdl",
                "models/player/group01/male_06.mdl",
                "models/player/group01/male_07.mdl",
                "models/player/group01/male_08.mdl",
                "models/player/group01/male_09.mdl",
            },
    description = DarkRP.getPhrase("gangster_desc"),
    weapons = {},
    command = "gangster",
    max = 9,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    candemote = false,
    category = DarkRP.getPhrase("criminal"),
    icon = "O",
    CanStealCars = true,
})

TEAM_MOB = DarkRP.createJob(DarkRP.getPhrase("mobboss"), {
    color = Color(0x45, 0x5a, 0x64),
    model = "models/player/gman_high.mdl",
    description = DarkRP.getPhrase("mobboss_desc"),
    weapons = {"handcuffs", "lockpick"},
    command = "mobboss",
    max = 0,
    salary = GAMEMODE.Config.normalsalary * 1.34,
    admin = 0,
    vote = false,
    candemote = false,
    customCheck = function(ply)
        local name, group = getgroup(ply)
        return CLIENT or name and group.boss == ply
    end,
    CustomCheckFailMsg = DarkRP.getPhrase("mobboss_msg"),
    category = DarkRP.getPhrase("criminal"),
    icon = "M",
    CanStealCars = true,
})

--[=[
TEAM_DRUG = DarkRP.createJob("Изготовитель наркотиков", {
    color = Color(93, 161, 48),
    model = "models/player/soldier_stripped.mdl",
    description = [[В погоне за необычными ощущениями люди нередко переключаются на наркотики. Вы можете "помочь" им в этом. Будьте осторожны, ваша продукция крайне нелегальна и может легко отправить вас за решётку.]],
    weapons = {},
    command = "drugdealer",
    max = .04,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("criminal_business"),
    CanStealCars = true,
})
]=]

TEAM_MERC = DarkRP.createJob(DarkRP.getPhrase("merc"), {
    color = Color(0x80, 0x40, 0x40),
    model = {
        "models/player/leet.mdl",
        "models/player/mossman_arctic.mdl"
    },
    description = DarkRP.getPhrase("merc_desc"),
    weapons = {},
    command = "merc",
    max = 2,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("criminal_business"),
    icon = "H",
    CanStealCars = true,
})

TEAM_FIRE = DarkRP.createJob(DarkRP.getPhrase("fireman"), {
    color = Color(0xff, 0x57, 0x16),
    model = "models/player/swat.mdl",
    description = DarkRP.getPhrase("fireman_desc"),
    weapons = {"weapon_extinguisher", "gx_radio",},
    command = "fireman",
    max = .08,
    salary = GAMEMODE.Config.normalsalary * 1.45,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("city_service"),
    cityservice = true,
    icon = "f",
    disabled = true,
})

TEAM_MEDIC = DarkRP.createJob(DarkRP.getPhrase("medic"), {
    color = Color(0x00, 0x96, 0x88),
    model = {
        "models/player/kleiner.mdl",
        "models/player/group03m/female_01.mdl",
        "models/player/group03m/male_09.mdl"
    },
    jobTitles = DarkRP.lKey("job_title_medic"),
    description = DarkRP.getPhrase("medic_desc"),
    weapons = {"med_kit", "gx_radio",},
    command = "medic",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 1.45,
    admin = 0,
    vote = false,
    medic = true,
    category = DarkRP.getPhrase("city_service"),
    cityservice = true,
    icon = "T",
})

TEAM_BUS = DarkRP.createJob(DarkRP.getPhrase("busdriver"), {
    color = Color(0x00, 0x60, 0x64),
    model = {
        "models/player/odessa.mdl",
    },
    description = DarkRP.getPhrase("busdriver_desc"),
    weapons = {},
    command = "busdriver",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 1.45,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("city_service"),
    cityservice = true,
    icon = "8",
    disabled = not GAMEMODE.Config.cars,
})

TEAM_COOK = DarkRP.createJob(DarkRP.getPhrase("bar"), {
    color = Color(0x8e, 0x24, 0xaa),
    model = "models/player/barney.mdl",
    description = DarkRP.getPhrase("bar_desc"),
    weapons = {},
    command = "bar",
    max = .04,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    cook = true,
    category = DarkRP.getPhrase("business"),
    icon = "I",
    disabled = true,
})

--if GAMEMODE.Config.cars then
    TEAM_TAXI = DarkRP.createJob(DarkRP.getPhrase("taxidriver"), {
        color = Color(0xfb, 0xc0, 0x2d),
        model = "models/player/hostage/hostage_01.mdl",
        description = DarkRP.getPhrase("taxidriver_desc"),
        weapons = {"nx_radio",},
        command = "taxidriver",
        max = 2,
        salary = GAMEMODE.Config.normalsalary,
        admin = 0,
        vote = false,
        category = DarkRP.getPhrase("business"),
        icon = "Q",
        disabled = not GAMEMODE.Config.cars,
    })
--end

TEAM_TRADE = DarkRP.createJob(DarkRP.getPhrase("trader"), {
    --color = Color(0x33, 0x69, 0x1e),
    color = Color(0x8e, 0x24, 0xaa),
    model = {
        "models/player/mossman.mdl",
        "models/player/barney.mdl",
    },
    description = DarkRP.getPhrase("trader_desc"),
    weapons = {},
    command = "trader",
    max = 2,
    salary = GAMEMODE.Config.normalsalary * 1.11,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("business"),
    icon = "U",
})

TEAM_GUN = DarkRP.createJob(DarkRP.getPhrase("gundealer"), {
    color = Color(0xfb, 0x8c, 0x00),
    model = {
        "models/player/monk.mdl",
        "models/player/alyx.mdl"
    },
    description = DarkRP.getPhrase("gundealer_desc"),
    weapons = {},
    command = "gundealer",
    max = 2,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("business"),
    icon = "L",
})

--[=[
TEAM_BANK = DarkRP.createJob("Банкир", {
    color = Color(79, 121, 66),
    model = {
        "models/player/hostage/hostage_02.mdl",
        "models/player/hostage/hostage_03.mdl",
    },
    description = [[Банкир может построить свой банк и принимать вклады других людей.
    Учтите, что вам придётся постоянно укреплять защиту своего бизнеса, иначе вас могут ограбить и ваш банк потеряет доверие игроков.]],
    weapons = {},
    command = "banker",
    max = .04,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("business")
})
]=]

TEAM_SECURITY = DarkRP.createJob(DarkRP.getPhrase("security"), {
    color = Color(0x29, 0xb6, 0xf6),
    model = "models/player/odessa.mdl",
    description = DarkRP.getPhrase("security_desc"),
    weapons = {"stunstick", "weaponchecker"},
    command = "security",
    max = 3,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    category = DarkRP.getPhrase("business"),
    icon = "G",
})

--if GAMEMODE.Config.cars then
    TEAM_CAR = DarkRP.createJob(DarkRP.getPhrase("carmaster"), {
        color = Color(0x9e, 0x9d, 0x24),
        model = "models/player/group02/male_02.mdl",
        description = DarkRP.getPhrase("carmaster_desc"),
        weapons = {"vc_wrench"},
        command = "carmaster",
        max = 2,
        salary = GAMEMODE.Config.normalsalary,
        admin = 0,
        vote = false,
        category = DarkRP.getPhrase("business"),
        icon = "a",
        disabled = not GAMEMODE.Config.cars,
    })
--end


DarkRP.createCategory{
    name = DarkRP.getPhrase("citizens"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x4c, 0xaf, 0x50),
    canSee = fp{fn.Id, true},
    sortOrder = 1,
}

DarkRP.createCategory{
    name = DarkRP.getPhrase("law_enforcement"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x39, 0x49, 0xab),
    canSee = fp{fn.Id, true},
    sortOrder = 2,
}

DarkRP.createCategory{
    name = DarkRP.getPhrase("criminal"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x45, 0x5a, 0x64),
    canSee = fp{fn.Id, true},
    sortOrder = 3,
}

DarkRP.createCategory{
    name = DarkRP.getPhrase("criminal_business"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x60, 0x7d, 0x8b),
    canSee = fp{fn.Id, true},
    sortOrder = 4,
}

DarkRP.createCategory{
    name = DarkRP.getPhrase("city_service"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x00, 0x96, 0x88),
    canSee = fp{fn.Id, true},
    sortOrder = 5,
}

DarkRP.createCategory{
    name = DarkRP.getPhrase("business"),
    categorises = "jobs",
    startExpanded = true,
    color = Color(0x33, 0x69, 0x1e),
    canSee = fp{fn.Id, true},
    sortOrder = 6,
}


TEAM_CITIZEN = TEAM_CITIZEN  or -1
TEAM_HOBO = TEAM_HOBO  or -1
TEAM_FISH = TEAM_FISH  or -1
TEAM_POLICE = TEAM_POLICE  or -1
TEAM_CHIEF = TEAM_CHIEF  or -1
TEAM_MAYOR = TEAM_MAYOR  or -1
TEAM_GANG = TEAM_GANG  or -1
TEAM_MOB = TEAM_MOB  or -1
TEAM_MERC = TEAM_MERC  or -1
TEAM_FIRE = TEAM_FIRE  or -1
TEAM_MEDIC = TEAM_MEDIC  or -1
TEAM_BUS = TEAM_BUS  or -1
TEAM_COOK = TEAM_COOK  or -1
--TEAM_TRADE = TEAM_TRADE  or -1
TEAM_TAXI = TEAM_TAXI  or -1
TEAM_GUN = TEAM_GUN  or -1
TEAM_SECURITY = TEAM_SECURITY  or -1
TEAM_CAR = TEAM_CAR  or -1

GAMEMODE.DefaultTeam = TEAM_CITIZEN

GAMEMODE.CivilProtection = {}
for team, job in pairs(RPExtraTeams) do
    if job.police then
        GAMEMODE.CivilProtection[team] = true
    end
end

DarkRP.createAgenda(DarkRP.getPhrase("agenda_cp"), {TEAM_CHIEF, TEAM_MAYOR}, {TEAM_POLICE})

DarkRP.createDemoteGroup("Police", {TEAM_POLICE, TEAM_CHIEF, TEAM_MAYOR})

GAMEMODE:AddGroupChat(FindMetaTable("Player").isCP)
GAMEMODE:AddGroupChat(TEAM_FISH)
GAMEMODE:AddGroupChat(TEAM_MEDIC, TEAM_FIRE)
GAMEMODE:AddGroupChat(TEAM_TAXI)

local cp = {}
for k, v in pairs(GAMEMODE.CivilProtection) do
    if v then
        table.insert(cp, k)
    end
end

AddDoorGroup(DarkRP.getPhrase("door_cp"), unpack(cp))

-- always have these in case something breaks
AddDoorGroup("Les forces de l'ordre", unpack(cp))
AddDoorGroup("Law Enforcement", unpack(cp))

--DarkRP.addHitmanTeam(TEAM_MOB)
--DarkRP.addHitmanTeam(TEAM_MERC)

function maxpolice()
    local n = 0
    for k, v in pairs(GAMEMODE.CivilProtection) do
        if v and not RPExtraTeams[k].mayor then
            n = n + RPExtraTeams[k].max
        end
    end
    return n
end

GAMEMODE.Config.minHitPriceJob = {
    [TEAM_GANG] = 1500,
    [TEAM_MOB] = 3000,
    [TEAM_POLICE] = 2500,
    [TEAM_CHIEF] = 5000,
    [TEAM_MAYOR] = 10000,
}
