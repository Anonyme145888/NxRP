local GAMEMODE = GM or GAMEMODE

GM.Config.elections = {
    termTime = 45 * 60,
    maxPerDay = 3,
    fastVotes = false
}

GM.Config.elections.registrationTime = GM.Config.elections.fastVotes and 5 or 2 * 60
GM.Config.elections.votingTime = GM.Config.elections.fastVotes and 20 or 2 * 60
GM.Config.elections.shortVotingTime = GM.Config.elections.fastVotes and 10 or 1 * 60
GM.Config.elections.botsVote = false
GM.Config.elections.botsRegister = false

GM.Config.cars = true
GM.Config.sellk = 0.5
GM.Config.paintprice = 1500
GM.Config.partsprice = 15000
GM.Config.car_lods = true
GM.Config.shipmentspawntime = 5

GM.Config.locale = nxserv.region_lang

GM.Config.joblimitmul = 1

if GM.Config.locale == "fr" then
    GM.Config.joblimitmul = 2
end

GM.Config.printerServiceEnabled = true
GM.Config.Winter = false
GM.Config.halloween = false
GM.Config.mediaPlayerEnabled = true
GM.Config.printerOnlyGangsters = false
GM.Config.classicPrinterDuration = true

-- Halloween

GM.Config.zombieReward = 50
GM.Config.antlionReward = 400
GM.Config.carkillReduction = 0.25

--[[-------------------------------------------------------------------------
Hitmenu module
---------------------------------------------------------------------------]]
-- The minimum price for a hit
GM.Config.minHitPrice = 1000
-- The maximum price for a hit
GM.Config.maxHitPrice = 50000

GM.Config.minHitPriceJob = {}

--[[-------------------------------------------------------------------------
Hungermod module
---------------------------------------------------------------------------]]
GM.Config.hunger = true

GM.StockSettings = {}
GM.StockSettings.money_printer_package = {
    maxstock = 2,
    restock = 30 * 60,
}
GM.StockSettings.life = {
    maxstock = 2,
    restock = 10 * 60,
    networked = true,
}
GM.StockSettings.mayor_limit = {
    maxstock = GM.Config.elections.maxPerDay,
    restock = math.Round(24 / GM.Config.elections.maxPerDay * 60 * 60),
    networked = true,
}
GM.StockSettings.demote = {
    maxstock = 1,
    restock = 5 * 60,
}

GM.Config.gangMinMembers = 2
GM.Config.busClass = "bustdm"


-- allowrpnames - Allow Players to Set their RP names using the /rpname command.
GM.Config.allowrpnames                  = true
-- allowvnocollide - Enable/disable the ability to no-collide a vehicle (for security).
GM.Config.allowvnocollide               = false
-- babygod - people spawn godded (prevent spawn killing)
GM.Config.babygod                       = true
-- canforcedooropen - whether players can force an unownable door open with lockpick or battering ram or w/e
GM.Config.canforcedooropen              = true
-- chatsounds - sounds are played when some things are said in chat
GM.Config.chatsounds                    = true
-- customjobs - Enable/disable the /job command (personalized job names).
GM.Config.customjobs                    = true
-- showdeaths - Display kill information in the upper right corner of everyone's screen.
GM.Config.showdeaths                    = false
-- detective_dna_time
GM.Config.detective_dna_time            = 4 * 60
-- detective_stay_time
GM.Config.detective_stay_time           = 8 * 60
-- doorwarrants - Enable/disable Warrant requirement to enter property.
GM.Config.doorwarrants                  = true
-- droppocketarrest - Enable/disable whether people drop the stuff in their pockets when they get arrested.
GM.Config.droppocketarrest              = true
-- droppocketdeath - Enable/disable whether people drop the stuff in their pockets when they die.
GM.Config.droppocketdeath               = true
-- dropweapondeath - Enable/disable whether people drop their current weapon when they die.
GM.Config.dropweapondeath               = false
-- enforceplayermodel - Whether or not to force players to use their role-defined character models.
GM.Config.enforceplayermodel            = true
-- letters - Enable/disable letter writing / typing.
GM.Config.letters                       = true
-- lockdown - Enable/Disable initiating lockdowns for mayors.
GM.Config.lockdown                      = true
--- lockpickfading - Enable/disable the lockpicking of fading doors
GM.Config.lockpickfading                = true
--
GM.Config.losemoneyondeath              = true
-- lottery - Enable/disable creating lotteries for mayors
GAMEMODE.Config.lottery                       = true
-- mayor_danger_time
GM.Config.mayor_danger_time             = 10 * 60
GM.Config.mayor_danger_time_increase    = 5 * 60
-- needwantedforarrest - Enable/disable Cops can only arrest wanted people.
GM.Config.needwantedforarrest           = false
-- norespawn - Enable/Disable that people don't have to respawn when they change job.
GM.Config.norespawn                     = true
-- npcarrest - Enable/disable arresting npc's
GM.Config.npcarrest                     = false
-- propertytax - Enable/disable property tax.
GM.Config.propertytax                   = true
-- proppaying - Whether or not players should pay for spawning props.
GM.Config.proppaying                    = false
-- propspawning - Enable/disable props spawning for non-admins.
GM.Config.propspawning                  = true
-- respawninjail - Enable/disable whether people can respawn in jail when they die
GM.Config.respawninjail                 = true
-- restrictdrop - Enable/disable restricting the weapons players can drop. Setting this to true disallows weapons from shipments from being dropped
GM.Config.restrictdrop                  = false
-- shouldResetLaws - Enable/Disable resetting the laws back to the default law set when the mayor changes
GM.Config.shouldResetLaws               = true
--
GM.Config.stripweaponsonjobchange       = false
-- telefromjail - Enable/disable teleporting from jail.
GM.Config.telefromjail                  = true
-- teletojail - Enable/disable teleporting to jail.
GM.Config.teletojail                    = true
-- unlockdoorsonstart - Enable/Disable unlocking all doors on map start.
GM.Config.unlockdoorsonstart            = false

GM.Config.realisticfalldamage           = true

GM.Config.decaltimer                    = 120

--[[
Value settings
--]]
-- adminnpcs - Whether or not NPCs should be admin only. 0 = everyone, 1 = admin or higher, 2 = superadmin or higher, 3 = rcon only
GM.Config.adminnpcs                     = 2
-- adminsents - Whether or not SENTs should be admin only. 0 = everyone, 1 = admin or higher, 2 = superadmin or higher, 3 = rcon only
GM.Config.adminsents                    = 2
-- adminvehicles - Whether or not vehicles should be admin only. 0 = everyone, 1 = admin or higher, 2 = superadmin or higher, 3 = rcon only
GM.Config.adminvehicles                 = 2
-- babygodtime - How long the babygod lasts
GM.Config.babygodtime                   = 5
-- changejobtime - Minimum amount of seconds a player has to wait before changing job.
GM.Config.changejobtime                 = 60 * 4
-- chatsoundsdelay - How long to wait before letting a player emit a sound from their chat again.
-- Leave this on at least a few seconds to prevent people from spamming sounds. Set to 0 to disable.
GM.Config.chatsoundsdelay               = 1
-- demotetime - Number of seconds before a player can rejoin a team after demotion from that team.
GM.Config.demotetime                    = 10 * 60
-- doorcost - Sets the cost of a door.
GM.Config.doorcost                      = 50
GM.Config.entremovedelay                = 0
-- jailtimer - Sets the jailtimer. (in seconds)
GM.Config.jailtimer                     = 240
-- lockdowndelay - The amount of time a mayor must wait before starting the next lockdown
GM.Config.lockdowndelay                 = 120
-- maxdoors - Sets the max amount of doors one can own.
GM.Config.maxdoors                      = 28
-- maxfoods - Sets the max food cartons per Microwave owner.
GM.Config.maxfoods                      = 16
-- maxletters - Sets max letters.
GM.Config.maxletters                    = 10
-- maxlotterycost - Maximum payment the mayor can set to join a lottery.
GM.Config.maxlotterycost                = 100000
-- maxvehicles - Sets how many vehicles one can buy.
GM.Config.maxvehicles                   = 5
-- microwavefoodcost - Sets the sale price of Microwave Food.
GM.Config.microwavefoodcost             = 400
-- minlotterycost - Minimum payment the mayor can set to join a lottery.
GM.Config.minlotterycost                = 30
-- Money packets will get removed if they don't get picked up after a while. Set to 0 to disable
GM.Config.moneyRemoveTime               = 0
-- namechange_cooldown
GM.Config.namechange_cooldown           = 60 * 60 * 24 * 3
-- normalsalary - Sets the starting salary for newly joined players.
GM.Config.normalsalary                  = 45
-- npckillpay - Sets the money given for each NPC kill.
GM.Config.npckillpay                    = 0
-- paydelay - Sets how long it takes before people get salary
GM.Config.paydelay                      = 180
-- pocketitems - Sets the amount of objects the pocket can carry
GM.Config.pocketitems                   = 10
--
GM.Config.policeres_cost_warrant = 3
--
GM.Config.policeres_cost_weaponsearch = 1
--
GM.Config.printercost = 8000
-- propcost - How much prop spawning should cost. (prop paying must be enabled for this to have an effect)
GM.Config.propcost                      = 10
-- respawntime - Minimum amount of seconds a player has to wait before respawning.
GM.Config.respawntime                   = 40
-- searchtime - Number of seconds for which a search warrant is valid.
GM.Config.searchtime                    = 60 * 10
-- speedlimit_min
GM.Config.speedlimit_min                = 55
-- speedlimit_max
GM.Config.speedlimit_max                = 200
-- startinghealth - the health when you spawn.
GM.Config.startinghealth                = 100
-- startingmoney - your wallet when you join for the first time.
GM.Config.startingmoney                 = 20000
-- vehiclecost - Sets the cost of a vehicle (To own it).
GM.Config.vehiclecost                   = 40
-- wantedtime - Number of seconds for which a player is wanted for.
GM.Config.wantedtime                    = 60 * 20

GM.Config.falldamagedamper              = 15
GM.Config.falldamageamount              = 35

-- walkspeed - Sets the max walking speed.
GM.Config.walkspeed                     = 180
GM.Config.slowwalkspeed                 = 350
-- runspeed - Sets the max running speed.
GM.Config.runspeed                      = 350
GM.Config.runspeedcp                    = 350
-- arrestspeed - Sets the max speed for arrested players.
GM.Config.arrestspeed                   = 120

GM.Config.talkDistance    = 250
GM.Config.whisperDistance = 90
GM.Config.yellDistance    = 550
GM.Config.meDistance      = 250
GM.Config.voiceDistance   = 550

GM.Config.taxiPriceRange = {200, 1000}
GM.Config.shopProfitRange = {15, 75}

GM.Config.maxShopResources = 2000
GM.Config.averageCannabisPrice = 400

GM.Config.minHitPrice = 1000
GM.Config.maxHitPrice = 150000
GM.Config.minHitDistance = 150
GM.Config.hudText = "Appuyez sur E pour ordonner une mise à mort"
GM.Config.hitmanText = "Commande Acceptée"
GM.Config.hitTargetCooldown = 60
GM.Config.hitCustomerCooldown = 150

GM.Config.MoneyClass = "spawned_money"
GM.Config.moneyModel = "models/props/cs_assault/money.mdl"
GM.Config.lockdownsound = "gxrp/lockdown_fr.ogg"
GM.Config.DarkRPSkin = "DarkRP"
GM.Config.currency = "gc"
GM.Config.chatCommandPrefix = ""
GM.Config.RulesURL = "https://gxserv.eu/help/rules/legacy/darkrp?lng=" .. GM.Config.locale
GM.Config.F1MenuHelpPage = ""
GM.Config.F1MenuHelpPageTitle = ""
GM.Config.DefaultPlayerGroups = {}
GM.Config.DisabledCustomModules = {}

GM.Config.DisallowDrop = {
    arrest_stick = true,
    door_ram = true,
    fun_vac = true,
    gmod_camera = true,
    gmod_tool = true,
    hands = true,
    keys = true,
    pocket = true,
    weapon_keypadchecker = true,
    weapon_physcannon = true,
    weapon_physgun = true,
    weaponchecker = true,
    zck_snowballswep = true,
    weapon_popcorn = true,
}

GM.Config.JailEscapeWeaponIgnore = {
    deployable_tool = true,
    nx_radio = true,
    zck_snowballswep = true,
    weapon_popcorn = true,
}

-- The list of weapons people spawn with
GM.Config.DefaultWeapons = {
    "weapon_physcannon",
    "weapon_physgun",
    "keys",
    "gmod_camera",
    "selfie_camera",
    "gmod_tool",
}

GM.Config.CategoryOverride = {
    jobs = {},
    entities = {},
    shipments = {},
    weapons = {},
    vehicles = {},
    ammo = {}
}

GM.Config.preventClassItemRemoval = {
    ["gunlab"] = false,
    ["microwave"] = false,
    ["spawned_shipment"] = false
}

--GM.Config.AdminWeapons = {}

local laws = {
    en = {
        "Intentional and unintentional murder, causing harm to citizens (except self-defence) and holding locked up against their will is punishable.",
        "It is forbidden to steal and break into people's homes, spoil private and city property, throw clumps of dirt.",
        "Money printers are illegal and must be destroyed. Citizen caught in keeping or carrying printers is subject to arrest, independently from printer's owner.",
        "Carrying and keeping, selling and distribution of weaponry requires license.",
        "It is forbidden to carry weaponry openly in public, even with license.",
        "Production, storage and sale of drugs is prohibited.",
        "Multiple or severe insulting of the forces of law and order is a violation of the law.",
        "Harboring criminals and wanted is a crime.",
        "Trespassing into government establishments is punishable by arrest.",
        "Police can use lethal weapons only when lives of citizens or police officers is at threat.",
        "During the curfew citizens (except city services) must reach their homes and stay inside, unless it's said otherwise during announcement.",
        "Prison escape is punishable by arrest for second term.",
        "The mayor and Police Officers aren't allowed to practice any illegal activity or to participate in criminal groups. Any violator should be kicked from Police and be prosecuted.",
    },
    ru = {
        "Умышленное и неумышленное убийство, причинение вреда гражданам (кроме самообороны) и удержание взаперти против их воли наказуемо.",
        "Запрещено воровать и вламываться в чужие дома, портить частное и городское имущество, кидаться грязью.",
        "Денежные принтеры запрещены и подлежат уничтожению. Гражданин, хранящий или переносящий принтеры, подлежит аресту, вне зависимости от владельца принтера.",
        "Ношение, хранение, продажа, сбыт, применение оружия требуют лицензии.",
        "Запрещается открытое ношение оружия в общественных местах, даже при наличии лицензии.",
        "Производство, хранение и сбыт наркотиков запрещены.",
        "Жесткое или многократное оскорбление сил правопорядка или власти является нарушением закона.",
        "Укрывательство преступников и разыскиваемых является преступлением.",
        "Проникновение в государственные учреждения дальше запрещающей таблички карается арестом.",
        "Полиция может применять летальное оружие только при угрозе для жизни сотрудника полиции или граждан.",
        "Во время комендантского часа граждане (кроме городских служб) обязаны прибыть в свои дома и не покидать их, если иное не указано в пояснении к комендантскому часу.",
        "Сбежавший из тюрьмы заключённый подлежит аресту на повторный срок.",
        "Мэру и Офицерам Полиции запрещается заниматься любой нелегальной деятельностью или участвовать в организованных преступных группировках. Любой провинившийся подлежит увольнению и наказанию.",
    },
    fr = {
        "Les homicides, volontaires, involontaires perturbants l'ordre public (sauf légitime défense) et enfermer des citoyens dans un bâtiment sont interdits.",
        "Il est interdit de voler et de s'introduire chez autrui et de détériorer les bâtiments publics et privés et de les salir avec de la terre.",
        "Les imprimantes à argent sont illégales et doivent être détruites. Les citoyens surpris en possession ou en transport de ces dernières sont sujets à être arrêtés, même s'ils ne sont pas les propriétaires de ces dernières.",
        "La port, la possession, la vente et la distribution d'armes nécessitent une licence d'armes.",
        "Il est interdit de sortir une arme en public, même avec une licence.",
        "La production, le stockage et la vente de drogues sont interdits.",
        "Insulter aux forces de l'ordre est un délit.",
        "Héberger des criminels et des citoyens recherchés est interdit.",
        "Pénétrer dans un bâtiment gouvernemental sans autorisation est passible d'une arrestation.",
        "La Police peut utiliser des armes létales uniquement si la vie d'autrui est en danger.",
        "Durant le couvre-feu (sauf les services de la ville) les citoyens doivent rentrer chez eux et rester à l'intérieur, sauf exceptions données par les forces de l'ordre.",
        "L'évasion de prison est passible d'une seconde arrestation.",
        "Le maire et les policiers ne sont pas autorisés à pratiquer des activités illégales et criminelles.  Any violator should be kicked from Police and be prosecuted.",
        -- Ils ne peuvent par exemple pas s'allier à un groupe de gangsters et utiliser des imprimantes avec eux.
    }
}
GM.Config.DefaultLaws = laws[GM.Config.locale] or laws.en

GM.Config.PocketBlacklist = {
    ["fadmin_jail"] = true,
    ["meteor"] = true,
    ["door"] = true,
    ["func_"] = true,
    ["player"] = true,
    ["beam"] = true,
    ["worldspawn"] = true,
    ["env_"] = true,
    ["path_"] = true,
    ["prop_physics"] = true,
    ["gunlab"] = true,
    ["prop_dynamic"] = true,
    ["prop_vehicle_prisoner_pod"] = true,
    ["keypad_wire"] = true,
    ["gmod_button"] = true,
    ["gmod_rtcameraprop"] = true,
    ["gmod_cameraprop"] = true,
    ["gmod_dynamite"] = true,
    ["gmod_thruster"] = true,
    ["gmod_light"] = true,
    ["gmod_lamp"] = true,
    ["gmod_emitter"] = true,
    ["keypad"] = true,
    ["item_suitcharger"] = true,
    ["item_healthcharger"] = true,
    ["microwave"] = true,
    ["ge_armor"] = true,
    ["plant_c4"] = true,
    ["skynet_atm"] = true,
    ["drinkmachine"] = true,
    ["mediaplayer_tv"] = true, 
    ["minimap_bank"] = true,
    ["minimap_cook"] = true, 
    ["minimap_gun"] = true, 
    ["minimap_mechanic"] = true, 
    ["minimap_medic"] = true,
    ["minimap_trader"] = true,
    ["p_weaponcenter"] = true, 
    ["p_healthcenter"] = true,
    ["p_ammocenter"] = true,
    ["bodypillow"] = true,
    ["great_gift"] = true,
    ["great_npc_base"] = true,
    ["skynet_npc_bubble"] = true,
    ["bm2_bitminer_1"] = true,
    ["bm2_bitminer_2"] = true,
    ["bm2_bitminer_rack"] = true,
    ["bm2_bitminer_server"] = true,
    ["bm2_extention_lead"] = true,
    ["bm2_fuel"] = true,
    ["bm2_generator"] = true,
    ["bm2_power_lead"] = true,
    ["drinkmachine"] = true,
    ["eml_buyer"] = true,
    ["eml_buyer_text"] = true,
    ["eml_gas"] = true,
    ["eml_iodine"] = true,
    ["eml_jar"] = true,
    ["eml_macid"] = true,
    ["eml_pot"] = true,
    ["eml_spot"] = true,
    ["eml_stove"] = true,
    ["eml_sulfur"] = true,
    ["eml_water"] = true,
    ["br_vault"] = true,
    ["health_station"] = true,
    ["br_money"] = true,
    ["br_money_case"] = true,
    ["armour_station"] = true,
    ["spawn_trash"] = true,
    ["keypad"] = true,
    ["vodkanpc"] = true,
    ["dumpster"] = true,
    ["vc_pickup_fuel_electricity"] = true,
    ["phone_box"] = true,
    ["ent_npcorg"] = true,
    ["greatrp_atm"] = true,
    ["great_npc_base"] = true,
    ["boxbuy"] = true,
    ["box"] = true,
    ["cm_coffemachine"] = true,
    ["money_printer"] = true,
    ["money_printer_premium"] = true,
    ["sent_soccerball"] = true,
    ["ent_jack_job_plantlamp"] = true,

    ["trampoline"] = true
}

GM.restrictions = {
	tools = {
		"transfer",

		"axis",
		"ballsocket",
		"constraintinfo",
		"elastic",
		"hydraulic",
		"motor",
		"muscle",
		"nocollide",
		"pulley",
		"rope",
		"slider",
		"weld",
		"winch",

		"wire_clutch",
		"wire_freezer",
		"wire_grabber",
		"wire_hydraulic",
		"wire_latch",
		"wire_nailer",
		"wire_speedometer",
		"wire_weight",

		"advdupe2",
		"balloon",
		"duplicator",
		"dynamite",
		"emitter",
		"hoverball",
		"lamp",
		"paint",
		"permaprops",
		"poly",
		"prop_door",
		"rt_buoyancy",
		"smart_freezer",
		"thruster",
		"total_mass",
		"trails",
		"turret",
		"weld_remover",
		"weight",
		"wheel",

		"eyeposer",
		"faceposer",
		"finger",
		"inflator",

		"wire_moneydetector",
		"wire_moneydetectorranger",

		"wire_cam",
		"wire_colorer",
		"wire_detonator",
		"wire_door",
		"wire_door_controller",
		"wire_exit_point",
		"wire_explosive",
		"wire_forcer",
		"wire_fx_emitter",
		"wire_gpulib_switcher",
		"wire_holoemitter",
		"wire_hologrid",
		"wire_hoverball",
		"wire_igniter",
		"wire_lamp",
		"wire_lever",
		"wire_light",
		"wire_motor",
		"wire_simple_explosive",
		"wire_spu",
		"wire_target_finder",
		"wire_teleporter",
		"wire_textreceiver",
		"wire_thruster",
		"wire_trail",
		"wire_turret",
		"wire_vthruster",
		"wire_wheel",

		"Admin_Cleanup",
		"Falco's prop protection admin settings",
		"WireE2Extensions",
	},
	wiregates = {
		"entity_aimentity",
		"entity_applyaf",
		"entity_applyf",
		"entity_applyof",
		"entity_applytorq",
		"entity_id2ent",
		"rd_distance",
		"rd_entity",
		"rd_hit",
		"rd_hitnorm",
		"rd_hitpos",
		"rd_hitworld",
		"rd_trace",
	},
	e2functions = {
		"aimEntity",
		"apply",
		"entity%(n%)",
		"^eyeTrace",
		"find.+%([^:]+%)",
		"holo",
		"httpRequest",
		"killPod",
		"^npc",
		"players",
		"prop",
		"^ranger",
		"reposition",
		"rerotate",
		"set.+%(e:",
		"Trails$",
		"^use",
	},
	models = {
		"models/cubemaps/cubemap_sheen_dome2.mdl",
		"models/fishy/furniture/piano.mdl",
		"models/grinchfox/construction/pdwindow.mdl",
		"models/grinchfox/rp/fertbag.mdl",
		"models/grinchfox/rp/frame.mdl",
		"models/grinchfox/rp/itemshop.mdl",
		"models/grinchfox/rp/orangetree.mdl",
		"models/grinchfox/rp/pot.mdl",
		"models/grinchfox/rp/printer2.mdl",
		"models/grinchfox/rp/weed.mdl",
		"models/grinchfox/turret.mdl",
		"models/healthvial.mdl",
		"models/hunter/blocks/cube8x8x8.mdl",
		"models/Items/battery.mdl",
		"models/items/boxmrounds.mdl",
		"models/map_props/rdc.mdl",
		"models/nxserv/cinema_screen.mdl",
		"models/props/cs_militia/bathroomwallhole01_wood_broken.mdl",
		"models/props/de_prodigy/wall_console3.mdl",
		"models/props/de_tides/gate_large.mdl",
		"models/props_borealis/mooring_cleat01.mdl",
		"models/props_buildings/collapsedbuilding01a.mdl",
		"models/props_c17/gravestone_coffinpiece001a.mdl",
		"models/props_c17/gravestone_coffinpiece002a.mdl",
		"models/props_combine/combinecamera001.mdl", -- prop spawns unfrozen for some reason, without any errors produced
		"models/props_combine/combine_citadel001.mdl",
		"models/props_combine/health_charger001.mdl",
		"models/props_combine/portalskydome.mdl",
		"models/props_combine/suit_charger001.mdl",
		"models/props_combine/weaponstripper.mdl",
		"models/props_mvm/dome_roof.mdl",
		"models/props_unique/showercurtain01.mdl",
		"models/props_wasteland/medbridge_base01.mdl",
		"models/weapons/w_c4.mdl",
		"models/weapons/w_c4_planted.mdl",
	},
	effects = {
		"models/breen_monitor.mdl",
	},
	dupes = {
		"cashdesk",
		"fishing_mod_catch_cosmogram",
		"food_shipment",
		"gmod_duplicator",
		"gmod_dynamite",
		"gmod_hoverball",
		"gmod_lamp",
		"gmod_playx_proximity",
		"gmod_rope",
		"gmod_thruster",
		"gmod_turret",
		"gmod_wheel",
		"gmod_wire_cam",
		"gmod_wire_colorer",
		"gmod_wire_detonator",
		"gmod_wire_explosive",
		"gmod_wire_forcer",
		"gmod_wire_gpulib_controller",
		"gmod_wire_holoemitter",
		"gmod_wire_hoverball",
		"gmod_wire_igniter",
		"gmod_wire_light",
		"gmod_wire_motor",
		"gmod_wire_simple_explosive",
		"gmod_wire_spu",
		"gmod_wire_target_finder",
		"gmod_wire_teleporter",
		"gmod_wire_thruster",
		"gmod_wire_turret",
		"gmod_wire_vthruster",
		"gmod_wire_wheel",
		"gmt_instrument_piano",
		"mediaplayer_tv",
		"money_printer",
		"money_printer_package",
		"npc_cashier",
		"npc_dealer",
		"npc_mike",
		"phys_torque",
		"prop_vehicle_jeep",
		"prop_vehicle_jeep_old",
		"sent_helicopter_nonadmin",
		"sent_sakariashelicopter",
		"spawned_ammo",
		"spawned_food",
		"spawned_money",
		"spawned_shipment",
		"spawned_weapon",
		"throw_molotov",
	},
	sounds = {
		"c4.click",
		"c4.disarmfinish",
		"c4.disarmstart",
		"c4.explode",
		"c4.plant",
		"c4.plantsound",
		"gxrp/interruptone.ogg",
		"gxrp/recyclerop.ogg",
		"plats/elevator_stop1.wav",
		"weapons/c4/c4_beep1.wav",
		"weapons/c4/c4_explode1.wav",
		"weapons/c4/c4_plant.wav",
	},
}

GM.Config.AdminWeapons = {}
GM.Config.noStripWeapons = {}

GM.Config.preventClassItemRemoval = {
    ["gunlab"] = false,
    ["microwave"] = false,
    ["spawned_shipment"] = false
}

-- Properties set to true are allowed to be used. Values set to false or are missing from this list are blocked.
GM.Config.allowedProperties = {
    remover = true,
    ignite = false,
    extinguish = true,
    keepupright = true,
    gravity = true,
    collision = true,
    skin = true,
    bodygroups = true,
    photon_siren = false,
    photon_liveries = false,
    photon_autoskin = false,
    photon_licenseplates = false,
    photon_preset = false,
    photon_selection = false,
    photon_configuration = false,
}


GM.Config.hideNonBuyable = false
GM.Config.hideTeamUnbuyable = true
GM.Config.hungerspeed = 0.8
GM.Config.starverate = 1