--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/preautorun/nxlocale_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

nxlocale = {}

nxlocale.directory = {}

--local langUserInfo = CreateConVar("_nxgml", "en", FCVAR_USERINFO)

nxlocale.getLanguage = function()
	return string.lower(SERVER and server and server.region.lang or GetConVarString("gmod_language") or "")
end

--langUserInfo:SetString(nxlocale.getLanguage())

-- TODO: flatten all keys in directory and don't do this shit
nxlocale.translate = function(key)
	local path = key:Split(".")

	local it
	function it(path, branch)
		local value = table.remove(path, 1)
		if #path == 0 then
			return branch and branch[value] or key
		else
			return branch and branch[value] and it(path, branch[value]) or key
		end
	end

	return it(path, nxlocale.directory)
end

_G.Translate = nxlocale.translate

local function scan(piece, lng)
	local t = {}

	for keyname, content in pairs(piece) do
		--if not istable(content) then continue end
		local fk, fv = next(content)

		if istable(fv) and #fv == 0 then
			t[keyname] = scan(content, lng)
		else
			t[keyname] = content[lng] or content.en or fv
		end
	end

	return t
end

local function doload()
	for _, f in SortedPairs(file.Find("nxlocale/*.lua", "LUA"), true) do
		local piece = include("nxlocale/" .. f)
		if not piece then continue end
		AddCSLuaFile("nxlocale/" .. f)

		local name = string.GetFileFromFilename(f):Left(-5)
		local lng = nxlocale.getLanguage()

		nxlocale.directory[name] = scan(piece, lng)
	end
end

nxlocale.doload = doload

nxlocale.getSpecificLngTable = function(name, lang)
	local piece = include("nxlocale/" .. name .. ".lua")
	return scan(piece, lang)
end

function nxlocale.reload()
	doload()
	--langUserInfo:SetString(nxlocale.getLanguage())
	hook.Run("LocaleChanged", nxlocale.getLanguage())
end

nxlocale.reload()

cvars.AddChangeCallback("gmod_language", function(name, old, new)
	nxlocale.reload()
end, "nxlocale")


-- Auto Tests...
assert(isstring(Translate("esc.resume")))
assert(isfunction(nxlocale.getSpecificLngTable))
