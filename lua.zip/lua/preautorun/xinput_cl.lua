xinput = xinput or {}

xinput.kbLayout = "default"

xinput.translations = {
	azerty = {
		[KEY_Q] = KEY_A,
		[KEY_W] = KEY_Z,
		[KEY_A] = KEY_Q,
		[KEY_Z] = KEY_W,
	},
}

function xinput.shouldShuggestLayoutCheck()
	--return server.lang == "fr"
	return true
end

xinput.binds = xinput.binds or {}
xinput.hooks = xinput.hooks or {}
xinput.hooks_registry = xinput.hooks_registry or {}

function xinput.bind(defaultKey, action, fn, priority)
	xinput.binds[defaultKey] = {
		action = action,
		fn = fn,
		priority = priority,
	}
end

function xinput.hook(inEnum, action, fn)
	xinput.hooks[inEnum] = xinput.hooks[inEnum] or {}
	local compositeKey = action .. "-" .. inEnum
	if xinput.hooks_registry[compositeKey] then
		table.remove(xinput.hooks[inEnum], xinput.hooks_registry[compositeKey])
	end
	xinput.hooks_registry[compositeKey] = table.insert(xinput.hooks[inEnum], {action, fn})
end

local bind2in = {
	["+attack"] = IN_ATTACK,
	["+attack2"] = IN_ATTACK2,
	["+reload"] = IN_RELOAD,
	["+use"] = IN_USE,
}

local trapped = {}

hook.Add("PlayerBindPress", "xinput", function(_, bind, pressed, keycode)
	if IsValid(LocalPlayer().Instrument) then
		return
	end

	local xbind = xinput.binds[keycode]
	if xbind and pressed then
		--print("BIND")
		trapped[keycode] = true
		if xbind.fn(keycode, bind) then
			return true
		end
	end

	local inEnum = bind2in[bind]
	if inEnum and xinput.hooks[inEnum] and pressed then
		for i, v in ipairs(xinput.hooks[inEnum]) do
			local action, fn = unpack(v)
			if fn(inEnum) then
				return true
			end
		end
	end
end)

hook.Add("Think", "xinput", function()
	local busy = gui.IsGameUIVisible() or IsValid(vgui.GetKeyboardFocus()) or IsValid(LocalPlayer().Instrument)

	for keycode, xbind in pairs(xinput.binds) do
		if busy and not xbind.priority then continue end

		if input.IsButtonDown(keycode) then
			if not trapped[keycode] then
				--print("TRP")
				xbind.fn(keycode)
				trapped[keycode] = true
			end
		else
			trapped[keycode] = false
		end
	end
end)

concommand.Add("nx_binds", function()
	print("binds:")
	for button, bind in pairs(xinput.binds) do
		print(input.GetKeyName(button):upper(), bind.action)
	end
	print("hooks:")
	for inEnum, hooks in pairs(xinput.hooks) do
		print(inEnum .. ":")
		for i, v in ipairs(hooks) do
			print("\t" .. v[1])
		end
	end
end)
