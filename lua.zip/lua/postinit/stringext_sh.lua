--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/postinit/stringext_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

-- Unicode (str:u...())

if SERVER then
	AddCSLuaFile("postinit/utf8.lua")
end
include("postinit/utf8.lua")

function string:uvalid()
	return string.utf8len(self) and true or false
end

function string:uforce()
	return utf8.force(self) -- does not replace all possible errors; todo: replace with a properly working implementation
end

function string:ulen()
	return string.utf8len(self)
end

-- stops counting at max+1
function string:ulenlimit(max)
	return string.utf8lenlimit(self, max)
end

function string:ulonger(max)
	return #self > max * 4 or self:ulenlimit(max) > max
end

function string:usub(n1, n2)
	return string.utf8sub(self, n1, n2)
end

function string:uLeft(n)
	return self:usub(1, n)
end

function string:uRight(n)
	return self:usub(-n)
end

function string:ulower()
	return string.utf8lower(self)
end

function string:uupper()
	return string.utf8upper(self)
end

-- use this for capitalization, more language-specific correctness than upper
function string:utitlecase()
	return self:uupper() -- same as uupper for now, proper implementation later
end

-- use this to case-indifferently compare texts, more language-specific correctness than lower
function string:ucasefold()
	return self:ulower() -- same as ulower for now, proper implementation later
end

function string:uCapitalize()
	return self:uLeft(1):utitlecase() .. self:usub(2)
end

function net.ReadStringU()
	return net.ReadString():uforce()
end


-- like String:Left(bytes), but makes sure not to cut off UTF sequences
function string:ByteTrim(bytes)
	if #self <= bytes then
		return self
	end

	return self:Left(utf8.offset(self, 0, bytes + 1) - 1)
end

-- https://gist.github.com/Badgerati/3261142
function string.Levenshtein(str1, str2)
	local len1 = #str1
	local len2 = #str2

	-- quick cut-offs to save time
	if len1 == 0 then
		return len2
	elseif len2 == 0 then
		return len1
	elseif str1 == str2 then
		return 0
	end

	local matrix = {}
	local cost

	-- initialise the base matrix values
	for i = 0, len1 do
		matrix[i] = {}
		matrix[i][0] = i
	end
	for j = 0, len2 do
		matrix[0][j] = j
	end

	-- actual Levenshtein algorithm
	for i = 1, len1 do
		for j = 1, len2 do
			if str1[i] == str2[j] then
				cost = 0
			else
				cost = 1
			end

			matrix[i][j] = math.min(matrix[i-1][j] + 1, matrix[i][j-1] + 1, matrix[i-1][j-1] + cost)
		end
	end

	-- return the last value - this is the Levenshtein distance
	return matrix[len1][len2]
end
