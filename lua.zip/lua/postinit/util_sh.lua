--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/postinit/util_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function table.iEmpty(tab)
	for k, v in ipairs(tab) do
		tab[k] = nil
	end
end

function table.iHasValue(t, val)
	for k, v in ipairs(t) do
		if v == val then return true end
	end
	return false
end

function table.iKeyFromValue(tbl, val)
	for key, value in ipairs(tbl) do
		if value == val then return key end
	end
end

function table.iRemoveByValue(tbl, val)
	local key = table.iKeyFromValue(tbl, val)
	if not key then return false end

	table.remove(tbl, key)
	return key
end

function table.KeyByMember(tbl, key, value)
	for k, v in pairs(tbl) do
		if v[key] == value then
			return k
		end
	end
end
function table.iKeyByMember(tbl, key, value)
	for k, v in ipairs(tbl) do
		if v[key] == value then
			return k
		end
	end
end

function table.filter(input, test)
	local result = {}
	for _, v in ipairs(input) do
		if test(v) then
			table.insert(result, v)
		end
	end
	return result
end

function table.iRandom(tbl)
	local k = math.random(#tbl)
	return tbl[k], k
end

function table.Shuffle(tbl)
	for k1 = #tbl, 2, -1 do
		local k2 = math.random(k1)
		tbl[k1], tbl[k2] = tbl[k2], tbl[k1]
	end
end

function table.WeightedRandom(choicesWeights) -- {{"Apples", 1}, {"Bananas", 2}, {"Oranges", 3}}
	local totalWeight = 0
	for i, choice in ipairs(choicesWeights) do
		totalWeight = totalWeight + choice[2]
	end

	local rand = math.random() * totalWeight

	for i, choice in ipairs(choicesWeights) do
		if rand < choice[2] then
			return choice[1], i
		else
			rand = rand - choice[2]
		end
	end
end

function table.WeightedRandomMul(choicesWeights, count)
	local ret = {}

	local copy = {}
	for i, v in ipairs(choicesWeights) do
		table.insert(copy, v)
	end

	for i = 1, count do
		local choice, choiceKey = table.WeightedRandom(copy)

		table.insert(ret, choice)
		table.remove(copy, choiceKey)
	end

	return ret
end

function table.CopyShallow(tab)
	local copy = {}

	for k, v in pairs(tab) do
		copy[k] = v
	end

	return copy
end

function table.iCopyShallow(tab)
	local copy = {}

	for i, v in ipairs(tab) do
		copy[i] = v
	end

	return copy
end

local function keyValuePairs(state)
	state.Index = state.Index + 1

	local keyValue = state.KeyValues[state.Index]
	if not keyValue then return end

	return keyValue.key, keyValue.val
end

local function toKeyValues(tbl)
	local result = {}

	for k, v in pairs(tbl) do
		table.insert(result, {key = k, val = v})
	end

	return result
end
local function toKeyValuesI(tbl)
	local result = {}

	for k, v in ipairs(tbl) do
		table.insert(result, v)
	end

	return result
end

-- way faster implementation of RandomPairs
function RandomPairs(pTable)
	local sortedTbl = toKeyValues(pTable)

	table.Shuffle(sortedTbl)

	return keyValuePairs, {Index = 0, KeyValues = sortedTbl}
end
function RandomIPairs(pTable)
	local sortedTbl = toKeyValuesI(pTable)

	table.Shuffle(sortedTbl)

	return ipairs(sortedTbl)
end


function chance(prob)
	return math.random() < prob
end


-- timer.Simple(0) работает, как ожидается, только первый раз в цепочке, дальше задержка на 1 тик перестаёт работать и всё вызывается в том же тике
TimerZeroSimple = TimerZeroSimple or timer.Simple
function timer.Simple(delay, func)
	delay = math.max(delay, 0.001)
	return TimerZeroSimple(delay, func)
end


nextid = class()

function nextid:constructor(start, max)
	self.start = start
	self.mod = max + 1 - start

	self.id = start - 1
end

function nextid:Next()
	self.id = (self.id + 1 - self.start) % self.mod + self.start
	return self.id
end

function nextid.meta.__call(self)
	return self:Next()
end


tnextid = class(nextid)

function tnextid:constructor(start, max, tbl)
	self:super(start, max)

	self.tbl = tbl or {}
end

function tnextid:Next()
	local start = self:super()
	while self.tbl[self.id] ~= nil do
		self:super()
		if self.id == start then
			error("Could not find a free ID")
		end
	end
	return self.id
end

function tnextid:Insert(value)
	local id = self:Next()
	self.tbl[id] = value
	return id
end


function bitmax(bits)
	return 2 ^ bits - 1
end


randstrUsed = randstrUsed or {}
local function randstrI(lenMin, lenMax)
	local result = {string.char(math.random(97, 122))}
	for n = 1, math.random(lenMin, lenMax) do
		local rchr = math.random(0, 2)

		if rchr == 0 then table.insert(result, string.char(math.random(48, 57)))
		elseif rchr == 1 then table.insert(result, string.char(math.random(65, 90)))
		elseif rchr == 2 then table.insert(result, string.char(math.random(97, 122)))
		end
	end

	return table.concat(result, "")
end
function randstr(lenMin, lenMax)
	local result

	repeat
		result = randstrI(lenMin, lenMax)
	until not table.iHasValue(randstrUsed, result)

	table.insert(randstrUsed, result)

	return result
end


function ShortDateToTime(d)
	return os.time({
		day = d % 100,
		month = math.floor(d/100) % 100,
		year = math.floor(d/10000) % 10000,
		hour = 12,
	})
end


WaitRunStatus = WaitRunStatus or {}

function WaitRunAdd(event)
	hook.Add(event, "WaitRun", function()
		WaitRunStatus[event] = true
	end)
end

function WaitRun(event, id, func)
	WaitRunAdd(event)

	hook.Add(event, id, func)

	if WaitRunStatus[event] then
		func()
	end
end
hook.AddRun = WaitRun

for event in ivalues{"Initialize", "InitPostEntity", "PostGamemodeLoaded"} do
	WaitRunAdd(event)
end


function ColorF(r, g, b, a)
	return Color(255 * r, 255 * g, 255 * b, 255 * (a or 1))
end


function NumC(num)
	if num ~= num then -- nan causes infinite cycle
		error("NaN")
	end

	if num == 0 then
		return "0"
	end

	local result = {}

	local n = math.abs(num)
	repeat
		table.insert(result, 1, n % 1000)
		n = math.floor(n / 1000)
	until n == 0

	result = table.concat(result, ",")

	if num < 0 then
		result = "-" .. result
	end

	return result
end


-- add `local delta = ThinkDelta(self)` at the top of your ENT:Think
function ThinkDelta(self)
	local curtime = CurTime()

	local LastThink = self.LastThink

	self.LastThink = curtime

	if LastThink then
		return curtime - LastThink
	else
		return 0
	end
end


local isalive = {
	function(pl)
		return pl:Alive()
	end,
	terrortown = function(pl)
		return pl:IsTerror()
	end,
}
hook.AddRun("Initialize", "GMIsAlive", function()
	GMIsAlive = isalive[GAMEMODE_NAME] or isalive[1]
end)


function meta.Entity:PushNoDraw(id)
	if not self.raynodraw then
		self.raynodraw = {}
	end
	self.raynodraw[id] = true
	self:SetNoDraw(true)
end
function meta.Entity:PopNoDraw(id)
	local raynodraw = self.raynodraw
	if raynodraw then
		raynodraw[id] = nil
		if not next(raynodraw) then
			self:SetNoDraw(false)
		end
	end
end


local cachecache = util.PlayerCacheCache or setmetatable({}, {__mode = "k"})
util.PlayerCacheCache = cachecache

function util.PlayerCache()
	local cache = setmetatable({}, {__mode = "k"})
	cachecache[cache] = true
	return cache
end

hook.Add("PlayerDisconnected", "utilPlayerCache", function(pl)
	for cache in pairs(cachecache) do
		cache[pl] = nil
	end
end)
