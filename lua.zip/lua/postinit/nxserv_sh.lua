--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/postinit/nxserv_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

server = {
	region = {
		area = "ru",
		lang = "ru",
		shop = "ru",
	},
}

if file.Exists("gserv-settings.lua", "LUA") then
	local data = include("gserv-settings.lua")
	if data then
		table.Merge(server, data)
	end
	if SERVER then
		AddCSLuaFile("gserv-settings.lua")

		if file.Exists("gserv-settings-sv.lua", "LUA") then
			local data = include("gserv-settings-sv.lua")
			if data then
				table.Merge(server, data)
			end
		end
	end
end

nxserv = {}

nxserv.region_area = server.region.area
nxserv.region_lang = server.region.lang
nxserv.region_shop = server.region.shop

nxserv.geoip_whitelist = {
	ru = {"Azerbaijan", "Belarus", "Estonia", "Israel", "Kazakhstan", "Kyrgyzstan", "Latvia", "Republic of Lithuania", "Republic of Moldova", "Russia", "Ukraine"},
	us = {"Canada", "United States"},
	fr = {"Belgium", "Canada", "France", "Luxembourg", "Mauritius", "Morocco", "Réunion", "Senegal", "Switzerland"},
}

nxserv.publicChannels = tokeys{
	"all",
	"city",
	"advert",
}

file.CreateDir("nxserv")


function server.whatgm(gamemode)
	gamemode = gamemode:lower()

	local gm = {name = gamemode}
	gm.sandbox = gamemode == "sandbox" or gamemode == "darkrp"
	gm.darkrp = gamemode == "darkrp"
	gm.terrortown = gamemode == "terrortown" or gamemode == "nx_trouble"
	return gm
end

if SERVER then
	server.gm = server.whatgm(GetConVarString("gamemode"))
	-- as early as autorun possible only on server
	-- keep nil on client on purpose so that it errors if used before being valid
end
hook.Add("PreGamemodeLoaded", "server.gm", function()
	server.gm = server.whatgm(GAMEMODE_NAME)
end)
