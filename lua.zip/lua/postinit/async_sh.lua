--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/postinit/async_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function Run(thread, ...)
	local success, text = coroutine.resume(thread, ...)
	if not success then
		error(debug.traceback(thread, text))
	end
end

function asyncSimple(func)
	return function(...)
		local thread = coroutine.create(func)
		Run(thread, ...)
	end
end

function async(func)
	local func2 = function(resolve, ...)
		resolve(func(...))
	end
	return function(...)
		return Promise(function(resolve, reject, ...)
			local thread = coroutine.create(func2)
			Run(thread, resolve, ...)
		end, ...)
	end
end

function asyncRun(func)
	return Promise(function(resolve, reject)
		local thread = coroutine.create(function(resolve)
			resolve(func())
		end)
		Run(thread, resolve)
	end)
end

function await(func)
	local thread = coroutine.running()

	local result
	local state = false

	func(function(...)
		result = {...}
		if state then
			Run(thread)
		else
			state = true
		end
	end)

	if state then return unpack(result) end

	state = true
	coroutine.yield()

	return unpack(result)
end


Promise = class()

function Promise:constructor(func, ...)
	if func then
		func(
			function(...) self:resolve(...) end,
			nil, -- reject will be here
			...
		)
	end
end

function Promise:resolve(...)
	self.result = {...}
	self.fulfilled = true
	if self.callback then
		self:finish()
	end
end

function Promise:finish() -- internal
	if getmetatable(self.result[1]) == getmetatable(self) then
		self.result[1](self.callback)
	else
		self.callback(unpack(self.result))
	end
end

function Promise:Then(callback)
	return Promise(function(resolve)
		self.callback = callback and function(...) resolve(callback(...)) end or resolve
		if self.fulfilled then
			self:finish()
		end
	end)
end

function Promise.meta.__call(self, callback)
	return self:Then(callback)
end

function Promise.static.all(tasks)
	return Promise(function(resolve)
		local results = {}
		if not next(tasks) then
			resolve(results)
			return
		end
		for key, task in pairs(tasks) do
			task(function(result)
				results[key] = result
				tasks[key] = nil
				if not next(tasks) then
					resolve(results)
				end
			end)
		end
	end)
end

function Promise.static.any(tasks)
	return Promise(function(resolve)
		if not next(tasks) then
			resolve()
			return
		end
		local done = false
		for key, task in pairs(tasks) do
			task(function(...)
				if done then return end
				done = true
				resolve(...)
			end)
		end
	end)
end

function Promise.static.resolve(...)
	local values = {...}
	return Promise(function(resolve)
		resolve(unpack(values))
	end)
end


function timer.Promise(delay)
	return Promise(function(resolve)
		timer.Simple(delay, resolve)
	end)
end

function hook.Promise(name, fn)
	return Promise(function(resolve)
		local id = util.UUID()

		hook.Add(name, id, function(...)
			if fn and fn(...) ~= true then
				return
			end

			hook.Remove(name, id)
			resolve(...)
		end)
	end)
end