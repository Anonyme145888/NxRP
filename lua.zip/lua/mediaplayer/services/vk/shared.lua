DEFINE_BASECLASS( "mp_service_base" )

SERVICE.Name 	= "VK"
SERVICE.Id 		= "vk"
SERVICE.Base 	= "browser"

local VKVideoIdPattern = "%-?%d+_%d+"
local UrlSchemes = {
	"vk%.com/video" .. VKVideoIdPattern,
	"vk%.com/video%?z=video" .. VKVideoIdPattern,
	"vk%.com/videos%-?%d+%?z=video" .. VKVideoIdPattern,
}

function SERVICE:New( url )
	local obj = BaseClass.New(self, url)
	obj._data = obj:GetVKVideoId()
	return obj
end

function SERVICE:Match( url )
	for _, pattern in pairs(UrlSchemes) do
		if string.find( url, pattern ) then
			return true
		end
	end

	return false
end

function SERVICE:IsTimed()
	if self._istimed == nil then
		self._istimed = self:Duration() > 0
	end

	return self._istimed
end

function SERVICE:GetVKVideoId()
	local videoId

	if self.videoId then

		videoId = self.videoId

	elseif self.urlinfo then

		local url = self.urlinfo

		if url.query and url.query.z and string.match(url.query.z, "^video(%-?%d+_%d+)") then
			videoId = string.match(url.query.z, "^video(%-?%d+_%d+)")
		elseif url.path and string.match(url.path, "^/video(%-?%d+_%d+)") then
			videoId = string.match(url.path, "^/video(%-?%d+_%d+)")
		end

		self.videoId = videoId

	end

	return videoId
end
