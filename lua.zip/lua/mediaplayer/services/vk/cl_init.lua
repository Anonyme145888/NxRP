include "shared.lua"

local urllib = url

DEFINE_BASECLASS( "mp_service_browser" )

local JS_SetVolume = "if(window.cur && window.cur.player) window.cur.player.setVolume(%s);"
local JS_Seek = "var arg = %s; if(window.cur && window.cur.player) if (Math.abs(window.cur.player.curTime() - arg) >= 3) window.cur.player.seekTo(arg);"
local JS_Play = "if(window.cur && window.cur.player) window.cur.player.play();"
local JS_Pause = "if(window.cur && window.cur.player) window.cur.player.pause();"

local function YTSetVolume( self )
	-- if not self.playerId then return end
	local js = JS_SetVolume:format( MediaPlayer.Volume())
	if self.Browser then
		self.Browser:RunJavascript(js)
	end
end

local function YTSeek( self, seekTime )
	-- if not self.playerId then return end
	local js = JS_Seek:format( seekTime )
	if self.Browser then
		self.Browser:RunJavascript(js)
	end
end

function SERVICE:SetVolume( volume )
	local js = JS_SetVolume:format( (volume or MediaPlayer.Volume()))
	self.Browser:RunJavascript(js)
end

function SERVICE:OnBrowserReady( browser )

	BaseClass.OnBrowserReady( self, browser )

	-- Resume paused player
	if self._YTPaused then
		self.Browser:RunJavascript( JS_Play )
		self._YTPaused = nil
		return
	end

	if self:CheckChromeSupport(browser) and self:CheckCodecSupport(browser, "h264") then
		browser:OpenURL(self._metadata.extra.player .. "&autoplay=1")
	end
end

function SERVICE:Pause()
	BaseClass.Pause( self )

	if ValidPanel(self.Browser) then
		self.Browser:RunJavascript(JS_Pause)
		self._YTPaused = true
	end
end

function SERVICE:Sync()
	local seekTime = self:CurrentTime()
	if self:IsPlaying() and self:IsTimed() and seekTime > 0 then
		YTSeek( self, seekTime )
	end
end

function SERVICE:IsMouseInputEnabled()
	return IsValid( self.Browser )
end
