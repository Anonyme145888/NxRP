--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/preinit/prof_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

prof_data_timers = {}

prof_timer_create = prof_timer_create or timer.Create
function timer.Create(name, delay, rep, func)
	local id = tostring(name) .. " " .. delay .. " " .. rep
	return prof_timer_create(name, delay, rep, function()
		if prof_enabled then
			prof_start()
			func()
			prof_finish("Timer", id)
		else
			func()
		end
	end)
end

prof_timer_adjust = prof_timer_adjust or timer.Adjust
function timer.Adjust(name, delay, rep, func)
	local id = tostring(name) .. " " .. delay .. " " .. rep
	return prof_timer_adjust(name, delay, rep, function()
		if prof_enabled then
			prof_start()
			func()
			prof_finish("Timer", id)
		else
			func()
		end
	end)
end