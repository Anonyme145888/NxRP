--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/preinit/rand_sh.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function feex(n)
	return bit.band(n, 2^31 - 1) + bit.rshift(n, 31) * 2^31
end
local function nomore(n)
	return bit.band(n, 2^32 - 1)
end
local function rotl(x, k)
	return bit.bor(bit.lshift(x, k), bit.rshift(x, 32 - k))
end

Random = class()
function Random:constructor(seed)
	self.s = {}

	self:seed(seed)
end
function Random:seed(seed)
	local state = self:getState()

	math._randomseed(seed or os.time())
	for n = 1, 4 do
		self.s[n] = math._random(1, 2^32-1)
	end

	for n = 1, 16 do
		self:next()
	end

	return state
end
function Random:getState()
	local state = {}
	for k, v in ipairs(self.s) do
		state[k] = v
	end
	return state
end
function Random:setState(state)
	for k, v in ipairs(state) do
		self.s[k] = v
	end
end
function Random:next()
	local s = self.s

	-- xoshiro128+
	-- local result = nomore(feex(s[1]) + feex(s[4]))
	-- local result = nomore(s[1] + s[4])

	-- xoshiro128**
	local result = nomore(rotl(s[2] * 5, 7) * 9)

	local t = bit.lshift(s[2], 9)

	s[3] = bit.bxor(s[3], s[1])
	s[4] = bit.bxor(s[4], s[2])
	s[2] = bit.bxor(s[2], s[3])
	s[1] = bit.bxor(s[1], s[4])

	s[3] = bit.bxor(s[3], t)

	s[4] = rotl(s[4], 11)

	return result
end
function Random:uint32()
	return feex(self:next())
end
-- function Random:random()
-- 	return self:uint32() / 2^32
-- end
function Random:random(low, high)
	local result = (bit.rshift(self:next(), 5) * 2^26 + bit.rshift(self:next(), 6)) / 2^53

	if not low then
		return result
	end

	if not high then
		high = low
		return 1 + math.floor(high * result)
	end

	return low + math.floor((high - low + 1) * result)
end
function Random:Rand(low, high)
	return low + (high - low) * self:random()
end
function Random:chance(prob)
	return self:random() < prob
end


math._random = math._random or math.random
math._randomseed = math._randomseed or math.randomseed

local rnd = Random()
math.randgen = rnd -- for the purpose of doing :seed :getState :setState; do not reassign from outside

function math.random(low, high)
	return rnd:random(low, high)
end

function math.randomseed(seed)
	-- ErrorNoHalt("math.randomseed used; switch to using the `Random` class")
	rnd:seed(seed)
end
