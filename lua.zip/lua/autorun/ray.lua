if SERVER then
	AddCSLuaFile("ray/client.lua")
	include("ray/server.lua")
end

if CLIENT then
	include("ray/client.lua")
end