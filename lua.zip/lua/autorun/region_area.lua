--[[
lua/postinit/region_area.lua
--]]
nxserv.region_area = "fr"

