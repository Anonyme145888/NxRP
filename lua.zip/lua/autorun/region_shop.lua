--[[
lua/postinit/region_shop.lua
--]]
nxserv.region_shop = "fr"

