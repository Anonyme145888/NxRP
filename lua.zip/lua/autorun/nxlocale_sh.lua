--[[
lua/preautorun/nxlocale_sh.lua
--]]
nxlocale = {}

nxlocale.directory = {}

--local langUserInfo = CreateConVar("_nxgml", "en", FCVAR_USERINFO)

nxlocale.getLanguage = function()
	return string.lower(SERVER and server and server.region.lang or GetConVarString("gmod_language") or "")
end

--langUserInfo:SetString(nxlocale.getLanguage())

nxlocale.translate = function(key)
	local path = key:Split(".")

	local it
	function it(path, branch)
		local value = table.remove(path, 1)
		if #path == 0 then
			return branch and branch[value] or key
		else
			return branch and branch[value] and it(path, branch[value]) or key
		end
	end

	return it(path, nxlocale.directory)
end

_G.Translate = nxlocale.translate

local function doload()
	for _, f in SortedPairs(file.Find("nxlocale/*.lua", "LUA"), true) do
		local piece = include("nxlocale/" .. f)
		AddCSLuaFile("nxlocale/" .. f)

		local name = string.GetFileFromFilename(f):Left(-5)

		nxlocale.directory[name] = piece[nxlocale.getLanguage()] or piece.en or table.Random(piece)
	end
end

nxlocale.doload = doload

nxlocale.getSpecificLngTable = function(name, lang)
	local piece = include("nxlocale/" .. name .. ".lua")
	return piece[lang or "fr"] or piece.en
end

doload()
hook.Run("LocaleChanged", nxlocale.getLanguage())

cvars.AddChangeCallback("gmod_language", function(name, old, new)
	doload()
	--langUserInfo:SetString(nxlocale.getLanguage())
	hook.Run("LocaleChanged", nxlocale.getLanguage())
end, "nxlocale")

-- Auto Tests...
assert(isstring(Translate("esc.resume")))
assert(isfunction(nxlocale.getSpecificLngTable))

local function iterator(t, k)
	k = k - 1
	if k >= 1 then
		return k, t[k]
	end
end

function backipairs(t)
	return iterator, t, #t + 1
end

local function iterator(state, n)
	n = n % #state.t + 1
	if not state.once then
		state.once = true
	elseif n == state.start then
		return
	end
	return n, state.t[n]
end
function cycleipairs(t, start)
	start = (start - 1) % #t
	return iterator, {t = t, start = start + 1}, start
end

local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
function base64_encode(data)
	return ((data:gsub('.', function(x) 
		local r,b='',x:byte()
		for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
		return r;
	end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
		if (#x < 6) then return '' end
		local c=0
		for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
		return b:sub(c+1,c+1)
	end)..({ '', '==', '=' })[#data%3+1])
end
function base64_decode(data)
	data = string.gsub(data, '[^'..b..'=]', '')
	return (data:gsub('.', function(x)
		if (x == '=') then return '' end
		local r,f='',(b:find(x)-1)
		for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
		return r;
	end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
		if (#x ~= 8) then return '' end
		local c=0
		for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
		return string.char(c)
	end))
end

function strhex(str)
	local result = {}
	for n = 1, #str do
		table.insert(result, ("%02X"):format(str[n]:byte()))
	end
	return table.concat(result, " ")
end