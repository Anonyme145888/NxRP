--[[
Server Name: ► Русский NxRP ✦ NxServ.ru ✦ Миллер
Server IP:   37.230.137.34:27015
File Path:   lua/autorun/util_misc.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local Entity = FindMetaTable("Entity")
local Player = FindMetaTable("Player")
local _Vector = FindMetaTable("Vector")

-- Perform a simple 2d vector to X axis projection
-- note: is fou want a different axis, you can simply x and y
-- level : number         X axis level
-- x1,y1,x2,y2 : number   vector coordinates
-- returns: x  : number   resulting positon on axis
function util.ProjectToAxis2D(level, x1, y1, x2, y2)
	local fc = (y1-level)/(y1-y2)
	return x2*fc+x1*(1-fc)
end

Player.__tostring = function(ent)
	return ent:IsValid() and ("Player [%d][%s]"):format(ent:UserID(), ent:Name()) or "Player [NULL]"
end

local ModelInfoCache = {}
function util.ModelInfo(path)
	if ModelInfoCache[path] == nil then
		local mdl = file.Open(path, "rb", "GAME")

		if mdl then
			local info = {}

			mdl:ReadLong() -- int id
			mdl:ReadLong() -- int version
			mdl:ReadLong() -- int checksum
			for n = 1, 64 do mdl:ReadByte() end -- char[64] name
			mdl:ReadLong() -- int dataLength
			mdl:ReadFloat() mdl:ReadFloat() mdl:ReadFloat() -- Vector eyeposition
			mdl:ReadFloat() mdl:ReadFloat() mdl:ReadFloat() -- Vector illumposition
			info.mins = Vector(mdl:ReadFloat(), mdl:ReadFloat(), mdl:ReadFloat()) -- Vector hull_min
			info.maxs = Vector(mdl:ReadFloat(), mdl:ReadFloat(), mdl:ReadFloat()) -- Vector hull_max

			mdl:Close()

			ModelInfoCache[path] = info
		else
			ModelInfoCache[path] = false
		end
	end

	return ModelInfoCache[path]
end

function util.LocalToWorldBBox(min, max, pos, ang)
	local points = {
		LocalToWorld(min, angle_zero, pos, ang),
		LocalToWorld(max, angle_zero, pos, ang),
		LocalToWorld(Vector(max.x, min.y, min.z), angle_zero, pos, ang),
		LocalToWorld(Vector(min.x, max.y, min.z), angle_zero, pos, ang),
		LocalToWorld(Vector(max.x, max.y, min.z), angle_zero, pos, ang),
		LocalToWorld(Vector(min.x, min.y, max.z), angle_zero, pos, ang),
		LocalToWorld(Vector(max.x, min.y, max.z), angle_zero, pos, ang),
		LocalToWorld(Vector(min.x, max.y, max.z), angle_zero, pos, ang),
	}
	local wmin, wmax = Vector(math.huge, math.huge, math.huge), Vector(-math.huge, -math.huge, -math.huge)
	for _, v in ipairs(points) do
		wmin.x = math.min(wmin.x, v.x)
		wmin.y = math.min(wmin.y, v.y)
		wmin.z = math.min(wmin.z, v.z)
		wmax.x = math.max(wmax.x, v.x)
		wmax.y = math.max(wmax.y, v.y)
		wmax.z = math.max(wmax.z, v.z)
	end
	return wmin, wmax
end

local result = {}
function util.TestSolid(trace, box1, box2) -- yes, magnificent
	trace.output = result

	trace.start = Vector(box1[1], box1[2], box1[3])
	trace.endpos = Vector(box2[1], box1[2], box1[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box2[2], box1[3])
	trace.endpos = Vector(box2[1], box2[2], box1[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box1[2], box2[3])
	trace.endpos = Vector(box2[1], box1[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box2[2], box2[3])
	trace.endpos = Vector(box2[1], box2[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box1[2], box1[3])
	trace.endpos = Vector(box1[1], box2[2], box1[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box2[1], box1[2], box1[3])
	trace.endpos = Vector(box2[1], box2[2], box1[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box1[2], box2[3])
	trace.endpos = Vector(box1[1], box2[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box2[1], box1[2], box2[3])
	trace.endpos = Vector(box2[1], box2[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box1[2], box1[3])
	trace.endpos = Vector(box1[1], box1[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box2[1], box1[2], box1[3])
	trace.endpos = Vector(box2[1], box1[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box1[1], box2[2], box1[3])
	trace.endpos = Vector(box1[1], box2[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	trace.start = Vector(box2[1], box2[2], box1[3])
	trace.endpos = Vector(box2[1], box2[2], box2[3])
	util.TraceLine(trace)
	if result.Hit then return true end

	return false
end

function util.VectorRand2D()
	local θ = math.random() * math.pi * 2
	return Vector(math.cos(θ), math.sin(θ))
end
function _Vector:AddZ(z) -- add Z [-1.0, 1.0] component to a 2D unit vector - resulting vector is still a unit vector
	local m = math.sqrt(1 - z^2)
	self.x = self.x * m
	self.y = self.y * m
	self.z = z
end
function util.VectorRand() -- like VectorRand(), but actually provides proper unit vectors instead of some shit with varying lengths
	local θ = math.random() * math.pi * 2
	local z = math.random() * 2 - 1
	local m = math.sqrt(1 - z^2)
	return Vector(math.cos(θ) * m, math.sin(θ) * m, z)
end
--[[
function util.VectorRand() -- like VectorRand(), but actually provides proper unit vectors instead of some shit with varying lengths
	local vec = util.VectorRand2D()
	vec:AddZ(math.random() * 2 - 1)
	return vec
end
]]

local random = math.random
function util.UUID()
	local template ='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
	return string.gsub(template, '[xy]', function (c)
		local v = (c == 'x') and random(0, 0xf) or random(8, 0xb)
		return string.format('%x', v)
	end)
end

string.InputCheckInvalid = 0
string.InputCheckShort = 1
string.InputCheckLong = 2
function string.InputCheck(str, min, max)
	if not max then
		max = min
		min = 1
	end

	-- do simple length first to avoid doing expensive utf8 operations on some superlong shit hackers could send
	if #str > max * 4 then
		return string.InputCheckLong, #str
	end

	local len = str:ulenlimit(max)

	if not len then
		return string.InputCheckInvalid, #str
	end

	if len < min then
		return string.InputCheckShort, len
	end

	if len > max then
		return string.InputCheckLong, len
	end

	return nil, len
end

local tests = {

}
function Player:IsTester(test)
	if tests[test] then
		return tests[test](self)
	else
		return self:IsAdmin() and server.region.area == "ru"
	end
end