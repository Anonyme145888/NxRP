nxshop = nxshop or {}

local function load()
	for _, fn in SortedPairsByValue((file.Find("skynetshop/flags/*.lua", "LUA"))) do
		xpcall(include, ErrorNoHalt, "skynetshop/flags/" .. fn)
	end

	AddCSLuaFile("skynetshop/locale.lua")
	AddCSLuaFile("skynetshop/cl_shop.lua")
	AddCSLuaFile("skynetshop/cl_admin.lua")
	AddCSLuaFile("skynetshop/cl_item_panel.lua")
	AddCSLuaFile("skynetshop/cl_wallet_panel.lua")
	AddCSLuaFile("skynetshop/cl_actionmenu.lua")
	AddCSLuaFile("skynetshop/cl_listmenu.lua")
	AddCSLuaFile("skynetshop/cl_manifest.lua")
	AddCSLuaFile("skynetshop/cl_networking.lua")
	AddCSLuaFile("skynetshop/cl_textwrap.lua")
	AddCSLuaFile("skynetshop/cl_wearables.lua")
	AddCSLuaFile("skynetshop/sh_wearables.lua")
	AddCSLuaFile("skynetshop/aligner.lua")
	AddCSLuaFile("skynetshop/sh_items.lua")
	AddCSLuaFile("skynetshop/sh_dermaskin.lua")
	AddCSLuaFile("skynetshop/sh_config.lua")
    AddCSLuaFile("skynetshop/sh_player_extension.lua")

	include("skynetshop/locale.lua")
	
	timer.Simple(0, function()

		if SERVER then
			include("skynetshop/sh_wearables.lua")
		else
			include("skynetshop/cl_textwrap.lua")
			include("skynetshop/cl_admin.lua")
			include("skynetshop/cl_item_panel.lua")
			include("skynetshop/cl_wallet_panel.lua")
			include("skynetshop/cl_actionmenu.lua")
			include("skynetshop/cl_listmenu.lua")
			include("skynetshop/cl_shop.lua")
			include("skynetshop/aligner.lua")
			include("skynetshop/sh_wearables.lua")
			include("skynetshop/cl_wearables.lua")
			include("skynetshop/sh_dermaskin.lua")
		end

		include("skynetshop/sh_dermaskin.lua")
		--include("skynetshop/sh_items.lua")
		include("skynetshop/sh_config.lua")
        include("skynetshop/sh_player_extension.lua")
	end)

	if CLIENT then
		include("skynetshop/cl_manifest.lua")
		include("skynetshop/cl_networking.lua")
	end
end

load()
if CLIENT then
	concommand.Add("nxshop_cl", load)
else
	concommand.Add("nxshop_sv", function(p)
		if not IsValid(pl) or pl:IsSuperAdmin() then
			load()
		end
	end)

	concommand.Add("nxshop_sh", function()
		if not IsValid(pl) or pl:IsSuperAdmin() then
			load()

			for k, v in pairs(player.GetAll()) do
				v:ConCommand("nxshop_cl")
			end
		end
	end)
end

