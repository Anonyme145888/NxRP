-- RAY ADMIN SYSTEM 6.5.5 --
------------------------------------------------------------------------------------
-- Ray Admins System --
-- Created by Fy-e and Nloginov --
-- NxServ 2019/2021 TM --

--Commands
util.AddNetworkString("RayCommand")
--NetB
util.AddNetworkString("NetBStart")
util.AddNetworkString("NetBFinish")
util.AddNetworkString("NetBData")
util.AddNetworkString("NetBStop")
util.AddNetworkString("NetBNext")
--Plugins
util.AddNetworkString("RayPluginsLoaded") -- Net.Receive --- NO
util.AddNetworkString("RayPlugins")
util.AddNetworkString("RayStopPlugin")
--Util
util.AddNetworkString("RayServerFrameTime")
--Client
util.AddNetworkString("RayLastPlayers")  -- Возможны Баги -- М-да...
util.AddNetworkString("RayHTTPServer")  -- Процесс передачи которой нет XD
util.AddNetworkString("RayFlags")
util.AddNetworkString("RayInitPostEntity")
util.AddNetworkString("RayPrint")
--Cfg Ray
util.AddNetworkString("RayUpdateConfig")
util.AddNetworkString("RayWho")
util.AddNetworkString("RayMonitoring")
util.AddNetworkString("RayJoinStatus")
------------------------------------------------------------------------------------

-- СЕРВЕРНЫЕ НАСТРОЙКИ--
Locked = true -- Доступ к серверу будет запрещен

if SERVER and Locked then
   RunConsoleCommand('hostname', "[Locked] ► Français GxRP ✦ Eclipse") 
end
if SERVER and not Locked then
   RunConsoleCommand('hostname', "► Français GxRP ✦ Ecplise") 
end

-- SERVER LOCKED HOOK BY ANON --
local allowed = {
   ["76561198813505894"] = true, -- AnonChaos
   ["76561199193843404"] = true, -- Stender
   ["76561198932202132"] = true, -- GxServ
}

hook.Add( "CheckPassword", "access_whitelist", function( steamID64 )
   if not Locked then return end
   if not allowed[steamID64] then
       return false, "Server is locked."
   end
end)