local PMeta = FindMetaTable("Player")

function PMeta:getMonthRank(target)
	local data = target:GetPData( "month_data" )
	if ( !data or data == "" ) then return nil end
	local tab = util.JSONToTable( data )
	if ( !tab ) then return nil end
	return tab
end

premium = premium or {}
function PMeta:giveTimedRank( name, time, target ) 
    target:SetUserGroup("premium")

	local tab = {
		rank = name,
		wait = time,
		timestamp = os.time()
	}
		
	target:SetPData("month_data", tab )
    premium["darkrp_premium"] = {
        name = "darkrp_premium", 
        expire = tab.timestamp + tab.wait
    }

	net.Start("NxShopUpdate") 
    net.WriteTable(premium)
    net.Send(target)

    tab = util.TableToJSON( tab )
end

hook.Add( "PlayerInitialSpawn", "giveMonthRank", function( ply )
	local tab = ply:getMonthRank(ply)
	
	if ( !tab or table.Count( tab ) <= 0 ) then return end
	if ( !tab.timestamp or !tab.wait ) then return end
	
	local dif = ( tab.timestamp + tab.wait ) - os.time()
    local time = tab.timestamp + tab.wait
	if ( dif <= 0 ) then
		ply:SetUserGroup(ply, "user")
		ply:RemovePData("month_data")
        ply:ChatPrint( "Your "..tab.rank.." has expired!" )
        ChatAddText(ply, ray.colors.orange, "▷ ", ray.colors.white, "Ваша привелегия Roleplay Premium истекла!")
    else
        net.Start("NxShopUpdate") 
        net.WriteTable({name = "darkrp_premium", expire = time})
        net.Send(ply)

        ply:SetUserGroup("premium")
	end
	
	timer.Simple( 20, function()
		if ( IsValid( ply ) and ply:GetUserGroup() != tab.rank ) then
			ply:RemovePData("month_data")
			net.Start("NxShopUpdate") 
            net.WriteTable({})
            net.Send(ply)
		end	
	end )
end )