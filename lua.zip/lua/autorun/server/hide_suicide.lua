local function NoSuicide(ply)
    if ply:IsSuperAdmin() then
        ply:PrintMessage(HUD_PRINTCONSOLE, "Vous pouvez vous suicider car vous êtes superadmin")
    else
        ply:PrintMessage(HUD_PRINTCONSOLE, "Vous ne pouvez pas vous suicider")
        return false
    end
end

hook.Add("CanPlayerSuicide", "RemoveSuicide", NoSuicide)