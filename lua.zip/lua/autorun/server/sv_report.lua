﻿util.AddNetworkString("ReportCheater")
util.AddNetworkString("Report")

net.Receive("Report", function(len, ply)
	local text = net.ReadString()
    ChatAddTextAdmins(ray.colors.white, "Problem report from ", team.GetColor(ply:Team()), ply:Name(), ray.colors.white, ": ", text)
end)

net.Receive("ReportCheater", function(len, ply)
	local sid = net.ReadUInt(32) 
	local cheater = sid == 0 and nil or ray.FindPlayer(sid)
	local text = "Внимание, подозреваю что игрок "..(sid == 0 and "BOT" or cheater:Name()).." ("..sid..") является читером!"

	ChatAddTextAdmins(ray.colors.white, "Cheater report from ", team.GetColor(ply:Team()), ply:Name(), ray.colors.white, ": ", text)
end)