util.AddNetworkString("IsTyping")

net.Receive("IsTyping", function(len, ply)
    local typing = net.ReadBool()
    ply:SetNWBool("IsTyping", typing)
end)

hook.Add("PlayerInitialSpawn", "isTypingFix", function(ply)
	ply:SetNWBool("IsTyping", false)
end)

local function Wchat(message, info, ply)
	net.Start("wChat")
	net.WriteEntity(ply)
	net.WriteString(info == 2 and "Moderator" or ply:Name())
    net.WriteUInt(info == 2 and 358831098 or ply:AccountID(), 32)
    net.WriteString(message)
    net.WriteBool(ply:IsPlayer() and true or false)
    net.WriteBool(ply:Alive())
    net.Send(ply)
end

util.AddNetworkString("wChat")
util.AddNetworkString("_ChatAddTpl")
net.Receive("wChat", function(len, ply)
	local chatType = net.ReadString()
	local message = net.ReadString()
    local info = net.ReadUInt(2)
    local tbl = {ply, message}
    local sphere = ents.FindInSphere( ply:GetPos(), 196 )
    local groupChats = {}
    for _, func in pairs(GAMEMODE.DarkRPGroupChats) do
        if not func(ply) then continue end
        if ( ply:GetNWString("gang_name") == "None" or ply:GetNWString("gang_name") == false ) then
           table.insert(groupChats, func)
        end
    end

    local prefix = message[1]
	if (prefix == "!" or prefix == "/") then
	   	ply:Say(message)
	    return
	end

	if not ply:Alive() then return end

	Wchat(message, 2, ply)

	net.Start("_ChatAddTpl")
	net.WriteString(chatType == "city" and "darkrp.ooc" or chatType == "advert" and "darkrp.advert" or chatType == "group" and "darkrp.group" or chatType == "local" and "darkrp.talk" or chatType == "me" and "darkrp.me")
	net.WriteTable(tbl)
	if chatType == "city" or chatType == "advert" then
	net.Broadcast()
    elseif chatType == "local" or chatType == "me" then
        for k, v in ipairs(sphere) do
        	if v:IsPlayer() and v:IsValid() then
        		net.Send(v)
        	end
        end
    elseif chatType == "group" then
    	if ( ply:GetNWString("gang_name") ~= "None" and ply:GetNWString("gang_name") ~= false and ply:GetNWString("gang_name") ~= nil and ply:GetNWString("gang_name") ~= "" ) then
    		 for k, v in pairs(player.GetAll()) do
                if v:GetNWString("gang_name") == ply:GetNWString("gang_name") then
                   net.Send(v)
                   return
                end
             end
        else
        for _, target in ipairs(player.GetAll()) do
        	if table.IsEmpty(groupChats) then
        		net.Send(ply)
            end
            for _, func in ipairs(groupChats) do
                if not func(target, ply) then continue end
                    if ( target:GetNWString("gang_name") == "None" or target:GetNWString("gang_name") == false or target:GetNWString("gang_name") == nil or target:GetNWString("gang_name") == "" ) and ( ply:GetNWString("gang_name") == "None" or ply:GetNWString("gang_name") == "" ) then
                       net.Send(target)
                       return
                    end
                end
            end
        end
    else
    end
end)

--[[
chat.no_prefixes	=	function: 0x203f2258
chat.pm.incoming	=	function: 0x3d77e520
chat.pm.outcoming	=	function: 0x3989d0a0
darkrp.advert	=	function: 0x3c8e3760
darkrp.dealer	=	function: 0x3c47c058
darkrp.demote	=	function: 0x3c8e37a0
darkrp.group	=	function: 0x3cdad968
darkrp.legacy	=	function: 0x21010e10
darkrp.me	=	function: 0x3890bab0
darkrp.ooc	=	function: 0x3c47c018
darkrp.region	=	function: 0x3cdbc020
darkrp.talk	=	function: 0x386ffa98
darkrp.whisper	=	function: 0x3a357850
darkrp.yell	=	function: 0x383ff948
]]

util.AddNetworkString("wChatPM")
net.Receive("wChatPM", function(len, ply)
	local steamid = net.ReadString()
	local message = net.ReadString()
	local info = net.ReadUInt(2)

	local target = steamid:Left(6) == "MODER_" and ray.FindPlayer(steamid:sub(7)) or ray.FindPlayer(steamid)

	if not target:IsPlayer() then return end
    if not target:IsValid() then return end

	net.Start("wChatPM")
	net.WriteString(info == 2 and "MODER_"..ply:AccountID() or ply:SteamID())
	net.WriteString(message)
	net.WriteBool(false)
	net.WriteEntity(ply) -- target
	net.WriteString(info == 2 and "Moderator" or ply:Name())
	net.WriteUInt(info == 2 and 358831098 or ply:AccountID(), 32)
    net.WriteUInt(info, 2)
    net.Send(target)
end)