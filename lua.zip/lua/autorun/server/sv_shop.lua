util.AddNetworkString("NxShopManifest")
util.AddNetworkString("NxShopUpdate")
