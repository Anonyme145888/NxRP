resource.AddWorkshop( "2414556240" ) -- Advanced Material 2
resource.AddWorkshop( "696374067" ) -- DurgzMod (The Original GMod Drugs Mod)
resource.AddWorkshop( "3187873526" ) -- FAS2 - GMOD
resource.AddWorkshop( "293934315" ) -- Ford Transit - Russian Ambulance Skin
resource.AddWorkshop( "151171713" ) -- LoneWolfies Police (and stuff) Package
resource.AddWorkshop( "594803288" ) -- Playable Drumset (2020 Update)
resource.AddWorkshop( "104548572" ) -- Playable Piano
resource.AddWorkshop( "489864412" ) -- TDM's Prop Pack
resource.AddWorkshop( "105463332" ) -- SprayMon
resource.AddWorkshop( "173482196" ) -- SProps Workshop Edition
resource.AddWorkshop( "113120185" ) -- TDMCars - Audi
resource.AddWorkshop( "112606459" ) -- TDMCars - Base Pack
resource.AddWorkshop( "113118541" ) -- TDMCars - BMW
resource.AddWorkshop( "113997239" ) -- TDMCars - Chevrolet
resource.AddWorkshop( "176984840" ) -- TDMCars - Chrysler
resource.AddWorkshop( "777864203" ) -- TDMCars - Commercial Vehicles
resource.AddWorkshop( "114001545" ) -- TDMCars - Dodge
resource.AddWorkshop( "349281554" ) -- TDMCars - Emergency Vehicles pack
resource.AddWorkshop( "119148996" ) -- TDMCars - Ferrari
resource.AddWorkshop( "113999373" ) -- TDMCars - Ford
resource.AddWorkshop( "120766823" ) -- TDMCars - GMC
resource.AddWorkshop( "230680318" ) -- TDMCars - Land Rover
resource.AddWorkshop( "233934024" ) -- TDMCars - Mazda
resource.AddWorkshop( "217264937" ) -- TDMCars - McLaren
resource.AddWorkshop( "131246684" ) -- TDMCars - Mercedes
resource.AddWorkshop( "225810491" ) -- TDMCars - Multi Brand
resource.AddWorkshop( "123455885" ) -- TDMCars - Nissan
resource.AddWorkshop( "259899351" ) -- TDMCars - Porsche
resource.AddWorkshop( "131245637" ) -- TDMCars - Toyota
resource.AddWorkshop( "673698301" ) -- Vape SWEP
resource.AddWorkshop( "390056021" ) -- [LW] 2015 Dodge Charger RT
resource.AddWorkshop( "263574779" ) -- [LW] Chevrolet Impala Package
resource.AddWorkshop( "258999371" ) -- [LW] Chevrolet Suburban/Tahoe Pack
resource.AddWorkshop( "343729375" ) -- [LW] Ford F350 Ambulance
resource.AddWorkshop( "320396634" ) -- [LW] Lamborghini Huracan LP610-4
resource.AddWorkshop( "414446616" ) -- [LW] Lamborghini Reventon
resource.AddWorkshop( "309880608" ) -- [LW] Quad Bikes
resource.AddWorkshop( "223767390" ) -- [LW] Mercedes-Benz G65 AMG
resource.AddWorkshop( "266579667" ) -- [LW] Shared Textures
resource.AddWorkshop( "972221842" ) -- [Skin] Physic gun Neon
resource.AddWorkshop( "3138301580" ) -- gxcontone