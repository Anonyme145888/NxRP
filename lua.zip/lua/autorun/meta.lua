local meta = FindMetaTable( "Player" )
function meta:IsPremium()
	return self:GetUserGroup() == "premium"
end