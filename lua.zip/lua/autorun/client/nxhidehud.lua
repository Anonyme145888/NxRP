--[[
lua/autorun/client/nxhidehud.lua
--]]
local cl_drawhud = GetConVar("cl_drawhud")

hook.Add("HUDShouldDraw", "nx_hidehud", function()
	if not cl_drawhud:GetBool() then
		return false
	end
end)

cvars.AddChangeCallback("cl_drawhud", function(_, old, new)
	hook.Run("cl_drawhud", cl_drawhud:GetBool())
end, "nx_hidehud")

