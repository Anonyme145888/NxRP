local JumpDelay = 0.01
if CLIENT then JumpDelay = JumpDelay + engine.TickInterval() end
local JumpLength = 0.1

local JumpState = util.PlayerCache()

hook.Add("StartCommand", "JumpDelay", function(pl, cmd)
	local state = JumpState[pl]
	if not state then
		state = {landed = 0}
		JumpState[pl] = state
	end

	local jump_want = cmd:KeyDown(IN_JUMP)

	if not pl:OnGround() then
		state.inair = true
	elseif state.inair then
		state.inair = false
		state.landed = CurTime()
		-- print("==gr==")
	end

	if not jump_want then
		state.pressed = nil
	elseif not state.pressed then
		state.pressed = CurTime()
	end

	if jump_want and CurTime() <= state.landed + JumpDelay and state.pressed >= state.landed then
		state.jump = CurTime()
		cmd:RemoveKey(IN_JUMP)
		-- print("cd")
	elseif CLIENT and state.jump and CurTime() > state.landed + JumpDelay and CurTime() <= state.jump + JumpDelay + JumpLength then
		cmd:AddKey(IN_JUMP)
		-- print("jp")
	end
end)
