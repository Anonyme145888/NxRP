local tag = "\13TO"

local PLAYER=FindMetaTable"Player"
local OldPing=PLAYER.Ping
function PLAYER:Ping()
	if self and self.timing_out then
		return -1
	else
		return OldPing(self)
	end
end

usermessage.Hook(tag,function(umsg)
	local timing_out=umsg:ReadBool()

	local pl=umsg:ReadEntity()

	if !pl:IsValid() then return end

	if LocalPlayer():IsValid() and LocalPlayer():IsAdmin() then
		Msg"[Ping] "print(pl:Name()..(timing_out and " timing out" or " recovered"))
	end

	if timing_out then
		pl.timing_out=true
	else
		pl.timing_out=nil
	end
end)