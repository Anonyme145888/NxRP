--[[
lua/autorun/client/nxui.lua
--]]
do -- NxTabScroller
	local PANEL = {}

	function PANEL:Init()
		self:SetSkin("NxShop")
		self:Dock(TOP)
		self:DockMargin(0, 0, 0, LargeMargin)
		self:SetTall(yscale(64))
	end

	function PANEL:PerformLayout(w, h)
		local cw = 0
		for k, v in pairs(self:GetChildren()) do
			cw = cw + v:GetWide()
		end

		self:DockPadding((w-cw)/2, 0, 0, 0)
	end

	function PANEL:AddTab(title, sheet, tab)
		local b = self:Add("NxTabScrollerButton")
		b.sheet = sheet
		b.tab = tab
		b:SetText(title)
		b:SizeToContents()

		return b
	end

	local sep_paint = function(_, w, h)
		surface.SetDrawColor(Color(255, 255, 255, 100))
		surface.DrawRect(4, 0, 1, h)
	end

	function PANEL:AddSeparator()
		local s = self:Add("Panel")
		s:Dock(LEFT)
		s:SetWide(9)
		s.Paint = sep_paint
	end

	derma.DefineControl("NxTabScroller", "", PANEL, "EditablePanel")

	---------

	local PANEL = {}

	function PANEL:Init()
		self:Dock(LEFT)
		self:SetFont("DermaNotLarge")
		self.grow = 0
	end

	local color_yello = Color(0xFD, 0xD8, 0x35)

	function nxui_NewTagSize()
		surface.SetFont("RobotoC16")
		local w, h = surface.GetTextSize("NEW!")

		return w + 8, h
	end

	function nxui_DrawNewTag(x, y, color)
		local w, h = nxui_NewTagSize()

		draw.RoundedBox(4, x, y, w, h, color)
		draw.RoundedBox(4, x + 1, y + 1, w - 2, h - 2, color_black)


		surface.SetTextColor(color)
		surface.SetTextPos(x + 4, y)
		surface.DrawText("NEW!")
	end

	function PANEL:Paint(w, h)
		if not self.sheet then return end

		local active = self.sheet:GetActiveTab() == self.tab

		if self.Hovered then
			surface.SetDrawColor(Color(255, 255, 255, 10))
			surface.DrawRect(0, 0, w, h)
		end

		self.grow = math.Clamp(self.grow + (active and FrameTime() or -FrameTime())*25, 0, 3)

		if math.Round(self.grow) > 0 then
			surface.SetDrawColor(color_white)
			surface.DrawRect(0, h - math.Round(self.grow), w, math.Round(self.grow))
		end

		if self.new then
			local ow, oh = nxui_NewTagSize()
			nxui_DrawNewTag(w - ow, 6, color_yello)
			surface.SetDrawColor(color_yello)
			surface.DrawRect(0, 0, w, 2)
		end
	end

	derma.DefineControl("NxTabScrollerButton", "", PANEL, "DButton")
end

do -- NxButton
	local PANEL = {}

	function PANEL:Init()
		self:SetDoubleClickingEnabled(false) -- double-clicking is pain in the ass if you want to click fast
		self:SetFont("DermaNotDefault")

		self.color = Color(0x45, 0x5A, 0x64, 255)
		self.color_hover = Color(0x54, 0x6E, 0x7A, 255)
		self.color_down = Color(0x37, 0x47, 0x4F, 255)
		self.color_disabled = Color(0x26, 0x32, 0x38)
		
		self:SetDoubleClickingEnabled(false)
		self:SetExpensiveShadow(1, color_black)
	end

	function PANEL:AutoSize()
		self:SizeToContents()
		self:SetSize(self:GetWide() + yscale(10), yscale(32))
	end

	function PANEL:SizeBig()
		self:DockMargin(LargeMargin*2, 0, LargeMargin*2, 0)
		self:SetTall(yscale(40))
	end

	function PANEL:SetPrimaryMainColors()
		self.color = Color(0x28, 0x35, 0x93)
		self.color_hover = Color(0x30, 0x3F, 0x9F)
		self.color_down = Color(0x1A, 0x23, 0x7E)
		self.color_disabled = Color(0x45, 0x5A, 0x64)
	end

	function PANEL:Paint(w, h)
		--DisableClipping( true )
		self:GetSkin().tex.Shadow( -4, -4, w+10, h+10 )
		--DisableClipping( false )

		local col = self.color
		local otl = false

		if self:IsDown() or self.m_bSelected then
			otl = true
			col = self.color_down
		elseif self:GetDisabled() then
			col = self.color_disabled
		elseif self.Hovered then
			col = self.color_hover
		end

		surface.SetAlphaMultiplier(0.9)
		surface.SetDrawColor(col)
		if otl then
			surface.DrawRect(1, 1, w - 2, h - 2)
			--draw.RoundedBox(1.5, 1, 1, w - 2, h - 2, col)
		else
			--draw.RoundedBox(1.5, 0, 0, w, h, col)
			surface.DrawRect(0, 0, w, h)
		end
		surface.SetAlphaMultiplier(1)

		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawOutlinedRect(0, 0, w, h)
	end

	local grey = Color(128, 128, 128)

	function PANEL:UpdateColours()
		if self:GetDisabled() then
			return self:SetTextStyleColor(grey)
		else
			return self:SetTextStyleColor(color_white)
		end
	end

	function PANEL:OnDepressed()
		surface.PlaySound("nxrp/tap_depress.wav")
	end
	
	function PANEL:OnReleased()
		surface.PlaySound("nxrp/tap_release.wav")
	end

	derma.DefineControl("NxButton", "", PANEL, "DButton")
end

do -- NxNumSlider
	local PANEL = {}

	function PANEL:Init()
		self:SetDecimals(0)
		self.Label:SetBright()
		self.Label:SetFont("DermaNotDefault")
		self.Scratch:SetVisible(false)
		self.Label:DockMargin(0, 0, MediumMargin, 0)
		self.TextArea:SetFont("DermaNotDefault")
		self.TextArea:SetTextColor(color_white)
		self.TextArea:SetTextColor(color_white)
		self.TextArea:SetCursorColor(color_white)
		self.Slider.Paint = function(self, w, h)
			surface.SetDrawColor( Color( 255, 255, 255, 100 ) )
			surface.DrawRect( 8, h / 2 - 1, w - 15, 2 )
		end
	end

	function PANEL:PerformLayout()

	end
	
	derma.DefineControl("NxNumSlider", "", PANEL, "DNumSlider")
end

do -- NxEditablePanel
	local PANEL = {}

	function PANEL:Init()

	end

	function PANEL:AddTitle(text, parent)
		parent = parent or self
		local title = parent:Add("DLabel")
		title:SetFont("DermaNotLarge")
		title:SetText(text)
		title:SetContentAlignment(4)
		title:SizeToContents()
		title:Dock(TOP)
		title:DockMargin(0, 0, 0, MediumMargin)

		return title
	end

	derma.DefineControl("NxEditablePanel", "", PANEL, "EditablePanel")
end

do -- NxGenericFrame
	surface.CreateFont("placeholderfont", {
		size = yscale(22),
		weight = 350,
		antialias = true,
		extended = true,
		font = "Roboto"})

	local PANEL = {}

	function PANEL:Init()
		esc.RegisterPanel(self, function()
			local prevent = self:OnBackPress()

			if not prevent then
				self:Remove()
			end

			return true
		end)

		surface.SetFont(_G.DarkRP and "nx_hud_compat_s" or "placeholderfont")
		local nwidth = surface.GetTextSize("I AM THE GREATEST I AM THE GREATE") + yscale(10)*2 + LargeMargin*2 + SmallMargin
		local width = ScrW() - (nwidth) * 2
		local width2 = ScrW() - (nwidth)

		if width > 1024 then
			self:SetSize(math.min(ScrW(), width), ScrH() - LargeMargin * 2)
			self:Center()
		else
			width = math.min(ScrW(), 1024)
			width = width2
			self:SetSize(width, ScrH() - LargeMargin * 2)
			self:SetPos(ScrW() - width - SmallMargin, LargeMargin)
		end
		
		self:MakePopup()

		self:DockPadding(LargeMargin, LargeMargin, LargeMargin, LargeMargin)

		local backButtonDocking = self:Add("EditablePanel")
		self.backButtonDocking = backButtonDocking
		backButtonDocking:Dock(BOTTOM)
		backButtonDocking:SetTall(yscale(32))
		backButtonDocking:DockMargin(0, MediumMargin, 0, 0)

		local backButton = backButtonDocking:Add("NxButton")
		self.BackButton = backButton
		backButton:Dock(RIGHT)
		backButton:SetText(Translate("ui.esc_back"))
		backButton:AutoSize()
		backButton.DoClick = function()
			local prevent = self:OnBackPress()

			if not prevent then
				self:Remove()
			end
		end

		--LocalPlayer():EmitSound(("physics/glass/glass_sheet_step%d.wav"):format(math.random(1, 4)), 100, 24)
		--LocalPlayer():EmitSound(("physics/glass/glass_sheet_step%d.wav"):format(math.random(1, 4)), 100, 54)
	end

	function PANEL:OnBackPress()
		return false
	end

	local bg = Material("nxrp/what_the_hex.png")
	local alpha = 255

	function PANEL:Paint(w, h)
		

		vgui.blurCopypaste(self, w, h)

		if false and self.BackgroundMaterial then
			surface.SetMaterial(self.BackgroundMaterial)
			--surface.SetAlphaMultiplier(0.9)
			--surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
			surface.SetDrawColor( 150, 150, 150, 200 )
			surface.DrawTexturedRect(0, 0, math.max(w, h), math.max(w, h))
			--surface.SetAlphaMultiplier(1)
		else
			if not bg:IsError() then
				--surface.SetDrawColor(255, 255, 255, 20)
				surface.SetDrawColor(255, 255, 255, alpha)
				surface.SetMaterial(bg)
				for x = 0, math.ceil(w/400) do
					for y = 0, math.ceil(h/400) do
						surface.DrawTexturedRect((x-1)*400, (y-1)*400, 400, 400)
					end
				end
			end
			surface.SetDrawColor( 40, 40, 40, 200 )
			surface.DrawRect(0, 0, w, h)
		end

		surface.SetDrawColor(40, 40, 40, 200)
		surface.DrawOutlinedRect(0, 0, w, h)
		surface.SetDrawColor(120, 120, 120, 200)
		surface.DrawOutlinedRect(1, 1, w - 2, h - 2)
		surface.SetDrawColor(40, 40, 40, 200)
		surface.DrawOutlinedRect(2, 2, w - 4, h - 4)

		DisableClipping( true )
		self:GetSkin().tex.Shadow( -10, -10, w+20, h+20 )
		self:GetSkin().tex.Shadow( -5, -5, w+10, h+10 )
		DisableClipping( false )

	end

	derma.DefineControl("NxGenericFrame", "", PANEL, "NxEditablePanel")
end

do -- NxGenericFramePaged
	local PANEL = {}

	function PANEL:Init()
		self.sheet = self:Add("DPropertySheet")
		self.sheet:Dock(FILL)
		self.sheet.Paint = function(s,w,h) --[[surface.SetDrawColor(Color(255, 0, 0)) surface.DrawOutlinedRect(0, 0, w, h)]] end
		self.sheet:SetPadding(0)
		self.sheet.tabScroller:SetVisible(false)
		self.sheet.tabScroller:DockMargin(0, 0, 0, 0)
		self.sheet.tabScroller:SetTall(0)
		self.sheet:DockPadding(0, 0, 0, 0)
		self.sheet:DockMargin(0, 0, 0, 0)
		self.sheet.GetPadding = function() return 0 end
	end

	local function paintTab(self, w, h)
		surface.SetDrawColor(color_white)
		surface.DrawOutlinedRect(0, 0, w, h)
	end

	function PANEL:NewSheet(name, class)
		local new = self.sheet:Add(class or "EditablePanel")
		new:Dock(FILL)
		new.tabizator = self.sheet
		
		local sheet = self.sheet:AddSheet(name, new)
		
		sheet.Tab.GetTabHeight = function() return yscale(32) end
		sheet.Tab:SetFont("DermaNotDefault")
		sheet.Tab.Paint = paintTab
		
		return new, sheet
	end

	function PANEL:OnBackPress()
		if IsValid(self.sheet:GetActiveTab()) and self.sheet:GetActiveTab():GetText() ~= "MainScreen" then
			return self.sheet:SwitchToName("MainScreen") -- found?
		end
	end

	function PANEL:EnableTabs()
		self.sheet.tabScroller:SetVisible(true)
		self.sheet.tabScroller:SetTall(yscale(32))
		self.sheet.tabScroller:SetOverlap(1)
		self.sheet.tabScroller:DockMargin(0, 0, 0, MediumMargin)
		self.sheet.tabScroller.Paint = function(s, w, h)
			surface.SetDrawColor(color_white)
			surface.DrawLine(0, h - 1, w, h - 1)
		end

		--[[
		function self:OnBackPress()
			return false
		end
		]]
	end

	derma.DefineControl("NxGenericFramePaged", "", PANEL, "NxGenericFrame")
	derma.DefineControl("NxEditablePanelPaged", "", table.Copy(PANEL), "NxEditablePanel")
end

do -- LoadingSpinner
	local PANEL = {}

	local mat = CreateMaterial("NxCircle", "UnlitGeneric", {
		["$basetexture"] = "vgui/circle",
		["$translucent"] = 1,
		["$ignorez"] = 1,
		["$vertexcolor"] = 1,
		["$vertexalpha"] = 1,
	})

	local col = Color(255, 255, 255, 127)

	function PANEL:Paint(w, h)
		render.SetMaterial(mat)
		local x, y = self:LocalToScreen(w/2, h/2)
		render.DrawQuadEasy(Vector(x, y), -vector_up, w * math.sin(SysTime()), h * math.sin(SysTime()), col, 0)
		render.DrawQuadEasy(Vector(x, y), -vector_up, w * math.cos(SysTime()), h * math.cos(SysTime()), col, 0)
	end

	derma.DefineControl("LoadingSpinner", "", PANEL, "EditablePanel")
end

do -- NxDivLine
	local PANEL = {}

	function PANEL:Init()
		self:SetMouseInputEnabled(false)
		self:SetTall(1)
		self:DockMargin(0, MediumMargin, 0, MediumMargin)
	end

	function PANEL:Paint(w, h)
		surface.SetDrawColor(color_white)
		surface.DrawRect(0, 0, w, h)
	end

	derma.DefineControl("NxDivLine", "", PANEL, "Panel")
end

local color_inactive = Color(128, 128, 128, 200)
nxui_DTextEntry_Paint = function(panel, w, h)
	local col
	if panel:HasFocus() then
		col = color_white
	else
		col = color_inactive
	end

	surface.SetDrawColor(col)
	surface.DrawLine(0, h - 1, w, h - 1)

	if panel.GetPlaceholderText and panel.GetPlaceholderColor and panel:GetPlaceholderText() and panel:GetPlaceholderText():Trim() ~= "" and panel:GetPlaceholderColor() and (not panel:GetText() or panel:GetText() == "") then
		local oldText = panel:GetText()
		local str = panel:GetPlaceholderText()

		if (str:StartWith("#")) then
			str = str:sub(2)
		end

		str = language.GetPhrase(str)
		panel:SetText(str)
		panel:DrawTextEntryText(color_inactive, panel:GetHighlightColor(), color_white)
		panel:SetText(oldText)

		return
	end

	panel:DrawTextEntryText(color_white, panel:GetHighlightColor(), color_white)
end

function fixscrollbar(scroll)
	scroll.VBar:SetHideButtons(true)
	scroll.VBar:SetWide(yscale(10) + SmallMargin)
	scroll:SetSkin("NxShop")
end

local origDerma = DermaMenu
local DermaMenu = function(...)
	local x = origDerma(...)

	fixscrollbar(x)

	x.Paint = function(self, w, h)
		vgui.blurCopypaste(self, w, h)

		surface.SetDrawColor( 40, 40, 40, 200 )
		surface.DrawRect(0, 0, w, h)
	end

	x.AddOption = function(...)
		local ret = DMenu.AddOption(...)

		ret:SetFont("DermaNotDefault")
		ret:SetTextColor(color_white)

		ret.PerformLayout = function(...)
			DMenuOption.PerformLayout(...)

			ret:SetTall(yscale(32))
		end

		return ret
	end

	return x
end
FixedDermaMenu = DermaMenu


