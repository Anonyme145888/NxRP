local period = 1

local pause, sheet, list_sv, list_cl, tab_sv, tab_cl

local events

local event
function prof_start()
	local t = SysTime()
	if event then
		event[2] = event[2] + (t - event[1])
	end
	-- 1 начало отрезка
	-- 2 своё время
	-- 3 время низших
	-- 4 верхний
	event = {0, 0, 0, event}
	event[1] = SysTime()
end
function prof_finish(category, name1, name2)
	local t = SysTime()
	local t_self = event[2] + (t - event[1])
	local t_lower = event[3]
	table.insert(events[category], {FrameNumber(), t_self, t_lower, name1, name2, RealTime()})
	event = event[4]
	if event then
		event[3] = event[3] + t_self + t_lower
		event[1] = SysTime()
	end
end

local current
function prof(name)
	if not prof_enabled then return end
	if current then
		prof_finish("Special", current)
		current = nil
	end
	current = name
	if current then
		prof_start()
	end
end

local function prof_think()
	local t = RealTime()

	for _, tbl in pairs(events) do
		local f

		for k, v in ipairs(tbl) do
			if v[6] >= t - period then
				f = v[1]
				break
			end
		end

		if f then
			local n = 1

			for k, v in ipairs(tbl) do
				if v[1] >= f then
					n = k
					break
				end
			end

			if n > 1 then
				for k = n, #tbl do
					tbl[k - n + 1] = tbl[k]
				end
				for k = #tbl - n + 2, #tbl do
					tbl[k] = nil
				end

				-- n = n - 1
				-- for k = 1, #tbl do
				-- 	tbl[k] = tbl[n + k]
				-- end
			end
		end
	end
end

local Hooks = hook.GetTable()
local GAMEMODE = "GAMEMODE"
local function hookCall(name, gm, ...)
	local a, b, c, d, e, f

	local HookTable = Hooks[name]
	if HookTable ~= nil then
		for k, v in pairs(HookTable) do
			if isstring(k) then
				prof_start()
				a, b, c, d, e, f = v(...)
				prof_finish("Hook", name, k)
			elseif IsValid(k) then
				prof_start()
				a, b, c, d, e, f = v(k, ...)
				prof_finish("Hook", name, tostring(k))
			else
				HookTable[k] = nil
			end

			if a ~= nil then
				return a, b, c, d, e, f
			end
		end
	end

	if not gm then return end
	local GamemodeFunction = gm[name]
	if GamemodeFunction == nil then return end

	prof_start()
	a, b, c, d, e, f = GamemodeFunction(gm, ...)
	prof_finish("Hook", name, GAMEMODE)

	return a, b, c, d, e, f
end
prof_hook_call = prof_hook_call or hook.Call

local function netIncoming(len, client)
	local i = net.ReadHeader()
	local strName = util.NetworkIDToString(i)

	if not strName then return end

	local func = net.Receivers[strName:lower()]
	if not func then return end

	-- len includes the 16 bit int which told us the message name
	len = len - 16

	prof_start()
	func(len, client)
	prof_finish("Net", strName)
end
prof_net_incoming = prof_net_incoming or net.Incoming

local function overrideR(orig, func)
	local R = debug.getregistry()
	for k, v in pairs(R) do
		if v == orig then
			R[k] = func
		end
	end
	return func
end

local enthooks = {"AcceptInput", "Blocked", "BuildBonePositions", "CalcAbsolutePosition", "CanProperty", "DoingEngineSchedule", "DoSchedule", "Draw", "DrawTranslucent", "EndTouch", "EngineScheduleFinish", "ExpressionFinished", "GetAttackSpread", "GetRelationship", "ImpactTrace", "Initialize", "IsTranslucent", "KeyValue", "NextTask", "OnCondition", "OnEntityCopyTableFinish", "OnReloaded", "OnRemove", "OnRestore", "OnTakeDamage", "OnTaskComplete", "PassesTriggerFilters", "PhysicsCollide", "PhysicsSimulate", "PhysicsUpdate", "PostEntityCopy", "PostEntityPaste", "PreEntityCopy", "RenderOverride", "RunAI", "RunEngineTask", "RunTask", "ScheduleFinished", "SelectSchedule", "SetTask", "SetupDataTables", "SpawnFunction", "StartEngineSchedule", "StartEngineTask", "StartSchedule", "StartTask", "StartTouch", "StoreOutput", "TaskFinished", "TaskTime", "TestCollision", "Think", "Touch", "TriggerOutput", "UpdateTransmitState", "Use", "AcceptInput", "AdjustMouseSensitivity", "Ammo1", "Ammo2", "CalcView", "CalcViewModelView", "CanPrimaryAttack", "CanSecondaryAttack", "ContextScreenClick", "CustomAmmoDisplay", "Deploy", "DoDrawCrosshair", "DoImpactEffect", "DrawHUD", "DrawHUDBackground", "DrawWeaponSelection", "DrawWorldModel", "DrawWorldModelTranslucent", "Equip", "EquipAmmo", "FireAnimationEvent", "FreezeMovement", "GetCapabilities", "GetTracerOrigin", "GetViewModelPosition", "Holster", "HUDShouldDraw", "Initialize", "KeyValue", "OnDrop", "OnReloaded", "OnRemove", "OnRestore", "OwnerChanged", "PostDrawViewModel", "Precache", "PreDrawViewModel", "PrimaryAttack", "PrintWeaponInfo", "Reload", "RenderScreen", "SecondaryAttack", "SetDeploySpeed", "SetupDataTables", "SetWeaponHoldType", "ShootBullet", "ShootEffects", "ShouldDropOnDie", "TakePrimaryAmmo", "TakeSecondaryAmmo", "Think", "TranslateActivity", "TranslateFOV", "ViewModelDrawn"}
for k1 = #enthooks, 1, -1 do
	local v = enthooks[k1]
	for k2 = 1, k1 - 1 do
		if enthooks[k2] == v then
			table.remove(enthooks, k1)
			break
		end
	end
end

local function overrideent(ent)
	for _, name in ipairs(enthooks) do
		if type(ent[name]) == "function" and debug.getinfo(ent[name], "S").source ~= "=[C]" then
			ent.prof = ent.prof or {}
			ent.prof[name] = ent.prof[name] or ent[name]
			local old = ent.prof[name]
			local class = ent:GetClass()
			ent[name] = function(...)
				prof_start()
				local a, b, c, d, e, f = old(...)
				prof_finish("Entity", name, class)
				return a, b, c, d, e, f
			end
			ent.prof2 = ent.prof2 or {}
			ent.prof2[name] = ent[name]
		end
	end
end

local function OnEntityCreated(ent)
	timer.Simple(0, function()
		if prof_enabled and ent:IsValid() then
			overrideent(ent)
		end
	end)
end

local function setvalue(a, t_self, t_lower)
	if t_lower and t_lower ~= 0 then
		a:SetText(("%08.4f + %08.4f"):format(t_self, t_lower))
		a.Value = t_self + t_lower
	else
		a:SetText(("%08.4f"):format(t_self))
		a.Value = t_self
	end
end

local function display(list, cat, name1, name2, t_self, t_lower)
	for _, line in ipairs(list.Lines) do
		if line.Columns[1].Value == cat and line.Columns[2].Value == name1 and line.Columns[3].Value == name2 then
			setvalue(line.Columns[4], t_self, t_lower)
			return
		end
	end

	local line = list:AddLine(cat, name1, name2, 0)
	setvalue(line.Columns[4], t_self, t_lower)
end

net.Receive("prof", function()
	if not (prof_frame and prof_frame:IsValid() and not pause) then return end

	local total = 0

	while net.ReadBool() do
		local cat = net.ReadString()
		while net.ReadBool() do
			local name1 = net.ReadString()
			while net.ReadBool() do
				local name2, t_self, t_lower = net.ReadString(), net.ReadFloat(), net.ReadFloat()

				total = total + t_self

				display(list_sv, cat, name1, name2, t_self, t_lower)
			end
		end
	end

	setvalue(list_sv.total.Columns[4], total)

	list_sv:SortByColumn(4, true)

	--[[local eh = "local t = {\n"
	for k, v in ipairs(list_sv.Sorted) do
		if k > 50 then
			break
		elseif k > 1 and v.Columns[1].Value == "Hook" and not (v.Columns[2].Value == "Think" and v.Columns[3].Value == "prof") then
			eh = eh .. ("\t{'%s', '%s'},\n"):format(v.Columns[2].Value, v.Columns[3].Value)
		end
	end
	eh = eh .. "}"
	SetClipboardText(eh)]]

	if sheet.m_pActiveTab == tab_sv then
		net.Start("prof")
		net.SendToServer()
	end
end)

local function prof_timer()
	if pause then return end

	local f = FrameNumber()

	local total = 0

	local data = {}
	for cat, events in pairs(events) do
		local tbl = {}
		for _, event in ipairs(events) do
			-- ignore current frame, show only past frames
			if event[1] >= f then
				break
			end

			local name1 = event[4]
			local name2 = event[5] or event[4]
			tbl[name1] = tbl[name1] or {}
			tbl[name1][name2] = tbl[name1][name2] or {0, 0}
			tbl[name1][name2][1] = tbl[name1][name2][1] + event[2]
			tbl[name1][name2][2] = tbl[name1][name2][2] + event[3]
		end
		data[cat] = tbl
	end

	for cat, events in pairs(data) do
		for name1, tbl in pairs(events) do
			for name2, t in pairs(tbl) do
				local t_self = t[1] * 1000 / period
				local t_lower = t[2] * 1000 / period

				total = total + t_self

				display(list_cl, cat, name1, name2, t_self, t_lower)
			end
		end
	end

	setvalue(list_cl.total.Columns[4], total)

	list_cl:SortByColumn(4, true)

	--[[local eh = "local t = {\n"
	for k, v in ipairs(list_cl.Sorted) do
		if k > 60 then
			break
		elseif k > 1 and v.Columns[1].Value == "Hook" and not (v.Columns[2].Value == "Think" and v.Columns[3].Value == "prof") then
			eh = eh .. ("\t{'%s', '%s'},\n"):format(v.Columns[2].Value, v.Columns[3].Value)
		end
	end
	eh = eh .. "}"
	SetClipboardText(eh)]]
end

local function stop()
	prof_enabled = false

	hook.Remove("Think", "prof")
	timer.Destroy("prof")

	hook.Call = overrideR(hook.Call, prof_hook_call)
	net.Incoming = overrideR(net.Incoming, prof_net_incoming)

	hook.Remove("OnEntityCreated", "prof")
	for _, ent in ipairs(ents.GetAll()) do
		if ent.prof then
			for k, v in pairs(ent.prof) do
				if ent[k] == ent.prof2[k] then
					ent[k] = v
				end
			end
			ent.prof = nil
		end
	end

	current = nil
	pause = nil
	events = nil
end

local function start()
	prof_enabled = true

	events = {
		Hook = {},
		Timer = {},
		Entity = {},
		Special = {},
		Net = {},
	}

	hook.Add("Think", "prof", prof_think)
	timer.Create("prof", period, 0, prof_timer)

	hook.Call = overrideR(hook.Call, hookCall)
	net.Incoming = overrideR(net.Incoming, netIncoming)

	for _, ent in ipairs(ents.GetAll()) do
		overrideent(ent)
	end
	hook.Add("OnEntityCreated", "prof", OnEntityCreated)
end

concommand.Add("prof", function(ply)
	if not ply:IsSuperAdmin() then return end

	if prof_frame and prof_frame:IsValid() then
		prof_frame:Remove()
	end

	prof_frame = vgui.Create("DFrame")
	prof_frame:SetSize(1024, ScrH() / 2)
	prof_frame:Center()
	prof_frame:MakePopup()
	prof_frame:SetKeyboardInputEnabled(false)
	prof_frame:SetTitle("Profiler")

	function prof_frame:OnRemove()
		stop()
	end

	sheet = prof_frame:Add("DPropertySheet")
	sheet:Dock(FILL)

	list_cl = vgui.Create("DListView")
	tab_cl = sheet:AddSheet("Client", list_cl, "icon16/monitor.png").Tab
	list_cl:Dock(FILL)
	local cols_cl = {}
	table.insert(cols_cl, list_cl:AddColumn(""))
	table.insert(cols_cl, list_cl:AddColumn(""))
	table.insert(cols_cl, list_cl:AddColumn(""))
	table.insert(cols_cl, list_cl:AddColumn(""))

	list_sv = vgui.Create("DListView")
	tab_sv = sheet:AddSheet("Server", list_sv, "icon16/server.png").Tab
	list_sv:Dock(FILL)
	local cols_sv = {}
	table.insert(cols_sv, list_sv:AddColumn(""))
	table.insert(cols_sv, list_sv:AddColumn(""))
	table.insert(cols_sv, list_sv:AddColumn(""))
	table.insert(cols_sv, list_sv:AddColumn(""))

	list_cl.total = list_cl:AddLine("Total", "Total", "Total", 0)
	list_sv.total = list_sv:AddLine("Total", "Total", "Total", 0)

	sheet._SetActiveTab = sheet.SetActiveTab
	function sheet:SetActiveTab(tab)
		sheet:_SetActiveTab(tab)

		if not pause and tab == tab_sv then
			net.Start("prof")
			net.SendToServer()
		end

		local yes = tab == tab_cl and not pause
		if yes ~= prof_enabled then
			if yes then
				start()
			else
				stop()
			end
		end
	end

	local pausebutton = prof_frame:Add("DButton")
	pausebutton:SetPos(60, 2)
	pausebutton:SetSize(prof_frame:GetWide() - 176, 21)
	pausebutton:SetText("Pause")
	function pausebutton:DoClick()
		pause = not pause

		self:SetText(pause and "== Pause ==" or "Pause")

		if not pause and sheet:GetActiveTab() == tab_sv then
			net.Start("prof")
			net.SendToServer()
		end

		local yes = sheet:GetActiveTab() == tab_cl and not pause
		if yes ~= prof_enabled then
			if yes then
				start()
			else
				stop()
			end
		end
	end

	start()
end)