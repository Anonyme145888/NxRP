local Panel = FindMetaTable("Panel")

-- исправление великой проблемы с уезжающим в самый низ DTextEntry
function Panel:Dock2(dock)
	if self:GetParent() then
		self:SetZPos(#self:GetParent():GetChildren())
	end
	return self:Dock(dock)
end

esc = esc or {}
esc.StillFrames = 0
esc.panels = esc.panels or {}
esc.history = esc.history or {}

local function SetFocus(panel, inside)
	repeat
		if esc.panels[panel] then
			table.RemoveByValue(esc.history, panel)
			table.insert(esc.history, panel)
			break
		end
		panel = panel:GetParent()
	until not panel
end

local function close()
	for panel in pairs(esc.panels) do
		if not panel:IsValid() then
			esc.panels[panel] = nil
		end
	end

	for n, panel in backipairs(esc.history) do
		if not (panel:IsValid() and esc.panels[panel]) then
			table.remove(esc.history, n)
		elseif panel:IsVisible() and panel:IsEnabled() then
			return esc.panels[panel](panel) ~= false
		end
	end

	gui.EnableScreenClicker(false)
end

local DefaultCallback = function(self)
	if self.Close then
		self:Close()
	else
		self:Remove()
	end
end
function esc.RegisterPanel(panel, callback)
	esc.panels[panel] = callback or DefaultCallback
end
function Panel:RegisterGamePanel(callback)
	esc.RegisterPanel(self, callback)
end

function esc.PreventGameMenu()
	if gui.IsGameUIVisible() then
		esc.StillFrames = 1
		--render.CapturePixels()
	end

	gui.HideGameUI()
end

hook.Add("PostRenderVGUI", "!EscFix", function()
	if esc.StillFrames > 0 then
		--render.DrawTextureToScreen("_rt_fullscreen")
		render.DrawTextureToScreen("_rt_fullframefb")
		esc.StillFrames = esc.StillFrames - 1
	end
end)

local wasPressed = input.IsKeyDown(KEY_ESCAPE)

hook.Add("PreRender", "!EscFix", function()
	if input.IsKeyDown(KEY_ESCAPE) and gui.IsGameUIVisible() and not wasPressed then
		if close() then
			esc.PreventGameMenu()
		end
	end

	wasPressed = input.IsKeyDown(KEY_ESCAPE)
end)

hook.Add("VGUIMousePressed", "!EscFix", function(panel, code)
	if panel == vgui.GetWorldPanel() then
		close()
	else
		SetFocus(panel)
	end
end)

Panel._MakePopup = Panel._MakePopup or Panel.MakePopup
function Panel:MakePopup(...)
	SetFocus(self)
	return self:_MakePopup(...)
end

do -- fonts
	surface.CreateFont("DermaNotDefault", {
		size = yscale(20),
		--weight = 350,
		antialias = true,
		extended = true,
		font = "Roboto Condensed",
	})

	surface.CreateFont("RobotoC16", {
		size = yscale(16),
		--weight = 350,
		antialias = true,
		extended = true,
		font = "Roboto Condensed",
	})

	surface.CreateFont("DermaNotDefaultIcon", {
		size = yscale(20),
		antialias = true,
		extended = true,
		font = NX_ICONFONT,
	})

	surface.CreateFont("DermaNotLarge", {
		font = "Roboto Condensed",
		size = yscale(32),
		weight = 500,
		antialias = true,
		extended = true,
	})

	surface.CreateFont("DermaNotLargeIcon", {
		size = yscale(32),
		antialias = true,
		extended = true,
		font = NX_ICONFONT,
	})

	SmallMargin = yscale(5)
	MediumMargin = yscale(10)
	LargeMargin = yscale(20)
end

local matBlurScreen = Material("pp/blurscreen")
function vgui.blurCopypaste(self, w, h)
	if true then
		local x, y = self:LocalToScreen(0, 0)
		render.SetScissorRect(x, y, x + self:GetWide(), y + self:GetTall(), true)

		surface.SetMaterial( matBlurScreen )
		surface.SetDrawColor( 255, 255, 255, 255 )

		for i=0.33, 1, 0.33 do
			matBlurScreen:SetFloat( "$blur", 5 * i )
			matBlurScreen:Recompute()
			render.UpdateScreenEffectTexture()
			surface.DrawTexturedRect( x * -1, y * -1, ScrW(), ScrH() )
		end

		--surface.SetDrawColor( 0, 0, 0, 200 )
		--surface.DrawRect(0, 0, w, h)

		render.SetScissorRect(0, 0, 0, 0, false)
	else
		surface.SetDrawColor( 255, 255, 255, 15 )
		surface.DrawRect(0, 0, w, h)
	end
end

local PANEL = {}

function PANEL:Init()
	self:SetHTML([[<html>
	<head>
		<style>
		html, body {
			margin: 0;
			padding: 0;
			color: white;
			font-family: "Tahoma", Sans-Serif;
			font-size: 10.5px;
			font-weight: 600;
			opacity: 0.999;
			word-break: break-word;
			overflow-x: hidden;
		}

		a {
			color: inherit;
		}

		a:hover {
			background-color: rgba(255, 255, 255, 0.2);
		}

		a:active {
			background-color: rgba(200, 200, 200, 0.2);
		}

		.highlight {
			background-color: yellow !important;
		}
		</style>
	</head>
	<body>
		<script>
		var autoscroll = true;
		var userscroll = false;

		document.addEventListener("scroll", function(e) {
			if (userscroll) {
				autoscroll = (window.innerHeight + window.scrollY) >= document.body.offsetHeight;
				//console.log("SCRRR " + autoscroll);
			}
		})

		document.addEventListener("mousewheel", function() {
			//console.log("WRRR");
			userscroll = true;
		}, false);

		var debouncer;
		var lasthighlight;
		var busy = false;
		var cycles = 0;

		function SoftScroll() {
			if (autoscroll) {
				GotoTextEnd();
			}
		}

		function GotoTextEnd() {
			if (debouncer) {
				clearTimeout(debouncer);
				debouncer = undefined;
			}

			cycles++;
			var busy2 = cycles > 100;

			if (busy != busy2) {
				busy = busy2
				gmod.SetBusy(busy);
			}

			debouncer = setTimeout(function() {
				userscroll = false;
				window.scrollTo(0, document.body.scrollHeight);
				cycles = 0;
				if (busy) {
					busy = false;
					gmod.SetBusy(false);
				}
			}, 0);

			autoscroll = true;
		}

		var lastspan;
		var lastlink;

		function InsertColorChange(r, g, b, a) {
			var span = document.createElement("span");

			span.style.color = "rgba(" + r + ", " + g + ", " + b + ", " + a/255 + ")";

			if (lastlink) {
				lastlink.appendChild(span);
			} else {
				document.body.appendChild(span);
			}

			lastspan = span;
		}

		function InsertText(parent, str) {
			var r = str.split("\n")
			for (i = 0; i < r.length; i++) {
				if (i > 0) {
					parent.appendChild(document.createElement("br"));
				}
				var node = document.createTextNode(r[i]);
				parent.appendChild(node);
				//console.log(r[i]);
			}
		}

		function AppendText(str) {
			SoftScroll();

			var node = document.createTextNode(str);

			if (lastspan) {
				InsertText(lastspan, str);
			} else if (lastlink) {
				InsertText(lastlink, str);
			} else {
				InsertText(document.body, str);
			}
		}

		function SetText(str) {
			SoftScroll();

			document.body.innerHTML = "";
			InsertText(document.body, str);
		}

		function ClickEvent(e) {
			e.preventDefault();
			gmod.TextClick(e.target.data);
			if (lasthighlight) {
				lasthighlight.className = "";
			}
			e.target.className = "highlight";
			lasthighlight = e.target;
		}

		function ClearHighlight() {
			if (lasthighlight) {
				lasthighlight.className = "";
				lasthighlight = undefined;
			}
		}

		function InsertClickableTextStart(str) {
			var link = document.createElement("a");
			link.href = "#";
			link.data = str || "";
			link.onclick = ClickEvent;

			if (lastspan) {
				lastspan.appendChild(link);
			} else {
				document.body.appendChild(link);
			}

			lastlink = link;
			lastspan = undefined;
		}

		function InsertClickableTextEnd() {
			lastlink = undefined;
		}

		document.addEventListener("contextmenu", function(e) {
			if (e.target.data) {
				gmod.TextClick(e.target.data);
				if (lasthighlight) {
					lasthighlight.className = "";
				}
				e.target.className = "highlight";
				lasthighlight = e.target;
			} else {
				gmod.ContextMenu(window.getSelection().toString());
			}
			//e.preventDefault();
		}, false);

		function SelectAll() {
			var selection = window.getSelection();
			var range = document.createRange();
			range.selectNodeContents(document.body);
			selection.removeAllRanges();
			selection.addRange(range);
		}
		</script>
	</body>
	</html>]])

	self:AddFunction("gmod", "TextClick", function(str)
		self:ActionSignal("TextClicked", str)
	end)

	self.busy = false
	self:AddFunction("gmod", "SetBusy", function(status)
		self.busy = status
	end)

	self:AddFunction("gmod", "ContextMenu", function(str)
		local menu = DermaMenu()
		menu:AddOption(Translate("chat.context.text.copy"), function()
			SetClipboardText(str)
		end)
		menu:AddOption(Translate("chat.context.text.all"), function()
			self:Call("SelectAll();")
		end)
		menu:Open()
		menu:MakePopup()
	end)
end

function PANEL:GotoTextEnd()
	self:Call("GotoTextEnd();")
end

function PANEL:InsertColorChange(r, g, b, a)
	self:Call(("InsertColorChange(%d, %d, %d, %d);"):format(r, g, b, a))
end

function PANEL:AppendText(str)
	self:Call(("AppendText(\"%s\");"):format(string.JavascriptSafe(str)))
end

function PANEL:SetText(str)
	self:Call(("SetText(\"%s\");"):format(string.JavascriptSafe(str)))
end

function PANEL:InsertClickableTextStart(str)
	self:Call(("InsertClickableTextStart(\"%s\");"):format(string.JavascriptSafe(str)))
end

function PANEL:InsertClickableTextEnd()
	self:Call("InsertClickableTextEnd();")
end

function PANEL:ClearHighlight()
	self:Call("ClearHighlight();")
end

function PANEL:SetFontInternal() end

function PANEL:PaintOver(w, h)
	if self.busy then
		surface.SetDrawColor(64, 64, 64, 150)
		surface.DrawRect(0, 0, w, h)
	end
end

derma.DefineControl("RichText2HTML", "", PANEL, "DHTML")

do -- web icons
	file.CreateDir("nxserv")
	file.CreateDir("nxserv/iconcache")

	local querying = {}
	local exists = {}

	function LoadWebIcon(icon, size, cb)
		local fn = "nxserv/iconcache/" .. icon .. "__" .. size .. ".png"

		if exists[fn] then
			if cb then cb(true, fn) end
			return
		end

		if file.Exists(fn, "DATA") then
			exists[fn] = true
			if cb then cb(true, fn) end
			return
		end

		if querying[icon .. "__" .. size] then
			table.insert(querying[icon .. "__" .. size], cb)
			return
		end

		querying[icon .. "__" .. size] = {cb}

		http.Fetch("https://nxserv.eu/api/icons?icon=" .. icon .. "&size=" .. size, function(body, _, _, code)
			if code ~= 200 then
				for i, v in ipairs(querying[icon .. "__" .. size]) do
					if v then v(false) end
				end

				querying[icon .. "__" .. size] = nil

				return
			end

			file.Write(fn, body)

			for i, v in ipairs(querying[icon .. "__" .. size]) do
				if v then v(true, fn) end
			end

			querying[icon .. "__" .. size] = nil
		end, function()
			for i, v in ipairs(querying[icon .. "__" .. size]) do
				if v then v(false) end
			end

			querying[icon .. "__" .. size] = nil
		end)
	end
end

function Panel:SetPosCenter(x, y)
	self:SetPos(x - self:GetWide() / 2, y - self:GetTall() / 2)
end

function Panel:PaintBorder(w, h, color)
	surface.SetDrawColor(color or color_white)
	surface.DrawOutlinedRect(0, 0, w, h)
end

local borderColor = Color(150, 200, 250, 255)
function DrawAllBorders(p)
	p._Paint = p.Paint
	function p:Paint(w, h)
		if self._Paint then
			self:_Paint(w, h)
		end
		self:PaintBorder(w, h, borderColor)
	end
	for p in values(p:GetChildren()) do
		DrawAllBorders(p)
	end
end
