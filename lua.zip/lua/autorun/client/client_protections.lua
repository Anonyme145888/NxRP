local said = 0
hook.Add("PlayerBindPress", "lua_run_cl", function(pl, str, down)
	if str:find("lua_", 1, true) and (
		str:find("lua_run", 1, true) or str:find("lua_send", 1, true) or str:find("lua_open", 1, true)
	) then
		if said < 3 and down then
			said = said + 1
			ErrorNoHalt("Blocked running: " .. str .. "\n")
		end

		return true
	end
end)