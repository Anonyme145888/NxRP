DoorsSetup = DoorsSetup or {}

local matBlurScreen = Material( "pp/blurscreen" )

local function ScaleVGUI()
    local iH = ScrH()

    if ( iLastH == iH ) then
        return iMargin, iRoundness
    end

    -- Responsive fonts
    local ceil = math.ceil
    local iH1,iH2 = ceil(iH * 0.025), ceil( iH * .015)

    surface.CreateFont( "DoorsSetup.MainFont", { font = "Roboto", size = iH1 } )
    surface.CreateFont( "DoorsSetup.BtnFont", { font = "Roboto", size = iH2 } )

    iLastH, iMargin, iRoundness = iH, ceil( iH * .008 ), ceil( iH * .006 )

    return iMargin, iRoundness
end

DoorsSetup.Colors = {
    ["bg"] = Color(0,0,0,150),
    ["outline"] = Color(40,40,40,255),
    ["white"] = Color(255,255,255,255),
    ["black"] = Color(0,0,0,255),
    ["btn"] = Color(80,106,115,255),
    ["accept"] = Color(20,99,0),
    ["obtn"] = Color(45,61,66),
    ["oaccept"] = Color(10,48,0),
}

local function dBlur(pnl)

    local x, y = pnl:LocalToScreen(0, 0)

    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(matBlurScreen)

    for i = 0.33,1,0.33 do
        matBlurScreen:SetFloat("$blur", 1 * 5 * i)
        matBlurScreen:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(x * -1, y * -1, ScrW(), ScrH())
    end
end


function DoorsSetup:OpenMenu()

    ScaleVGUI()

    local main = vgui.Create("DFrame")
    main:SetSize(ScrW() * 0.2, ScrH() * 0.2)
    main:SetTitle("")
    main:ShowCloseButton(false)
    main:Center()
    main:MakePopup()

    main:SetKeyboardInputEnabled(true)

    local x,y = main:LocalToScreen(0, 0)

    function main:Paint(w,h)

        dBlur(self)

        --surface.SetDrawColor(PoliceLocker.Colors["bg"])
        surface.DrawRect(0,0,w,h)

        --surface.SetDrawColor(PoliceLocker.Colors["outline"])
        surface.DrawOutlinedRect(0,0,w,h,2)


    end

    local title = vgui.Create("DLabel", main)
    title:SetSize(main:GetWide(), main:GetTall() * .05)
    title:SetFont("DoorsSetup.MainFont")
    title:SetText("Création de porte")
    title:SizeToContents()
    title:SetPos( ( main:GetWide() / 2 ) - ( title:GetWide() / 2 ), main:GetTall() * 0.01)

    local close = vgui.Create("DButton", main)
    function close:DoClick() main:Remove() end
    close:SetSize(main:GetWide() * 0.18, main:GetTall() * 0.10)
    close:SetText("")
    close:SetPos(main:GetWide() * 0.8, main:GetTall() * .88)

    function close:Paint(w,h)

        surface.SetDrawColor(DoorsSetup.Colors["btn"])
        surface.DrawRect(0,0,w,h)
        surface.SetDrawColor(DoorsSetup.Colors["obtn"])
        surface.DrawOutlinedRect(0,0,w,h,1)

        draw.SimpleTextOutlined("[ESC] Retour", "DoorsSetup.BtnFont", w/2,h/2, DoorsSetup.Colors["white"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, DoorsSetup.Colors["black"])

    end

    local doorname = vgui.Create("DLabel", main)
    doorname:SetSize(main:GetWide(), main:GetTall() * .15)
    doorname:SetFont("DoorsSetup.MainFont")
    doorname:SetText("Nom de la porte")
    doorname:SizeToContents()
    doorname:SetPos( ( main:GetWide() / 2 ) - ( doorname:GetWide() / 2 ), main:GetTall() * 0.15)

    local door = vgui.Create("DTextEntry", main)
    door:SetSize(main:GetWide() * 0.5, main:GetTall() * 0.1)
    door:SetPos(main:GetWide() * 0.25, main:GetTall() * 0.3)
    door:SetFont("DoorsSetup.BtnFont")
    door:SetPlaceholderText("Nom de la porte")
    door:SetUpdateOnType(true)

    local acceptBtn = vgui.Create("DButton", main)
    acceptBtn:SetSize(main:GetWide() * 0.5, main:GetTall() * 0.1)
    acceptBtn:SetPos(main:GetWide() * 0.25, main:GetTall() * 0.45)
    acceptBtn:SetText("")
    function acceptBtn:Paint(w,h)

        surface.SetDrawColor(DoorsSetup.Colors["accept"])
        surface.DrawRect(0,0,w,h)
        surface.SetDrawColor(DoorsSetup.Colors["oaccept"])
        surface.DrawOutlinedRect(0,0,w,h,1)

        draw.SimpleTextOutlined("Accepter", "DoorsSetup.BtnFont", w/2,h/2, DoorsSetup.Colors["white"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, DoorsSetup.Colors["black"])

    end

    function acceptBtn:DoClick()

        if #door:GetValue() == 0 or door:GetValue() == " " then return end

        net.Start("DoorsSetup:AddDoors")
        net.WriteTable(DoorsSetup.SelectedDoors)
        net.WriteString(door:GetValue())
        net.SendToServer()

        DoorsSetup.SelectedDoors = {}

        main:Remove()

    end



    hook.Add("Think", "DoorsSetup:Think", function()

        if not IsValid(main) then hook.Remove("Think", "DoorsSetup:Think") end

        if not input.IsKeyDown(KEY_ESCAPE) then return end

        gui.HideGameUI()

        main:Remove()

    end)

end

net.Receive("DoorsSetup:SendDoors", function()
    DoorsSetup.Doors = net.ReadTable()
    DoorsSetup.DoorsID = net.ReadTable()
end)
