local PANEL = {}

function PANEL:Init()
	self.visible = true
	ray.PanelC(self)
	self.tickets = {}

	self:SetKeyboardInputEnabled(false)
	--self:SetWide(yscale(400))
	self:SetWide(math.min(495, yscale(400)))
	self:SetPos(ScrW() - self:GetWide() - 5, 528 + 30 + 10)
	self:SetTall(ScrH() - (528 + 30 + 10) - 10 - yscale(150))

	self:DockPadding(0, 0, 0, 0)

	local scroll = self:Add("DScrollPanel")
	self.scroll = scroll
	fixscrollbar(scroll)
	scroll:Dock(FILL)

	scroll.OnMousePressed = function(s, code)
		hook.Run("VGUIMousePressed", vgui.GetWorldPanel())
	end


	for i = 1, 64 do
		--self:Data(i, true, "test", Vector(), 0, {[LocalPlayer()] = true})
	end
end

function PANEL:Data(accid, open, entries, pos, name, status, workers, chatid, time)
	local pnl = self.tickets[accid]

	if not IsValid(pnl) then
		pnl = self.scroll:Add("ReportTicket")
		pnl:Dock(TOP)
		pnl:DockMargin(0, 0, 0, SmallMargin)
	end

	pnl:Data(accid, open, entries, pos, name, status, workers, chatid, time)
	self.tickets[accid] = pnl

	if not open then
		self.tickets[accid] = nil
		pnl:Remove()
	end
end

local prevMon
function PANEL:Think()
	local now = ray.IsMonitoringVisible and ray.IsMonitoringVisible()
	if prevMon ~= now then
		prevMon = now

		local monitoringTall = (ray.IsMonitoringVisible and ray.IsMonitoringVisible()) and 528 + 10 or 0
		local wantedTall = ScrH() - (30 + monitoringTall) - 10 - yscale(150)

		self:SetPos(ScrW() - self:GetWide() - 5, 30 + monitoringTall)
		self:SetTall(ScrH() - (30 + monitoringTall) - 10 - yscale(150))
	end
end

--[[
function PANEL:Paint(w, h)
	surface.SetDrawColor(0, 0, 0, 100)
	surface.DrawRect(0, 0, w, h)
end
]]

derma.DefineControl("TicketsPanel", "", PANEL, "EditablePanel")

---------------------------------------------------------------------------

local colors = {
	new = Color(0x30, 0x3F, 0x9F),
	subbed = Color(0xF9, 0xC8, 0x25),
	inwork = Color(0x45, 0x5A, 0x64),
	closed = Color(0x33, 0x69, 0x1E),
}

local STATUS_NEW = 0
local STATUS_INWORK = 1
local STATUS_CLOSED = 2

local translation = {
	[STATUS_NEW] = "new",
	[STATUS_INWORK] = "inwork",
	[STATUS_CLOSED] = "closed",
}

for k, v in pairs(colors) do
	colors[k] = {v}

	local h, s, v = ColorToHSV(v)

	table.insert(colors[k], HSVToColor(h, s * 0.8, math.min(1, v * 1.2)))
	table.insert(colors[k], HSVToColor(h, s * 0.8, v * 0.8))
end

local PANEL = {}

local function topsidePaint(self, w, h)
	local scheme = colors[self.parent.status] or colors.closed

	local col = scheme[1]
	local otl = false

	if self:IsDown() or self.m_bSelected or self.namebuttons:IsDown() or self.namebuttons.m_bSelected then
		otl = true
		col = scheme[3]
	elseif self.Hovered or self.namebuttons.Hovered then
		col = scheme[2]
	end

	surface.SetAlphaMultiplier(0.9)
	surface.SetDrawColor(col)
	if otl then
		surface.DrawRect(1, 1, w - 2, h - 2)
		--draw.RoundedBox(1.5, 1, 1, w - 2, h - 2, col)
	else
		--draw.RoundedBox(1.5, 0, 0, w, h, col)
		surface.DrawRect(0, 0, w, h)
	end
	surface.SetAlphaMultiplier(1)

	surface.SetDrawColor(0, 0, 0, 150)
	surface.DrawOutlinedRect(0, 0, w, h)
end

function PANEL:Init()
	self.status = "new"
	self.subbed = false
	self.buttons = {}

	self:SetTall(yscale(100))

	local topside = self:Add("NxButton")
	self.topside = topside
	topside.parent = self
	topside:DockPadding(MediumMargin, MediumMargin, MediumMargin, MediumMargin)
	topside:SetText("")
	topside:Dock(TOP)

	local namebuttons = topside:Add("DButton")
	topside.namebuttons = namebuttons
	namebuttons:SetMouseInputEnabled(true)
	namebuttons:SetDoubleClickingEnabled(false)
	namebuttons:SetText("")
	namebuttons.Paint = function() end
	self.namebuttons = namebuttons
	namebuttons:Dock(TOP)

	namebuttons:SetCursor("hand")
	namebuttons.DoClick = function()
		topside:DoClick()
	end
	namebuttons.DoRightClick = function()
		topside:DoRightClick()
	end

	topside.Paint = topsidePaint

	self.cancel = namebuttons:Add("NxButton")
	self.cancel:SetMouseInputEnabled(true)
	self.cancel:Dock(RIGHT)
	self.cancel:SetText("Cancel")
	self.cancel.DoClick = function()
		self:SendNetCommand(4)
	end
	self.cancel:SizeToContents()
	self.cancel:SetTall(yscale(20))
	self.cancel:SetTooltip("Revert ticket close")
	self.cancel:DockMargin(4, 0, 0, 0)

	local function chat(pl)
		if not IsValid(pl) then
			LocalPlayer():ChatPrint("Player is gone")
			return
		end

		wChat:SetActive(true)

		wChat.tabs.newpm:OnPlayerSelected(pl)

		if ray.HasAccess("anon_chat") and IsValid(wChat.tabs[pl:SteamID()]) then
			wChat.tabs[pl:SteamID()].persona = 2
		end

		--[[
		local tab = wChat:GetPMTab("REPORT_" .. self.chatid)
		tab.SheetData.Tab:DoClick()
		]]
	end

	for i, v in backipairs({
		{
			"icon16/briefcase.png",
			function()
				local new = not self.subbed
				self:SendNetCommand(new and 0 or 1)
				self:Expand(new)
			end,
			"Toggle working status"
		},
		{
			"icon16/table.png",
			function()
				ray.MonitoringFilter(self.plname, self.accid)
			end,
			"Open monitoring"
		},
		{
			"icon16/user_go.png",
			function()
				if not self.subbed then
					self:SendNetCommand(0)
					self:Expand(true)
				end
				self:RunCommand("goto", self.accid)
			end, "TP to player"
		},
		{
			"icon16/world_go.png",
			function()
				if not self.subbed then
					self:SendNetCommand(0)
					self:Expand(true)
				end
				self:RunCommand("goto", self.pos.x .. " " .. self.pos.y .. " " .. self.pos.z)
			end,
			"TP to report position"
		},
		{
			"icon16/comments.png",
			function()
				chat(self.pl)
			end,
			"Chat"
		},
		{
			"icon16/accept.png",
			function()
				self:SendNetCommand(2)
				self:Expand(false)
			end,
			"Mark as resolved"
		},
		-- {
		-- 	"icon16/cancel.png",
		-- 	function()
		-- 		self:SendNetCommand(3)
		-- 		self:Expand(false)
		-- 	end,
		-- 	"Dismiss ticket (doesn't notify player)"
		-- },
	}) do
		local b = namebuttons:Add("NxButton")
		b:SetMouseInputEnabled(true)
		b:Dock(RIGHT)
		b:SetText("")
		b.DoClick = v[2]
		b:SetSize(yscale(20), yscale(20))
		b:SetTooltip(v[3])
		b:DockPadding(2, 2, 2, 2)

		local i = b:Add("DImage")
		i:SetImage(v[1])
		i:Dock(FILL)

		local m = namebuttons:Add("EditablePanel")
		m:SetWide(SmallMargin)
		m:Dock(RIGHT)

		table.insert(self.buttons, b)
		table.insert(self.buttons, m)
	end

	local time = namebuttons:Add("DLabel")
	self.time = time
	time:SetMouseInputEnabled(false)
	time:SetFont("DermaNotDefault")
	time:SetText(" - 12:30")
	time:SetExpensiveShadow(1, color_black)
	time:SetColor(color_white)
	time:SizeToContents()
	time:Dock(RIGHT)
	time:SetContentAlignment(4)

	local name = namebuttons:Add("DLabel")
	self.name = name
	name:SetMouseInputEnabled(false)
	name:SetFont("DermaNotDefault")
	--name:SetText("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
	name:SetText("Донат Апельсинов")
	name:SetExpensiveShadow(1, color_black)
	name:SetColor(color_white)
	name:SizeToContents()
	name:Dock(FILL)
	name:SetContentAlignment(4)

	namebuttons:SetTall(yscale(20))

	self.shortreason = topside:Add("DLabel")
	self.shortreason:SetFont("DermaNotDefault")
	self.shortreason:SetText("...")
	self.shortreason:SetExpensiveShadow(1, color_black)
	self.shortreason:SetColor(color_white)
	self.shortreason:SizeToContents()
	self.shortreason:Dock(TOP)
	self.shortreason:DockMargin(0, SmallMargin, 0, 0)

	local reason = topside:Add("DLabel")
	self.reason = reason
	reason:SetFont("DermaNotDefault")
	reason:SetText("Имя:  Alex Sleek Нарушение: 4.Ваша цель — не победить всех, не убивайте всех на своём пути. Каждое убийство должно иметь достойную причину. (Random DeathMatch, RDM)")
	--reason:SetWrap(true)
	reason:SetExpensiveShadow(1, color_black)
	reason:SetColor(color_white)
	--reason:SetAutoStretchVertical(true)
	reason:SizeToContents()
	reason:Dock(TOP)
	reason:DockMargin(0, SmallMargin, 0, 0)

	topside:InvalidateLayout(true)
	topside:SizeToChildren(false, true)

	local drawer = self:Add("EditablePanel")
	self.drawer = drawer
	drawer:DockPadding(MediumMargin, MediumMargin, MediumMargin, MediumMargin)
	drawer:Dock(TOP)

	self.workers = drawer:Add("EditablePanel")
	self.workers:Dock(TOP)
	self.workers:SetTall(0)

	--[[
	for k, v in pairs({"Хамми Кофельнагель", "Отец Смоук"}) do
		local moder = drawer:Add("DLabel")
		moder:SetFont("DermaNotDefault")
		moder:SetText(v)
		moder:SizeToContents()
		moder:Dock(TOP)
	end
	]]

	--[[
	убрано, пока нет специального чата и возможности показывать последнее сообщения чата здесь

	local chatDock = drawer:Add("EditablePanel")
	chatDock:Dock(TOP)

	local doChat = chatDock:Add("NxButton")
	doChat:SetText("Chat")
	doChat:AutoSize()
	doChat:Dock(LEFT)
	doChat.DoClick = function()
		chat(self.pl)
	end

	chatDock:InvalidateLayout(true)
	chatDock:SizeToChildren(false, true)
	]]

	self:Expand(false)

	topside.DoClick = function()
		self:Expand(not drawer:IsVisible())
	end

	topside.DoRightClick = function()
		local m = DermaMenu()
		m:AddOption(("%s (%d)"):format(IsValid(self.pl) and self.pl:Name() or self.plname, self.accid)):SetEnabled(false)
		m:AddOption(os.date("%F %T (your local time)", self.itime)):SetEnabled(false)
		m:AddSpacer()
		m:AddOption("Copy AccountID", function() SetClipboardText(self.accid) end)

		for i, v in ipairs(self.entries) do
			if v.type ~= 1 or v.aid == 0 then continue end

			m:AddSpacer()
			m:AddOption(("%s (%d)"):format(v.name or "<error>", v.aid)):SetEnabled(false)
			m:AddOption("Copy AccountID", function() SetClipboardText(v.aid) end)
			m:AddOption("Monitoring", function() ray.MonitoringFilter(v.name, v.aid) end)
			m:AddOption("Chat", function() chat(player.GetByAccountID(v.aid)) end)
		end

		m:Open()
	end


	self:InvalidateLayout(true)
	drawer:InvalidateLayout(true)
	drawer:SizeToChildren(false, true)
	self:SizeToChildren(false, true)
end

function PANEL:Expand(state)
	self.drawer:SetVisible(state)
	self.reason:SetVisible(state)
	self.shortreason:SetVisible(not state)
end

function PANEL:UpdateWorkers(workers)
	self.workers:Clear()

	local any = false
	for pl, cachedName in pairs(workers) do
		any = true
		local moder = self.workers:Add("DLabel")
		moder:SetFont("DermaNotDefault")
		moder:SetText(pl:IsValid() and pl:Name() or cachedName or "???")
		moder:SizeToContents()
		moder:Dock(TOP)
	end

	self.workers:DockMargin(0, 0, 0, any and MediumMargin or 0)

	self.workers:InvalidateLayout(true)
	self.workers:SizeToChildren(false, true)
	self.drawer:InvalidateLayout(true)
	self.drawer:SizeToChildren(false, true)
end

function PANEL:Data(accid, open, entries, pos, name, status, workers, chatid, time)
	self.pl = player.GetByAccountID(accid) or NULL
	self.accid = accid
	
	if open then
		self.chatid = chatid

		self.name:SetText(name)
		self.name:SizeToContents()
		self.time:SetText((" - %s"):format(os.date("%H:%M", time)))
		self.time:SizeToContents()

		self.itime = time
		self.entries = entries
		
		self.subbed = false
		self.status = translation[status]
		if workers[LocalPlayer()] and status == STATUS_INWORK then
			self.status = "subbed"
			self.subbed = true
		end

		local text = {}

		for k, v in pairs(entries) do
			if v.type == 0 then
				table.insert(text, ("Question: %s"):format(v.text))
			elseif v.type == 1 then
				local name = v.aid ~= 0 and ("%s (%d)"):format(v.name or "<error>", v.aid) or "Unknown"
				table.insert(text, ("%s - %s"):format(name, v.text))
			end
		end

		text = table.concat(text, "\n")

		local wrappedText = surface.textWrap(text, "DermaNotDefault", math.min(495, yscale(400)) - 20 - MediumMargin * 2)
		local shortText = wrappedText:match("([^\n]+)")

		self.reason:SetText(wrappedText)
		self.reason:SizeToContents()

		self.shortreason:SetText(shortText .. (shortText ~= wrappedText and "..." or ""))
		self.shortreason:SizeToContents()

		self.pos = pos
		self.plname = name

		self:UpdateWorkers(workers)

		self.cancel:SetVisible(self.status == "closed")

		for k, v in pairs(self.buttons) do
			v:SetVisible(self.status ~= "closed")
		end
	else
		self.status = "closed"

		for k, v in pairs(self.buttons) do
			v:SetVisible(false)
		end

		self.cancel:SetVisible(false)
	end
end

function PANEL:SendNetCommand(cmd)
	net.Start("Ticket")
		net.WriteUInt(self.accid, 32)
		net.WriteUInt(cmd, 4)
	net.SendToServer()
end

function PANEL:RunCommand(...)
	if ray.HasAccess("silent") then
		RunConsoleCommand("rays", ...)
	else
		RunConsoleCommand("ray", ...)
	end
end

function PANEL:Think()
	--self.topside:SetTall(MediumMargin + self.namebuttons:GetTall() + SmallMargin + self.reason:GetTall() + MediumMargin)
	self.topside:SizeToChildren(false, true)
	self:SizeToChildren(false, true)
end

function PANEL:Paint(w, h)
	surface.SetDrawColor( 40, 40, 40, 200 )
	surface.DrawRect(0, 0, w, h)
end

derma.DefineControl("ReportTicket", "", PANEL, "EditablePanel")

---------------------------------------------------------------------------

if IsValid(spanwedTicketsWindow) then
	spanwedTicketsWindow:Remove()
	spanwedTicketsWindow = nil
end

function SpawnTicketsWindow()
	if IsValid(spanwedTicketsWindow) or not ray.HasAccess("tickets") then return end
	spanwedTicketsWindow = vgui.Create("TicketsPanel")
end

WaitRun("RayUpdateRank", "Tickets", function()
	local access = ray.HasAccess("tickets")
	if access ~= IsValid(spanwedTicketsWindow) then
		if access then
			SpawnTicketsWindow()
		else
			spanwedTicketsWindow:Remove()
		end
	end
end)

hook.Add("PlayerBindPress", "F6", function(_, bind, pressed)
	if bind == input.LookupKeyBinding(KEY_F6) and ray.HasAccess("tickets") then
		return true
	end
end)

local trapped = false
hook.Add("Think", "F6", function()
	if not ray.HasAccess("tickets") then return end

	local keyDown = input.IsKeyDown(KEY_F6)
	if keyDown and not trapped then
		spanwedTicketsWindow.visible = not spanwedTicketsWindow.visible
	end
	trapped = keyDown

	local should = hook.Run("HUDShouldDraw", "spanwedTicketsWindow")
	if should ~= false then
		should = spanwedTicketsWindow.visible
	end
	spanwedTicketsWindow:SetVisible(should)
end)

net.Receive("Ticket", function(len)
	SpawnTicketsWindow()

	local accid = net.ReadUInt(32)
	local open = net.ReadBool()

	if open then
		local entries = ray.ReadList(function()
			local type = net.ReadUInt(1)
			local text = net.ReadString()
			local aid = type == 1 and net.ReadUInt(32) or nil
			local name = type == 1 and net.ReadString() or nil

			return {
				type = type,
				text = text,
				aid = aid,
				name = name,
			}
		end)

		local pos = net.ReadVector()
		local name = net.ReadString()
		local status = net.ReadUInt(4)
		local workers = net.ReadTable()
		--local chatid = net.ReadUInt(16)
		local chatid = nil
		local time = net.ReadUInt(32)

		spanwedTicketsWindow:Data(accid, open, entries, pos, name, status, workers, chatid, time)
	else
		spanwedTicketsWindow:Data(accid, open)
	end
end)
