NotifCenter = {}
NotifCenter.messages = {}
NotifCenter.messagesSorted = {}

local dbg = IsValid(me) and me:IsPlayer() and me:IsAdmin()

--

function NotifCenter.Close(noticeId)
	net.Start("NotifCenter")
		net.WriteUInt(0, 4)
		net.WriteUInt(noticeId, 32)
	net.SendToServer()

	NotifCenter.Remove(noticeId)
end

function NotifCenter.Delivery(inbox)
	for i, v in ipairs(inbox) do
		local ex = NotifCenter.messages[v.id]
		if ex then
			table.Merge(ex, v)
			if dbg then
				print("NotifCenter_MsgUpdated")
				PrintTable(v)
			end
			hook.Run("NotifCenter_MsgUpdated", v.id)
		else
			NotifCenter.messages[v.id] = v
			table.insert(NotifCenter.messagesSorted, v)
			if dbg then
				print("NotifCenter_MsgCreated")
				PrintTable(v)
			end
			hook.Run("NotifCenter_MsgCreated", v.id)
		end
	end
end

function NotifCenter.Remove(noticeId)
	print("NotifCenter_MsgRemoved", noticeId)
	hook.Run("NotifCenter_MsgRemoved", noticeId)
	local ex = NotifCenter.messages[noticeId]
	if not ex then return end
	table.iRemoveByValue(NotifCenter.messagesSorted, ex)
	NotifCenter.messages[noticeId] = nil
end

--

net.Receive("NotifCenter", function(len)
	local cmd = net.ReadUInt(4)

	if cmd == 0 then
		local inbox = ray.ReadList(function()
			return {
				id = net.ReadUInt(32),
				type = net.ReadString(),
				format = net.ReadUInt(4),
				content = net.ReadString(),
				time = net.ReadUInt(32),
			}
		end)
		NotifCenter.Delivery(inbox)
	elseif cmd == 1 then
		local ids = ray.ReadList(net.ReadUInt, 32)
		for i, id in ipairs(ids) do
			NotifCenter.Remove(id)
		end
	end
end)
