chat = chat or {}

chat.templates = {}

function chat.SendText(pl, ...)
	chat.AddText(...)
end

function chat.SendTpl(pl, tpl, ...)
	chat.AddTpl(tpl, ...)
end

function chat.AddTemplate(name, fn)
	chat.templates[name] = fn
end

function chat.AddTpl(tpl, ...)
	local template = chat.templates[tpl]

	if not template then
		ErrorNoHalt("No template for message!")
		print(tpl)
		PrintTable({...})
		return
	end

	chat.AddText(template(...))
end

net.Receive("_ChatAddText", function(msgLen)
	local len = net.ReadUInt(8)

	local tbl = {}

	for i = 1, len do
		table.insert(tbl, net.ReadType())
	end

	chat.AddText(unpack(tbl))
end)

net.Receive("_ChatAddTpl", function(msgLen)
	local tpl = net.ReadString()
	local tbl = {}
	tbl = net.ReadTable()

	chat.AddTpl(tpl, unpack(tbl))
end)

TYPE_PERSON = 127
net.ReadVars[TYPE_PERSON] = function() return NewPlayerProxy(net.ReadEntity(), net.ReadString(), net.ReadUInt(32)) end

hook.Add("PostGamemodeLoaded", "FixOnPlayerChat", function()
	gamemode.Get("base").OnPlayerChat = function(self, player, strText, bTeamOnly, bPlayerIsDead)
		local tab = {}

		if (bPlayerIsDead) then
			table.insert(tab, Color(255, 30, 40))
			table.insert(tab, "*DEAD* ")
		end

		if (bTeamOnly) then
			table.insert(tab, Color(30, 160, 40))
			table.insert(tab, "(TEAM) ")
		end

		if (IsValid(player) or getmetatable(player) == PlayerProxy) then
			table.insert(tab, player)
		else
			table.insert(tab, "[...]")
		end

		table.insert(tab, Color(255, 255, 255))
		table.insert(tab, ": " .. strText)
		chat.AddText(unpack(tab))

		return true
	end
end)

-- Default templates

local lime = Color(204, 255, 0)
chat.AddTemplate("chat.pm.incoming", function(prefix, message, hidden)
	return lime, "[" .. Translate("chat.pm.pm") .. "] ", color_white, prefix, color_white, (hidden and (": " .. message) or "")
end)

chat.AddTemplate("chat.pm.outcoming", function(prefix, message, hidden)
	return lime, "[" .. Translate("chat.pm.pm") .. "] " .. Translate("chat.pm.sent_to") .. " ", color_white, prefix, color_white, (hidden and (": " .. message) or "")
end)

chat.AddTemplate("chat.no_prefixes", function()
	return lime, Translate("chat.prefixes_hint")[1], color_white, " TAB ", lime, Translate("chat.prefixes_hint")[2]
end)

-- Tests...

chat.AddTemplate("test1", function(tbl)
	return Color(0, 255, 0), "Hello, ", Color(255, 255, 0), tbl.name
end)

chat.AddTemplate("test2", function(name, surname, ent)
	return Color(0, 255, 0), "Hello, ", Color(255, 255, 0), name, " ", Color(0, 0, 255), surname, Color(255, 0, 0), ". ", tostring(ent), " ", ent
end)