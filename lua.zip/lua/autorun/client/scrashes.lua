if not GetTimeoutInfo then return end

local tolerance = 1.1
local crashed = false

hook.Add("Tick", "Crash_Ticker", function()
	local timingOut, time = GetTimeoutInfo()
	if (time > tolerance) then
		crashed = true
		disableReconnect = false
		hook.Run("CrashTick", true, time + tolerance)
	elseif crashed then
		crashed = false
		hook.Run("CrashTick", false)
	end
end)