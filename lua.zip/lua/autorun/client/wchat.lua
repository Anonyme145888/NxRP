-- wChat (wide Chat or something)
FindMetaTable("Player").GetFont = function(self) return self:GetNWString("NxPremFont", nil) end
PlayerProxy = {}

function PlayerProxy:__index(key)
    if PlayerProxy[key] then return PlayerProxy[key] end
    if self.pl:IsValid() and self.pl[key] then return isfunction(self.pl[key]) and function(a, ...) return self.pl[key](a == self and self.pl or a, ...) end or self.pl[key] end
end

function PlayerProxy:Name()
    return self.name
end

function PlayerProxy:AccountID()
    return self.aid
end

function PlayerProxy:SteamID()
    return rayid(self.aid)
end

function PlayerProxy:Team()
    return self.pl:IsValid() and self.pl:Team() or TEAM_CONNECTING
end

function PlayerProxy:GetFont()
    return self.pl:IsValid() and self.pl:GetNWString("NxPremFont", nil) or nil
end

PlayerProxy.Nick = PlayerProxy.Name
PlayerProxy.GetName = PlayerProxy.Name

function NewPlayerProxy(pl, name, aid)
    return setmetatable({
        pl = pl,
        name = name,
        aid = aid
    }, PlayerProxy)
end

net.Receive("wChat", function(len)
    local pl = net.ReadEntity()
    local name = net.ReadString()
    local aid = net.ReadUInt(32)
    local team = net.ReadBool()
    local msg = net.ReadString()
    local alive = net.ReadBool()
    hook.Run("OnPlayerChat", NewPlayerProxy(pl, name, aid), msg, team, not alive)
end)

function SendMessage(str, chatType, persona)
    net.Start("wChat")
    net.WriteString(chatType or "all")
    net.WriteString(str)
    net.WriteUInt(persona or 0, 2)
    net.SendToServer()
end

local FontSize = CreateClientConVar("wchat_fontsize2", "16", true, false)
local Blur = CreateClientConVar("wchat_blur", "1", true, false)
local ShowTime = CreateClientConVar("wchat_timestamps", "0", true, false)
local NoPrivacy = CreateClientConVar("wchat_noprivacy", "0", true, false)
local lime = Color(204, 255, 0)
local red_sea = Color(31, 64, 55)
local thetime = Color(150, 200, 255)
local color_yellow = Color(255, 255, 0)
local LastFocus

local emotes = {
    ["3"] = "3.png",
    ["akko"] = "akko.gif",
    ["angeryfrench"] = "angeryfrench.png",
    ["angeryshake"] = "angeryshake.gif",
    ["animeahhhhh"] = "animeahhhhh.gif",
    ["animebooty"] = "animebooty.gif",
    ["animeeyes"] = "animeeyes.gif",
    ["bakabear"] = "bakabear.gif",
    ["banned"] = "banned.png",
    ["bear"] = "bear.gif",
    ["beargo"] = "beargo.gif",
    ["bearstab"] = "bearstab.gif",
    ["blobhang"] = "blobhang.gif",
    ["clapclap"] = "clapclap.gif",
    ["colorfuldino"] = "colorfuldino.gif",
    ["dabbingyeet"] = "dabbingyeet.gif",
    ["dirtblock"] = "dirtblock.gif",
    ["drakeno"] = "drakeno.png",
    ["drakeyes"] = "drakeyes.png",
    ["dumb"] = "dumb.png",
    ["dvathinker"] = "dvathinker.png",
    ["e"] = "e.png",
    ["excusemewtf"] = "excusemewtf.gif",
    ["ez"] = "ez.png",
    ["fidgetspinner"] = "fidgetspinner.gif",
    ["fire"] = "fire.gif",
    ["gaben"] = "gaben.png",
    ["gachigasm"] = "gachigasm.png",
    ["gmod"] = "gmod.png",
    ["hanekawasmug"] = "hanekawasmug.gif",
    ["harold"] = "harold.png",
    ["hentai"] = "hentai.gif",
    ["hyperneko"] = "hyperneko.gif",
    ["jabami"] = "jabami.jpg",
    ["joyrow"] = "joyrow.gif",
    ["kaboom"] = "kaboom.gif",
    ["kannabear"] = "kannabear.png",
    ["knifethink"] = "knifethink.png",
    ["kumikorun"] = "kumikorun.gif",
    ["loading"] = "loading.gif",
    ["madblob"] = "madblob.gif",
    ["mikupeer"] = "mikupeer.png",
    ["nooooooo"] = "nooooooo.png",
    ["oilup"] = "oilup.png",
    ["ok_hand"] = "ok_hand.gif",
    ["omegalul"] = "omegalul.png",
    ["oof"] = "oof.png",
    ["orehus"] = "orehus.png",
    ["pantsfast"] = "pantsfast.gif",
    ["partybear"] = "partybear.gif",
    ["pepecopter"] = "pepecopter.gif",
    ["pepelmfao"] = "pepelmfao.gif",
    ["peperain"] = "peperain.gif",
    ["polarbroke"] = "polarbroke.gif",
    ["polarcool"] = "polarcool.gif",
    ["polarfire"] = "polarfire.gif",
    ["polargirl"] = "polargirl.gif",
    ["polarok"] = "polarok.gif",
    ["polarspace"] = "polarspace.gif",
    ["policebear"] = "policebear.gif",
    ["prideparrot"] = "prideparrot.gif",
    ["rainbowpuke"] = "rainbowpuke.gif",
    ["really"] = "really.png",
    ["reee"] = "reee.gif",
    ["reggin"] = "reggin.gif",
    ["ricardoflick"] = "ricardoflick.gif",
    ["ricardosmile"] = "ricardosmile.png",
    ["ricardosmug"] = "ricardosmug.png",
    ["rollsafe"] = "rollsafe.png",
    ["sadcat"] = "sadcat.png",
    ["salt"] = "salt.png",
    ["spurdo"] = "spurdo.png",
    ["superfastspin"] = "superfastspin.gif",
    ["thankong"] = "thankong.png",
    ["thinking"] = "thinking.png",
    ["tomlul"] = "tomlul.png",
    ["tsutail"] = "tsutail.gif",
    ["ultrachomp"] = "ultrachomp.gif",
    ["waifukiss"] = "waifukiss.gif",
    ["waitwhat"] = "waitwhat.png",
    ["wall"] = "wall.png",
    ["weewoo"] = "weewoo.gif",
    ["woke"] = "woke.png",
    ["wriwd"] = "wriwd.png",
    ["wtf"] = "wtf.png",
    ["yoshihammer"] = "yoshihammer.gif",
    ["zabivaka"] = "zabivaka.png",
    ["zuccwater"] = "zuccwater.png"
}

do
    local pm = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAAA02lDQ1BpY2MAABjTY2BgTMhJzi1mMWBgyM0rKXIPcoyMiIxSYL/PwMEgyCDGoMAglphcXOAb7BbCgBN8u8bACKIv64LMYiANsKSkFicD6S1AbJFcUFQCpN8AsV95SQGQzWgDZItkhwQ5A9kBQLZAbk5pMlQvyFae1LzQYCAtA8bpDEUMiQyVQHcnMZQyZDLkMJQw6ALpPKD/sOszAuvzY8gH6kkGkgVA3UVAHekMGUC9OkDRUoZihlQgnQYUTwXCHKAKIACFE7r/CxKLEuE+YzI2BgCw7DNM6umvmwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAK1JREFUKM9j/M+AHzAxEFSgzvCQ4T8O+JBBjYkhlEGO4RxWzWeBMqFMDCxAphlDIcMXFMnPDAUM5kCaFeKGtQxrGDQZNsKlNzBoMawDioLA/4b/IPD5f8F/5v8B/x//f/TfH8gqBIqAQAPMFzwM/QwnGR4DzdFieMJwiqEPKAIGLEj2GgOVTAHSOQzMCEEWFKcxM+STEVAEFfzBK/+b4b/a/wf/cYF7/1UYKY5NAMY8W5r6COY5AAAAAElFTkSuQmCC"
    local main = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAAA02lDQ1BpY2MAABjTY2BgTMhJzi1mMWBgyM0rKXIPcoyMiIxSYL/PwMEgyCDGoMAglphcXOAb7BbCgBN8u8bACKIv64LMYiANsKSkFicD6S1AbJFcUFQCpN8AsV95SQGQzWgDZItkhwQ5A9kBQLZAbk5pMlQvyFae1LzQYCAtA8bpDEUMiQyVQHcnMZQyZDLkMJQw6ALpPKD/sOszAuvzY8gH6kkGkgVA3UVAHekMGUC9OkDRUoZihlQgnQYUTwXCHKAKIACFE7r/CxKLEuE+YzI2BgCw7DNM6umvmwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAIVJREFUKM9j/K/MEMPAyIAODjHsg7L+1//HBvb9Z4BAJiy6QYAJxmBhwA0SGOQZFuNXYM/wn4kBP2AipICBoAKYG24yvEARX4eqYCdDAMMP3CaApCOAbkYHBhAFBxg6gLrlgV7CYcIBML0YHKrIQIEhHhIXuGEDME4a8IVkA4hg/I8/GBQAsEBAgstHx0cAAAAASUVORK5CYII="
    local settings = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAYNJREFUOI2NU7GOgkAQnWWuEmpiIEaJxISCH6OR5RcopKCUAhshIf4R0EogsSWw0Y695jDciue9arIz72XfmwyBN3Acx1FVVQUAuN1utziO43ezLyCEkMfj8eA/6Pu+/0gyTdNERAQAsCzL4gJM0zQBABARt9vt9hd5tVqt7vf7va7r+nQ6nRhjTBTo+76P4zhumqZhjDFN07SnwOVyuYiET0jTNAUAANu27bmBPM9zSil1XdfN8zwX+8MwDJZlWYCIeDgcDsMwDFPyYrFYjD+UZVkuiqKYkn3f9yVJkmZtUEqpGDKllI79JEmS8f2pQAghY80553OrnasBETEMw1D0L8uyPM4oiqKUZVlOLQRBECAigm3b9tT/iKIoCkop9TzPm5JfQgQAyLIs+2tlczifz+enDV3XdcYYu16v1yiKoq7rOpHQtm17PB6PVVVVXdd1y+Vy+SukzWazGdey2+12ooBhGAYAgCRJ0nq9XoshvyT+32P6mnvknPP9fr+fnvM7gW+gduCLlAABvQAAAABJRU5ErkJggg=="
    local location = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAQlBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////8IX9KGAAAAFXRSTlMAKu6dBPIWd9fNu6NQRToyGwh5WFfK61buAAAAbklEQVQY01WN2w7AIAhDUZnuPt3G///qQKvJzgO0DQ1U4SOlg2lwzaLMV/duksrkEKxmLFybjyo35k1XJONU5bSo61Tb1E60t1xhL+LTbROfg4DQ3wpwBMI4ANGb95EGjwVv0yihMCjLUuhHzhAfWYEHce24sP0AAAAASUVORK5CYII="
    local tts_off = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAbFBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8+T+BWAAAAI3RSTlMAwIdxYvPbtAXugWkZA7mupZBsa0M5LCEfEQjRqJOPdGgyItzq6IAAAACMSURBVBjTZcxXDoNQDETRAb8GhN5Jz+x/jzFBBEU5H/64sgY/TpOe8YHd4s4BEGaY561EbPTe2OaXWP99PtBpCJZN7gUxDRw1PEneg6BjhZLrNFUKGNY6AnWlijX0wVqsjPeplh7CErtMy2I5AHiZKirSTrRkAkwFN4nTohJ+JZ/CQyQUIDrUaEf8eQMoEAxmz89oGQAAAABJRU5ErkJggg=="
    local tts_on = "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAwEFiLdquayAQCAT69O/RpZCBcBfturizoIl8cWA6OKmGSsIAAAB/SURBVBjTbY5XDsQwCETBcYnj9GR7m/ufcsGWNrK072eYJySgir2te+emVCZjSzKCxmsEONJ+TRZOeoSy0R0NOeg+FJacyauwUG7UYCEGCZMKI+Kdhl5FXNkbyQ9t8PUfQ6/322bm82o6GcNT6gWFMVDmhB+PLHDAWfDBQv/4AkDkCoEflhYcAAAAAElFTkSuQmCC"
    file.Write("greatrp/ic_email_white_18dp_1x.png", base64_decode(pm))
    file.Write("greatrp/ic_forum_white_18dp_1x.png", base64_decode(main))
    file.Write("greatrp/ic_settings_white_18dp_1x.png", base64_decode(settings))
    file.Write("greatrp/ic_location_on_white_18dp_1x_.png", base64_decode(location))
    file.Write("greatrp/baseline_voice_over_off_white_18dp.png", base64_decode(tts_off))
    file.Write("greatrp/baseline_record_voice_over_white_18dp.png", base64_decode(tts_on))
    util.PrecacheSound("gxserv/pm.ogg")
end

-- Box
local BOX = {}

function BOX:Init()
    local w, h = chat.GetChatBoxSize()
    local x, y = chat.GetChatBoxPos(true)
    x = 8
    y = (ScrH() - h) / 2
    --[[

	if DarkRP then

		x = (ScrW() - w)/2

		y = ScrH() - 8 - h

	end

	]]
    self:SetPos(x, y)
    self:SetSize(w, h)
    self:SetCookieName("wChat")
    -- get rid of what we've got from dframe
    self:DockPadding(6, 0, 6, 6)
    self:SetSizable(true)
    self:SetMinWidth(200)
    self:SetMinHeight(100)
    self:SetDraggable(true)
    self:ShowCloseButton(false)
    self:SetTitle("")
    self:SetSkin("Default")
    self:ShowCloseButton(false)
    self:InitTabs()
    self:InitButtons()

    if _G.KARMA then
        self:InitEmotePicker()
    end

    self:InitAdditionalButtons()
end

function BOX:InitTabs()
    self.tabs = {}
    self.sheets = self:Add("DPropertySheet")
    self.sheets:Dock(FILL)
    self.sheets.tabScroller:SetOverlap(0)
    self.sheets.tabScroller:DockMargin(0, 0, 90, 0)

    self.sheets.tabScroller.OnMousePressed = function(s)
        self:OnMousePressed()
    end

    self.sheets.tabScroller.OnMouseReleased = function(s)
        self:OnMouseReleased()
    end

    self.sheets.Paint = function() end

    self.sheets.SetActiveTab = function(self, active)
        if self.m_pActiveTab == active then return end

        if self.m_pActiveTab then
            if self:GetFadeTime() > 0 then
                self.animFade:Start(self:GetFadeTime(), {
                    OldTab = self.m_pActiveTab,
                    NewTab = active
                })
            else
                self.m_pActiveTab:GetPanel():SetVisible(false)
            end
        end

        self.m_pActiveTab = active
        self:InvalidateLayout()

        -- All you had to do is call the damn hook, CJ!
        if IsValid(active.m_pPanel) and isfunction(active.m_pPanel.OnTabActive) then
            active.m_pPanel:OnTabActive()
        end
    end

    self.MainTab = self:NewTab("main", "WChatboxHTMLTab")

    concommand.Add("wchat_clear", function()
        self.MainTab:Clear()
    end)

    -- holy shit what a hack
    self.MainTab:SetTabTitle("  ")
    local tab = self.MainTab.SheetData.Tab
    tab.image = vgui.Create("DImage", tab)
    tab.image:SetMouseInputEnabled(false)
    tab.image:SetImage("../data/nxserv/ic_forum_white_18dp_1x.png")
    tab.image:SetSize(16, 16)
    tab.image:SetPos(5, 3)

    function self.MainTab:OnEnter(input, str)
        local teamChat = self.chatType == "team" or self.chatType == "group"
        local chatType = self.chatType
        local bigself = self
        self = input
        str = string.Trim(self:GetValue())

        if str ~= "" then
            if hook.Run("wChatPreSend", str, chatType) then
                self.RED = self.RED or RealTime()

                return
            end

            -- if true then
            SendMessage(str, chatType, bigself.persona)
            -- else
            -- 	LocalPlayer():ConCommand("say" .. (teamChat and "_team" or "") .. " \"" .. str .. "\"")
            -- end
            self:AddHistory(str, chatType)
            self.HistoryPos = 0
            input.dirty = false
            input.TempText = nil
            input.TempChat = nil
        end

        wChat:SetActive(false)
        self:SetText("")
    end

    local baseMethod = self.MainTab.input.OnTextChanged

    function self.MainTab.input:OnTextChanged()
        -- todo make it behave like valve chat
        hook.Run("ChatTextChanged", self:GetValue())
        baseMethod(self)
    end

    local pmtab = self:NewTab("newpm", "WChatboxNewPM")
    pmtab:SetTabTitle("  ")
    local tab = pmtab.SheetData.Tab
    tab.image = vgui.Create("DImage", tab)
    tab.image:SetMouseInputEnabled(false)
    tab.image:SetImage("../data/nxserv/ic_email_white_18dp_1x.png")
    tab.image:SetSize(16, 16)
    tab.image:SetPos(5, 2)
    self.LastModerPMs = {}

    self:RegisterGamePanel(function()
        wChat:SetActive(false)
        self.MainTab.input:SetText("")
        self.MainTab.input.HistoryPos = 0
        self.MainTab.input.dirty = false
        self.MainTab.input.TempText = nil
        self.MainTab.input.TempChat = nil
    end)
end

function BOX:InitButtons()
    self.close = vgui.Create("DButton", self)
    self.close:SetTextColor(color_white)

    if system.IsWindows() then
        self.close:SetFont("Marlett")
        self.close:SetText("r")
    else
        self.close:SetText("✖")
    end

    self.close.Paint = function(s, w, h)
        if s.Depressed then
            surface.SetDrawColor(Color(128, 0, 0, 200))
        elseif s.Hovered then
            surface.SetDrawColor(Color(255, 0, 0, 200))
        else
            surface.SetDrawColor(Color(255, 0, 0, 150))
        end

        surface.DrawRect(0, 0, w, h)
    end

    self.close.DoClick = function()
        self:SetActive(false)
    end

    self.ttsToggle = vgui.Create("DButton", self)
    self.ttsToggle:SetText("")
    self.ttsToggle:SetTooltip("Озвучивание сообщений")
    local cvar = GetConVar("nx_tts")
    self.ttsToggle:SetImage(cvar and cvar:GetBool() and "../data/nxserv/baseline_record_voice_over_white_18dp.png" or "../data/nxserv/baseline_voice_over_off_white_18dp.png")
    self.ttsToggle:SetWide(16 + 8)

    self.ttsToggle.Paint = function(s, w, h)
        if s.Depressed then
            surface.SetDrawColor(Color(32, 32, 32, 200))
        elseif s.Hovered then
            surface.SetDrawColor(Color(64, 64, 64, 200))
        else
            surface.SetDrawColor(Color(64, 64, 64, 150))
        end

        surface.DrawRect(0, 0, w, h)
    end

    self.ttsToggle.DoClick = function()
        local newState = not GetConVar("nx_tts"):GetBool()
        self.ttsToggle:SetImage(newState and "../data/nxserv/baseline_record_voice_over_white_18dp.png" or "../data/nxserv/baseline_voice_over_off_white_18dp.png")
        GetConVar("nx_tts"):SetBool(newState)
    end

    if not _G.KARMA then
        self.ttsToggle:SetVisible(false)
    end

    self.opts = vgui.Create("DButton", self)
    self.opts:SetText("")
    self.opts:SetImage("../data/nxserv/ic_settings_white_18dp_1x.png")
    self.opts:SetWide(16 + 8)

    self.opts.Paint = function(s, w, h)
        if s.Depressed then
            surface.SetDrawColor(Color(32, 32, 128, 200))
        elseif s.Hovered then
            surface.SetDrawColor(Color(64, 64, 255, 200))
        else
            surface.SetDrawColor(Color(64, 64, 255, 150))
        end

        surface.DrawRect(0, 0, w, h)
    end

    self.opts:SetVisible(true)

    self.opts.DoClick = function()
        local menu = DermaMenu()
        menu:AddCVar(Translate("chat.options.blur"), "wchat_blur", "1", "0")
        menu:AddCVar(Translate("chat.options.noprivacy"), "wchat_noprivacy", "1", "0")
        menu:AddCVar(Translate("chat.options.timestamps"), "wchat_timestamps", "1", "0")
        local yer = menu:AddSubMenu(Translate("chat.options.fontsize"), function() end)

        for i = 9, 24 do
            yer:AddOption(i .. "px" .. (i == 16 and (" (%s)"):format(Translate("chat.options.default")) or ""), function()
                RunConsoleCommand("wchat_fontsize2", i)
            end):SetChecked(FontSize:GetInt() == i)
        end

        menu:Open()
        menu:MakePopup()
    end

    self:DockPadding(6, 0, 6, 6)
end

function BOX:InitEmotePicker()
    self.emotepicker = vgui.Create("DHTML")

    self.emotepicker.Think = function(s)
        if not IsValid(self) then
            s:Remove()

            return
        end
    end

    local cntEmotes = table.Count(emotes)
    local columns = 8
    self.emotepicker:SetSize(4 + 36 * columns + 4 + 8 + 4, 18 + math.ceil(cntEmotes / columns) * 36 + 8)
    self.emotepicker:SetVisible(false)
    local codes = {}

    --for i = 1, 10 do
    for k, v in SortedPairs(emotes) do
        table.insert(codes, [[<div class="emote" onmouseout="epleave()" onmouseover="ephover(']] .. k .. [[')" onclick="epclick(']] .. k .. [[')" title="]] .. k .. [[" style="background-image: url('http://gxserv.eu/chat/]] .. v .. [[');"></div>]])
    end

    --end
    self.emotepicker:AddFunction("gmod", "PickEmote", function(code)
        local inp = self.sheets:GetActiveTab().m_pPanel.input

        if IsValid(inp) then
            inp:SetValue(inp:GetValue() .. ":" .. code .. ":")
            inp:SetCaretPos(select(2, inp:GetText():gsub('[^\128-\191]', '')))
            inp:RequestFocus()
        end

        if not input.IsKeyDown(KEY_LSHIFT) and not input.IsKeyDown(KEY_RSHIFT) then
            self.emotepicker:SetVisible(false)
        end
    end)

    self.emotepicker:SetHTML([[

	<style>

	body {

		margin: 0 0;

		width: 100%;

		height: 100%;

		overflow: hidden;

	}





	::-webkit-scrollbar {

		width: 8px;

		height: 8px;

		background-color: #ddd;

	}



	::-webkit-scrollbar-thumb {

		background-color: #aaa;

	}



	.wrapper {

		background: #eee;

		border-radius: 4px;

		height: 100%;

		padding: 4px;

		overflow: hidden;

		box-sizing: border-box;

	}



	.scroll {

		overflow: auto;

		height: 100%;

	}



	.emote {

		border-radius: 2px;

		padding: 2px;

		display: inline-block;

		width: 32px;

		height: 32px;

		background-size: auto 32px;

		background-repeat: no-repeat;

		background-position: center center;

		cursor: pointer;

	}



	.emote:hover {

		background-color: #999;

	}



	.info {

		height: 18px;

		font-family: "Tahoma", Sans-Serif;

		font-size: 14px;

		padding-bottom: 2px;

		//box-sizing: border-box;

	}

	</style>



	<body>

		<div class="wrapper">

			<div class="info"></div>

			<div class="scroll">

				]] .. table.concat(codes, "") .. [[

			</div>

		</div>

	</body>



	<script>

		function ephover(code) {

			document.getElementsByClassName("info")[0].innerHTML = ":" + code + ":";

		}



		function epleave() {

			document.getElementsByClassName("info")[0].innerHTML = "";

		}



		function epclick(code) {

			console.log("click " + code);

			gmod.PickEmote(code);

		}

	</script>

	]])
end

function BOX:InitAdditionalButtons()
    self.addbuttons = vgui.Create("EditablePanel")
    self.addbuttons:SetVisible(false)

    self.addbuttons.Think = function(s)
        if not IsValid(self) then
            s:Remove()

            return
        end
    end

    local tall = 0

    for k, v in pairs({
        {
            "chat.addbuttons.report",
            function()
                SpawnReportWindow()
            end
        },
        {
            "chat.addbuttons.stuck",
            function()
                RunConsoleCommand("say", "!unstuck")
            end
        },
        {
            "chat.addbuttons.stopsound",
            function()
                RunConsoleCommand("stopsound")
            end
        },
{"chat.addbuttons.invis_players", nx_forceupdate, function() return _G.KARMA ~= nil end}
    }) do
        if v[3] and not v[3]() then continue end
        local b = self.addbuttons:Add("NxButton")
        b:Dock(LEFT)
        b:DockMargin(0, 0, 5, 0)
        b:SetText(Translate(v[1]))
        b:AutoSize()
        b.DoClick = v[2]
        tall = b:GetTall()
    end

    self.addbuttons:InvalidateLayout(true)
    self.addbuttons:SizeToChildren(true, false)
    self.addbuttons:SetTall(tall)
end

function BOX:PerformLayout()
    self.BaseClass.PerformLayout(self)

    if self and self.close then
        self.close:SetPos(self:GetWide() - self.close:GetWide(), 0)
        self.opts:SetPos(self:GetWide() - self.close:GetWide() - self.opts:GetWide(), 0)
        self.ttsToggle:SetPos(self:GetWide() - self.close:GetWide() - self.opts:GetWide() - self.ttsToggle:GetWide(), 0)
    end

    -- hack to calculate all positioning bullshit and hide chatbox
    if self.plsdie then
        self.plsdie = false
        self:SetAlpha(0)

        hook.Add("Think", "wChat-please", function()
            self:SetAlpha(255)
            self:SetActive(false)
            hook.Remove("Think", "wChat-please")
        end)
    end
end

local matBlurScreen = Material("pp/blurscreen")

function BOX:Paint(w, h)
    if Blur:GetBool() then
        local x, y = self:LocalToScreen(0, 0)
        render.SetScissorRect(x, y, x + self:GetWide(), y + self:GetTall(), true)
        surface.SetMaterial(matBlurScreen)
        surface.SetDrawColor(255, 255, 255, 255)

        for i = 0.33, 1, 0.33 do
            matBlurScreen:SetFloat("$blur", 5 * i)
            matBlurScreen:Recompute()
            render.UpdateScreenEffectTexture()
            surface.DrawTexturedRect(x * -1, y * -1, ScrW(), ScrH())
        end

        surface.SetDrawColor(0, 0, 0, 200)
        surface.DrawRect(0, 0, w, h)
        render.SetScissorRect(0, 0, 0, 0, false)
    else
        surface.SetDrawColor(0, 0, 0, 200)
        surface.DrawRect(0, 0, w, h)
    end
    --[[

	if self.Hovered then

		surface.SetDrawColor(Color(255, 0, 0))

		surface.DrawRect(0, 0, w, h)

	end



	print(vgui.GetHoveredPanel())

	]]
end

function BOX:Think(...)
    self.Hovered = true
    self.BaseClass.Think(self, ...)
    local mousey = math.Clamp(gui.MouseY(), 1, ScrH() - 1)

    if (self.Hovered and self:GetDraggable() and mousey < (self.y + 24)) then
        self.sheets.tabScroller:SetCursor("sizeall")
    else
        self.sheets.tabScroller:SetCursor("arrow")
    end

    local x, y = self:GetPos()
    local w, h = self:GetSize()

    if self.emotepicker then
        self.emotepicker:SetPos(x + w + 4, y + h - self.emotepicker:GetTall())
    end

    self.addbuttons:SetPos(x, y - self.addbuttons:GetTall() - 5)
end

-- Creates a tab
function BOX:NewTab(id, class)
    local pnl = vgui.Create(class or "EditablePanel")
    self.tabs[id] = pnl
    pnl:Dock(FILL)
    pnl.SheetData = self.sheets:AddSheet(id, pnl)

    pnl.SheetData.Tab.Paint = function(s, w, h)
        local col = Color(255, 255, 255, 30)

        if pnl.flash then
            local f = math.abs(math.sin(RealTime() * 4))
            local v = LerpVector(f, Vector(100, 200, 255), Vector(255, 255, 255))
            col = Color(v.x, v.y, v.z, 30)
        end

        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
    end

    pnl.SetTabTitle = function(self, str)
        self.SheetData.Tab:SetText(str)
        self.SheetData.Tab:InvalidateLayout(true)
    end

    return pnl
end

-- PM functionality:
-- finds or inits pm tab
function BOX:GetPMTab(steamid)
    if not IsValid(self.tabs[steamid]) then
        local IsModTab = steamid:Left(6) == "MODER_"
        self.tabs[steamid] = self:NewTab(steamid, "WChatboxHTMLTab")
        -- this really shouldn't be here
        self.tabs[steamid].page:Call("ShowOld();")
        local tab = self.tabs[steamid].SheetData.Tab
        tab.Image = vgui.Create("AvatarImage", tab)
        tab.Image:SetMouseInputEnabled(false)
        tab.Image:SetSteamID(IsModTab and "76561198319096826" or util.SteamIDTo64(steamid), 16)
        tab.Image:SetSize(16, 16)
        tab.Image.SetImageColor = function() end
        tab:InvalidateLayout()

        function tab.DoRightClick()
            local menu = DermaMenu()

            menu:AddOption(Translate("chat.pm.close"), function()
                self.sheets:CloseTab(tab, true)
            end)

            menu:AddOption(self:GetBlocked(steamid) and Translate("chat.pm.unblock") or Translate("chat.pm.block"), function()
                self:SetBlocked(steamid, not self:GetBlocked(steamid))
            end)

            menu:AddOption(Translate("chat.pm.open_profile"), function()
                gui.OpenURL("http://steamcommunity.com/profiles/" .. util.SteamIDTo64(steamid) .. "/")
            end)

            menu:AddOption(Translate("chat.pm.copy_sid"), function()
                SetClipboardText(tostring(steamid:rayid()))
            end)

            menu:Open()
            menu:MakePopup()
        end

        function tab.DoMiddleClick()
            self.sheets:CloseTab(tab, true)
        end

        local pl = player.GetBySteamID(steamid)

        if pl then
            self.tabs[steamid]:SetTabTitle(pl:Name())
        end

        if IsModTab then
            self.tabs[steamid]:SetTabTitle("Moderator#" .. steamid:sub(7))
            self.tabs[steamid].SheetData.Tab:SetTextColor(Color(255, 255, 0))
        end

        self.tabs[steamid].Think = function(s)
            if IsValid(pl) and pl:SteamID() == steamid then
                s:SetTabTitle(pl:Name())
            end
        end

        self.tabs[steamid].OnEnter = function(_, input)
            local str = string.Trim(input:GetValue())

            if str ~= "" then
                if hook.Run("wChatPreSend", str, "PM" .. steamid) then
                    input.RED = input.RED or RealTime()

                    return
                end

                self:OnPMSend(steamid, str)
                input:AddHistory(str)
                input.HistoryPos = 0
                input.dirty = false
                input.TempText = nil
                input.TempChat = nil
            end

            input:SetText("")
            input:RequestFocus()
        end
    end

    return self.tabs[steamid]
end

function BOX:GetBlocked(steamid)
    return self:GetCookieNumber(steamid, 0) == 1
end

function BOX:SetBlocked(steamid, bool)
    return self:SetCookie(steamid, bool and 1 or 0)
end

local function OpenModerTab(id)
    local tab = wChat:GetPMTab(id)
    tab.SheetData.Tab:DoClick()
end

function BOX:OnPMReceived(steamid, message, info, sysMsg, pl)
    if self:GetBlocked(steamid) then return end
    --local prefix = player.GetBySteamID(steamid) or steamid
    local prefix = pl or steamid
    local pnl = self:GetPMTab(steamid)

    if pnl.lastday ~= os.date("%d") then
        pnl:AddText(thetime, os.date("%d %B %Y"))
    end

    pnl.lastday = os.date("%d")

    if not sysMsg then
        pnl:AddText(thetime, os.date("%H:%M - "), color_white, prefix, lime, "", color_white, ": ", message)
    else
        pnl:AddText(thetime, os.date("%H:%M - "), lime, message)
    end

    if self.sheets:GetActiveTab() ~= pnl.SheetData.Tab then
        pnl.flash = true
    end

    surface.PlaySound("gxserv/pm.ogg")
    chat.AddTpl("chat.pm.incoming", prefix, message, NoPrivacy:GetBool())

    if steamid:Left(6) == "MODER_" then
        if not self.LastModerPMs[steamid] or os.time() - self.LastModerPMs[steamid] > 30 * 60 then
            wChat.MainTab:AddPlashque(Translate("chat.moder_msg_notify"), OpenModerTab, nil, nil, nil, nil, nil, steamid)
        end

        self.LastModerPMs[steamid] = os.time()
    end
end

net.Receive("wChatPM", function(len)
    local steamid, message, sysMsg = net.ReadString(), net.ReadString(), net.ReadBool()
    local pl, info = nil, 0

    if not sysMsg then
        pl = net.ReadType(TYPE_PERSON)
        info = net.ReadUInt(2)
    end

    wChat:OnPMReceived(steamid, message, info, sysMsg, pl)
end)

function BOX:OnPMSend(steamid, message)
    local pnl = self:GetPMTab(steamid)

    if pnl.lastday ~= os.date("%d") then
        pnl:AddText(thetime, os.date("%d %B %Y"))
    end

    pnl.lastday = os.date("%d")
    local info = pnl.persona
    pnl:AddText(thetime, os.date("%H:%M - "), color_white, LocalPlayer(), lime, info > 0 and " (Moder)" or "", color_white, ": ", message)
    chat.AddTpl("chat.pm.outcoming", steamid:Left(6) == "MODER_" and "Moderator" or player.GetBySteamID(steamid) or steamid, message, NoPrivacy:GetBool())
    net.Start("wChatPM")
    net.WriteString(steamid)
    net.WriteString(message)
    net.WriteUInt(info, 2)
    net.SendToServer()
end

-- activation hooks
function BOX:SetActive(active, teamChat)
    if not active then
        hook.Run("FinishChat")

        --chat.Close() -- fix loose Valve chat
        if self.MainTab.input:GetValue() ~= "" then
            hook.Run("ChatTextChanged", "")
        end

        self.sheets:SetActiveTab(self.MainTab.SheetData.Tab)
        self.MainTab:SetVisible(true)
        self.MainTab.hint:SetVisible(false)
        self.MainTab.input:SetVisible(false)

        if self.MainTab.lctn then
            self.MainTab.lctn:SetVisible(false)
        end

        if self.MainTab.emotePickerButton then
            self.MainTab.emotePickerButton:SetVisible(false)
        end

        self.MainTab.persona0:SetVisible(false)
        self.MainTab.persona2:SetVisible(false)
        local x, y = self.MainTab:LocalToScreen(0, 0)
        local w, h = self.MainTab:GetSize()
        self.MainTab:SetParent()
        self.MainTab:ParentToHUD()
        self.MainTab.page:Call("document.body.style.overflowY = 'hidden'")
        self.MainTab.page:Call("HideOld(); window.getSelection().removeAllRanges();")
        self.MainTab:Dock(NODOCK)
        self.MainTab:SetPos(x, y)
        self.MainTab:SetSize(w, h)
        self:SetVisible(false)

        hook.Add("Think", "WChatbox-HUDShouldDraw", function()
            if not IsValid(self) then
                hook.Remove("Think", "WChatbox-HUDShouldDraw")
            end

            local should = hook.Run("HUDShouldDraw", "WChatbox")
            should = should == nil and true or should

            if should ~= self.MainTab.page:IsVisible() then
                self.MainTab.page:SetVisible(should)
            end
        end)

        if self.emotepicker then
            self.emotepicker:SetVisible(false)
        end

        self.addbuttons:SetVisible(false)
    else
        self:SetVisible(true)
        self.MainTab:Dock(FILL)
        self.MainTab.page:Call("document.body.style.overflowY = 'auto'")
        self.MainTab.page:Call("ShowOld();")
        -- nil ->
        self.MainTab:SetChatType((not not teamChat) and chat.DefaultTabTeam or chat.DefaultTab)
        self.MainTab:SetParent(self.sheets)
        self.MainTab.input:SetVisible(true)
        self.MainTab.hint:SetVisible(true)

        if self.MainTab.lctn then
            self.MainTab.lctn:SetVisible(true)
        end

        if self.MainTab.emotePickerButton then
            self.MainTab.emotePickerButton:SetVisible(true)
        end

        self.MainTab.persona0:SetVisible(false)
        self.MainTab.persona2:SetVisible(false)
        self.MainTab.input:RequestFocus()
        self.MainTab.page:SetVisible(true)
        hook.Remove("Think", "WChatbox-HUDShouldDraw")
        --self.emotepicker:SetVisible(true)
        self.addbuttons:SetVisible(true)
    end

    self.MainTab:GotoTextEnd()
    self.MainTab:CloseChatTypeHint()
    local t = SysTime()

    hook.Add("Think", "wChat-gotoend-" .. t, function()
        if (SysTime() - t) >= 0.1 then
            self.MainTab:GotoTextEnd()
            hook.Remove("Think", "wChat-gotoend-" .. t)
        end
    end)
end

local ignore

hook.Add("StartChat", "WChatbox", function(isTeam)
    if IsValid(wChat) and not ignore then return true end
end)

hook.Add("PlayerBindPress", "WChatbox", function(pl, bind, pressed)
    if pressed then
        local ok, ret = pcall(function() return LocalPlayer():GetVehicle():GetParent():GetParent():GetClass() end)
        if ok and ret == "gmt_instrument_piano" then return end

        if bind == "messagemode" or bind == "messagemode2" then
            wChat:SetActive(true, bind == "messagemode2") -- if something errors this way, we're fucked!
            wChat:MakePopup()
            --wChat.input:RequestFocus()
            ignore = true
            hook.Run("StartChat", bind == "messagemode2")
            ignore = false

            return true
        end
    end
end)

-- integration
function BOX:AddText(...)
    if ShowTime:GetBool() then
        if self.MainTab.lastday ~= os.date("%d") then
            self.MainTab:AddText(thetime, os.date("%d %B %Y"))
        end

        self.MainTab.lastday = os.date("%d")
        self.MainTab:AddText(thetime, os.date("%H:%M - "), color_white, ...)
    else
        self.MainTab:AddText(...)
    end
end

chat.AddTextX = chat.AddTextX or chat.AddText

function chat.AddText(...)
    if wChat and IsValid(wChat) then
        xpcall(wChat.AddText, function(err)
            ErrorNoHalt(err .. "\n")
        end, wChat, ...)
    end

    --chat.AddTextX(...) -- replace it with MsgC
    local vrg = {...}
    table.insert(vrg, "\n")
    MsgC(unpack(vrg))
end

chat._GetChatBoxPos = chat._GetChatBoxPos or chat.GetChatBoxPos

function chat.GetChatBoxPos(pls)
    return unpack((pls or not IsValid(wChat)) and {chat._GetChatBoxPos()} or {wChat:GetPos()})
end

table.Empty(hook.GetTable().ChatText or {}) -- lobotomy for metastruct chat

hook.Add("ChatText", "WChatbox", function(id, name, str, what)
    if what == "chat" then
        chat.AddText(red_sea, "Console", color_white, ": ", str)
    elseif what == "none" then
        if name ~= "Console" then return false end
        if str:find("^Server cvar") then return false end
        chat.AddText(lime, str)
    elseif what == "servermsg" then
        return false
    elseif what == "namechange" then
        return false
    elseif what == "joinleave" then
        return false
    else
        chat.AddText(lime, str, color_black, what, " ", id, " ", name)
    end
end)

hook.Add("Think", "wChat", function()
    if input.IsKeyDown(KEY_SLASH) and IsValid(wChat) and DarkRP and not wChat:IsVisible() and not gui.IsGameUIVisible() and not IsValid(vgui.GetKeyboardFocus()) then
        wChat:SetActive(true)
        --wChat.MainTab.input:SetValue("/")
        wChat:MakePopup()
        --wChat.MainTab.input:SetCaretPos(select(2, wChat.MainTab.input:GetText():gsub('[^\128-\191]', '')))
        wChat.MainTab:SetChatType("city")
    end

    if IsValid(vgui.GetKeyboardFocus()) then
        LastFocus = vgui.GetKeyboardFocus()
    end
end)

derma.DefineControl("WChatbox", "", BOX, "DFrame")
-- / done
-- WChatboxHTMLTab
local JSTAB = {}
local HTML = [[

<style>

	/* @import url(http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic&subset=latin,cyrillic-ext,latin-ext,cyrillic); */



	@font-face {

		font-family: 'Open Sans';

		font-style: normal;

		font-weight: 600;

		src: url(http://gxserv.eu/opensans.woff) format('woff');

	}



	* {

		box-sizing: border-box;

	}



	body {

		font-family: "Open Sans", "Segoe UI", Sans-Serif;

		font-size: ]] .. FontSize:GetInt() .. [[px;

		font-weight: 600;

		margin: 0 0;

		margin-left: 1px;

		opacity: 1;

		background-color: rgba(0, 0, 0, 0.0);

		color: white;

		//text-shadow: 0px 0px 0px black, 1px 0px 0px black, -1px 0px 0px black, 0px -1px 0px black, 0px 1px 0px black;

		text-shadow: 0px 0px 0px black, 0px 0px 1px black, 0px 0px 2px black, 0px 0px 3px black, 0px 0px 3px black, 0px 0px 3px black, 0px 0px 3px black;

		word-break: break-word;

		-webkit-font-smoothing: antialiased;

		overflow-x: hidden;

	}



	img {

		max-width: 100%;

		max-height: 100%;

	}



	.emoji {

		height: 1em;

		width: 1em;

		margin: 0 .05em 0 .1em;

		vertical-align: -0.1em;

	}



	.vee {

		background-image: url("https://dl.dropboxusercontent.com/u/7313569/fp_smileys/v.gif");

		content: "&nbsp;";

		width: 16px;

		height: 16px;

		display: inline-block;

	}



	.volvo {

		background-image: url("http://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Valve_logo.svg/100px-Valve_logo.svg.png");

		content: "&nbsp;";

		width: 100px;

		height: 27px;

		display: inline-block;

	}



	@-webkit-keyframes rave {

		0% { color: red; }

		50% { color: blue; }

		100% { color: red; }

	}





	@-webkit-keyframes alert {

		0% { color: inherit; }

		50% { color: red; }

		100% { color: inherit; }

	}



	.rave {

		-webkit-animation: rave 0.1s infinite;

	}



	.moder {

		background-color: #005bbb;

		color: white;

		padding: 0px 4px;

		border-radius: 2px;



		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAFiQAABYkBbWid+gAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAFJSURBVDiNrZS7TgJBFIb/sQKttGGBxkptkMInsLOy0c7ExJZKO421jS/gA2hhYS9G0PAAxoSQ4CWxMXgLaywgYkj4LCA4DLugwb/amTnn2/OfuUj/JDNoEYhLWukMT4wxL3+iAxEgDbzzIx+YByK/ASSBLNAkXE3gFEgMAl0MALjK2bnGgkQl1TWkb/Z/JY0bYxqSNGYtzA6DPLx9qtFs2VMzrqW409g+lSs1vEyB9YOSPe0Dnl3RqqRJG35W9LvfN091Le5dSZJ2lqftsKlObo+1rrJFX0v719o6ulPZglzuLmguMeGG41rz7Zo3D2/R2jnRjTxepkC5UgtyXAVibp/SbtT28T2xTIHSYyAEINVnB4gCLTfy+eMrDNIi7JQD+bCsAOUCIR1QkvbxH+2KWMAI7Qtqb0AVSIXZGfaMeOp9Rl6HVjGqvgEXPPeqWfFFQgAAAABJRU5ErkJggg==");

		background-repeat: no-repeat;

		background-position: 4px center;

		padding-left: 26px;

	}



	.alert {

		-webkit-animation: alert 1s infinite;

	}



	span {

		opacity: 1;

		-webkit-transition-property: opacity;

		-webkit-transition-duration: 0.1s;

	}



	/*

	span span {

		background-color: rgba(0, 0, 0, 0.5)

	}

	*/



	.old {

		opacity: 0;

	}



	.plashque {

		padding: 8px 8px;

		border-radius: 4px;

		background-color: #FDD835;

		display: inline-block;

		box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.5);

		margin: 4px 0;

		text-shadow: none;

		color: black;

	}



	.plashque-shadow {

		text-shadow: 0px 0px 0px black, 0px 0px 1px black, 0px 0px 2px black, 0px 0px 3px black, 0px 0px 3px black, 0px 0px 3px black, 0px 0px 3px black;

	}



	.plashque:hover {

		background-color: #FDE681;

	}



	.plashque:active {

		background-color: #C9AC2A;

	}



	.gps {

		background-color: rgba(127, 200, 127, 1);

		border-radius: 2px;

		padding: 0px 4px;



		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAQAAAD8x0bcAAAAp0lEQVQoFZ3BTQoBYQDH4X+ZxAFIuQAjC9mxZqtsuAmu4rM4hXIFWzmEr5n9+Jnpbeo1MxTPI/2KHH0mTOiRUzbanImdaCkNFx+bR01JHDB8PIy93lHB2JInz47Ik7JsdDFchWhgdGSjiTFQiCFGQzYcHkSuTJlxI3LH0TsWJM2VRJ0AW0BdaayxLZWFMldiF0rKxpjYSJ+xIbLSNxQ5cqSg76hS1T9epcXg2E5sg54AAAAASUVORK5CYII=");

		background-repeat: no-repeat;

		background-position: 4px center;

		padding-left: 26px;



		box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.5);

		color: white;

	}



	.gps:hover {

		background-color: rgba(127, 255, 127, 1);

	}



	.gps:active {

		background-color: rgba(64, 100, 64, 1);

	}



	a {

		color: inherit;

		text-decoration: none;

	}



	.font-times { font-family: "Times New Roman"; }

	.font-comic { font-family: "Comic Sans MS"; }

	.font-impact { font-family: "Impact"; font-weight: 500; }

	.font-arialb { font-family: "Arial Black"; }

	.font-consolas { font-family: "Consolas"; }

	.font-segoep { font-family: "Segoe Print"; }



</style>

<script src="http://twemoji.maxcdn.com/twemoji.min.js"></script>

<script>

	var rule, cssbody;

	var emojiOpts = {};//{size: "16x16"};



	document.onreadystatechange = function() {

		document.body.innerHTML = "";



		rules = document.styleSheets[0].cssRules;

		for (i = 0; i < rules.length; i++) {

			if (rules[i].selectorText == ".old")

				rule = rules[i];



			if (rules[i].selectorText == "body")

				cssbody = rules[i];

		}



		delete rules;

	}





	document.addEventListener("contextmenu", function(e) {

		if (e.target.pl) {

			gmod.ContextMenu("", 1, e.target.pl);

		} else if (e.target.href) {

			gmod.ContextMenu("", 2, e.target.href);

		} else {

			gmod.ContextMenu(window.getSelection().toString());

		}

		//e.preventDefault();

	}, false);



	var autoscroll = true;



	document.addEventListener("scroll", function(e) {

		autoscroll = (window.innerHeight + window.scrollY) >= document.body.offsetHeight;

	})



	function HideOld() {

		if (rule != null)

			rule.style.opacity = 0;

	}



	function ShowOld() {

		if (rule != null)

			rule.style.opacity = 1;

	}



	function scroll() {

		setTimeout(function() {

			document.body.scrollTop = document.body.scrollHeight;

			autoscroll = true;

		}, 50);

	}



	function softscroll() {

		if (autoscroll)

			document.body.scrollTop = document.body.scrollHeight;

	}



	function SetFontSize(size) {

		cssbody.style.fontSize = parseInt(size) + "px";

	}



	function SelectAll() {

		var selection = window.getSelection();

		var range = document.createRange();

		range.selectNodeContents(document.body);

		selection.removeAllRanges();

		selection.addRange(range);

	}



	function AddJSON (data) {

		var span = document.createElement("span");

		span.style.display = "block";

		document.body.appendChild(span);



		var lastspan = span



		setTimeout(function() {

			span.className = "old";

		}, 10000);



		data = JSON.parse(data);



		for (key in data) {

			if (data.hasOwnProperty(key)) {

				if (Object.prototype.toString.call( data[key] ) === "[object Object]" & data[key].a) {

					var s = document.createElement("span");

					var color = "rgba(" + data[key].r + ", " + data[key].g + ", " + data[key].b + ", " + data[key].a/255 + ")"



					s.style.color = color

					span.appendChild(s);



					lastspan = s

				} else if (data[key].img) {

					var i = document.createElement("img")

					i.onload = function(e) {

						setTimeout(function() {

							scroll();

						}, 50);

					}

					if (i.complete) {

						setTimeout(function() {

							scroll();

						}, 50);

					}

					i.src = data[key].img

					//i.style.background = "red"

					if (data[key].imge) {

						i.style.height = "32px"

					}

					lastspan.appendChild(i)

				} else if (data[key].vector) {

					var link = document.createElement("a")



					link.href = "#"

					link.className = "gps"

					link.innerHTML = "]] .. Translate("chat.sent_gps_button") .. [[";

					link.pl = data[key].pl;

					link.vector = data[key].vector;



					link.onclick = function(e) {

						gmod.SpotLocation(this.pl, this.vector[0], this.vector[1], this.vector[2]);

						return false;

					}



					lastspan.appendChild(link)

				} else if (data[key].pl) {

					var link = document.createElement("a");

					link.href = "#";

					link.pl = data[key].pl;

					link.nick = data[key].nick;

					link.channel = data[key].channel;

					link.onclick = function(e) {

						gmod.CitePlayer(this.pl, this.nick, this.channel);

						return false;

					}

					link.appendChild(document.createTextNode(data[key].nick));





					if (data[key].pl == "STEAM_0:0:179415549") {

						link.classList.add("moder")

					}



					if (data[key].font) {

						link.classList.add("font-" + data[key].font)

					}



					lastspan.appendChild(link);

				} else if (data[key].href) {

					var link = document.createElement("a");

					link.href = data[key].href;

					link.pl = data[key].pl;

					link.onclick = function(e) {

						gmod.OpenURL(this.href);

						return false;

					}

					link.appendChild(document.createTextNode(data[key].href));

					lastspan.appendChild(link);

				} else if (data[key].plashque) {

					var link = document.createElement(data[key].pointer ? "a" : "span");

					link.href = "#";

					link.className = "plashque";



					if (data[key].shadow) {

						link.classList.add("plashque-shadow");

					}



					var r = data[key].plashque.split("\n")

					for (i = 0; i < r.length; i++) {

						if (i > 0) {

							link.appendChild(document.createElement("br"));

						}

						var node = document.createTextNode(r[i]);

						link.appendChild(node);

					}



					//link.appendChild(document.createTextNode(data[key].plashque));



					if (data[key].pointer) {

						link.pointer = data[key].pointer

						link.arg1 = data[key].arg1

						link.onclick = function(e) {

							gmod.ClickPlashque(link.pointer, link.arg1);

							return false;

						}

					} else if (data[key].color) {

						link.style.backgroundColor  = "rgb(" + data[key].color[0] + ", " + data[key].color[1] + ", " + data[key].color[2] + ")"

					} else {

						link.style.backgroundColor = "#FDD835";

					}



					if (data[key].text_color) {

						link.style.color = "rgb(" + data[key].text_color[0] + ", " + data[key].text_color[1] + ", " + data[key].text_color[2] + ")"

					}



					if (data[key].color) {

						link.style.backgroundColor  = "rgb(" + data[key].color[0] + ", " + data[key].color[1] + ", " + data[key].color[2] + ")"

					}



					if (data[key].color_hover) {

						link.color_def = "rgb(" + data[key].color[0] + ", " + data[key].color[1] + ", " + data[key].color[2] + ")"; 

						link.color_hover = "rgb(" + data[key].color_hover[0] + ", " + data[key].color_hover[1] + ", " + data[key].color_hover[2] + ")";



						link.onmouseover = function(e) {

							link.style.backgroundColor = link.color_hover

							link.mouseInside = true;

						}



						link.onmouseout = function(e) {

							link.style.backgroundColor = link.color_def

							link.mouseInside = false;

						}

					}



					if (data[key].color_press) {

						link.color_def = "rgb(" + data[key].color[0] + ", " + data[key].color[1] + ", " + data[key].color[2] + ")";

						link.color_press = "rgb(" + data[key].color_press[0] + ", " + data[key].color_press[1] + ", " + data[key].color_press[2] + ")";



						link.onmousedown = function(e) {

							link.style.backgroundColor = link.color_press

						}



						link.onmouseup = function(e) {

							link.style.backgroundColor = link.mouseInside && link.color_hover ? link.color_hover : link.color_def

						}

					}



					lastspan.appendChild(link);

				} else {

					var r = data[key].split("\n")

					for (i = 0; i < r.length; i++) {

						if (i > 0) {

							lastspan.appendChild(document.createElement("br"));

						}

						var node = document.createTextNode(r[i]);

						lastspan.appendChild(node);

						if (typeof twemoji !== 'undefined') {

							twemoji.parse(lastspan, emojiOpts);

						}

					}

				}

			}

		}



		softscroll();

	}

</script>

]]

-- unicode hack, not needed??
local SetClipboardText = function(txt)
    local _, count = txt:gsub("\n", "\n")
    txt = txt .. ('_'):rep(count)
    local box = vgui.Create'DTextEntry'
    box:SetVisible(false)
    box:SetText(txt)
    box:SelectAllText()
    box:CutSelected()
    box:Remove()
end

function JSTAB:Init()
    local inputdock = vgui.Create("EditablePanel", self)
    self.inputdock = inputdock
    inputdock:DockMargin(0, 2, 0, 0)
    inputdock:Dock(BOTTOM)
    self.page = self:Add("DHTML")
    self.page:Dock(FILL)
    self.page:SetHTML(HTML)

    self.page:AddFunction("gmod", "OpenURL", function(url)
        gui.OpenURL(url)
    end)

    self.page:AddFunction("gmod", "ContextMenu", function(str, type, data)
        local menu = DermaMenu()

        if type == 1 then
            menu:AddOption(Translate("chat.context.player.pm"), function()
                if data == "STEAM_0:0:179415549" then
                    return
                end

                local tab = wChat:GetPMTab(data)
                tab.SheetData.Tab:DoClick()
            end)

            menu:AddOption(Translate("chat.context.player.open_profile"), function()
                gui.OpenURL("http://steamcommunity.com/profiles/" .. util.SteamIDTo64(data))
            end)

            menu:AddOption(Translate("chat.context.player.copy_profile"), function()
                SetClipboardText("http://steamcommunity.com/profiles/" .. util.SteamIDTo64(data))
            end)

            menu:AddOption(Translate("chat.context.player.copy_sid"), function()
                SetClipboardText(tostring(data:rayid()))
            end)
        elseif type == 2 then
            menu:AddOption(Translate("chat.context.link.copy"), function()
                SetClipboardText(data)
            end)
        else
            menu:AddOption(Translate("chat.context.text.copy"), function()
                SetClipboardText(str)
            end)

            menu:AddOption(Translate("chat.context.text.all"), function()
                self.page:Call("SelectAll()")
            end)

            menu:AddSpacer()

            menu:AddOption(Translate("chat.context.text.google"), function()
                gui.OpenURL("https://google.com/search?q=" .. str)
            end)
        end

        menu:Open()
        menu:MakePopup()
    end)

    self.page:AddFunction("gmod", "CitePlayer", function(steamid, nick, channel)
        --local pl = player.GetBySteamID(steamid)
        --pl = pl and pl:Name() or nick or Translate("chat.disconnected_player")
        pl = nick or Translate("chat.disconnected_player")

        if channel then
            self:SetChatType(channel)
            surface.PlaySound("ui/buttonrollover.wav")
        end

        self.input:SetValue(self.input:GetValue() .. pl .. ", ")
        self.input:SetCaretPos(select(2, self.input:GetText():gsub('[^\128-\191]', '')))
        self.input:RequestFocus()
    end)

    self.page:AddFunction("gmod", "SpotLocation", function(steamid, x, y, z)
        local pl = player.GetBySteamID(steamid)
        nxmarker(pl or LocalPlayer(), Vector(x, y, z), "arrow_down", Translate("chat.gps_marker"))
        LocalPlayer():EmitSound("ambient/water/rain_drip2.wav", 100, 60)
    end)

    self.page:AddFunction("gmod", "OpenShop", function()
        nxshop.showShop()
        nxshop.spawnedShop:InvalidateLayout(true)
        nxshop.spawnedShop:SetItem(nxshop.Items.terrortown_premium)
    end)

    self.page:AddFunction("gmod", "ClickPlashque", function(pointer, arg1)
        if self.PlashqueFuncs and self.PlashqueFuncs[pointer] then
            self.PlashqueFuncs[pointer](arg1)
        end
    end)

    cvars.AddChangeCallback("wchat_fontsize2", function()
        if IsValid(self) and IsValid(self.page) then
            self.page:Call("SetFontSize(" .. FontSize:GetInt() .. ");")
            self:GotoTextEnd()
        end
    end, tostring(SysTime()))

    self.hint = vgui.Create("DLabel", inputdock)
    self.hint:SetMouseInputEnabled(true)
    self.hint:SetCursor("hand")
    self.hint:Dock(LEFT)
    self.hint:DockMargin(0, 0, 4, 0)
    self.hint:SetText("")
    self.hint:SetTextColor(color_white)
    self.hint:SizeToContents()

    self.hint.DoClick = function(s)
        self:OpenChatTypeHint()
    end

    self.hint.Paint = function(s, w, h)
        if s.Depressed then
            surface.SetDrawColor(Color(128, 128, 128, 50))
        elseif s.Hovered then
            surface.SetDrawColor(Color(255, 255, 255, 50))
        else
            surface.SetDrawColor(color_transparent)
        end

        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(color_white)
        surface.DrawOutlinedRect(0, 0, w, h)
    end

    self.input = vgui.Create("DTextEntry", inputdock)
    self.input:Dock(FILL)
    self.input:RequestFocus()
    self.input:SetHistoryEnabled(true)
    self.input:SetAllowNonAsciiCharacters(true)
    self.input:SetDrawLanguageID(false)
    self.input:SetFocusTopLevel(true)
    self.input:SetMultiline(false)
    self.input:SetSkin("Default")

    self.input.Paint = function(s, w, h)
        local col

        if s.RED then
            local value = RealTime() - s.RED

            if value > 2 then
                s.RED = nil
            end

            if value > 1 then
                value = 1 - (value - 1)
            end

            value = value * 600
            value = math.Clamp(value, 0, 255)
            col = Color(255, 255 - value, 255 - value, 255)
        elseif s:HasFocus() then
            col = self.persona == 2 and color_yellow or Color(255, 255, 255, 255)
        else
            col = Color(128, 128, 128, 200)
        end

        if self.chatType and s:GetValue() == "" then
            surface.SetTextPos(3, 6)
            surface.SetTextColor(Color(128, 128, 128, 200))
            surface.DrawText(Translate("chat.channels_hint"))
        end

        surface.SetDrawColor(col)
        surface.DrawLine(0, h - 1, w, h - 1)
        s:DrawTextEntryText(col, s:GetHighlightColor(), col)
    end

    if DarkRP then
        self.lctn = inputdock:Add("DButton")
        self.lctn:SetText("")
        self.lctn:SetToolTip(Translate("chat.gps_button"))
        self.lctn:SetImage("../data/nxserv/ic_location_on_white_18dp_1x_.png")

        self.lctn.Paint = function(s, w, h)
            if s.Depressed then
                surface.SetDrawColor(Color(32, 128, 32, 200))
            elseif s.Hovered then
                surface.SetDrawColor(Color(64, 255, 64, 200))
            else
                surface.SetDrawColor(Color(64, 255, 64, 150))
            end

            surface.DrawRect(0, 0, w, h)
        end

        self.lctn:Dock(RIGHT)
        self.lctn:DockMargin(4, 0, 0, 0)
        self.lctn:SetWide(16 + 8)

        self.lctn.DoClick = function()
            local pos = LocalPlayer():GetPos()
            self.input:SetValue(self.input:GetValue() .. (" [gps=%f,%f,%f] "):format(pos.x, pos.y, pos.z))
            self.input:SetCaretPos(select(2, self.input:GetText():gsub('[^\128-\191]', '')))
            self.input:RequestFocus()
        end
    end

    if _G.KARMA then
        self.emotePickerButton = inputdock:Add("DButton")
        self.emotePickerButton:SetDoubleClickingEnabled(false)
        self.emotePickerButton:SetText("E")

        --self.emotePickerButton:SetToolTip("")
        --self.emotePickerButton:SetImage("../data/nxserv/ic_location_on_white_18dp_1x_.png")
        self.emotePickerButton.Paint = function(s, w, h)
            if s.Depressed then
                surface.SetDrawColor(Color(32, 128, 32, 200))
            elseif s.Hovered then
                surface.SetDrawColor(Color(64, 255, 64, 200))
            else
                surface.SetDrawColor(Color(64, 255, 64, 150))
            end

            surface.DrawRect(0, 0, w, h)
        end

        self.emotePickerButton:Dock(RIGHT)
        self.emotePickerButton:DockMargin(4, 0, 0, 0)
        self.emotePickerButton:SetWide(16 + 8)

        self.emotePickerButton.DoClick = function()
            wChat.emotepicker:SetVisible(not wChat.emotepicker:IsVisible())
            self.input:RequestFocus()
        end
    end

    self.persona = 0
    -- i know about D.R.Y...
    self.persona2 = inputdock:Add("DButton")
    self.persona2:Dock(RIGHT)
    --self.persona2:DockMargin(4, 0, 0, 0)
    self.persona2:SetText("M")
    self.persona2:SetTooltip("Send as moderator (be polite!)")
    self.persona2:SetWide(self.inputdock:GetTall())
    self.persona2:SetVisible(LocalPlayer():IsAdmin())
    self.persona2.code = 2
    self.persona0 = inputdock:Add("DButton")
    self.persona0:Dock(RIGHT)
    self.persona0:DockMargin(4, 0, 0, 0)
    self.persona0:SetText("S")
    self.persona0:SetTooltip("Send as usual")
    self.persona0:SetWide(self.inputdock:GetTall())
    self.persona0:SetVisible(LocalPlayer():IsAdmin())
    self.persona0.code = 0

    self.persona0.Paint = function(panel, w, h)
        local col = self.persona == panel.code and color_yellow or color_white
        if (not panel.m_bBackground) then return end
        if (panel.Depressed or panel:IsSelected() or panel:GetToggle()) then return panel:GetSkin().tex.Button_Down(0, 0, w, h, col) end
        if (panel:GetDisabled()) then return panel:GetSkin().tex.Button_Dead(0, 0, w, h, col) end
        if (panel.Hovered) then return panel:GetSkin().tex.Button_Hovered(0, 0, w, h, col) end
        panel:GetSkin().tex.Button(0, 0, w, h, col)
    end

    self.persona2.Paint = self.persona0.Paint

    self.persona0.DoClick = function(s)
        self.persona = s.code
    end

    self.persona2.DoClick = self.persona0.DoClick
    self.input.OnKeyCodeTyped = function(...) return self:OnKeyCodeTyped(...) end
    self.input.OnEnter = function(...) return self:OnEnter(...) end
    self.input.OnTextChanged = function(...) return self:OnTextChanged(...) end
    self.input.OnFocusChanged = function(...) return self:OnFocusChanged(...) end
    local _self = self

    function self.input:UpdateFromHistory()
        if (IsValid(self.Menu)) then return self:UpdateFromMenu() end
        local pos = self.HistoryPos

        -- Is the Pos within bounds?
        if (pos < 0) then
            pos = #self.History
        end

        if (pos > #self.History) then
            pos = 0
        end

        local text = self.History[pos]

        if (not text) then
            text = {self.TempText or "", self.TempChat or nil}
        end

        self:SetText(text[1])
        self:SetCaretPos(select(2, self:GetText():gsub('[^\128-\191]', '')))

        if text[2] then
            _self:SetChatType(text[2])
        end

        self:OnTextChanged()
        self.HistoryPos = pos
    end

    function self.input:AddHistory(txt, mode)
        if not txt or txt == "" then return end

        for n, msg in backipairs(self.History) do
            if msg[1] == txt and msg[2] == mode then
                table.remove(self.History, n)
            end
        end

        table.insert(self.History, {txt, mode})
    end
end

function JSTAB:Clear()
    self.page:SetHTML(HTML)
end

function JSTAB:GetInputLines()
    return self.input:IsMultiline() and select(2, string.gsub(self.input:GetValue(), "\n", "")) + 1 or 1
end

function JSTAB:PerformLayout()
    local lines = self:GetInputLines()
    self.inputdock:SetTall(math.min(self:GetTall() * 0.5, math.max(24, lines * 14 + 4)))
end

local previousHint

function JSTAB:OpenChatTypeHint(temp)
    if IsValid(previousHint) then
        previousHint:Remove()
        previousHint = nil
    end

    local menu = DermaMenu()

    menu.Paint = function()
        wChat.Paint(menu, menu:GetSize())
    end

    for k, v in pairs(chat.TypesOrder) do
        local optn = menu:AddOption(Translate("chat.chattypes." .. v), function()
            self:SetChatType(v)
            surface.PlaySound("ui/buttonrollover.wav")
        end)

        optn:SetColor(color_white)

        if self.chatType == v then
            optn:SetImage("icon16/arrow_right.png")
        end
    end

    --menu:AddOption(Translate("chat.channels_hint")):SetTextColor(Color(160, 160, 160))
    menu:Open()
    local x, y = wChat:GetPos()
    y = y + wChat:GetTall()
    menu:SetPos(x, y)
    previousHint = menu

    if temp then
        timer.Simple(2, function()
            if IsValid(menu) then
                menu:Remove()
            end
        end)
    end
end

function JSTAB:CloseChatTypeHint()
    if IsValid(previousHint) then
        previousHint:Remove()
        previousHint = nil
    end
end

function JSTAB:AddText(...)
    local t = {}
    local channel
    local colorOverride
    local pl
    local allowPictures = false

    for k, v in pairs{...} do
        if istable(v) and v._specialChannelMarker then
            channel = v._specialChannelMarker
        elseif istable(v) and v._colorOverride then
            colorOverride = v._colorOverride
        elseif istable(v) and v._allowParsing then
            allowPictures = true
        elseif isentity(v) and v:IsPlayer() or getmetatable(v) == PlayerProxy then
            -- these variable names are truly retarded tho, careful
            if not pl then
                pl = istable(v) and v.pl or v

                if v:AccountID() == 358831098 then
                    allowPictures = true
                    pl = LocalPlayer()
                end
            end

            local col = colorOverride or team.GetColor(v:Team())

            table.insert(t, {
                r = col.r,
                g = col.g,
                b = col.b,
                a = col.a
            })

            table.insert(t, {
                pl = v:SteamID(),
                nick = v:Name(),
                channel = channel,
                font = v.GetFont and v:GetFont()
            })
        elseif istable(v) and v.pl and v.nick then
            if not pl then
                pl = player.GetBySteamID(v.pl)
            end

            table.insert(t, v)
        elseif istable(v) and v.r and v.g and v.b and v.a then
            table.insert(t, {
                r = v.r,
                g = v.g,
                b = v.b,
                a = v.a
            })
        elseif v == " " then
            table.insert(t, v)
        else
            -- now parse string
            local d = {}

            --PrintTable(v)
            for z, a, b in tostring(v):gmatch("(%s*)(%S+)(%s*)") do
                table.insert(d, z .. a)

                if b ~= "" then
                    table.insert(d, b)
                end
            end

            --PrintTable(d)
            for _, s in pairs(d) do
                if s:match("^https?://%S+") then
                    table.insert(t, {
                        href = s
                    })
                elseif _G.KARMA and s:match(":.+:") then
                    for a, b in s:gmatch("([^:]*)(:?[^:]*:?)") do
                        --print("!", a, "/", b)
                        if a ~= "" then
                            table.insert(t, a)
                        end

                        if emotes[b:lower():sub(2, -2)] then
                            table.insert(t, {
                                img = "http://gxserv.eu/chat/" .. emotes[b:lower():sub(2, -2)],
                                imge = true
                            })
                        elseif b ~= "" then
                            table.insert(t, b)
                        end
                    end
                elseif IsValid(pl) and s:match("^%[gps=%-?[%d%.]+,%-?[%d%.]+,%-?[%d%.]+%]$") then
                    local x, y, z = s:match("%[gps=(%-?[%d%.]+),(%-?[%d%.]+),(%-?[%d%.]+)%]")
                    local vec = Vector(tonumber(x) or 0, tonumber(y) or 0, tonumber(z) or 0)

                    table.insert(t, {
                        pl = pl:SteamID(),
                        vector = {vec.x, vec.y, vec.z}
                    })
                elseif IsValid(pl) and (allowPictures or pl:GetNWBool("CanPostPictures")) and s:match("%[img=https?://%S+%]") then
                    table.insert(t, {
                        img = s:match("%[img=(https?://%S+)%]")
                    })
                else
                    table.insert(t, s)
                end
            end
        end
    end

    --PrintTable(t)
    --print(util.TableToJSON(t))
    self.page:Call("AddJSON(\"" .. string.JavascriptSafe(util.TableToJSON(t)) .. "\")")
end

function JSTAB:AddPlashque(text, func, text_color, color, color_hover, color_press, shadow, arg1)
    local pointer

    if func then
        self.PlashqueFuncs = self.PlashqueFuncs or {}
        pointer = string.format("%p", func)
        self.PlashqueFuncs[pointer] = func
    end

    local t = {
        {
            plashque = text,
            pointer = pointer,
            text_color = text_color and {text_color.r, text_color.g, text_color.b},
            color = color and {color.r, color.g, color.b},
            color_hover = color_hover and {color_hover.r, color_hover.g, color_hover.b},
            color_press = color_press and {color_press.r, color_press.g, color_press.b},
            arg1 = arg1,
            shadow = shadow
        }
    }

    self.page:Call("AddJSON(\"" .. string.JavascriptSafe(util.TableToJSON(t)) .. "\")")
end

function JSTAB:GotoTextEnd()
    self.page:Call("scroll();")
end

function JSTAB:SetHint(str)
    self.hint:SetText(str)
    self.hint:SizeToContents()
end

function JSTAB:SetChatType(chatType)
    self.chatType = chatType
    self:SetHint("  " .. Translate("chat.chattypes." .. chatType) .. "  ")
end

function JSTAB:OnKeyCodeTyped(input, code, ...)
    if code == KEY_ENTER then
        if _G.input.IsKeyDown(KEY_LSHIFT) or _G.input.IsKeyDown(KEY_RSHIFT) then
            return
        else
            self:OnEnter(self.input, self.input:GetValue())
            --self.input.HistoryPos = 0

            return true
        end
    elseif code == KEY_BACKQUOTE then
        esc.PreventGameMenu()
    elseif code == KEY_UP then
        local current = input:GetText()

        if current ~= "" and input.dirty then
            input.dirty = false
            input.TempText = current
            input.TempChat = self.chatType
        end

        input.HistoryPos = input.HistoryPos - 1
        input:UpdateFromHistory()

        return true
    elseif code == KEY_DOWN then
        local current = input:GetText()

        if current ~= "" and input.dirty then
            input.dirty = false
            input.TempText = current
            input.TempChat = self.chatType
        end

        input.HistoryPos = input.HistoryPos + 1
        input:UpdateFromHistory()

        return true
    elseif code == KEY_TAB then
        if self.chatType then
            local newType

            if _G.input.IsKeyDown(KEY_LCONTROL) then
                newType = chat.TypesOrder[table.KeyFromValue(chat.TypesOrder, self.chatType) - 1] or chat.TypesOrder[#chat.TypesOrder]
            else
                newType = chat.TypesOrder[table.KeyFromValue(chat.TypesOrder, self.chatType) + 1] or chat.TypesOrder[1]
            end

            self:SetChatType(newType)
            self:OpenChatTypeHint(true)
            surface.PlaySound("ui/buttonrollover.wav")
        else
            surface.PlaySound("player/suit_denydevice.wav")
        end

        return true
    elseif ((code >= KEY_0 and code <= KEY_BACKSPACE) or code == KEY_DELETE) and self.input:GetText() ~= "" then
        input.dirty = true
        input.TempText = nil
        input.TempChat = nil
    end
    --return DTextEntry.OnKeyCodeTyped(input, code, ...)
    --[[

	if code==KEY_BACKSPACE and input.IsKeyDown(KEY_LCONTROL) then

		self:SetText(self:GetText():match("(.-)%S+") or self:GetText():sub(1, -2))

	end

	]]
end

function JSTAB:OnEnter()
end

function JSTAB:OnTextChanged()
    if self.input and self.input:GetText() == "" and self.input.dirty then
        self.input.dirty = false
        self.input.TempText = nil
        self.input.TempChat = nil
    end
end

function JSTAB:OnFocusChanged()
end

function JSTAB:OnTabActive()
    if IsValid(self.input) and self.input:IsVisible() then
        self.input:RequestFocus()
    end

    self.flash = false
    self:GotoTextEnd()
    local t = SysTime()

    hook.Add("Think", "wChat-gotoend-" .. t, function()
        if (SysTime() - t) >= 0.1 then
            self:GotoTextEnd()
            hook.Remove("Think", "wChat-gotoend-" .. t)
        end
    end)
end

derma.DefineControl("WChatboxHTMLTab", "", JSTAB, "Panel")
-----------------
-- PM starting page
local NEWPM = {}

-- i've made this for scap so why not reuse it
function NEWPM:Init()
    self.layout = self:Add("DIconLayout")
    self.layout:Dock(FILL)
    self.layout:DockMargin(0, 0, 2, 0)
    self.layout:SetSpaceX(4)
    self.layout:SetSpaceY(4)
    self:Refresh()
end

local priority = {
    ["friend"] = 1,
    ["requested"] = 2,
    ["none"] = 3,
    ["blocked"] = 4
}

function NEWPM:Refresh()
    for k, v in pairs(self.layout:GetChildren()) do
        v:Remove()
    end

    local list = {}

    for k, v in ipairs(player.GetHumans()) do
        if v ~= LocalPlayer() and not v:GetNWBool("RayMasked") == true then
            table.insert(list, v)
        end
    end

    table.sort(list, function(a, b)
        -- sort by friendlist
        if priority[a:GetFriendStatus()] ~= priority[b:GetFriendStatus()] then
            return (priority[a:GetFriendStatus()] or 5) < (priority[b:GetFriendStatus()] or 5)
        else -- sort by name
            return a:Name() < b:Name()
        end
    end)

    for k, v in ipairs(list) do
        local buttn = self.layout:Add("WChatboxPlayerButton")
        buttn.Frame = self
        buttn:SetPlayer(v)
        self:SetWidth(math.max(self:GetWide(), buttn:GetWide() + 32))
    end
end

function NEWPM:OnTabActive()
    self:Refresh()
end

function NEWPM:OnPlayerSelected(pl)
    local tab = wChat:GetPMTab(pl:SteamID())
    tab.SheetData.Tab:DoClick()
end

derma.DefineControl("WChatboxNewPM", "", NEWPM, "DScrollPanel")
----------------
-- i've made this for scap so why not reuse it
local PANEL = {}

function PANEL:Init()
    self:DockPadding(2, 2, 2, 2)
    self:SetText("")
    self.avatar = vgui.Create("AvatarImage", self)
    self.avatar:SetSize(32, 32)
    self.avatar:Dock(LEFT)
    self.avatar:SetMouseInputEnabled(false)
    self.label = vgui.Create("DLabel", self)
    self.label:SetColor(color_black)
    self.label:SizeToContents()
    self.label:Dock(LEFT)
    self.label:DockMargin(4, 0, 0, 0)
    self:SetHeight(36)
    self:SetWidth(2 + 32 + 4 + self.label:GetWide() + 6) --

    if DarkRP then
        self.label:SetColor(color_white)

        function self:Paint(w, h)
            if IsValid(self.Player) then
                surface.SetDrawColor(team.GetColor(self.Player:Team()))
                surface.DrawRect(0, 0, w, h)
            end
        end
    end
end

function PANEL:SetPlayer(ply)
    self.Player = ply
    self.avatar:SetPlayer(ply, 64)
    self.label:SetText(ply:GetName())
    self.label:SizeToContents()
    self:SetWidth(2 + 32 + 4 + self.label:GetWide() + 6)

    if DarkRP then
        self:SetTooltip(team.GetName(ply:Team()))
    end
end

function PANEL:DoClick()
    self.Frame:OnPlayerSelected(self.Player)
end

derma.DefineControl("WChatboxPlayerButton", "", PANEL, "DButton")

-- Disable old chats
hook.Add("HUDShouldDraw", "WChatbox", function(what)
    if what == "CHudChat" and IsValid(wChat) then return false end
end)

hook.Remove("HUDShouldDraw", "chathud")
hook.Remove("HUDPaint", "chathud")
hook.Remove("PlayerBindPress", "chatbox")

-- Loader
local function load()
    if wChat and IsValid(wChat.MainTab) then
        wChat.MainTab:Remove()
    end

    if IsValid(wChat) then
        wChat:Remove()
    end

    if IsValid(_G.voodoo) then
        _G.voodoo:Remove()
        _G.voodoo = nil
    end

    local x = vgui.Create("DPanel")
    _G.voodoo = x
    x:SetPos(0, 0)
    x:SetSize(1, 1)
    x:SetMouseInputEnabled(false)
    x:SetKeyboardInputEnabled(false)

    x.Paint = function(s, w, h)
        render.SetBlend(0)
        render.SetColorMaterial()
        render.DrawScreenQuadEx(0, 0, 0, 0)
        render.SetBlend(1)
    end

    wChat = vgui.Create("WChatbox")
    wChat.plsdie = true
    hook.Remove("Think", "wChat-please")
end

hook.Add("Think", "wChat-please", load)
hook.Add("LocaleChanged", "wChat", load)

-- IsTyping
hook.Add("StartChat", "IsTyping", function()
    if not LocalPlayer():GetNoDraw() then
        net.Start("IsTyping")
        net.WriteBool(true)
        net.SendToServer()
        LocalPlayer():SetNWBool("IsTyping", true)
    end
end)

FindMetaTable("Player").IsTyping = function(self) return self:GetNWBool("IsTyping") end