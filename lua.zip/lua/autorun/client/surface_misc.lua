-- Draw sliced from 0 to and degree rectangle sector
-- centered in x,y, w wide, h tall
-- x, y : number   center
-- w, h : number   width and height
-- ang  : number   slice angle
function surface.DrawPie(x, y, w, h, ang)
    if ang <= 0 then return end
    local w2, h2 = w / 2, h / 2

    if ang >= 360 then
        surface.DrawTexturedRect(x - w2, y - h2, w, h)
    elseif ang < 180 then
        local tc = math.tan(math.min(math.rad(ang), math.rad(45))) * 0.5
        local rc = math.tan(math.rad(math.min(ang - 90, 45))) * 0.5
        local bc = math.tan(math.rad(180 - ang)) * 0.5

        surface.DrawPoly{
            {
                x = x,
                y = y,
                u = 0.5,
                v = 0.5
            },
            {
                x = x,
                y = y - h2,
                u = 0.5,
                v = 0
            },
            {
                x = x + tc * w,
                y = y - h2,
                u = 0.5 + tc,
                v = 0
            },
            ang > 45 and {
                x = x + w2,
                y = y + rc * h,
                u = 1,
                v = 0.5 + rc
            },
            ang > 135 and {
                x = x + bc * w,
                y = y + h2,
                u = 0.5 + bc,
                v = 1
            }
        }
    else
        surface.DrawPoly{
            {
                x = x,
                y = y - h2,
                u = 0.5,
                v = 0
            },
            {
                x = x + h2,
                y = y - h2,
                u = 1,
                v = 0
            },
            {
                x = x + h2,
                y = y + h2,
                u = 1,
                v = 1
            },
            {
                x = x,
                y = y + h2,
                u = 0.5,
                v = 1
            }
        }

        local bc = math.tan(math.rad(math.min(ang - 180, 45))) * 0.5
        local lc = math.tan(math.rad(math.min(ang - 270, 45))) * 0.5
        local tc = math.tan(-math.rad(ang)) * 0.5

        surface.DrawPoly{
            {
                x = x,
                y = y,
                u = 0.5,
                v = 0.5
            },
            {
                x = x,
                y = y + h2,
                u = 0.5,
                v = 1
            },
            {
                x = x - bc * w,
                y = y + h2,
                u = 0.5 - bc,
                v = 1
            },
            ang > 225 and {
                x = x - w2,
                y = y - lc * h,
                u = 0,
                v = 0.5 - lc
            },
            ang > 315 and {
                x = x - tc * w,
                y = y - h2,
                u = 0.5 - tc,
                v = 0
            }
        }
    end
end


NX_ICONFONT = "nxiconic14c"

surface.CreateFont("NXIconicLarge", {
    font = NX_ICONFONT,
    size = 48
})

-- just multiply size by align coefficient and add it to position
ALIGN_LEFT = 0
ALIGN_CENTER = 0.5
ALIGN_RIGHT = 1
ALIGN_TOP = 1
ALIGN_BOTTOM = 0

local shadow_x = 1
local shadow_y = 1
local col_face = Color(255, 255, 255, 255)
local col_shadow = Color(0, 0, 0, 255)
local col_half_shadow = Color(0, 0, 0, 200)
local col_money = Color(64, 192, 32)

function draw.BeautyText(str, font, font_shadow, x, y, color, xalign, yalign)
    font = font or "nx_hud"
    surface.SetFont(font)
    local tw, th = surface.GetTextSize(str)
    x = (x or 0) - tw * (xalign or 0)
    y = (y or 0) - th * (yalign or 0)
    surface.SetTextPos(x, y)

    -- soft shadow
    if font_shadow then
        surface.SetTextPos(x, y + 3)
        surface.SetTextColor(col_shadow)
        surface.SetFont(font_shadow)
        surface.DrawText(str)
        surface.SetTextPos(x, y)
    end

    -- sharp shadow
    surface.SetTextPos(x + shadow_x, y + shadow_y)
    surface.SetTextColor(col_half_shadow)
    surface.SetFont(font)
    surface.DrawText(str)
    -- text itself
    surface.SetTextColor(color or col_face)
    surface.SetTextPos(x, y)
    surface.DrawText(str)

    return tw, th
end

local function charWrap(text, pxWidth, maxWidth)
    local total = 0

    text = text:gsub(utf8.charpattern, function(char)
        total = total + surface.GetTextSize(char)

        -- Wrap around when the max width is reached
        if total >= pxWidth then
            total = 0
            pxWidth = maxWidth

            return "\n" .. char
        end

        return char
    end)

    return text, total
end

function surface.textWrap(text, font, pxWidth)
    local total = 0
    surface.SetFont(font)
    local spaceSize = surface.GetTextSize(' ')

    text = text:gsub("(%s?[%S]+)", function(word)
        local char = string.sub(word, 1, 1)

        if char == "\n" or char == "\t" then
            total = 0
        end

        local wordlen = surface.GetTextSize(word)
        total = total + wordlen

        -- Wrap around when the max width is reached
        -- Split the word if the word is too big
        if wordlen >= pxWidth then
            local splitWord, splitPoint = charWrap(word, pxWidth - (total - wordlen), pxWidth)
            total = splitPoint

            return splitWord
        elseif total < pxWidth then
            return word
        end

        -- Split before the word
        if char == ' ' then
            total = wordlen - spaceSize

            return '\n' .. string.sub(word, 2)
        end

        total = wordlen

        return '\n' .. word
    end)

    return text
end