local L = function(s) return s end
local checking

local hostip, hostport = unpack(game.GetIPAddress():Split(":"))
local unix

http.Fetch("http://" .. hostip .. ":27011/" .. (hostport or 27015), function(str, _, _, code)
	if code == 200 then
		unix = str
		print("Server last start:", unix)
	end
end)

-- you need to send this or nope
net.Receive("checkurl", function()
	local ip = net.ReadUInt(32)
	
	local checkip = ("%d.%d.%d.%d"):format(bit.band(bit.rshift(ip, 24), 0xff), bit.band(bit.rshift(ip, 16), 0xff), bit.band(bit.rshift(ip, 8), 0xff), bit.band(ip, 0xff))
	local checkport = tostring(net.ReadUInt(16))

	if hostip ~= checkip then
		easylua.Print("hostip and checkip don't match!")
		hostip = checkip
	end

	if hostport ~= checkport then
		easylua.Print("hostport and checkport don't match!")
		hostport = checkport
	end
end)

local function checkInternet(cb)
	http.Fetch("http://clients3.google.com/generate_204", function(str, _, _, code)
		cb(true, code == 204)
	end, function()
		cb(false)
	end)
end

local ripInternet

local function isInternetFucked()
	checkInternet(function(hasConnection, notRestricted)
		local now = not (hasConnection and notRestricted)

		if ripInternet ~= now then
			hook.Run("InternetStatus", not now)
		end

		ripInternet = now
	end)
end

local function check_servid(cb)
	if (checking and checking > SysTime()) then return end
	checking = SysTime() + 0.6

	http.Fetch("http://" .. hostip .. ":27011/" .. (hostport or 27015), function(str, _, _, code)
		checking = false

		if code == 200 and unix ~= str then
			cb(true)
		else
			cb(false)
		end
	end)
end

local hookName = "Crash_Tick"
local RECONNECT_DELAY = 100
---------------------------------
-- Autoreconnect
---------------------------------
local disableReconnect = false
local PLAYER = FindMetaTable("Player")

local function reconnect()
	if not disableReconnect then
		-- TODO: This also happens during changelevel...
		MsgN("========================")
		MsgN("Server did not recover.\nTrying to reconnect.")
		MsgN("========================\n")
		PLAYER.ConCommand(NULL, "retry", true) -- epic leet hax
		PLAYER.ConCommand(NULL, "retry") -- epic leet hax
		RunConsoleCommand"retry"
	end
end

local wasup

local function callback_pollup(up)
	if up then
		wasup = true
		print"Server says it's up. let's go!"
		reconnect()
	else
		wasup = false
		print"Server says, it is still down :\\"
	end
end

local function pollup()
	if not hostport then return end
	if disableReconnect and wasup then return end
	check_servid(callback_pollup)
	isInternetFucked()
end

local function PlayerBindPress_Hook(_, key, down)
	if not down then return end

	if string.find(key, "gm_showhelp", 1, true) then
		if not disableReconnect then
			disableReconnect = true
			chat.AddText(L"Autoreconnect prevented. Press F1 again to trigger reconnect!")
		else
			disableReconnect = false
			reconnect()
		end

		return true
	end
end

local messages = {
	{time = 0, msg = "Something went wrong"},
	{time = 5, func = isInternetFucked, msg = "We're sorry for the lag"},
	{time = 7, func = pollup, msg = "We're sorry for the lag"},
	{time = 10, func = pollup, msg = "Okay, the server crashed"},
	{time = 15, func = pollup, msg = "#LoadingProgress_Changelevel"},
	{time = 20, func = pollup, msg = "#LoadingProgress_Changelevel"},
	{time = 25, func = pollup, msg = "#LoadingProgress_Changelevel"},
	{time = 28, func = pollup, msg = "#LoadingProgress_Changelevel"},
	{time = 30, func = pollup, msg = "Asking if it's up"},
	{time = 31, func = pollup, msg = "Asking again if it's up!"},
	{time = 32, func = pollup, msg = "Meh...."},
	{time = 33, func = pollup, msg = "#GameUI_EstablishingConnection"},
	{time = 38, func = pollup, msg = "One more check..."},
	{time = 42, func = pollup, msg = "Okay, it's taking a bit longer"},
	{time = 43, func = pollup, msg = "Hold on a second :)"},
	{time = 45, func = pollup, msg = "#GameUI_EstablishingConnection"},
	{time = 47, func = pollup, msg = "Reconnecting soon."},
	{time = 51, func = pollup, msg = "Reconnecting soon.."},
	{time = 53, func = pollup, msg = "Reconnecting soon..."},
	{time = 55, func = pollup, msg = "Reconnecting soon...."},
	{time = 60, func = pollup, msg = "It sure is slow today :("},
	{time = 62, func = pollup, msg = "It sure is slow today :(("},
	{time = 65, func = pollup, msg = "It sure is slow today :((("},
	{time = 70, func = pollup, msg = "It sure is slow today :(((("},
	{time = 73, func = pollup, msg = "It sure is slow today :((((("},
	{time = 75, func = pollup, msg = "Reconnecting anyway"},
	{time = 80, func = pollup, msg = "Reconnecting anyway (soon)"},
	{time = 85, func = pollup, msg = "Reconnecting anyway (veeery soon)"},
	{time = 90, func = pollup, msg = "Waiting 10 more seconds... and then! I promise!"},
	{time = 95, func = pollup, msg = "Oh well..reconnecting anyway for real..."},
	{time = RECONNECT_DELAY, func = reconnect},
	{time = RECONNECT_DELAY + 5, msg = ""},
}

local function resetmessages()
	for _, msg in pairs(messages) do
		msg.NotTriggered = true
	end
end

resetmessages()
local showmsg = "SERVFAIL"
local stripes = surface.GetTextureID"vgui/alpha-back"
local starttime = 0
local checklist

surface.CreateFont("crashsystems_big", {
	size = 22
})

local function crashoverlay()
	if disableReconnect and (RealTime() - starttime) > (RECONNECT_DELAY + 5) then return end
	local fade = (RealTime() - starttime) * 0.5
	local alpha = (fade < 0 and 0 or fade > 1 and 1 or fade) * 200
	local wide = ScrW()
	local tall = 32
	surface.SetDrawColor(30, 30, 30, alpha)
	surface.DrawRect(0, 0, wide, tall)
	local frac = (RealTime() - starttime) / RECONNECT_DELAY
	frac = frac < 0 and 0 or frac > 1 and 1 or frac
	local pos = wide * frac
	surface.SetTexture(stripes)
	surface.SetDrawColor(20, 50, 200, alpha)
	surface.DrawTexturedRectUV(-(pos % 128), 0, pos + (pos % 128), tall, 0, 0, (pos + (pos % 128)) / 128, 1)
	local msg = ripInternet and "NO INTERNET" or tostring(showmsg)
	local extra = " (" .. math.Round(RECONNECT_DELAY - (RealTime() - starttime)) .. " s)"
	surface.SetFont"crashsystems_big"
	local w, h = surface.GetTextSize(msg .. extra)
	surface.SetTextColor(255, 255, 255, alpha)
	pos = (pos - w * 0.5) < 0 and w * 0.5 or (pos + w * 0.5) > wide and wide - w * 0.5 or pos
	surface.SetTextPos(pos - w * 0.5, 16 - h * 0.5)
	surface.DrawText(msg)
	surface.DrawText(extra)
	if frac < 0.1 then return end
	if disableReconnect then return end
	if ripInternet then return end
	checklist = checklist or markup.Parse(Translate("crashes.instructions"))

	if checklist then
		checklist:Draw(2, 32 + 16)
	end
end

local inicrash

hook.Add("CrashTick", "CrashTick_Autoreconnect", function(crashed, when)
	if not crashed then
		resetmessages()
		ripInternet = nil
		inicrash = false
		--hook.Remove("HUDPaint", "CrashTick_Autoreconnect")
		hook.Remove("PlayerBindPress", "CrashTick_Autoreconnect")
		--hook.Remove("ShutDown", hookName)
		disableReconnect = false

		hook.Run("InternetStatus", true)
		hook.Run("CrashTick_Restored")

		return
	end

	if not inicrash then
		inicrash = true
		starttime = RealTime()
		--hook.Add("HUDPaint", "CrashTick_Autoreconnect", crashoverlay)
		hook.Add("PlayerBindPress", "CrashTick_Autoreconnect", PlayerBindPress_Hook)
		--hook.Add("ShutDown", hookName, reconnect_hook)
		disableReconnect = false

		hook.Run("CrashTick_Lost")
	end

	for _, msg in pairs(messages) do
		if (msg.NotTriggered and when > msg.time) then
			msg.NotTriggered = false

			if msg.msg then
				showmsg = msg.msg
				Msg"[Crash Tick] "
				print("Frozen for " .. msg.time .. " seconds")
				hook.Run("CrashTick_Msg", msg.time, msg.msg)
			end

			if (msg.func) then
				pcall(msg.func)
			end


			break
		end
	end
end)