if not GetGlobalBool("db-down") then return end

local texts = {
	ru = "Сейчас мы испытываем проблемы со связью. Из-за этого могут не загружаться деньги, имена, достижения.",
	en = "We are experiencing communication problems right now. Because of this money, names, and achievements can not be loaded.",
	fr = "Nous éprouvons des problèmes de communication en ce moment. En raison de cet argent, les surnoms et les réalisations ne peuvent pas être chargés.",
}

hook.Add("PostRenderVGUI", "db-down", function()
	surface.SetDrawColor(Color(255, 200, 0))
	surface.DrawRect(0, 0, ScrW(), 32)
	surface.SetTextColor(color_black)
	surface.SetFont("DermaLarge")
	surface.SetTextPos(0, 0)
	surface.DrawText(texts[nxserv.region_lang or "en"] or texts.en)
end)
