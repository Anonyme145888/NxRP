hook.Add("PlayerBindPress", "F7", function(_, bind, pressed)
	if bind == input.LookupKeyBinding(KEY_F7) then
		return true
	end
end)

local spawnedWindow
function SpawnReportWindow()
	if IsValid(spawnedWindow) then
		spawnedWindow:MakePopup()
		spawnedWindow.reports.entry:RequestFocus()
	else
		spawnedWindow = vgui.Create("ReportPanel")
	end
end

local trapped = false
hook.Add("Think", "F7", function()
	local keyDown = input.IsKeyDown(KEY_F7)
	if keyDown and not trapped then
		SpawnReportWindow()
	end
	trapped = keyDown
end)
