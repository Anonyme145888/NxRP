local langs = {"ru", "en", "fr"}

local function Panel(height, path, addbuttons)
	return Promise(function(resolve)
		local frame = vgui.Create("DPanel")
		-- frame:RegisterGamePanel()
		frame:SetSize(math.min(ScrW(), 780), math.min(ScrH(), height))
		frame:Center()
		frame:MakePopup()
		frame:SetKeyboardInputEnabled(false)
		function frame:Paint(w, h)
			self.m_fCreateTime = self.m_fCreateTime or SysTime()
			Derma_DrawBackgroundBlur(self, self.m_fCreateTime)
		end
		function frame:OnRemove()
			resolve()
		end

		local lang = server.region.lang

		local html = frame:Add("DHTML")
		html:OpenURL(("https://nxserv.eu/infopanel/%s/%s.htm"):format(path, table.iHasValue(langs, lang) and lang or "en"))
		html:Dock(FILL)

		local button = frame:Add("DButton")
		button:SetText(Translate("ui.close"))
		function button:DoClick()
			frame:Remove()
		end
		button:SetTall(50)
		button:Dock(BOTTOM)

		if addbuttons then
			addbuttons(frame)
		end
	end)
end

hook.AddRun("Initialize", "infopanels", function()
	if server.gm.darkrp then
		hook.AddRun("SpawnViewFinished", "infopanels", asyncSimple(function()
			if GetConVarString("cl_downloadfilter") ~= "all" then
				await(Panel(892, "downloadfilter"))
				-- changing of cl_downloadfilter is blocked :<
			end
		end))
	else
		asyncRun(function()
			if GetConVarString("cl_downloadfilter") ~= "all" then
				await(Panel(892, "downloadfilter"))
				-- changing of cl_downloadfilter is blocked :<
			end
		end)
	end
end)