local PANEL = {}

function PANEL:Init()
	self.massoc = {}
	self.lasttall = 0

	ray.PanelC(self)
	--self:SetSize(300, 492)
	self:Think()
	

	self.scroll = self:Add("DScrollPanel")
	self.scroll:Dock(FILL)
	fixscrollbar(self.scroll)
	-- piece of shit dscrollpanel doesn't play well with dock(bottom)

	self:InvalidateLayout(true)
	self:InvalidateChildren(true)

	--[[
	self.canvas = self:Add("Panel")
	self.canvas:Dock(FILL)
	self.canvas:SetPaintedManually(true)
	]]

	local last

	for i, v in ipairs(NotifCenter.messagesSorted) do
		last = self:AddEntry(v)
	end

	if last then
		self:InvalidateLayout(true)
		self:InvalidateChildren(true)
		self.scroll:ScrollToChild(last)
	end

	self.uid = ("%p"):format(self)

	hook.Add("NotifCenter_MsgCreated", self.uid, function(id)
		local pnl = self:MessageCreated(id)

		if vgui.CursorVisible() then
			self.scrollto = pnl
		else
			self:InvalidateLayout(true)
			self:InvalidateChildren(true)
			self.scroll:ScrollToChild(pnl)
		end

		self:SetVisible(true)
	end)

	hook.Add("NotifCenter_MsgUpdated", self.uid, function(id)
		self:MessageUpdated(id)
	end)

	hook.Add("NotifCenter_MsgRemoved", self.uid, function(id)
		--print("REMOOOV", id)
		self:MessageRemoved(id)
	end)

	timer.Create("SpawnedNotifCenter" .. self.uid, 1, 0, function()
		if IsValid(self) then
			self:SetVisible(self.scroll.pnlCanvas:HasChildren())
		end
	end)
end

function PANEL:Think()
	local tall = 0

	if self.scroll then
		tall = self.scroll.pnlCanvas:GetTall()
	end

	local x, y = chat.GetChatBoxPos()
	--local w, h = wChat:GetSize()
	local w, h = chat.GetChatBoxSize()
	local left = y - wChat.addbuttons:GetTall() - 10
	self:SetSize(w, math.min(left, tall))
	self:SetPos(x, left - self:GetTall())

	--[[
	if self.lasttall ~= tall then
		self:InvalidateLayout(true)
		self:InvalidateChildren(true)
	end

	self.lasttall = tall
	]]

	if self.scrollto and self.scrollto:IsValid() and not vgui.CursorVisible() then
		self:InvalidateLayout(true)
		self:InvalidateChildren(true)
		self.scroll:ScrollToChild(self.scrollto)
		self.scrollto = nil
	end
end

--[[
local grad = Material("gui/gradient_up")

local tex = render.GetScreenEffectTexture(0)

local myMat = CreateMaterial( "ExampleMaskRTMat3", "UnlitGeneric", {
	["$basetexture"] = tex:GetName(), -- Make the material use our render target texture
	["$translucent"] = "1" -- make the drawn material transparent
} )

function PANEL:Paint(w, h)
	render.PushRenderTarget(tex)
		render.Clear(0, 0, 0, 0, true, true)
		cam.Start2D()
			self.canvas:PaintManual()

			local x, y = self.canvas:LocalToScreen(0, 0)

			render.SetWriteDepthToDestAlpha( false )
				render.OverrideBlend( true, BLEND_SRC_COLOR, BLEND_SRC_ALPHA, 3 )
					surface.SetDrawColor( color_white )
					surface.SetMaterial( grad )
					surface.DrawTexturedRect( x, y, w, 64 )
				render.OverrideBlend( false )
			render.SetWriteDepthToDestAlpha( true )
		cam.End2D()
	render.PopRenderTarget()

	--DisableClipping(true)
		render.SetMaterial(myMat)
		render.DrawScreenQuad()
	--DisableClipping(false)
end
]]

function PANEL:OnMousePressed(code)
	hook.Run("VGUIMousePressed", vgui.GetWorldPanel())
end

function PANEL:AddEntry(data, after)
	local pnl = self.scroll:Add("NotifCenterUI_Line")
	self.massoc[data.id] = pnl
	pnl:Dock(TOP)
	pnl:DockMargin(0, 5, 0, 0)
	pnl:Set(data)

	if after then
		pnl:MoveToAfter(after)
	end

	return pnl
end

function PANEL:MessageCreated(id)
	local ex = self.massoc[id]
	if IsValid(ex) then
		ex:Remove()
		self.massoc[id] = nil
	end

	local data = NotifCenter.messages[id]
	if not data then return end

	local children = self:GetChildren()

	return self:AddEntry(data, children[1])
end

function PANEL:MessageUpdated(id)
	local data = NotifCenter.messages[id]
	if not data then return end

	local ex = self.massoc[id]
	if IsValid(ex) then
		ex:Set(data)
	end
end

function PANEL:MessageRemoved(id)
	local ex = self.massoc[id]
	if IsValid(ex) then
		ex:Remove()
		self.massoc[id] = nil
	end
end

function PANEL:OnRemove()
	hook.Remove("NotifCenter_MsgCreated", self.uid)
	hook.Remove("NotifCenter_MsgUpdated", self.uid)
	hook.Remove("NotifCenter_MsgRemoved", self.uid)
	timer.Remove("SpawnedNotifCenter" .. self.uid)
end

derma.DefineControl("NotifCenterUI", "", PANEL, "Panel")

--
-- NotifCenterUI_Line
--

local PANEL = {}

function PANEL:Init()
	self:DockPadding(SmallMargin, SmallMargin, SmallMargin, SmallMargin)

	self.icondock = self:Add("Panel")
	self.icondock:Dock(LEFT)
	self.icondock:DockMargin(0, 0, SmallMargin, 0)
	self.icon = self.icondock:Add("DImage")

	self.lbl = self:Add("DLabel")
	self.lbl:Dock(FILL)
	self.lbl:SetFont("DermaNotDefault")
	self.lbl:SizeToContents()
	self.lbl:SetColor(color_white)

	--self.lbl:SetWrap(true)

	local tall = self.lbl:GetTall()

	self:SetTall(tall + SmallMargin * 2)
	self.icon:SetSize(tall, tall)
	self.icondock:SetSize(tall, tall)

	self.btndock = self:Add("Panel")
	self.btndock:Dock(RIGHT)
	self.btn = self.btndock:Add("NxButton")
	self.btn:SetSize(tall, tall)
	self.btndock:SetSize(tall, tall)
	self.btndock:DockMargin(SmallMargin, 0, 0, 0)
	self.btn:SetText("✖")

	self.btn.color = Color(0xD3, 0x2F, 0x2F)
	self.btn.color_hover = Color(0xF4, 0x43, 0x36)
	self.btn.color_down = Color(0xB7, 0x1C, 0x1C)

	self.btn.DoClick = function()
		NotifCenter.Close(self.id)
	end

	self:InvalidateLayout(true)
end

function PANEL:Set(data)
	self.id = data.id

	local text = ""

	if data.format == 0 then
		text = data.content
	else
		local json = util.JSONToTable(data.content)

		if data.format == 1 then
			text = Translate(json[1]):format(select(2, unpack(json)))
		elseif data.format == 2 then
			text = json[nxlocale.getLanguage()] or json.en or table.Random(json)
		end
	end


	self.lbl:SetText(surface.textWrap(text, "DermaNotDefault", self:GetParent():GetWide() - SmallMargin * 4 - self.icon:GetWide() - self.btn:GetWide() - yscale(10) - SmallMargin))
	self.lbl:SizeToContents()
	self:SetTall(self.lbl:GetTall() + SmallMargin * 2)
	self:InvalidateLayout(true)
	self.btn:Center()

	--[[
	self.lbl:SetText(data.content)
	self:InvalidateLayout(true)
	]]

	LoadWebIcon(data.type, self.icon:GetTall(), function(success, fn)
		if success then
			self.icon:SetImage("../data/" .. fn)

			if self.icon:GetMaterial():IsError() then
				self.icon:SetImage("icon16/asterisk_yellow.png")
			end
		else
			self.icon:SetImage("icon16/asterisk_yellow.png")
		end
	end)
end

--[[
function PANEL:Think()
	self.lbl:SizeToContentsY()
	self:SetTall(self.lbl:GetTall() + SmallMargin * 2)
	self.btn:Center()
end
]]

local bgColor = Color(32, 38, 48, 240)

function PANEL:Paint(w, h)
	draw.RoundedBox(4, 0, 0, w, h, bgColor)
end

derma.DefineControl("NotifCenterUI_Line", "", PANEL, "EditablePanel")

--
-- panel spawn
--

WaitRun("wChatLoaded", "NotifCenterUI", function()
	if IsValid(SpawnedNotifCenter) then
		SpawnedNotifCenter.Think = function() end
		SpawnedNotifCenter:Remove()
		SpawnedNotifCenter = nil
	end

	SpawnedNotifCenter = vgui.Create("NotifCenterUI")
end)