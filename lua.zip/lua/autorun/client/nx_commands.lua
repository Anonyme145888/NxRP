nx_forceupdate = function()
	RunConsoleCommand("record", "__delete_me")
	RunConsoleCommand("stop")
end

concommand.Add("nx_forceupdate", nx_forceupdate)


local cl_drawhud = GetConVar("cl_drawhud")

hook.Add("HUDShouldDraw", "nx_hidehud", function(name)
	if not cl_drawhud:GetBool() then
		return false
	end

	if name == "CMapOverview" and not (LocalPlayer():IsValid() and LocalPlayer():IsSuperAdmin()) then
		return false
	end
end)

cvars.AddChangeCallback("cl_drawhud", function(_, old, new)
	hook.Run("cl_drawhud", cl_drawhud:GetBool())
end, "nx_hidehud")

concommand.Add("corner", function(pl)
	if not pl.ohhmycorner then
		pl.ohhmycorner = Vector()
	end
	local corner = pl.ohhmycorner

	local trace = pl:GetEyeTrace()

	local component
	local max = 0
	for n = 1, 3 do
		local v = math.abs(trace.HitNormal[n])
		if v >= max then
			component = n
			max = v
		end
	end
	if not component then return end

	corner[component] = trace.HitPos[component]

	pl:ChatPrint(tostring(corner))
end)
