local orig_drawmodel = GetConVarNumber("r_drawmodeldecals")

RunConsoleCommand("r_drawmodeldecals", 0)

hook.Add("ShutDown", "drawmps", function()
	RunConsoleCommand("r_drawmodeldecals", orig_drawmodel)
end)

--[[
gamemodes/darkrp/gamemode/libraries/parse_model.lua
--]]
-- simple model utils



-- Valve model format reference used:

-- https://developer.valvesoftware.com/wiki/MDL

-- note: header actually has 1 more int value followed by version



-- Various offsets and sizes

local mdl_texture_head_offset = 204

local mdl_texturedir_head_offset = 212

local mdl_name_offset = 12

local mdl_mstudiotexture_size = 64



-- reads null terminated string from file

local function read_nullterm( f, limit )

	limit = limit or 256

	local s = ""

	local char = ""

	local n = 0

	repeat

		n = n + 1

		s = s..char

		char = f:Read(1)

	until char=="\0" or n>limit

	return s

end



-- Reads model material from file ( skins are not supported YET )

-- model: string    model filename

-- num: number      material id

-- returns: string  material name

function util.GetModelMaterial( model, num )

	num = num or 0

	local f = file.Open( model, "rb", "GAME" )

	if not f then

		print("Warning! Can't open "..model.." for reading.")

		return ""

	end



	local magick = f:Read(4)

	if( magick ~= "IDST" ) then

		f:Close()

		print("Warning! Does'nt seems like "..model.." is an MDL.")

		return "" 

	end



	f:Seek( mdl_texture_head_offset ) 



	local count = f:ReadLong()

	local offset = f:ReadLong()

	

	if( num > (count-1) or num <0 ) then return "" end



	local struct_offset = offset + (num) * mdl_mstudiotexture_size



	f:Seek( struct_offset )

	

	local stroffset = f:ReadLong();

	f:Seek( struct_offset + stroffset )



	local material = read_nullterm( f )



	-- TODO: This script assumes that the is only one base directory

	f:Seek( mdl_texturedir_head_offset )

	

	local count = f:ReadLong()

	local offset = f:ReadLong()



	f:Seek( offset )

	local stroffset = f:ReadLong();



	f:Seek( stroffset );



	local base = read_nullterm( f );

	

	f:Close()

	return string.Replace(base..material,"\\","/")

end

