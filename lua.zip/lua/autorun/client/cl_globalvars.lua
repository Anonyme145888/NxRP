local types = {"Angle", "Bool", "Entity", "Float", "Int", "String", "Var", "Vector"}
local defaults = {
	Angle = function() return Angle() end,
	Bool = function() return false end,
	Entity = function() return NULL end,
	Float = function() return 0 end,
	Int = function() return 0 end,
	String = function() return "" end,
	Vector = function() return Vector() end,
}
local readers = {
	[0] = util.noop,
	[3] = net.ReadString,
	[2] = net.ReadDouble,
	[1] = net.ReadBool,
	[4] = net.ReadEntity,
	[5] = net.ReadVector,
	[6] = net.ReadAngle,
}

globalvars = globalvars or {}
local globalvars = globalvars

for t in ivalues(types) do
	local default = defaults[t] or util.noop
	_G["GetGlobal" .. t] = function(name, fallback)
		local val = globalvars[name]
		if val ~= nil then
			return val
		elseif fallback ~= nil then
			return fallback
		else
			return default()
		end
	end
	_G["SetGlobal" .. t] = util.noop
end

net.Receive("globalvars", function()
	while net.ReadBool() do
		globalvars[net.ReadString()] = readers[net.ReadUInt(3)]()
	end
end)
