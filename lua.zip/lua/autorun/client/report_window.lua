local PANEL = {}

local savedText = ""

function PANEL:Init()
	self:MakePopup()
	self:SetSize(yscale(600), yscale(500))
	self:Center()

	self.sheet.OnActiveTabChanged = function(s, old, new)
		self.send:SetVisible(new:GetText() == "ReportScreen" or new:GetText() == "ReportCheaterScreen")
	end

	local main = self:NewSheet("MainScreen", "NxEditablePanel")
	main:AddTitle(Translate("report.title"))

	local thanksPanel = self:NewSheet("Thanks", "EditablePanel")
	local thanks = thanksPanel:Add("DLabel")
	thanks:Dock(TOP)
	thanks:SetText("✔ " .. Translate("report.thanks"))
	thanks:SetFont("DermaNotLarge")
	thanks:SizeToContents()
	thanks:SetColor(Color(0, 255, 0))

	self.reports = self:NewSheet("ReportScreen", "ReportScreen")
	self.reports.parent = self

	self.cheaters = self:NewSheet("ReportCheaterScreen", "ReportCheaterScreen")
	self.cheaters.parent = self

	local b1 = main:Add("NxButton")
	b1:Dock(LEFT)
	b1:SetText(Translate("report.title_usual"))
	b1:DockMargin(0, 0, MediumMargin, 0)
	b1.DoClick = function()
		self.sheet:SwitchToName("ReportScreen")
		self.reports.entry:RequestFocus()
	end

	local b2 = main:Add("NxButton")
	b2:Dock(LEFT)
	b2:SetText(Translate("report.title_cheater"))
	b2.DoClick = function()
		self.sheet:SwitchToName("ReportCheaterScreen")
		self.reports.entry:RequestFocus()
	end

	b1:SetWide(math.floor((yscale(600) - LargeMargin*2 - MediumMargin)/2))
	b2:SetWide(b1:GetWide())

	local send = self.backButtonDocking:Add("NxButton")
	self.send = send
	send:Dock(LEFT)
	send:SetText(Translate("report.send_button"))
	send:AutoSize()
	send:SetPrimaryMainColors()

	send.DoClick = function()
		local pnl = self.sheet:GetActiveTab():GetPanel()
		if pnl.Send then
			pnl:Send()
		end
	end

	send:SetVisible(false)

	if savedText ~= "" then
		b1:DoClick()
	end
end

local ignoring = {MainScreen = true, Thanks = true}
function PANEL:OnBackPress()
	if IsValid(self.sheet:GetActiveTab()) and not ignoring[self.sheet:GetActiveTab():GetText()] and savedText == "" then
		return self.sheet:SwitchToName("MainScreen") -- found?
	end
end

function PANEL:Done()
	self.sheet:SwitchToName("Thanks")

	timer.Simple(1, function()
		if IsValid(self) then self:Remove() end
	end)
end

derma.DefineControl("ReportPanel", "", PANEL, "NxGenericFramePaged")

local PANEL = {}

function PANEL:Init()
	self:AddTitle(Translate("report.title_usual"))

	local lbl_warn = self:Add("DLabel")
	lbl_warn:SetFont("DermaNotDefault")
	lbl_warn:Dock(TOP)
	lbl_warn:SetText(Translate("report.notice"))
	lbl_warn:SizeToContents()
	lbl_warn:SetWrap(true)
	lbl_warn:SetAutoStretchVertical(true)
	lbl_warn:DockMargin(0, 0, 0, LargeMargin)

	local lbl = self:Add("DLabel")
	lbl:SetFont("DermaNotDefault")
	lbl:Dock(TOP)
	lbl:SetText(Translate("report.entry_label"))
	lbl:SizeToContents()
	lbl:DockMargin(0, 0, 0, MediumMargin)

	local entry = self:Add("DTextEntry")
	entry:Dock(FILL)
	entry:SetMultiline(true)
	entry:SetFont("DermaNotLarge")
	entry.Paint = nxui_DTextEntry_Paint
	entry:SetDrawLanguageID(false)
	self.entry = entry

	local lbl2 = self:Add("DLabel")
	lbl2:SetFont("DermaNotDefault")
	lbl2:Dock(BOTTOM)
	lbl2:SetText(Translate("report.saved_text"))
	lbl2:SizeToContents()
	lbl2:DockMargin(0, MediumMargin, 0, 0)

	entry.OnKeyCodeTyped = function(s, code)
		if code == KEY_ENTER then
			return true
		end
	end

	entry:SetValue(savedText)
	entry:SetCaretPos(ray.Len(savedText))
	entry:SetUpdateOnType(true)
	entry.OnValueChange = function(s, val)
		savedText = val
	end
end

function PANEL:Send()
	local text = string.Trim(utf8.force(self.entry:GetValue()))

	if text == "" then
		Derma_Message(Translate("report.too_short"))
		return
	end

	savedText = ""

	chat.AddText(Color(200, 200, 200), "[F7] ", text)

	net.Start("Report")
		net.WriteString(text)
	net.SendToServer()

	self.parent:Done()
end

derma.DefineControl("ReportScreen", "", PANEL, "NxEditablePanel")

local PANEL = {}

function PANEL:Init()
	self:AddTitle(Translate("report.title_cheater"))

	local lbl = self:Add("DLabel")
	lbl:SetFont("DermaNotDefault")
	lbl:SetText(Translate("report.cheater_entry"))
	lbl:Dock(TOP)
	lbl:DockMargin(0, 0, 0, MediumMargin)

	local playerList = self:Add("DComboBox")
	self.playerList = playerList
	playerList:SetFont("DermaNotDefault")
	playerList:SetTall(yscale(32))
	playerList:Dock(TOP)
	playerList:SetTextColor(color_black)
	playerList:DockMargin(0, 0, 0, LargeMargin)

	for k, v in ipairs(player.GetAll()) do
		if v ~= LocalPlayer() then
			playerList:AddChoice(("%s (%d)"):format(v:Name(), v:AccountID() or 0), v:AccountID() or 0, false)
		end
	end

	local lbl2 = self:Add("DLabel")
	lbl2:SetFont("DermaNotDefault")
	lbl2:SetText(Translate("report.cheater_desc"))
	lbl2:SizeToContents()
	lbl2:SetWrap(true)
	lbl2:SetAutoStretchVertical(true)
	lbl2:Dock(TOP)
end

function PANEL:Send()
	local aid = select(2, self.playerList:GetSelected())
	if not aid then
		surface.PlaySound("player/suit_denydevice.wav")
		return
	end

	net.Start("ReportCheater")
		net.WriteUInt(aid, 32)
	net.SendToServer()

	self.parent:Done()
end

derma.DefineControl("ReportCheaterScreen", "", PANEL, "NxEditablePanel")
