--[[
lua/autorun/wchat_channels.lua
--]]
chat = chat or {}

chat.TypesHash = {}
chat.TypesOrder = {}

function chat.addType(name, fn)
	if not chat.TypesHash[name] then
		table.insert(chat.TypesOrder, name)
	end

	chat.TypesHash[name] = fn
end

timer.Simple(0, function()
	if not DarkRP then
		chat.addType("team", function() end)
		chat.addType("all", function() end)
		chat.DefaultTab = "all"
		chat.DefaultTabTeam = "team"
	end
end)