if SERVER then
	AddCSLuaFile()
	include("skynetshop/sv_init.lua")
end

if CLIENT then
	include "skynetshop/cl_init.lua"
end

PS:Initialize()