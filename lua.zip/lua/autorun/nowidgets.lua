function widgets.PlayerTick() end
function widgets.RenderMe() end
hook.Remove("PostDrawEffects", "RenderWidgets")
hook.Remove("PlayerTick", "TickWidgets")

hook.Add("Initialize", "nowidgets", function()
	if server.gm.sandbox then return end

	if not properties then return end

	if SERVER then
		net.Receivers.properties = nil
	end
	if CLIENT then
		hook.Remove("PreDrawHalos", "PropertiesHover")
		hook.Remove("GUIMousePressed", "PropertiesClick")
		hook.Remove("PreventScreenClicks", "PropertiesPreventClicks")
	end
end)
