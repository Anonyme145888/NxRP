--[[
lua/postinit/nxserv_sh.lua
--]]
nxserv = {}

nxserv.geoip_whitelist = {
	ru = {"Azerbaijan", "Belarus", "Estonia", "Israel", "Kazakhstan", "Latvia", "Lithuania", "Russia", "Russian Federation", "Ukraine"},
	us = {"Canada", "United States"},
	fr = {"Belgium", "Canada", "France", "Mauritius", "Morocco", "Reunion", "Senegal", "Switzerland"},
}

file.CreateDir("nxserv")

TimerZeroSimple = TimerZeroSimple or timer.Simple
function timer.Simple(delay, func)
	delay = math.max(delay, 0.001)
	return TimerZeroSimple(delay, func)
end
