--[[
lua/postinit/region_lang.lua
--]]
nxserv.region_lang = "fr"

