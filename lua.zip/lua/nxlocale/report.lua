--[[
lua/nxlocale/report.lua
--]]
return {
	en = {
		title = "Report a problem",
		entry_label = "Specify your problem:",
		send_button = "Send",
		thanks = "Thank you!",
		too_short = "Message is too short",
		saved_text = "Text will be saved if you close this window.",
		ticket_working = "Moderation is solving your problem now.",
		ticket_closed = "The moderator has marked your problem as resolved.",
		notice = [[To successfully solve the problem we ask you to consider a few points:

If you have a question, please enter it's subject here.
If you have a complaint, please specify at least the offender and the violation.
Messages like "tp i need to ask" without specifying the subject matter will be ignored.]],
		title_usual = "Questions and complaints",
		title_cheater = "Report a cheater",
		cheater_entry = "Specify the player who you think uses cheats:",
		cheater_desc = "Administration will check this player for using forbidden software and ban if we detect cheats.",
	},

	ru = {
		title = "Сообщить о проблеме",
		entry_label = "Опишите свою проблему:",
		send_button = "Отправить",
		thanks = "Спасибо!",
		too_short = "Сообщение слишком короткое",
		saved_text = "При закрытии окна текст будет сохранён.",
		ticket_working = "Модерация занимается вашей проблемой.",
		ticket_closed = "Модератор отметил вашу проблему как решённую.",
		notice = [[Для успешного рассмотрения проблемы просим учесть несколько моментов:

Если у вас вопрос, сразу укажите его тему здесь.
Если у вас жалоба, сразу укажите как минимум нарушителя и нарушение.
Заявки по типу "тп мне нужно обсудить" без указания предмета вопроса будут игнорироваться.]],
		title_usual = "Вопросы и жалобы",
		title_cheater = "Сообщить о читере",
		cheater_entry = "Укажите игрока, который по вашему мнению использует читы:",
		cheater_desc = "Администрация по возможности проверит игрока на использование запрещённых программ и забанит при обнаружении читов.",
	},

	fr = {
		title = "Signaler un problème",
		entry_label = "Précisez votre problème (+ nom du joueur) :",
		send_button = "Envoyer",
		thanks = "Merci !",
		too_short = "La description est trop courte",
		saved_text = "Le texte sera sauvegardé si vous fermez cette fenêtre.",
		ticket_working = "La modération résout votre problème maintenant.",
		ticket_closed = "Le modérateur a marqué votre problème comme résolu.",
		notice = [[Pour réussir à résoudre le problème, nous vous demandons de considérer quelques points :

Si vous avez une question, s'il vous plaît entrer son sujet ici.
Si vous avez une plainte, veuillez préciser au moins le contrevenant et la violation.
Des messages comme "une question tp svp", sans préciser l'objet sera ignoré.]],
		title_usual = "Questions et plaintes",
		title_cheater = "Rapport d'un tricheur",
		cheater_entry = "Spécifiez le joueur qui, selon vous, utilise des tricheurs :",
		cheater_desc = "L'Administration va vérifier ce joueur pour l'utilisation de logiciels interdits et bannir si nous détectons des tricheurs.",
	},
}


