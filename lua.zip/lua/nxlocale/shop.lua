return {
	en = {
		account = "Account: %s%d",
		subscriptions = "Subscriptions & Specials",
		weapons = "Weapons",
		cars = "Cars",
		hats = "Appearance",
		bought = "Purchased",
		buying_period = "Valid for %s",
		expires_in = "Expires in ",
		expired = "Expired!",
		discount = "%s, %d%% OFF!",
		open_in_browser = "To get required information, copy this link and open it in your favorite browser",
		copy_link = "Copy link",
		nofunds_ask = "Your account doesn't have enough funds to buy this item.\nWould you like to top up your balance?",
		nofunds = "Insufficient funds",
		yes = "Yes",
		no = "No",
		sending_request = "Sending request...",
		item_bought = "Success: Item Purchased",
		error = "Error",
		button_topup = "How to top up?",
		button_topup_act = "Add money to your balance",
		scroll = "Scroll with mouse wheel",
		already_bought = "You already own this item",
		few_seconds = "few seconds",
		seconds = " seconds",
		minutes = " minutes",
		hours = " hours",
		days = " days",
		you_bought = "You bought %s",
		you_already_own = "You already own this item!",
		x_already_owns = "%s already owns this item!",
		no_item = "There's an error in processing your request.",
		thanks = "Your funds have been added to your account, cheers!",
		buy_for = "Buy for ",
		renew_for = "Renew for ",
		premium_cars = "Premium Cars",
		premium_cars_desc = "Exclusive automobiles from Porsche and Mercedes. Emphasize your high status.\nBought only with real money.\nCar is permanently added to your vehicle list.",
		regular_cars = "Regular cars",
		regular_cars_desc = "Automobiles which are available to all. Bought with in-game currency.",
		slots = "Slots:",
		store = "Store:",
		ui_back = "< Back",
		equip = "Wear",
		unequip = "Remove",
		game_money = "In-Game Money: ",
		darkrp_premium_desc = [["Premium" package allows you to gain additional advantages in the game on our DarkRP servers.
With "Premium" you gain money quickier and survive better in the city full of criminality.

Character:
* Respawn time shortens to 10 seconds
* Hunger rate is 4 times slower
* Premium icon in scoreboard makes you more noticeable

Cars:
* Cars consume 50% less fuel
* 10% off when buying cars
* Car renting becomes available
* Cosmetic tuning becomes available (spoilers, bumpers, skirts, hoods and etc)

Gameplay:
* You can initiate demote votes
* Job limits aren't applied to you, you can get any job at any time
* When starting (as Mayor) a lottery you get 2.5% from lottery pool
* Money Printers and Fishing give 50% more income]],
		moneypack_desc = "Only for DarkRP. Number of purchases is unlimited.",
		moneypack_title = "In-Game Currency %s",
		premium_car_desc = [[Exclusive Premium-class vehicle, permanently added to your vehicle list.]],
		car_seats = "Passenger seats: %d",
		car_hardness = "Body strength: %d",
		car_fuel_cons = "Fuel consumption: %d",
		car_maxspeed = "Max speed: %d km/h",
		car_horsepower = "Horsepower: %d",
		car_trunk_cap = "Trunk capacity: %d",
		rent = "Rent...",
		rent_x = "Rent ",
		rent_desc = "First fee: 10,000 kr.\nThen rent payment occurs every game evening in amount of %s.\nIf you are unable to pay rent, it will be cancelled.\nIf in the event of forced cancellation your car is destroyed,\nthen you will be blocked from rent for 1 game day and then you will have to pay a 3,000 kr fine.\nSpendings on car modification are not refunded.",
		fine = "Fine",
		fine_desc = "You need to pay a 3,000 kr fine for destroying your rented car,\nbefore using rent again.\nPay now?",
		free = "FREE",

		slot_names = {
			face2 = "Face",
			eyes = "Eyes",
			torso = "Body",
			legs = "Legs",
			fullbody = "Suit",
			hat = "Hat",
			glasses = "Glasses",
			face = "Headbands/masks",
			mouth = "Mouth",
			neck = "Neck",
			back = "Back",
			tail = "Tail",
		},

		purchase_already_process = "You already have purchase in process.\nPlease wait before trying to make another purchase.\nIf this problem persists, please contact administration.",
		price_increase = "Price will increase!",
		price_increase_desc = "Price for this item will be increased %s. Have time to buy at the old price!\n",
	
		gift_btn = "Make a gift...",
		gift_confirm = "You're sending a gift with %s to %s.\nYou will be charged %s for this.\n\nIs everything correct?",
		gift_incoming = "Wow! %s has sent you a gift with %s!",
		gift_sent = "You've sent a gift with %s to %s!",
		player_disconnected = "Player you selected has left the game!",
	},

	ru = {
		account = "На счету: %d %s",
		subscriptions = "Подписки и Спецпредложения",
		weapons = "Оружие",
		cars = "Машины",
		hats = "Одежда",
		bought = "Приобретено",
		buying_period = "Приобретается на %s",
		expires_in = "Истекает через ",
		expired = "Действие заканчивается",
		discount = "%s, Скидка %d%%!",
		open_in_browser = "Для получения инструкции по пополнению счёта, скопируйте эту ссылку и откройте её в вашем браузере.\nЧтобы свернуть окно с игрой, нажмите Win (флажок) и D одновременно.",
		copy_link = "Скопировать ссылку",
		nofunds_ask = "На вашем счету недостаточно средств для приобретения данного предмета.\nЖелаете пополнить баланс?",
		nofunds = "Недостаточно средств",
		yes = "Да",
		no = "Нет",
		sending_request = "Передача данных...",
		item_bought = "Предмет куплен",
		error = "Ошибка",
		button_topup = "Как пополнить?",
		button_topup_act = "Пополнить счёт",
		scroll = "Прокрутка колёсиком мыши",
		already_bought = "Предмет уже куплен",
		few_seconds = "пару секунд",
		seconds = " с",
		minutes = " мин",
		hours = " ч",
		days = " дн",
		you_bought = "Вы приобрели %s",
		you_already_own = "У вас уже имеется данный предмет!",
		x_already_owns = "%s уже имеет этот предмет!",
		no_item = "Ошибка при поиске предмета.",
		thanks = "Ваши средства поступили на счёт, счастливых покупок!",
		buy_for = "Купить за ",
		renew_for = "Продлить за ",
		premium_cars = "Премиум машины",
		premium_cars_desc = "Эксклюзивные автомобили от Porsche и Mercedes. Подчеркните ваш высший статус.\nПриобретается только за реальные деньги.\nАвтомобиль добавляется в список машин навсегда.",
		regular_cars = "Обычные машины",
		regular_cars_desc = "Автомобили, доступные всем. Приобретаются за внутриигровую валюту.",
		slots = "Слоты:",
		store = "Магазин:",
		ui_back = "< Назад",
		equip = "Надеть",
		unequip = "Снять",
		game_money = "Игровые деньги: ",
		darkrp_premium_desc = [[Пакет "Премиум" даст вам дополнительные преимущества в игре на нашем SCPRP сервере.
С "Премиум" вы зарабатываете быстрее и выживаете чаще.

Персонаж:
* Время ожидания возрождения сокращается до 15 секунд
* Голод накапливается в 4 раза медленнее
* Премиум иконка в скорборде заметно выделяет вас среди остальных
* Появляется доступ к красивым изменяемым моделям на профессиях Глава учёных (Кляйнер), Руководитель фонда (Брин), Агент фонда (Барни), Зам РК (Магнусон)+

Геймплей:
* Дается возможность использовать голосования на увольнение
* Принтеры дают на 50% больше прибыли
* Открывается доступ к профессиям: Класс D Вор | Убийца, Агент Фонда, Глава Ученых]],
		moneypack_desc = "Только для DarkRP. Количество приобретений неограниченно.",
		moneypack_title = "Игровая валюта %s",
		premium_car_desc = [[Эксклюзивный автомобиль Премиум-класса, добавляемый в список купленных машин навсегда.]],
		car_seats = "Мест для пассажиров: %d",
		car_hardness = "Прочность кузова: %d",
		car_fuel_cons = "Потребление топлива: %d",
		car_maxspeed = "Максимальная скорость: %d km/h",
		car_horsepower = "Лошадиных сил: %d",
		car_trunk_cap = "Вместимость багажника: %d",
		rent = "Арендовать...",
		rent_x = "Аренда ",
		rent_desc = "Первоначальная комиссия: 10,000 kr.\nЗатем следует списание каждый игровой вечер в размере %s.\nЕсли вы будете неспособны оплатить аренду, то она прекращается.\nЕсли при принудительном прекращении аренды машина будет разрушена,\nто вам будет запрещена аренда на 1 игровой день и вы будете вынуждены заплатить штраф 3,000 kr.\nЗатраты на модификацию машины не возвращаются.",
		fine = "Штраф",
		fine_desc = "Необходимо заплатить штраф за повреждение арендованной машины в размере 3,000 kr,\nпрежде чем снова пользоваться арендой.\nЗаплатить сейчас?",
		free = "БЕСПЛАТНО",

		slot_names = {
			face2 = "Лицо",
			eyes = "Глаза",
			torso = "Тело",
			legs = "Ноги",
			fullbody = "Костюмы",
			hat = "Шляпа",
			glasses = "Очки",
			face = "Повязки/маски",
			mouth = "Губы",
			neck = "Шея",
			back = "Спина",
			tail = "Хвост",

			crowbar = "Монтировка",
			magnetostick = "Магнитопалка",
		},

		purchase_already_process = "Ваша предыдущая покупка всё ещё обрабатывается.\nПожалуйста, подождите перед тем как совершить другую покупку.\nЕсли проблема не уходит, свяжитесь с администрацией.",
		price_increase = "Цена повысится!",
		price_increase_desc = "Цена на товар повысится %s. Успейте купить по старой цене!\n",
	
		gift_btn = "Сделать подарок...",
		gift_confirm = "Вы собираетесь отправить %s в подарок %s.\nС вашего счёта будет списано %s.\n\nВсё верно?",
		gift_incoming = "Ого! %s отправил вам подарок с %s!",
		gift_sent = "Вы отправили %s подарком %s!",
		player_disconnected = "Выбранный игрок вышел из игры!",
	},

	fr = {
		account = "Solde : %s%d",
		subscriptions = "Abonnements & Offres Spéciales",
		weapons = "Armes",
		cars = "Véhicules",
		hats = "Apparence",
		bought = "Acheté",
		buying_period = "Disponible pour %s",
		expires_in = "Expire dans ",
		expired = "Expiré !",
		discount = "%s, %d%% de réduction !",
		open_in_browser = "Pour obtenir les informations requises, copiez ce lien et collez le dans votre navigateur préféré",
		copy_link = "Copier le lien",
		nofunds_ask = "Votre compte ne dispose pas de suffisamment de fonds pour acheter ce produit.\nSouhaitez recharger votre solde ?",
		nofunds = "Fonds insuffisants",
		yes = "Oui",
		no = "Non",
		sending_request = "Envoi de la demande...",
		item_bought = "Succès !",
		error = "Erreur",
		button_topup = "Comment recharger ?",
		button_topup_act = "Compléter votre solde",
		scroll = "Molette de la souris – faire défiler",
		already_bought = "Vous possédez déjà cet élément",
		few_seconds = "quelques secondes",
		seconds = " secondes",
		minutes = " minutes",
		hours = " heures",
		days = " jours",
		you_bought = "Vous avez acheté %s",
		you_already_own = "Vous possédez déjà cet élément !",
		x_already_owns = "%s possède déjà cet élément !",
		no_item = "Il y a eu une erreur dans le traitement de votre demande.",
		thanks = "Les fonds ont été ajoutés à votre solde avec succès, merci !",
		buy_for = "Acheter pour ",
		renew_for = "Renouvelez pour ",
		premium_cars = "Véhicules Premium",
		premium_cars_desc = "Automobiles exclusives de Porsche à Mercedes. Mettez l'accent sur votre statut élevé.\nAchetables uniquement avec de l'argent réel.\nLes véhicules sont ajoutés à votre garage de façon permanente.",
		regular_cars = "Véhicules ordinaires",
		regular_cars_desc = "Automobiles qui sont disponibles pour tout le monde. Achetables avec la monnaie du jeu.",
		slots = "Emplacements :",
		store = "Magasin :",
		ui_back = "< Retour",
		equip = "Mettre",
		unequip = "Enlever",
		game_money = "Monnaie du jeu : ",
		darkrp_premium_desc = [[Le "Premium" vous donne des avantages supplémentaires dans le jeu sur nos serveurs DarkRP.
Avec le "Premium", vous gagnez de l'argent plus rapidement et vous survivez mieux dans cette ville pleine de criminalité.

Personnage :
* Le temps de respawn réduit à 10 secondes
* La barre de faim descend 4 fois moins vite
* L'icône Premium dans le TAB vous rend plus perceptible

Véhicules :
* Les véhicules consomment 50% de carburant en moins
* 10% de rabais lors de l'achat de véhicules
* La location de véhicules est désormais disponible
* Le tuning sur les véhicules est désormais disponible (spoilers, pare-chocs, jupes, hottes, etc.)

Gameplay :
* Vous pouvez lancer des votes de licenciement
* La limite de métiers n'est pas appliquée à vous, vous pouvez jouer n'importe quel métier à n'importe quel moment
* En tant que maire, lors du démarrage d'une loterie, vous recevez 2.5% des gains
* Les imprimantes à argent et la pêche donnent 50% de revenus en plus]],
		moneypack_desc = "Seulement pour le DarkRP. Le nombre d'achat est illimité.",
		moneypack_title = "%s Monnaie Du Jeu",
		premium_car_desc = [[Catégorie exclusive de véhicules Premium, ajoutés de façon permanente à votre liste de véhicules.]],
		car_seats = "Sièges passagers : %d",
		car_hardness = "Résistance du véhicule : %d",
		car_fuel_cons = "Consommation d'essence : %d",
		car_maxspeed = "Vitesse de pointe : %d km/h",
		car_horsepower = "Puissance en chevaux : %d",
		car_trunk_cap = "Capacité du coffre : %d",
		rent = "Louer...",
		rent_x = "Louer ",
		rent_desc = "Premier frais : 10,000 kr.\nEnsuite, le paiement est effectué chaque soir en jeu d'un montant de %s.\nSi vous ne pouvez pas payer, la location sera annulée. Si vous ne pouvez pas payer la location, elle sera annulée.\nEn cas d'annulation de location forcée, le véhicule est détruit,\nensuite vous serez banni de la location pendant 1 jour en jeu et vous devrez payer une amende de 3,000 kr.\nLes investissements dans les modifications de véhicules ne sont pas remboursés.",
		fine = "Amende",
		fine_desc = "Vous devez payer une amende de 3,000 kr pour détruire le véhicule loué,\navant d'utiliser la location de nouveau.\nPayer maintenant ?",
		free = "GRATUIT",

		slot_names = {
			face2 = "Visage",
			eyes = "Yeux",
			torso = "Corps",
			legs = "Jambes",
			fullbody = "Costume",
			hat = "Chapeau",
			glasses = "Lunettes",
			face = "Bandeaux/masques",
			mouth = "Bouche",
			neck = "Cou",
			back = "Dos",
			tail = "Queue",
		},

		purchase_already_process = "You already have purchase in process.\nPlease wait before trying to make another purchase.\nIf this problem persists, please contact administration.",
		price_increase = "Le prix va augmenter!",
		price_increase_desc = "Le prix des marchandises augmentera %s. Avoir le temps d'acheter à l'ancien prix!\n",
	
		gift_btn = "Faire un cadeau...",
		gift_confirm = "Vous envoyez un cadeau avec %s à %s.\nVous serez facturé %s pour cela.\n\nTout est-il correct ?",
		gift_incoming = "Hou la la ! %s vous a envoyé un cadeau avec %s !",
		gift_sent = "Vous avez envoyé un cadeau avec %s à %s !",
		player_disconnected = "Le joueur que vous avez sélectionné a quitté le jeu !",
	},
}