--[[
lua/nxlocale/misc.lua
--]]
return {
	en = {
		dupe_elevator = "Contraption containing an elevator can only be placed with the \"Paste at original location\" box ticked",
	},

	ru = {
		dupe_elevator = "Постройку, содержащую лифт, пожно поставить только с отмеченной галкой \"Paste at original location\"",
	},

	fr = {
		dupe_elevator = "Contraption containing an elevator can only be placed with the \"Paste at original location\" box ticked",
	},
}


