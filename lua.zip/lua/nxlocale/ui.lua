--[[
lua/nxlocale/ui.lua
--]]
return {
	en = {
		esc_back = "[ESC] Back",
		esc_close = "[ESC] Close",
	},

	ru = {
		esc_back = "[ESC] Назад",
		esc_close = "[ESC] Закрыть",
	},

	fr = {
		esc_back = "[ESC] Retour",
		esc_close = "[ESC] Fermer",
	},
}


