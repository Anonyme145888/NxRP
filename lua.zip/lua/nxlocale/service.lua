--[[
lua/nxlocale/service.lua
--]]
return {
	en = {
		drp_dont_disconnect = "All valuables you have in your inventory or just lying somewhere in the world will be saved and restored if you don't leave the server.",

		nightly = {
			restart_5m = "Scheduled nightly restart will commence in 5 minutes.",
			restart_1m = "Scheduled nightly restart will commence in 1 minute.",
			generic = "Scheduled nightly restart will commence soon.\nYou will be reconnected automatically.",
		},
	},

	ru = {
		drp_dont_disconnect = "Все ценные предметы, находящиеся в вашем инвентаре, либо просто лежащие в мире, будут сохранены и восстановлены после перезапуска, если вы не выйдете с сервера.",

		nightly = {
			restart_5m = "Через 5 минут будет произведён плановый ночной перезапуск серверов.",
			restart_1m = "Через 1 минуту будет произведён плановый ночной перезапуск серверов.",

			generic = "Будет произведён плановый ночной перезапуск серверов.\nВы будете переподключены автоматически.",
		},

		planned = {
			generic = "Будет произведён плановый перезапуск сервера.\nВы будете переподключены автоматически.",
		},

		techjob = {
			generic = "Сервер будет выключен для проведения технического обслуживания.\n\nПосетите наш сайт grserv.site чтобы увидеть когда сервер снова будет доступен.",
		},
	},

	fr = {
		drp_dont_disconnect = "Tous les objets de valeurs que vous avez dans votre inventaire ou qui sont juste quelque part dans le monde seront sauvegardés et restaurés si vous ne quittez pas le serveur.",

		nightly = {
			restart_5m = "Le redémarrage nocturne arrive dans 5 minutes.",
			restart_1m = "Le redémarrage nocturne arrive dans 1 minute.",
			generic = "Le redémarrage nocturne arrive bientôt.\nVous serez reconnecté automatiquement.",
		},
	},
}

