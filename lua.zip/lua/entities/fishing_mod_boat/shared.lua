ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Boat"
ENT.Spawnable = true
ENT.Category = "Fishing Mod"