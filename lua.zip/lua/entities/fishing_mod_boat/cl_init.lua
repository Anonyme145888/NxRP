language.Add("fishing_mod_boat","Fishing Boat")

include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end